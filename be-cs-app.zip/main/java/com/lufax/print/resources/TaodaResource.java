package com.lufax.print.resources;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Date;
import java.util.List;

import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.commons.lang.StringUtils;

import com.google.gson.Gson;
import com.lufax.common.Constant;
import com.lufax.common.resources.gsonTemplate.PaginationGson;
import com.lufax.common.utils.DateUtils;
import com.lufax.jersey.usercontext.UserContextUtils;
import com.lufax.jersey.utils.Logger;
import com.lufax.print.domain.TaodaUserType;
import com.lufax.print.service.TaodaRecordService;
import com.sun.jersey.api.core.InjectParam;

@Path("/taoda")
public class TaodaResource {

	@InjectParam
	private TaodaRecordService taodaRecordService;

	@POST
	@Path("/create-record")
	@Produces(value = MediaType.TEXT_PLAIN)
	public String createRecord(@FormParam("userType") TaodaUserType userType, @FormParam("useFor") List<String> useFor, @FormParam("fileName") String fileName) {
		
		if(userType == null){
			Logger.warn(this, "TaodaResource.createRecord is invoked with null userType param");
			throw new WebApplicationException(Response.status(Response.Status.BAD_REQUEST).entity("请选择角色").build());
		}
		
		if(useFor == null || useFor.size() == 0){
			Logger.warn(this, "TaodaResource.createRecord is invoked with null useFor param");
			throw new WebApplicationException(Response.status(Response.Status.BAD_REQUEST).entity("请选择协议").build());
		}
		
		if(StringUtils.isBlank(fileName)){
			Logger.warn(this, "TaodaResource.createRecord is invoked with null fileName param");
			throw new WebApplicationException(Response.status(Response.Status.BAD_REQUEST).entity("上传的文件名称不存在").build());
		}
		
		String operatorId = UserContextUtils.getCurrentUserContext().getUserId();
		// Mock
//		String operatorId = "1748157";
		
		long recordId = taodaRecordService.insert(userType, useFor, fileName, operatorId);
		
		return String.valueOf(recordId);
	}
	
	@POST
	@Path("/confirm-record")
	public void confirmRecord(@FormParam("recordId") String recordId) {
		
		if(StringUtils.isBlank(recordId)){
			Logger.warn(this, "TaodaResource.confirmRecord is invoked with null recordId param");
			throw new WebApplicationException(Response.status(Response.Status.BAD_REQUEST).entity("套打ID不能为空").build());
		}
		taodaRecordService.confirm(recordId);
	}
	
	@GET
	@Path("/detail")
	@Produces(value = MediaType.APPLICATION_JSON)
	public String queryTaodaRecordDetail(@QueryParam("recordId") String recordId, @QueryParam("pageNum") int pageNum, @QueryParam("pageSize") int pageSize) {
		
		if(StringUtils.isBlank(recordId)){
			Logger.warn(this, "TaodaResource.queryTaodaRecordDetail is invoked with null recordId param");
			throw new WebApplicationException(Response.status(Response.Status.BAD_REQUEST).entity("套打ID不能为空").build());
		}
		
		if(pageNum == 0){
			Logger.warn(this, "TaodaResource.createRecord is invoked with null pageNum param");
			throw new WebApplicationException(Response.status(Response.Status.BAD_REQUEST).entity("页数必须大于0").build());
		}
		
		if(pageSize == 0){
			pageSize = Constant.DEFAULT_PAGE_SIZE;
		}
		
		PaginationGson paginationGson = taodaRecordService.queryForDetails(recordId, pageNum, pageSize);
		
		return new Gson().toJson(paginationGson);
	}
	
	@GET
	@Path("/query")
	@Produces(value = MediaType.APPLICATION_JSON)
	public String queryTaodaRecord(@QueryParam("operatorName") String operatorName, @QueryParam("createdAtDate") String createdAtDate, @QueryParam("pageNum") int pageNum, @QueryParam("pageSize") int pageSize) {
		
		Date createdAt = null;
		
		if(StringUtils.isNotBlank(createdAtDate)){
			createdAt = DateUtils.parse(DateUtils.DATE_FORMAT_DEFAULT, createdAtDate);
		}
		
		if(pageNum == 0){
			Logger.warn(this, "TaodaResource.queryTaodaRecord is invoked with null pageNum param");
			throw new WebApplicationException(Response.status(Response.Status.BAD_REQUEST).entity("页数必须大于0").build());
		}
		
		if(pageSize == 0){
			pageSize = Constant.DEFAULT_PAGE_SIZE;
		}
		
		PaginationGson paginationGson = taodaRecordService.queryForRecord(operatorName, createdAt, pageNum, pageSize);
		
		return new Gson().toJson(paginationGson);
	}
	
	@GET
	@Path("/generate-pdf")
	@Produces(value = MediaType.TEXT_PLAIN)
	public String generatePdf() {
		
		Logger.info(this, "TaodaResource.generatePdf is invoked at " + new Date());
		taodaRecordService.generate();
		Logger.info(this, "TaodaResource.generatePdf is invoked and end at " + new Date());
		return "SUCCESS";
	}
	
	@GET
	@Path("/download")
	@Produces(MediaType.APPLICATION_OCTET_STREAM)
	public Response download(@QueryParam("recordId") long recordId) {
		
		Logger.info(this, "TaodaResource.download is invoked with id " + recordId);

		String absoluteFilePath = taodaRecordService.findAbsoluteZipFilePath(recordId);
		String fileName = absoluteFilePath.substring(absoluteFilePath.lastIndexOf("/") + 1);
		
		File file = new File(absoluteFilePath);
		
        try {
            return Response.ok().entity(new FileInputStream(file)).header("Content-Disposition", String.format("attachment; filename=%s", URLEncoder.encode(fileName, "UTF-8"))).header("Extension", "zip").build();
        } catch (FileNotFoundException e) {
            Logger.error(this, String.format("Contract [%s] is not found.", absoluteFilePath), e);
            throw new WebApplicationException(Response.Status.NOT_FOUND);
        } catch (UnsupportedEncodingException e) {
        	Logger.error(this, String.format("encode filName [%s] failed.", fileName), e);
        	throw new WebApplicationException(Response.Status.INTERNAL_SERVER_ERROR);
		}
	}
}
