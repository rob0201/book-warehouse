package com.lufax.print.service.printer;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.PageSize;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.PdfContentByte;
import com.lowagie.text.pdf.PdfWriter;
import com.lufax.print.service.printer.data.PrintData;

public class GuaranteeContractPrinter extends AbstractContractTaodaPrinter {

    protected String getContractName() {
        return "保证合同";
    }

    protected void generatePdf(File file, PrintData data) throws DocumentException, IOException {

        BaseFont bf = BaseFont.createFont("simsun.ttc,1", BaseFont.IDENTITY_H, BaseFont.NOT_EMBEDDED);
        int fontSize = 12;

        Document document = new Document(PageSize.A4);
        PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(file));
        document.open();
        PdfContentByte contentByte = writer.getDirectContent();


        writePage4(data, contentByte, bf, fontSize);
        document.newPage();
        writePage2(data, contentByte, bf, fontSize);
        document.newPage();
        writePage1(data, contentByte, bf, fontSize);
        document.newPage();
        writePage3(data, contentByte, bf, fontSize);

        document.close();
    }

    private void writePage1(PrintData data, PdfContentByte contentByte, BaseFont bf, int fontSize) {
        write(contentByte, bf, fontSize, data.getGuaranteeContractCode(),370,730);
        write(contentByte, bf, fontSize, data.getInvestorName(),150,700);
        write(contentByte, bf, fontSize, data.getInvestorIdentityNumber(),180,682);
        write(contentByte, bf, fontSize, data.getInvestorAddress(),170,667);
        write(contentByte, bf, fontSize, data.getInvestorPhoneNumber(),170,652);
        write(contentByte, bf, fontSize, data.getLoanerName(),190,542);
        write(contentByte, bf, fontSize, data.getLoanContractCode(),375,542);
    }

    private void writePage2(PrintData data, PdfContentByte contentByte, BaseFont bf, int fontSize) {
        writeNull(contentByte, bf, fontSize);
    }

    private void writePage3(PrintData data, PdfContentByte contentByte, BaseFont bf, int fontSize) {
        write(contentByte, bf, fontSize, data.getGuaranteeContractCode(),168,711);
        write(contentByte, bf, fontSize, data.getInvestorName(),120,662);
    }

    private void writePage4(PrintData data, PdfContentByte contentByte, BaseFont bf, int fontSize) {
        write(contentByte, bf, fontSize, data.getGuaranteeContractCode(),185,712);
    }
}
