package com.lufax.print.service.printer.data;

import org.springframework.stereotype.Service;

import com.lufax.print.domain.TaodaRecord;
import com.lufax.print.domain.TaodaRecordDetail;

@Service("completeContractPrintDataFactory")
public class CompleteContractPrintDataFactory implements PrintDataFactory {

	public PrintData buildPrintData(TaodaRecord record, TaodaRecordDetail recordDetail) {
		
		PrintData data = new PrintData(recordDetail);
		
		return data;
	}

}
