package com.lufax.print.service.printer;

import java.io.File;
import java.io.IOException;

import com.lowagie.text.DocumentException;
import com.lowagie.text.Element;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.PdfContentByte;
import com.lufax.common.utils.StringUtils;
import com.lufax.jersey.utils.Logger;
import com.lufax.print.domain.TaodaRecord;
import com.lufax.print.domain.TaodaRecordDetail;
import com.lufax.print.service.printer.data.PrintData;
import com.lufax.print.service.printer.data.PrintDataFactory;

public abstract class AbstractContractTaodaPrinter implements ContractTaodaPrinter {
	
	private PrintDataFactory printDataFactory;
	
	public void setPrintDataFactory(PrintDataFactory printDataFactory) {
		this.printDataFactory = printDataFactory;
	}

	public void generate(File dir, TaodaRecord record, TaodaRecordDetail recordDetail) {
		String fileName = getContractFileName(recordDetail);
		PrintData data = printDataFactory.buildPrintData(record, recordDetail);
		try {
			generatePdf(new File(dir, fileName), data);
		} catch (DocumentException e) {
			Logger.warn(this, "error occurs when generating taoda contract pdf", e);
		} catch (IOException e) {
			Logger.warn(this, "error occurs when generating taoda contract pdf", e);
		}

	}

	// 借款人姓名_业务产品编号_合同名称_投资人姓名_投资人身份证号.pdf
	public String getContractFileName(TaodaRecordDetail recordDetail) {
		return StringUtils.toString(recordDetail.getLoanerName()) + "_"
				+ StringUtils.toString(recordDetail.getBusinessCode()) + "_" + getContractName()
				+ "_" + StringUtils.toString(recordDetail.getInvestorName()) + "_"
				+ StringUtils.toString(recordDetail.getInvestorIdentityNumber()) + ".pdf";
	}

    protected void write(PdfContentByte contentByte, BaseFont font, int fontSize, String text, int x, int y){
        if(org.apache.commons.lang.StringUtils.isBlank(text)){
            text = "";
        }
        contentByte.beginText();
        contentByte.setFontAndSize(font, fontSize);
        contentByte.setTextMatrix(x, y);
        contentByte.showText(text);
        contentByte.endText();
    }

    protected void write(PdfContentByte contentByte, BaseFont font, int fontSize, String text, int x, int y, float rotation){
        if(org.apache.commons.lang.StringUtils.isBlank(text)){
            text = "";
        }
        contentByte.beginText();
        contentByte.setFontAndSize(font, fontSize);
        contentByte.showTextAligned(Element.ALIGN_CENTER,text, x, y, rotation);
        contentByte.endText();
    }

    protected void writeNull(PdfContentByte contentByte, BaseFont bf, int fontSize) {
        write(contentByte, bf, fontSize, "", 1, 1);
    }

	abstract protected String getContractName();

	abstract protected void generatePdf(File file, PrintData data) throws DocumentException, IOException;

}
