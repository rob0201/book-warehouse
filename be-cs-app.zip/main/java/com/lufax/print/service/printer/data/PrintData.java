package com.lufax.print.service.printer.data;

import com.lufax.print.domain.TaodaRecordDetail;


public class PrintData {
	private String businessCode;
    private String principal;
    private String period;
    private String pledgePrincipal;
    private String loanerName;
    private String loanerIdentityNumber;
    private String loanerRegistName;
    private String loanerAddress;
    private String loanerPhoneNumber;
    private String bankInfo;
    private String bankCardNo;
	private String investorName;
	private String investorIdentityNumber;
    private String investorRegistName;
	private String investorAddress;
	private String investorPhoneNumber;
    private String investorNameAll;
    private String investorIdentityNumberAll;
    private String pledgeUserName;
    private String pledgeUserIdentityType;
    private String pledgeUserIdentityNumber;
    private String pledgeUserAddress;
    private String pledgeUserPhoneNumber;
    private String sharedPersonName;
    private String sharedPersonIdentityNumber;
    private String houseCertCode;
    private String pledgeAddress;
    private String numOfRoom;
    private String houseNumber;
    private String roomNumber;
    private String proportion;
    private String pledgeType;
    private String houseStatus;
    private String otherPerson;
    private String otherPersonPhoneNumber;
    private String otherPersonIdentityNumber;
    private String otherPersonIdType;
    private String pledgeGrantedPersonOne;
    private String pledgeGrantedPersonOneId;
    private String pledgeGrantedPersonTwo;
    private String pledgeGrantedPersonTwoId;
    private String reverseGuarantorName;
    private String reverseGuarantorId;
    private String reverseGuarantorAddress;
    private String reverseGuarantorPhoneNumber;
    private String loanContractCode;
    private String loanContractCodeAll;
    private String guaranteeContractCode;
    private String guaranteeContractCodeAll;
    private String pledgeContractCode;
    private String proxyGuaranteeContractCode;
    private String reverseContractCode;
    private String consultContractCode;
    private String grantPledgeContractCode;
    private String useFor;
    private String interestStartDate;
    private String firstRepaymentDate;
    private String deadLine;
	private String repayDay;
    private String interestRate;
    private String consultRate;
    private String consultAmount;
    private String guaranteeAmount;
    private String oneRepaymentDate;
    private String oneInterestAmount;
    private String onePrincipalAmount;
    private String oneTotalAmount;
    private String twoRepaymentDate;
    private String twoInterestAmount;
    private String twoPrincipalAmount;
    private String twoTotalAmount;
    private String threeRepaymentDate;
    private String threeInterestAmount;
    private String threePrincipalAmount;
    private String threeTotalAmount;
    private String fourRepaymentDate;
    private String fourInterestAmount;
    private String fourPrincipalAmount;
    private String fourTotalAmount;
    private String fiveRepaymentDate;
    private String fiveInterestAmount;
    private String fivePrincipalAmount;
    private String fiveTotalAmount;
    private String sixRepaymentDate;
    private String sixInterestAmount;
    private String sixPrincipalAmount;
    private String sixTotalAmount;

    public PrintData() {
	}

    public PrintData(TaodaRecordDetail recordDetail) {
    	this.businessCode = recordDetail.getBusinessCode();
    	this.principal = recordDetail.getPrincipal();
    	this.period = recordDetail.getPeriod();
    	this.pledgePrincipal = recordDetail.getPledgePrincipal();
    	this.loanerName = recordDetail.getLoanerName();
    	this.loanerIdentityNumber = recordDetail.getLoanerIdentityNumber();
    	this.loanerRegistName = recordDetail.getLoanerRegistName();
    	this.loanerAddress = recordDetail.getLoanerAddress();
    	this.loanerPhoneNumber = recordDetail.getLoanerPhoneNumber();
    	this.bankInfo = recordDetail.getBankInfo();
    	this.bankCardNo = recordDetail.getBankCardNo();
    	this.investorName = recordDetail.getInvestorName();
    	this.investorIdentityNumber = recordDetail.getInvestorIdentityNumber();
    	this.investorRegistName = recordDetail.getInvestorRegistName();
    	this.investorAddress = recordDetail.getInvestorAddress();
    	this.investorPhoneNumber = recordDetail.getInvestorPhoneNumber();
    	this.investorNameAll = recordDetail.getInvestorNameAll();
    	this.investorIdentityNumberAll = recordDetail.getInvestorIdentityNumberAll();
    	this.pledgeUserName = recordDetail.getPledgeUserName();
    	this.pledgeUserIdentityType = recordDetail.getPledgeUserIdentityType();
    	this.pledgeUserIdentityNumber = recordDetail.getPledgeUserIdentityNumber();
    	this.pledgeUserAddress = recordDetail.getPledgeUserAddress();
    	this.pledgeUserPhoneNumber = recordDetail.getPledgeUserPhoneNumber();
    	this.sharedPersonName = recordDetail.getSharedPersonName();
    	this.sharedPersonIdentityNumber = recordDetail.getSharedPersonIdentityNumber();
    	this.houseCertCode = recordDetail.getHouseCertCode();
    	this.pledgeAddress = recordDetail.getPledgeAddress();
    	this.numOfRoom = recordDetail.getNumOfRoom();
    	this.houseNumber = recordDetail.getHouseNumber();
    	this.roomNumber = recordDetail.getRoomNumber();
    	this.proportion = recordDetail.getProportion();
    	this.pledgeType = recordDetail.getPledgeType();
    	this.houseStatus = recordDetail.getHouseStatus();
    	this.otherPerson = recordDetail.getOtherPerson();
    	this.otherPersonPhoneNumber = recordDetail.getOtherPersonPhoneNumber();
    	this.otherPersonIdentityNumber =recordDetail.getOtherPersonIdentityNumber();
    	this.otherPersonIdType = recordDetail.getOtherPersonIdType();
    	this.pledgeGrantedPersonOne = recordDetail.getPledgeGrantedPersonOne();
    	this.pledgeGrantedPersonOneId = recordDetail.getPledgeGrantedPersonOneId();
    	this.pledgeGrantedPersonTwo = recordDetail.getPledgeGrantedPersonTwo();
    	this.pledgeGrantedPersonTwoId = recordDetail.getPledgeGrantedPersonTwoId();
    	this.reverseGuarantorName = recordDetail.getReverseGuarantorName();
    	this.reverseGuarantorId = recordDetail.getReverseGuarantorId();
    	this.reverseGuarantorAddress = recordDetail.getReverseGuarantorAddress();
    	this.reverseGuarantorPhoneNumber = recordDetail.getReverseGuarantorPhoneNumber();
    	this.loanContractCode = recordDetail.getLoanContractCode();
    	this.loanContractCodeAll = recordDetail.getLoanContractCodeAll();
    	this.guaranteeContractCode = recordDetail.getGuaranteeContractCode();
    	this.guaranteeContractCodeAll = recordDetail.getGuaranteeContractCodeAll();
    	this.pledgeContractCode = recordDetail.getPledgeContractCode();
    	this.proxyGuaranteeContractCode = recordDetail.getProxyGuaranteeContractCode();
    	this.reverseContractCode = recordDetail.getReverseContractCode();
    	this.consultContractCode = recordDetail.getConsultContractCode();
    	this.grantPledgeContractCode = recordDetail.getGrantPledgeContractCode();
    	this.useFor = recordDetail.getUseFor();
    	this.interestStartDate = recordDetail.getInterestStartDate();
    	this.firstRepaymentDate = recordDetail.getFirstRepaymentDate();
    	this.deadLine = recordDetail.getDeadLine();
    	this.repayDay = recordDetail.getRepayDay();
    	this.interestRate = recordDetail.getInterestRate();
    	this.consultRate = recordDetail.getConsultRate();
    	this.consultAmount = recordDetail.getConsultAmount();
    	this.guaranteeAmount = recordDetail.getGuaranteeAmount();
    	this.oneRepaymentDate = recordDetail.getOneRepaymentDate();
    	this.oneInterestAmount = recordDetail.getOneInterestAmount();
    	this.onePrincipalAmount = recordDetail.getOnePrincipalAmount();
    	this.oneTotalAmount = recordDetail.getOneTotalAmount();
    	this.twoRepaymentDate = recordDetail.getTwoRepaymentDate();
    	this.twoInterestAmount = recordDetail.getTwoInterestAmount();
    	this.twoPrincipalAmount = recordDetail.getTwoPrincipalAmount();
    	this.twoTotalAmount = recordDetail.getTwoTotalAmount();
    	this.threeRepaymentDate = recordDetail.getThreeRepaymentDate();
    	this.threeInterestAmount = recordDetail.getThreeInterestAmount();
    	this.threePrincipalAmount = recordDetail.getThreePrincipalAmount();
    	this.threeTotalAmount = recordDetail.getThreeTotalAmount();
    	this.fourRepaymentDate = recordDetail.getFourRepaymentDate();
    	this.fourInterestAmount = recordDetail.getFourInterestAmount();
    	this.fourPrincipalAmount = recordDetail.getFourPrincipalAmount();
    	this.fourTotalAmount = recordDetail.getFourTotalAmount();
    	this.fiveRepaymentDate = recordDetail.getFiveRepaymentDate();
    	this.fiveInterestAmount = recordDetail.getFiveInterestAmount();
    	this.fivePrincipalAmount = recordDetail.getFivePrincipalAmount();
    	this.fiveTotalAmount = recordDetail.getFiveTotalAmount();
    	this.sixRepaymentDate = recordDetail.getSixRepaymentDate();
    	this.sixInterestAmount = recordDetail.getSixInterestAmount();
    	this.sixPrincipalAmount = recordDetail.getSixPrincipalAmount();
    	this.sixTotalAmount = recordDetail.getSixTotalAmount();
	}

	public String getBusinessCode() {
        return businessCode;
    }

    public void setBusinessCode(String businessCode) {
        this.businessCode = businessCode;
    }

    public String getPrincipal() {
        return principal;
    }

    public void setPrincipal(String principal) {
        this.principal = principal;
    }
    
    public String getPeriod() {
		return period;
	}

	public void setPeriod(String period) {
		this.period = period;
	}

	public String getPledgePrincipal() {
        return pledgePrincipal;
    }

    public void setPledgePrincipal(String pledgePrincipal) {
        this.pledgePrincipal = pledgePrincipal;
    }

    public String getLoanerName() {
        return loanerName;
    }

    public void setLoanerName(String loanerName) {
        this.loanerName = loanerName;
    }

    public String getLoanerIdentityNumber() {
        return loanerIdentityNumber;
    }

    public void setLoanerIdentityNumber(String loanerIdentityNumber) {
        this.loanerIdentityNumber = loanerIdentityNumber;
    }

    public String getLoanerRegistName() {
        return loanerRegistName;
    }

    public void setLoanerRegistName(String loanerRegistName) {
        this.loanerRegistName = loanerRegistName;
    }

    public String getLoanerAddress() {
        return loanerAddress;
    }

    public void setLoanerAddress(String loanerAddress) {
        this.loanerAddress = loanerAddress;
    }

    public String getLoanerPhoneNumber() {
        return loanerPhoneNumber;
    }

    public void setLoanerPhoneNumber(String loanerPhoneNumber) {
        this.loanerPhoneNumber = loanerPhoneNumber;
    }

    public String getBankInfo() {
        return bankInfo;
    }

    public void setBankInfo(String bankInfo) {
        this.bankInfo = bankInfo;
    }

    public String getBankCardNo() {
        return bankCardNo;
    }

    public void setBankCardNo(String bankCardNo) {
        this.bankCardNo = bankCardNo;
    }

    public String getInvestorName() {
        return investorName;
    }

    public void setInvestorName(String investorName) {
        this.investorName = investorName;
    }

    public String getInvestorIdentityNumber() {
        return investorIdentityNumber;
    }

    public void setInvestorIdentityNumber(String investorIdentityNumber) {
        this.investorIdentityNumber = investorIdentityNumber;
    }

    public String getInvestorRegistName() {
        return investorRegistName;
    }

    public void setInvestorRegistName(String investorRegistName) {
        this.investorRegistName = investorRegistName;
    }

    public String getInvestorAddress() {
        return investorAddress;
    }

    public void setInvestorAddress(String investorAddress) {
        this.investorAddress = investorAddress;
    }

    public String getInvestorPhoneNumber() {
        return investorPhoneNumber;
    }

    public void setInvestorPhoneNumber(String investorPhoneNumber) {
        this.investorPhoneNumber = investorPhoneNumber;
    }

    public String getInvestorNameAll() {
        return investorNameAll;
    }

    public void setInvestorNameAll(String investorNameAll) {
        this.investorNameAll = investorNameAll;
    }

    public String getInvestorIdentityNumberAll() {
        return investorIdentityNumberAll;
    }

    public void setInvestorIdentityNumberAll(String investorIdentityNumberAll) {
        this.investorIdentityNumberAll = investorIdentityNumberAll;
    }

    public String getPledgeUserName() {
        return pledgeUserName;
    }

    public void setPledgeUserName(String pledgeUserName) {
        this.pledgeUserName = pledgeUserName;
    }

    public String getPledgeUserIdentityNumber() {
        return pledgeUserIdentityNumber;
    }

    public void setPledgeUserIdentityNumber(String pledgeUserIdentityNumber) {
        this.pledgeUserIdentityNumber = pledgeUserIdentityNumber;
    }

    public String getPledgeUserAddress() {
        return pledgeUserAddress;
    }

    public void setPledgeUserAddress(String pledgeUserAddress) {
        this.pledgeUserAddress = pledgeUserAddress;
    }

    public String getPledgeUserPhoneNumber() {
        return pledgeUserPhoneNumber;
    }

    public void setPledgeUserPhoneNumber(String pledgeUserPhoneNumber) {
        this.pledgeUserPhoneNumber = pledgeUserPhoneNumber;
    }

    public String getSharedPersonName() {
        return sharedPersonName;
    }

    public void setSharedPersonName(String sharedPersonName) {
        this.sharedPersonName = sharedPersonName;
    }

    public String getSharedPersonIdentityNumber() {
        return sharedPersonIdentityNumber;
    }

    public void setSharedPersonIdentityNumber(String sharedPersonIdentityNumber) {
        this.sharedPersonIdentityNumber = sharedPersonIdentityNumber;
    }

    public String getHouseCertCode() {
        return houseCertCode;
    }

    public void setHouseCertCode(String houseCertCode) {
        this.houseCertCode = houseCertCode;
    }

    public String getPledgeAddress() {
        return pledgeAddress;
    }

    public void setPledgeAddress(String pledgeAddress) {
        this.pledgeAddress = pledgeAddress;
    }

    public String getNumOfRoom() {
        return numOfRoom;
    }

    public void setNumOfRoom(String numOfRoom) {
        this.numOfRoom = numOfRoom;
    }

    public String getHouseNumber() {
        return houseNumber;
    }

    public void setHouseNumber(String houseNumber) {
        this.houseNumber = houseNumber;
    }

    public String getRoomNumber() {
        return roomNumber;
    }

    public void setRoomNumber(String roomNumber) {
        this.roomNumber = roomNumber;
    }

    public String getProportion() {
        return proportion;
    }

    public void setProportion(String proportion) {
        this.proportion = proportion;
    }

    public String getPledgeType() {
        return pledgeType;
    }

    public void setPledgeType(String pledgeType) {
        this.pledgeType = pledgeType;
    }

    public String getHouseStatus() {
        return houseStatus;
    }

    public void setHouseStatus(String houseStatus) {
        this.houseStatus = houseStatus;
    }

    public String getOtherPerson() {
        return otherPerson;
    }

    public void setOtherPerson(String otherPerson) {
        this.otherPerson = otherPerson;
    }

    public String getOtherPersonPhoneNumber() {
        return otherPersonPhoneNumber;
    }

    public void setOtherPersonPhoneNumber(String otherPersonPhoneNumber) {
        this.otherPersonPhoneNumber = otherPersonPhoneNumber;
    }

    public String getOtherPersonIdentityNumber() {
        return otherPersonIdentityNumber;
    }

    public void setOtherPersonIdentityNumber(String otherPersonIdentityNumber) {
        this.otherPersonIdentityNumber = otherPersonIdentityNumber;
    }

    public String getOtherPersonIdType() {
        return otherPersonIdType;
    }

    public void setOtherPersonIdType(String otherPersonIdType) {
        this.otherPersonIdType = otherPersonIdType;
    }

    public String getPledgeGrantedPersonOne() {
        return pledgeGrantedPersonOne;
    }

    public void setPledgeGrantedPersonOne(String pledgeGrantedPersonOne) {
        this.pledgeGrantedPersonOne = pledgeGrantedPersonOne;
    }

    public String getPledgeGrantedPersonOneId() {
        return pledgeGrantedPersonOneId;
    }

    public void setPledgeGrantedPersonOneId(String pledgeGrantedPersonOneId) {
        this.pledgeGrantedPersonOneId = pledgeGrantedPersonOneId;
    }

    public String getPledgeGrantedPersonTwo() {
        return pledgeGrantedPersonTwo;
    }

    public void setPledgeGrantedPersonTwo(String pledgeGrantedPersonTwo) {
        this.pledgeGrantedPersonTwo = pledgeGrantedPersonTwo;
    }

    public String getPledgeGrantedPersonTwoId() {
        return pledgeGrantedPersonTwoId;
    }

    public void setPledgeGrantedPersonTwoId(String pledgeGrantedPersonTwoId) {
        this.pledgeGrantedPersonTwoId = pledgeGrantedPersonTwoId;
    }

    public String getReverseGuarantorName() {
        return reverseGuarantorName;
    }

    public void setReverseGuarantorName(String reverseGuarantorName) {
        this.reverseGuarantorName = reverseGuarantorName;
    }

    public String getReverseGuarantorId() {
        return reverseGuarantorId;
    }

    public void setReverseGuarantorId(String reverseGuarantorId) {
        this.reverseGuarantorId = reverseGuarantorId;
    }

    public String getReverseGuarantorAddress() {
        return reverseGuarantorAddress;
    }

    public void setReverseGuarantorAddress(String reverseGuarantorAddress) {
        this.reverseGuarantorAddress = reverseGuarantorAddress;
    }

    public String getReverseGuarantorPhoneNumber() {
        return reverseGuarantorPhoneNumber;
    }

    public void setReverseGuarantorPhoneNumber(String reverseGuarantorPhoneNumber) {
        this.reverseGuarantorPhoneNumber = reverseGuarantorPhoneNumber;
    }

    public String getLoanContractCode() {
        return loanContractCode;
    }

    public void setLoanContractCode(String loanContractCode) {
        this.loanContractCode = loanContractCode;
    }

    public String getLoanContractCodeAll() {
        return loanContractCodeAll;
    }

    public void setLoanContractCodeAll(String loanContractCodeAll) {
        this.loanContractCodeAll = loanContractCodeAll;
    }

    public String getGuaranteeContractCode() {
        return guaranteeContractCode;
    }

    public void setGuaranteeContractCode(String guaranteeContractCode) {
        this.guaranteeContractCode = guaranteeContractCode;
    }

    public String getGuaranteeContractCodeAll() {
        return guaranteeContractCodeAll;
    }

    public void setGuaranteeContractCodeAll(String guaranteeContractCodeAll) {
        this.guaranteeContractCodeAll = guaranteeContractCodeAll;
    }

    public String getPledgeContractCode() {
        return pledgeContractCode;
    }

    public void setPledgeContractCode(String pledgeContractCode) {
        this.pledgeContractCode = pledgeContractCode;
    }

    public String getProxyGuaranteeContractCode() {
        return proxyGuaranteeContractCode;
    }

    public void setProxyGuaranteeContractCode(String proxyGuaranteeContractCode) {
        this.proxyGuaranteeContractCode = proxyGuaranteeContractCode;
    }

    public String getReverseContractCode() {
        return reverseContractCode;
    }

    public void setReverseContractCode(String reverseContractCode) {
        this.reverseContractCode = reverseContractCode;
    }

    public String getConsultContractCode() {
        return consultContractCode;
    }

    public void setConsultContractCode(String consultContractCode) {
        this.consultContractCode = consultContractCode;
    }

    public String getGrantPledgeContractCode() {
        return grantPledgeContractCode;
    }

    public void setGrantPledgeContractCode(String grantPledgeContractCode) {
        this.grantPledgeContractCode = grantPledgeContractCode;
    }

    public String getUseFor() {
        return useFor;
    }

    public void setUseFor(String useFor) {
        this.useFor = useFor;
    }

    public String getInterestStartDate() {
        return interestStartDate;
    }

    public void setInterestStartDate(String interestStartDate) {
        this.interestStartDate = interestStartDate;
    }

    public String getFirstRepaymentDate() {
        return firstRepaymentDate;
    }

    public void setFirstRepaymentDate(String firstRepaymentDate) {
        this.firstRepaymentDate = firstRepaymentDate;
    }

    public String getDeadLine() {
        return deadLine;
    }

    public void setDeadLine(String deadLine) {
        this.deadLine = deadLine;
    }

    public String getRepayDay() {
        return repayDay;
    }

    public void setRepayDay(String repayDay) {
        this.repayDay = repayDay;
    }

    public String getInterestRate() {
        return interestRate;
    }

    public void setInterestRate(String interestRate) {
        this.interestRate = interestRate;
    }

    public String getConsultRate() {
        return consultRate;
    }

    public void setConsultRate(String consultRate) {
        this.consultRate = consultRate;
    }

    public String getConsultAmount() {
        return consultAmount;
    }

    public void setConsultAmount(String consultAmount) {
        this.consultAmount = consultAmount;
    }

    public String getGuaranteeAmount() {
        return guaranteeAmount;
    }

    public void setGuaranteeAmount(String guaranteeAmount) {
        this.guaranteeAmount = guaranteeAmount;
    }

    public String getPledgeUserIdentityType() {
        return pledgeUserIdentityType;
    }

    public void setPledgeUserIdentityType(String pledgeUserIdentityType) {
        this.pledgeUserIdentityType = pledgeUserIdentityType;
    }

    public String getOneRepaymentDate() {
        return oneRepaymentDate;
    }

    public void setOneRepaymentDate(String oneRepaymentDate) {
        this.oneRepaymentDate = oneRepaymentDate;
    }

    public String getOneInterestAmount() {
        return oneInterestAmount;
    }

    public void setOneInterestAmount(String oneInterestAmount) {
        this.oneInterestAmount = oneInterestAmount;
    }

    public String getOnePrincipalAmount() {
        return onePrincipalAmount;
    }

    public void setOnePrincipalAmount(String onePrincipalAmount) {
        this.onePrincipalAmount = onePrincipalAmount;
    }

    public String getOneTotalAmount() {
        return oneTotalAmount;
    }

    public void setOneTotalAmount(String oneTotalAmount) {
        this.oneTotalAmount = oneTotalAmount;
    }

    public String getTwoRepaymentDate() {
        return twoRepaymentDate;
    }

    public void setTwoRepaymentDate(String twoRepaymentDate) {
        this.twoRepaymentDate = twoRepaymentDate;
    }

    public String getTwoInterestAmount() {
        return twoInterestAmount;
    }

    public void setTwoInterestAmount(String twoInterestAmount) {
        this.twoInterestAmount = twoInterestAmount;
    }

    public String getTwoPrincipalAmount() {
        return twoPrincipalAmount;
    }

    public void setTwoPrincipalAmount(String twoPrincipalAmount) {
        this.twoPrincipalAmount = twoPrincipalAmount;
    }

    public String getTwoTotalAmount() {
        return twoTotalAmount;
    }

    public void setTwoTotalAmount(String twoTotalAmount) {
        this.twoTotalAmount = twoTotalAmount;
    }

    public String getThreeRepaymentDate() {
        return threeRepaymentDate;
    }

    public void setThreeRepaymentDate(String threeRepaymentDate) {
        this.threeRepaymentDate = threeRepaymentDate;
    }

    public String getThreeInterestAmount() {
        return threeInterestAmount;
    }

    public void setThreeInterestAmount(String threeInterestAmount) {
        this.threeInterestAmount = threeInterestAmount;
    }

    public String getThreePrincipalAmount() {
        return threePrincipalAmount;
    }

    public void setThreePrincipalAmount(String threePrincipalAmount) {
        this.threePrincipalAmount = threePrincipalAmount;
    }

    public String getThreeTotalAmount() {
        return threeTotalAmount;
    }

    public void setThreeTotalAmount(String threeTotalAmount) {
        this.threeTotalAmount = threeTotalAmount;
    }

    public String getFourRepaymentDate() {
        return fourRepaymentDate;
    }

    public void setFourRepaymentDate(String fourRepaymentDate) {
        this.fourRepaymentDate = fourRepaymentDate;
    }

    public String getFourInterestAmount() {
        return fourInterestAmount;
    }

    public void setFourInterestAmount(String fourInterestAmount) {
        this.fourInterestAmount = fourInterestAmount;
    }

    public String getFourPrincipalAmount() {
        return fourPrincipalAmount;
    }

    public void setFourPrincipalAmount(String fourPrincipalAmount) {
        this.fourPrincipalAmount = fourPrincipalAmount;
    }

    public String getFourTotalAmount() {
        return fourTotalAmount;
    }

    public void setFourTotalAmount(String fourTotalAmount) {
        this.fourTotalAmount = fourTotalAmount;
    }

    public String getFiveRepaymentDate() {
        return fiveRepaymentDate;
    }

    public void setFiveRepaymentDate(String fiveRepaymentDate) {
        this.fiveRepaymentDate = fiveRepaymentDate;
    }

    public String getFiveInterestAmount() {
        return fiveInterestAmount;
    }

    public void setFiveInterestAmount(String fiveInterestAmount) {
        this.fiveInterestAmount = fiveInterestAmount;
    }

    public String getFivePrincipalAmount() {
        return fivePrincipalAmount;
    }

    public void setFivePrincipalAmount(String fivePrincipalAmount) {
        this.fivePrincipalAmount = fivePrincipalAmount;
    }

    public String getFiveTotalAmount() {
        return fiveTotalAmount;
    }

    public void setFiveTotalAmount(String fiveTotalAmount) {
        this.fiveTotalAmount = fiveTotalAmount;
    }

    public String getSixRepaymentDate() {
        return sixRepaymentDate;
    }

    public void setSixRepaymentDate(String sixRepaymentDate) {
        this.sixRepaymentDate = sixRepaymentDate;
    }

    public String getSixInterestAmount() {
        return sixInterestAmount;
    }

    public void setSixInterestAmount(String sixInterestAmount) {
        this.sixInterestAmount = sixInterestAmount;
    }

    public String getSixPrincipalAmount() {
        return sixPrincipalAmount;
    }

    public void setSixPrincipalAmount(String sixPrincipalAmount) {
        this.sixPrincipalAmount = sixPrincipalAmount;
    }

    public String getSixTotalAmount() {
        return sixTotalAmount;
    }

    public void setSixTotalAmount(String sixTotalAmount) {
        this.sixTotalAmount = sixTotalAmount;
    }
}
