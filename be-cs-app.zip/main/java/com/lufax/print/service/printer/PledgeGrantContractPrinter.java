package com.lufax.print.service.printer;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.PageSize;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.PdfContentByte;
import com.lowagie.text.pdf.PdfWriter;
import com.lufax.print.service.printer.data.PrintData;

public class PledgeGrantContractPrinter extends AbstractContractTaodaPrinter {

    protected String getContractName() {
        return "抵押授权委托书";
    }

    protected void generatePdf(File file, PrintData data) throws DocumentException, IOException {

        BaseFont bf = BaseFont.createFont("simsun.ttc,1", BaseFont.IDENTITY_H, BaseFont.NOT_EMBEDDED);
        int fontSize = 12;

        Document document = new Document(PageSize.A4);
        PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(file));
        document.open();
        PdfContentByte contentByte = writer.getDirectContent();
        
        writePage1(data, contentByte, bf, fontSize);

        document.close();
    }

    private void writePage1(PrintData data, PdfContentByte contentByte, BaseFont bf, int fontSize) {
        write(contentByte, bf, fontSize, data.getGrantPledgeContractCode(),345,775);
        write(contentByte, bf, fontSize, data.getPledgeGrantedPersonOne(),110,593);
        write(contentByte, bf, fontSize, data.getPledgeGrantedPersonOneId(),252,593);
        write(contentByte, bf, fontSize, data.getPledgeGrantedPersonTwo(),447,594);
        write(contentByte, bf, fontSize, data.getPledgeGrantedPersonTwoId(),175,560);
        write(contentByte, bf, fontSize, data.getHouseCertCode(),235,496);
        String address = data.getPledgeAddress();
        
        if(address.length() > 12){
        	write(contentByte, bf, fontSize, address.substring(0, 12),394,496);
        	write(contentByte, bf, fontSize, address.substring(12),90,465);
        } else {
        	write(contentByte, bf, fontSize, address,394,496);
        }
        
        write(contentByte, bf, fontSize, data.getRoomNumber(),250,465);
        write(contentByte, bf, fontSize, data.getProportion(),402,465);
    }
    
    public static void main(String[] args){
    	String v = "蜀山区往江西路198号华府君元24幢14xxxx";
    	System.out.println(v.length());
    	System.out.println(v.substring(0, 12));
    	System.out.println(v.substring(12));
    }
}
