package com.lufax.print.service.printer.data;

import org.springframework.stereotype.Service;

import com.lufax.print.domain.TaodaRecord;
import com.lufax.print.domain.TaodaRecordDetail;
import com.lufax.print.domain.TaodaUserType;

@Service("personLoanContractPrintDataFactory")
public class PersonLoanContractPrintDataFactory implements PrintDataFactory {

	public PrintData buildPrintData(TaodaRecord record, TaodaRecordDetail recordDetail) {
		
		PrintData data = new PrintData();
		
		if(TaodaUserType.INVESTOR.equals(record.getUserType())){
			//投资人
			data.setInvestorName(recordDetail.getInvestorName());
			data.setInvestorIdentityNumber(recordDetail.getInvestorIdentityNumber());
			data.setInvestorRegistName(recordDetail.getInvestorRegistName());
		} else {
			//借款人
			data.setLoanContractCode(recordDetail.getLoanContractCode());
			data.setLoanerName(recordDetail.getLoanerName());
			data.setLoanerIdentityNumber(recordDetail.getLoanerIdentityNumber());
			data.setLoanerRegistName(recordDetail.getLoanerRegistName());
			data.setPrincipal(recordDetail.getPrincipal());
			data.setUseFor(recordDetail.getUseFor());
			data.setDeadLine(recordDetail.getDeadLine());
			data.setInterestRate(recordDetail.getInterestRate());
			data.setRepayDay(recordDetail.getRepayDay());
			data.setFirstRepaymentDate(recordDetail.getFirstRepaymentDate());
			data.setBankInfo(recordDetail.getBankInfo());
			data.setBankCardNo(recordDetail.getBankCardNo());
			data.setGuaranteeContractCode(recordDetail.getGuaranteeContractCode());
//			data.setInvestorName(recordDetail.getInvestorName());
			data.setInterestStartDate(recordDetail.getInterestStartDate());
			
			data.setOneRepaymentDate(recordDetail.getOneRepaymentDate());
			data.setOneInterestAmount(recordDetail.getOneInterestAmount());
			data.setOnePrincipalAmount(recordDetail.getOnePrincipalAmount());
			data.setOneTotalAmount(recordDetail.getOneTotalAmount());
			
			data.setTwoRepaymentDate(recordDetail.getTwoRepaymentDate());
			data.setTwoInterestAmount(recordDetail.getTwoInterestAmount());
			data.setTwoPrincipalAmount(recordDetail.getTwoPrincipalAmount());
			data.setTwoTotalAmount(recordDetail.getTwoTotalAmount());
			
			data.setThreeRepaymentDate(recordDetail.getThreeRepaymentDate());
			data.setThreeInterestAmount(recordDetail.getThreeInterestAmount());
			data.setThreePrincipalAmount(recordDetail.getThreePrincipalAmount());
			data.setThreeTotalAmount(recordDetail.getThreeTotalAmount());
			
			data.setFourRepaymentDate(recordDetail.getFourRepaymentDate());
			data.setFourInterestAmount(recordDetail.getFourInterestAmount());
			data.setFourPrincipalAmount(recordDetail.getFourPrincipalAmount());
			data.setFourTotalAmount(recordDetail.getFourTotalAmount());
			
			data.setFiveRepaymentDate(recordDetail.getFiveRepaymentDate());
			data.setFiveInterestAmount(recordDetail.getFiveInterestAmount());
			data.setFivePrincipalAmount(recordDetail.getFivePrincipalAmount());
			data.setFiveTotalAmount(recordDetail.getFiveTotalAmount());
			
			data.setSixRepaymentDate(recordDetail.getSixRepaymentDate());
			data.setSixInterestAmount(recordDetail.getSixInterestAmount());
			data.setSixPrincipalAmount(recordDetail.getSixPrincipalAmount());
			data.setSixTotalAmount(recordDetail.getSixTotalAmount());
		}
		
		return data;
	}

}
