package com.lufax.print.service.printer;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.PageSize;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.PdfContentByte;
import com.lowagie.text.pdf.PdfWriter;
import com.lufax.print.service.printer.data.PrintData;

public class ConsultServiceContractPrinter extends AbstractContractTaodaPrinter {

    protected String getContractName() {
        return "咨询服务协议";
    }

    protected void generatePdf(File file, PrintData data) throws DocumentException, IOException {

        BaseFont bf = BaseFont.createFont("simsun.ttc,1", BaseFont.IDENTITY_H, BaseFont.NOT_EMBEDDED);
        int fontSize = 12;

        Document document = new Document(PageSize.A4);
        PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(file));
        document.open();
        PdfContentByte contentByte = writer.getDirectContent();
        
        writePage4(data, contentByte, bf, fontSize);
        document.newPage();
        writePage2(data, contentByte, bf, fontSize);
        document.newPage();
        writePage1(data, contentByte, bf, fontSize);
        document.newPage();
        writePage3(data, contentByte, bf, fontSize);

        document.close();
    }

    private void writePage1(PrintData data, PdfContentByte contentByte, BaseFont bf, int fontSize) {
        write(contentByte, bf, fontSize, data.getConsultContractCode(),385,720);
        write(contentByte, bf, fontSize, data.getLoanerName(),190,685);
        write(contentByte, bf, fontSize, data.getLoanerRegistName(),195,670);
        write(contentByte, bf, fontSize, data.getLoanerIdentityNumber(),188,655);
        write(contentByte, bf, fontSize, data.getLoanerAddress(),180,640);
        write(contentByte, bf, fontSize, data.getLoanerPhoneNumber(),180,625);
        write(contentByte, bf, fontSize, data.getConsultRate(),478,324);
        write(contentByte, bf, fontSize, data.getConsultAmount(),185,309);
    }

    private void writePage2(PrintData data, PdfContentByte contentByte, BaseFont bf, int fontSize) {
        writeNull(contentByte, bf, fontSize);
    }

    private void writePage3(PrintData data, PdfContentByte contentByte, BaseFont bf, int fontSize) {
        write(contentByte, bf, fontSize, data.getConsultContractCode(),195,719);
        write(contentByte, bf, fontSize, data.getLoanerName(),125,665);
    }

    private void writePage4(PrintData data, PdfContentByte contentByte, BaseFont bf, int fontSize) {
        write(contentByte, bf, fontSize, data.getConsultContractCode(),210,720);
    }
}
