package com.lufax.print.service.printer.data;

import org.springframework.stereotype.Service;

import com.lufax.print.domain.TaodaRecord;
import com.lufax.print.domain.TaodaRecordDetail;
import com.lufax.print.domain.TaodaUserType;

@Service("guaranteeContractPrintDataFactory")
public class GuaranteeContractPrintDataFactory implements PrintDataFactory {

	public PrintData buildPrintData(TaodaRecord record, TaodaRecordDetail recordDetail) {
		
		PrintData data = new PrintData();
		
		if(TaodaUserType.INVESTOR.equals(record.getUserType())){
			//投资人
			data.setInvestorName(recordDetail.getInvestorName());
			data.setInvestorIdentityNumber(recordDetail.getInvestorIdentityNumber());
			data.setInvestorAddress(recordDetail.getInvestorAddress());
			data.setInvestorPhoneNumber(recordDetail.getInvestorPhoneNumber());
		} else {
			//借款人
			data.setGuaranteeContractCode(recordDetail.getGuaranteeContractCode());
			data.setLoanerName(recordDetail.getLoanerName());
			data.setLoanContractCode(recordDetail.getLoanContractCode());
//			data.setInvestorName(recordDetail.getInvestorName());
		}
		
		return data;
	}

}
