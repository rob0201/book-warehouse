package com.lufax.print.service.printer;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.PageSize;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.PdfContentByte;
import com.lowagie.text.pdf.PdfWriter;
import com.lufax.print.service.printer.data.PrintData;

public class PledgeContractPrinter extends AbstractContractTaodaPrinter {

    protected String getContractName() {
        return "抵押合同";
    }

    protected void generatePdf(File file, PrintData data) throws DocumentException, IOException {

        BaseFont bf = BaseFont.createFont("simsun.ttc,1", BaseFont.IDENTITY_H, BaseFont.NOT_EMBEDDED);
        int fontSize = 12;

        Document document = new Document(PageSize.A4);
        PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(file));
        document.open();
        PdfContentByte contentByte = writer.getDirectContent();

        writePage12(data, contentByte, bf, fontSize);
        document.newPage();
        writePage6(data, contentByte, bf, fontSize);
        document.newPage();
        writePage1(data, contentByte, bf, fontSize);
        document.newPage();
        writePage7(data, contentByte, bf, fontSize);
        document.newPage();
        writePage10(data, contentByte, bf, fontSize);
        document.newPage();
        writePage4(data, contentByte, bf, fontSize);
        document.newPage();
        writePage3(data, contentByte, bf, fontSize);
        document.newPage();
        writePage9(data, contentByte, bf, fontSize);
        document.newPage();
        writePage8(data, contentByte, bf, fontSize);
        document.newPage();
        writePage2(data, contentByte, bf, fontSize);
        document.newPage();
        writePage5(data, contentByte, bf, fontSize);
        document.newPage();
        writePage11(data, contentByte, bf, fontSize);

        document.close();
    }

    private void writePage1(PrintData data, PdfContentByte contentByte, BaseFont bf, int fontSize) {
        write(contentByte, bf, fontSize, data.getPledgeContractCode(),330,723);
        write(contentByte, bf, fontSize, data.getPledgeUserName(),150,691);
        write(contentByte, bf, fontSize, data.getPledgeUserIdentityNumber(),180,676);
        write(contentByte, bf, fontSize, data.getPledgeUserAddress(),170,660);
        write(contentByte, bf, fontSize, data.getPledgeUserPhoneNumber(),170,645);
        write(contentByte, bf, fontSize, data.getLoanerName(),155,533);
        write(contentByte, bf, fontSize, data.getProxyGuaranteeContractCode(),380,533);
        write(contentByte, bf, fontSize, data.getInvestorNameAll(),205,485);
        write(contentByte, bf, fontSize, data.getLoanContractCodeAll(),105,470);
    }

    private void writePage2(PrintData data, PdfContentByte contentByte, BaseFont bf, int fontSize) {
        writeNull(contentByte, bf, fontSize);
    }

    private void writePage3(PrintData data, PdfContentByte contentByte, BaseFont bf, int fontSize) {
    	writeNull(contentByte, bf, fontSize);
    }

    private void writePage4(PrintData data, PdfContentByte contentByte, BaseFont bf, int fontSize) {
    	writeNull(contentByte, bf, fontSize);
    }

    private void writePage5(PrintData data, PdfContentByte contentByte, BaseFont bf, int fontSize) {
        write(contentByte, bf, fontSize, data.getPledgePrincipal(),400,447);
        write(contentByte, bf, fontSize, data.getDeadLine(),320,433);
    }

    private void writePage6(PrintData data, PdfContentByte contentByte, BaseFont bf, int fontSize) {
        write(contentByte, bf, fontSize, data.getProxyGuaranteeContractCode(),205,716);
        write(contentByte, bf, fontSize, data.getPledgeUserName(),135,644);
    }

    private void writePage7(PrintData data, PdfContentByte contentByte, BaseFont bf, int fontSize) {
        write(contentByte, bf, fontSize, data.getProxyGuaranteeContractCode(),198,709);
    }

    private void writePage8(PrintData data, PdfContentByte contentByte, BaseFont bf, int fontSize) {
    	write(contentByte, bf, fontSize, data.getPledgeUserName(),205,664);
    	write(contentByte, bf, fontSize, data.getPledgeUserIdentityNumber(),390,664);
    	write(contentByte, bf, fontSize, data.getPledgeContractCode(),255,640);
    	write(contentByte, bf, fontSize, data.getHouseCertCode(),135,594);
    	write(contentByte, bf, fontSize, data.getSharedPersonName(),200,287);
    	write(contentByte, bf, fontSize, data.getSharedPersonIdentityNumber(),390,287);
    	write(contentByte, bf, fontSize, data.getPledgeContractCode(),250,264);
    	write(contentByte, bf, fontSize, data.getPledgeUserName(),478,241);
    	write(contentByte, bf, fontSize, data.getPledgeUserIdentityNumber(),185,217);
    	write(contentByte, bf, fontSize, data.getHouseCertCode(),435,217);
    }

    private void writePage9(PrintData data, PdfContentByte contentByte, BaseFont bf, int fontSize) {
    	write(contentByte, bf, fontSize, data.getPledgeUserName(),150,640);
    	String[] guaranteeContracts = data.getGuaranteeContractCodeAll().split("/");
    	for(int i = 0; i < guaranteeContracts.length; i++){
    		write(contentByte, bf, fontSize, guaranteeContracts[i].trim(),70,585 - i * 10);
    	}
    	write(contentByte, bf, fontSize, data.getPledgeContractCode(),292,585);
    	
    	String pledgeAddress = data.getPledgeAddress();
    	if(pledgeAddress.length() > 15){
    		write(contentByte, bf, fontSize, pledgeAddress.substring(0, 15),70,430);
    		write(contentByte, bf, fontSize, pledgeAddress.substring(15),70,420);
    	} else {
    		write(contentByte, bf, fontSize, pledgeAddress,70,430);
    	}
    	write(contentByte, bf, fontSize, data.getHouseCertCode(),255,430);
    }

    private void writePage10(PrintData data, PdfContentByte contentByte, BaseFont bf, int fontSize) {
    	writeNull(contentByte, bf, fontSize);
    }

    private void writePage11(PrintData data, PdfContentByte contentByte, BaseFont bf, int fontSize) {
	    writeNull(contentByte, bf, fontSize);
    }

    private void writePage12(PrintData data, PdfContentByte contentByte, BaseFont bf, int fontSize) {
    	writeNull(contentByte, bf, fontSize);
    }
    
}
