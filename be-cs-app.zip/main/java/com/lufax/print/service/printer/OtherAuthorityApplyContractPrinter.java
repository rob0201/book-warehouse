package com.lufax.print.service.printer;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.PageSize;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.PdfContentByte;
import com.lowagie.text.pdf.PdfWriter;
import com.lufax.print.service.printer.data.PrintData;

public class OtherAuthorityApplyContractPrinter extends AbstractContractTaodaPrinter {

    protected String getContractName() {
        return "合肥市房地产他项权利登记申请";
    }

    protected void generatePdf(File file, PrintData data) throws DocumentException, IOException {

//        PdfReader pdfReader = new PdfReader("/home/zhouchengming606/Documents/7.pdf");
//        PdfStamper pdfStamper = new PdfStamper(pdfReader, new FileOutputStream(file));
//        PdfContentByte contentByte = pdfStamper.getOverContent(2);


        BaseFont bf = BaseFont.createFont("simsun.ttc,1", BaseFont.IDENTITY_H, BaseFont.NOT_EMBEDDED);
        int fontSize = 12;

        Document document = new Document(PageSize.A4);
        PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(file));
        document.open();
        PdfContentByte contentByte = writer.getDirectContent();


        writePage1(data, contentByte, bf, fontSize);

        document.close();
    }

    private void writePage1(PrintData data, PdfContentByte contentByte, BaseFont bf, int fontSize) throws IOException, DocumentException {

        BaseFont bf_webdings = BaseFont.createFont("WINGDNG2.TTF", BaseFont.IDENTITY_H, BaseFont.NOT_EMBEDDED);
        int fontSize_webdings = 18;

        write(contentByte,bf, fontSize, "抵押人姓名", 170, 770);
        write(contentByte,bf, fontSize, "抵押人联系电话", 430, 770);
        write(contentByte,bf, fontSize, "抵押人证件号吗", 170, 740);
        write(contentByte,bf_webdings, fontSize_webdings, "P", 430, 740);
        write(contentByte,bf_webdings, fontSize_webdings, "P", 200, 710);
        write(contentByte,bf_webdings, fontSize_webdings, "P", 450, 710);
        write(contentByte,bf, fontSize, "他项权利人", 170, 685);
        write(contentByte,bf, fontSize, "他项权利人联系电话", 440, 685);
        write(contentByte,bf, fontSize, "他项权利人证件号码", 170, 655);
        write(contentByte,bf_webdings, fontSize_webdings, "P", 430, 660);

    }

    private void writePage2(PrintData data, PdfContentByte contentByte, BaseFont bf, int fontSize) {
        write(contentByte,bf, fontSize, "房产权利证号", 165, 160, 90);
        write(contentByte,bf, fontSize, "抵押物地址", 165, 230, 90);
        write(contentByte,bf, fontSize, "幢号", 165, 445, 90);
        write(contentByte,bf, fontSize, "室号", 165, 480, 90);
        write(contentByte,bf, fontSize, "建筑面积", 165, 535, 90);
    }

//    public static void main(String[] args) throws DocumentException, IOException{
//        OtherAuthorityApplyContractPrinter printer = new OtherAuthorityApplyContractPrinter();
//        printer.generatePdf(new File("/home/zhouchengming606/Documents/测试.pdf"), null);
//    }

}
