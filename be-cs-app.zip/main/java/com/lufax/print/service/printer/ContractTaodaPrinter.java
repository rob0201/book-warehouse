package com.lufax.print.service.printer;

import java.io.File;

import com.lufax.print.domain.TaodaRecord;
import com.lufax.print.domain.TaodaRecordDetail;

public interface ContractTaodaPrinter {

	public void generate(File dir, TaodaRecord record, TaodaRecordDetail recordDetail);

}
