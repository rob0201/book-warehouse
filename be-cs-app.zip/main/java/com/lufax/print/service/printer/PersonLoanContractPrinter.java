package com.lufax.print.service.printer;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.PageSize;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.PdfContentByte;
import com.lowagie.text.pdf.PdfWriter;
import com.lufax.print.service.printer.data.PrintData;

public class PersonLoanContractPrinter extends AbstractContractTaodaPrinter {

	protected String getContractName() {
		return "个人借款合同";
	}

	protected void generatePdf(File file, PrintData data) throws DocumentException, IOException {

        BaseFont bf = BaseFont.createFont("simsun.ttc,1", BaseFont.IDENTITY_H, BaseFont.NOT_EMBEDDED);
        int fontSize = 12;

        Document document = new Document(PageSize.A4);
        PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(file));

        document.open();

        PdfContentByte contentByte = writer.getDirectContent();


        writePage8(data, contentByte, bf, fontSize);
        document.newPage();
        writePage4(data, contentByte, bf, fontSize);
        document.newPage();
        writePage1(data, contentByte, bf, fontSize);
        document.newPage();
        writePage5(data, contentByte, bf, fontSize);
        document.newPage();
        writePage6(data, contentByte, bf, fontSize);
        document.newPage();
        writePage2(data, contentByte, bf, fontSize);
        document.newPage();
        writePage3(data, contentByte, bf, fontSize);
        document.newPage();
        writePage7(data, contentByte, bf, fontSize);


        document.close();
    }

    private void writePage1(PrintData data, PdfContentByte contentByte, BaseFont bf, int fontSize) {
        write(contentByte, bf, fontSize, data.getLoanContractCode(),368,715);
        write(contentByte, bf, fontSize, data.getLoanerName(),158,683);
        write(contentByte, bf, fontSize, data.getLoanerIdentityNumber(),180,668);
        write(contentByte, bf, fontSize, data.getLoanerRegistName(),190,652);
        write(contentByte, bf, fontSize, data.getInvestorName(),158,620);
        write(contentByte, bf, fontSize, data.getInvestorIdentityNumber(),180,605);
        write(contentByte, bf, fontSize, data.getInvestorRegistName(),190,590);
        write(contentByte, bf, fontSize, data.getPrincipal(),275,463);
        write(contentByte, bf, fontSize, data.getUseFor(),195,431);
        //借款到期日
        write(contentByte, bf, fontSize, data.getDeadLine(), 415, 368);
        //年化利率
        write(contentByte, bf, fontSize, data.getInterestRate(),228,352);
        //结息日
        write(contentByte, bf, fontSize, data.getRepayDay(),218,305);
        //首次还息日
        write(contentByte, bf, fontSize, data.getFirstRepaymentDate(),120,273);
    }

    private void writePage2(PrintData data, PdfContentByte contentByte, BaseFont bf, int fontSize) {
        write(contentByte, bf, fontSize, data.getLoanerName(), 158, 715);
        write(contentByte, bf, fontSize, data.getBankInfo(), 173, 700);
        write(contentByte, bf, fontSize, data.getBankCardNo(), 188, 685);
        write(contentByte, bf, fontSize, data.getGuaranteeContractCode(), 230, 415);
    }

    private void writePage3(PrintData data, PdfContentByte contentByte, BaseFont bf, int fontSize) {
        writeNull(contentByte, bf, fontSize);
    }

    private void writePage4(PrintData data, PdfContentByte contentByte, BaseFont bf, int fontSize) {
        writeNull(contentByte, bf, fontSize);
    }

    private void writePage5(PrintData data, PdfContentByte contentByte, BaseFont bf, int fontSize) {
        writeNull(contentByte, bf, fontSize);
    }

    private void writePage6(PrintData data, PdfContentByte contentByte, BaseFont bf, int fontSize) {
        write(contentByte, bf, fontSize, data.getLoanContractCode(), 180, 720);
        write(contentByte, bf, fontSize, data.getLoanerName(), 145, 672);
    }

    private void writePage7(PrintData data, PdfContentByte contentByte, BaseFont bf, int fontSize) {
        write(contentByte, bf, fontSize, data.getLoanContractCode(), 170, 710);
        write(contentByte, bf, fontSize, data.getInvestorName(), 135, 665);
    }

    private void writePage8(PrintData data, PdfContentByte contentByte, BaseFont bf, int fontSize) {
        //借款起息日
        write(contentByte, bf, fontSize, data.getInterestStartDate(), 235, 689);
        //第一期还款日
        write(contentByte, bf, fontSize, data.getOneRepaymentDate(), 120, 610);
        //第一期应还利息
        write(contentByte, bf, fontSize, data.getOneInterestAmount(), 220, 610);
        //第一期应还本金
        write(contentByte, bf, fontSize, data.getOnePrincipalAmount(), 320, 610);
        //第一期应还款总金额
        write(contentByte, bf, fontSize, data.getOneTotalAmount(), 425, 610);

        //第二期还款日
        write(contentByte, bf, fontSize, data.getTwoRepaymentDate(), 120, 585);
        //第二期应还利息
        write(contentByte, bf, fontSize, data.getTwoInterestAmount(), 220, 585);
        //第二期应还本金
        write(contentByte, bf, fontSize, data.getTwoPrincipalAmount(), 320, 585);
        //第二期应还款总金额
        write(contentByte, bf, fontSize, data.getTwoTotalAmount(), 425, 585);

        //第三期还款日
        write(contentByte, bf, fontSize, data.getThreeRepaymentDate(), 120, 560);
        //第三期应还利息
        write(contentByte, bf, fontSize, data.getThreeInterestAmount(), 220, 560);
        //第三期应还本金
        write(contentByte, bf, fontSize, data.getThreePrincipalAmount(), 320, 560);
        //第一期应还款总金额
        write(contentByte, bf, fontSize, data.getThreeTotalAmount(), 425, 560);

        //第四期还款日
        write(contentByte, bf, fontSize, data.getFourRepaymentDate(), 120, 536);
        //第四期应还利息
        write(contentByte, bf, fontSize, data.getFourInterestAmount(), 220, 536);
        //第四期应还本金
        write(contentByte, bf, fontSize, data.getFourPrincipalAmount(), 320, 536);
        //第四期应还款总金额
        write(contentByte, bf, fontSize, data.getFourTotalAmount(), 425, 536);

        //第五期还款日
        write(contentByte, bf, fontSize, data.getFiveRepaymentDate(), 120, 512);
        //第五期应还利息
        write(contentByte, bf, fontSize, data.getFiveInterestAmount(), 220, 512);
        //第五期应还本金
        write(contentByte, bf, fontSize, data.getFivePrincipalAmount(), 320, 512);
        //第五期应还款总金额
        write(contentByte, bf, fontSize, data.getFiveTotalAmount(), 425, 512);

        //第六期还款日
        write(contentByte, bf, fontSize, data.getSixRepaymentDate(), 120, 489);
        //第六期应还利息
        write(contentByte, bf, fontSize, data.getSixInterestAmount(), 220, 489);
        //第六期应还本金
        write(contentByte, bf, fontSize, data.getSixPrincipalAmount(), 320, 489);
        //第六期应还款总金额
        write(contentByte, bf, fontSize, data.getSixTotalAmount(), 425, 489);
    }
}
