package com.lufax.print.service.printer;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.PageSize;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.PdfContentByte;
import com.lowagie.text.pdf.PdfWriter;
import com.lufax.print.service.printer.data.PrintData;

public class ReverseGuaranteeContractPrinter extends AbstractContractTaodaPrinter {

    protected String getContractName() {
        return "反担保专用保证合同";
    }

    protected void generatePdf(File file, PrintData data) throws DocumentException, IOException {

        BaseFont bf = BaseFont.createFont("simsun.ttc,1", BaseFont.IDENTITY_H, BaseFont.NOT_EMBEDDED);
        int fontSize = 12;

        Document document = new Document(PageSize.A4);
        PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(file));
        document.open();
        PdfContentByte contentByte = writer.getDirectContent();
        
        writePage8(data, contentByte, bf, fontSize);
        document.newPage();
        writePage4(data, contentByte, bf, fontSize);
        document.newPage();
        writePage1(data, contentByte, bf, fontSize);
        document.newPage();
        writePage5(data, contentByte, bf, fontSize);
        document.newPage();
        writePage6(data, contentByte, bf, fontSize);
        document.newPage();
        writePage2(data, contentByte, bf, fontSize);
        document.newPage();
        writePage3(data, contentByte, bf, fontSize);
        document.newPage();
        writePage7(data, contentByte, bf, fontSize);

        document.close();
    }

    private void writePage1(PrintData data, PdfContentByte contentByte, BaseFont bf, int fontSize) {
        write(contentByte, bf, fontSize, data.getReverseContractCode(),345,741);
        write(contentByte, bf, fontSize, data.getReverseGuarantorName(),150,706);
        write(contentByte, bf, fontSize, data.getReverseGuarantorId(),188,691);
        write(contentByte, bf, fontSize, data.getReverseGuarantorAddress(),180,675);
        write(contentByte, bf, fontSize, data.getReverseGuarantorPhoneNumber(),180,660);
        write(contentByte, bf, fontSize, data.getLoanerName(),164,529);
        write(contentByte, bf, fontSize, data.getProxyGuaranteeContractCode(),395,529);
        write(contentByte, bf, fontSize, data.getInvestorNameAll(),210,479);
        write(contentByte, bf, fontSize, data.getLoanContractCodeAll(),100,464);
    }

    private void writePage2(PrintData data, PdfContentByte contentByte, BaseFont bf, int fontSize) {
        writeNull(contentByte, bf, fontSize);
    }

    private void writePage3(PrintData data, PdfContentByte contentByte, BaseFont bf, int fontSize) {
       writeNull(contentByte, bf, fontSize);
    }

    private void writePage4(PrintData data, PdfContentByte contentByte, BaseFont bf, int fontSize) {
    	write(contentByte, bf, fontSize, data.getProxyGuaranteeContractCode(),195,690);
    	write(contentByte, bf, fontSize, data.getReverseGuarantorName(),120,641);
    }

   

    private void writePage5(PrintData data, PdfContentByte contentByte, BaseFont bf, int fontSize) {
       write(contentByte, bf, fontSize, data.getProxyGuaranteeContractCode(),200,689);
    }

    private void writePage6(PrintData data, PdfContentByte contentByte, BaseFont bf, int fontSize) {
       writeNull(contentByte, bf, fontSize);
    }

    private void writePage7(PrintData data, PdfContentByte contentByte, BaseFont bf, int fontSize) {
       writeNull(contentByte, bf, fontSize);
    }

    private void writePage8(PrintData data, PdfContentByte contentByte, BaseFont bf, int fontSize) {
       writeNull(contentByte, bf, fontSize);
    }
    
}
