package com.lufax.print.service.printer;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.PageSize;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.PdfContentByte;
import com.lowagie.text.pdf.PdfWriter;
import com.lufax.print.service.printer.data.PrintData;

public class ProxyGuaranteeContractPrinter extends AbstractContractTaodaPrinter {

    protected String getContractName() {
        return "委托担保合同";
    }

    protected void generatePdf(File file, PrintData data) throws DocumentException, IOException {

        BaseFont bf = BaseFont.createFont("simsun.ttc,1", BaseFont.IDENTITY_H, BaseFont.NOT_EMBEDDED);
        int fontSize = 12;

        Document document = new Document(PageSize.A4);
        PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(file));
        document.open();
        PdfContentByte contentByte = writer.getDirectContent();
        
        writePage8(data, contentByte, bf, fontSize);
        document.newPage();
        writePage4(data, contentByte, bf, fontSize);
        document.newPage();
        writePage1(data, contentByte, bf, fontSize);
        document.newPage();
        writePage5(data, contentByte, bf, fontSize);
        document.newPage();
        writePage6(data, contentByte, bf, fontSize);
        document.newPage();
        writePage2(data, contentByte, bf, fontSize);
        document.newPage();
        writePage3(data, contentByte, bf, fontSize);
        document.newPage();
        writePage7(data, contentByte, bf, fontSize);

        document.close();
    }

    private void writePage1(PrintData data, PdfContentByte contentByte, BaseFont bf, int fontSize) {
        write(contentByte, bf, fontSize, data.getProxyGuaranteeContractCode(),310,708);
        write(contentByte, bf, fontSize, data.getLoanerName(),148,693);
        write(contentByte, bf, fontSize, data.getLoanerIdentityNumber(),180,677);
        write(contentByte, bf, fontSize, data.getLoanerAddress(),170,661);
        write(contentByte, bf, fontSize, data.getLoanerPhoneNumber(),170,645);
        write(contentByte, bf, fontSize, data.getInvestorNameAll(),312,550);
        write(contentByte, bf, fontSize, data.getGuaranteeAmount(),190,205);
    }

    private void writePage2(PrintData data, PdfContentByte contentByte, BaseFont bf, int fontSize) {
       write(contentByte, bf, fontSize, data.getPledgeAddress(),260,620);
        write(contentByte, bf, fontSize, data.getHouseCertCode(),260,605);
    }

    private void writePage3(PrintData data, PdfContentByte contentByte, BaseFont bf, int fontSize) {
       writeNull(contentByte, bf, fontSize);
    }

    private void writePage4(PrintData data, PdfContentByte contentByte, BaseFont bf, int fontSize) {
       writeNull(contentByte, bf, fontSize);
    }

    private void writePage5(PrintData data, PdfContentByte contentByte, BaseFont bf, int fontSize) {
       writeNull(contentByte, bf, fontSize);
    }

    private void writePage6(PrintData data, PdfContentByte contentByte, BaseFont bf, int fontSize) {
        write(contentByte, bf, fontSize, data.getProxyGuaranteeContractCode(),210,721);
        write(contentByte, bf, fontSize, data.getLoanerName(),132,674);
    }

    private void writePage7(PrintData data, PdfContentByte contentByte, BaseFont bf, int fontSize) {
       write(contentByte, bf, fontSize, data.getProxyGuaranteeContractCode(),198,703);
    }

    private void writePage8(PrintData data, PdfContentByte contentByte, BaseFont bf, int fontSize) {
       write(contentByte, bf, fontSize, data.getLoanerName(),150,708);
       write(contentByte, bf, fontSize, data.getLoanerIdentityNumber(),210,692);
       write(contentByte, bf, fontSize, data.getInvestorNameAll(),150,676);
       write(contentByte, bf, fontSize, data.getInvestorIdentityNumberAll(),210,660);
       write(contentByte, bf, fontSize, data.getPeriod(),158,613);
       write(contentByte, bf, fontSize, data.getPrincipal(),182,598);
       write(contentByte, bf, fontSize, data.getInterestRate(),158,582);
    }
    
}
