package com.lufax.print.service.printer.data;

import com.lufax.print.domain.TaodaRecord;
import com.lufax.print.domain.TaodaRecordDetail;

public interface PrintDataFactory {

	public PrintData buildPrintData(TaodaRecord record, TaodaRecordDetail recordDetail);

}
