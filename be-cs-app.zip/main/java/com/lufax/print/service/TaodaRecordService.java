package com.lufax.print.service;

import com.lufax.common.domain.User;
import com.lufax.common.domain.repository.UserRepository;
import com.lufax.common.exception.CSException;
import com.lufax.common.resources.gsonTemplate.PaginationGson;
import com.lufax.jersey.utils.Logger;
import com.lufax.print.domain.TaodaRecord;
import com.lufax.print.domain.TaodaRecordDetail;
import com.lufax.print.domain.TaodaRecordStatus;
import com.lufax.print.domain.TaodaUserType;
import com.lufax.print.domain.repository.TaodaRecordRepository;
import com.lufax.print.gson.TaodaRecordDetailGson;
import com.lufax.print.gson.TaodaRecordGson;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

@Service
public class TaodaRecordService {
	
	@Value("${nas.upload.temporary.path}")
	private String uploadTemporaryDirectory;
	
	@Autowired
	private TaodaRecordDetailGenerator taodaRecordDetailGenerator;
	
	@Autowired
	private TaodaRecordRepository taodaRecordRepository;
	
	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private TaodaZipFileGenerator taodaZipFileGenerator;

	@Transactional
	public long insert(TaodaUserType userType, List<String> useFor, String fileName, String operatorId){
		
		TaodaRecord record = new TaodaRecord(Long.parseLong(operatorId),userType, useFor);
		
		List<TaodaRecordDetail> recordDetailList = taodaRecordDetailGenerator.generate(record, getAbsoluteUploadFilePath(fileName));
		
		record.setTaodaRecordDetailList(recordDetailList);
		
		taodaRecordRepository.persist(record);
		
		return record.getId();
	}
	
	private String getAbsoluteUploadFilePath(String fileName){
		return uploadTemporaryDirectory + "/" + fileName;
	}

	@Transactional
	public PaginationGson queryForDetails(String recordId, int pageNum,	int pageSize) {
		
		TaodaRecord record = taodaRecordRepository.load(Long.parseLong(recordId));
		
		if(record == null){
			Logger.warn(this, String.format("taoda record was not found with id [%s]", recordId));
			throw new CSException(String.format("taoda record was not found with id [%s]", recordId));
		}
		
		long totalNum = taodaRecordRepository.countDetailList(record.getId());
		
		PaginationGson result = new PaginationGson(pageSize, totalNum, pageNum);
		
		if(totalNum == 0){
			return result;
		}
		
		List<TaodaRecordDetail> taodaRecordDetailList = taodaRecordRepository.findDetailList(record.getId(), (pageNum - 1) * pageSize, pageSize);
		
		List<TaodaRecordDetailGson> taodaRecordDetailGsonList = new ArrayList<TaodaRecordDetailGson>();
		for(TaodaRecordDetail detail : taodaRecordDetailList){
			taodaRecordDetailGsonList.add(new TaodaRecordDetailGson(detail));
		}
		result.setData(taodaRecordDetailGsonList);
		
		return result;
	}

	@Transactional
	public PaginationGson queryForRecord(String operatorName, Date createdAt, int pageNum, int pageSize) {
		
		long totalNum = taodaRecordRepository.count(operatorName, createdAt, Arrays.asList(TaodaRecordStatus.PROCESSING, TaodaRecordStatus.DONE));

		PaginationGson result = new PaginationGson(pageSize, totalNum, pageNum);
		
		if(totalNum == 0){
			return result;
		}
		List<TaodaRecord> taodaRecordList  = taodaRecordRepository.find(operatorName, createdAt, Arrays.asList(TaodaRecordStatus.PROCESSING, TaodaRecordStatus.DONE),(pageNum - 1) * pageSize, pageSize);
		
		List<TaodaRecordGson> taodaRecordGsonList = new ArrayList<TaodaRecordGson>();
		for(TaodaRecord record : taodaRecordList){
			User operator = userRepository.load(record.getOperatorId());
			taodaRecordGsonList.add(new TaodaRecordGson(record, operator.getUsername()));
		}
		result.setData(taodaRecordGsonList);
		
		return result;
	}

	@Transactional
	public void confirm(String recordId) {
		TaodaRecord record = taodaRecordRepository.load(Long.parseLong(recordId));
		//只对未经确认的记录更改状态
		if(record.getStatus().equals(TaodaRecordStatus.UNCONFIRMED)){
			record.setStatus(TaodaRecordStatus.PROCESSING);
			record.setUpdatedAt(new Date());
		}
	}

	public void generate() {
		
		//TODO
		int maxNum = 5;
		List<TaodaRecord> recordList = taodaRecordRepository.find(TaodaRecordStatus.PROCESSING, maxNum);
		
		if(recordList.size() == 0){
			Logger.info(this, "there is no taoda record found to generate pdf zip");
			return;
		}
		
		for(TaodaRecord record : recordList){
			try {
				String fileName = taodaZipFileGenerator.generate(record);
				record.setTargetFilePath(fileName);
				record.setStatus(TaodaRecordStatus.DONE);
				record.setUpdatedAt(new Date());
				taodaRecordRepository.update(record);
			} catch(Exception e){
				Logger.warn(this, "generate zip file failed with record " + record.getId(), e);
			}
		}
		
	}
	
	public String findAbsoluteZipFilePath(long recordId){
		TaodaRecord record = taodaRecordRepository.load(recordId);
		
		if(!record.getStatus().equals(TaodaRecordStatus.DONE)){
			Logger.warn(this, String.format("taoda record [%s] is not in status done", recordId));
			throw new CSException(String.format("套打记录[%s]还没有生成相关zip文件", recordId));
		}
		
		return taodaZipFileGenerator.findAbsoluteZipFilePath(record);
	}
}
