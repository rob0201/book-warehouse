package com.lufax.print.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.springframework.stereotype.Service;

import com.lufax.common.utils.CsvTableDataFileParser;
import com.lufax.common.utils.TableDataFileParser;
import com.lufax.jersey.utils.Logger;
import com.lufax.print.domain.TaodaRecord;
import com.lufax.print.domain.TaodaRecordDetail;

@Service
public class TaodaRecordDetailGenerator {

	public List<TaodaRecordDetail> generate(TaodaRecord record, String fileName) {

//        TableDataFileParser parser = new ExcellTableDataFileParser(fileName);
        TableDataFileParser parser = new CsvTableDataFileParser(fileName);

		int rowSize = parser.getRows();
		
		Logger.debug(this, String.format("the data in file [%s] has %s num of rows ", fileName, rowSize));
		
		if(rowSize <= 1){
			return Collections.emptyList();
		}
		
		List<TaodaRecordDetail> taodaRecordDetailList = new ArrayList<TaodaRecordDetail>();
		//数据内容从第二行开始获取
		for(int rowNum = 1; rowNum < rowSize; rowNum++){
			TaodaRecordDetail detail = createTaodaRecordDetail(record, parser, rowNum);
			taodaRecordDetailList.add(detail);
		}
		
		return taodaRecordDetailList;
	}

	private TaodaRecordDetail createTaodaRecordDetail(TaodaRecord record, TableDataFileParser parser, int rowNum) {
		
		TaodaRecordDetail detail = new TaodaRecordDetail();

		detail.setTaodaRecord(record);

        detail.setBusinessCode((String)parser.get(rowNum,0));
        detail.setPrincipal((String) parser.get(rowNum, 1));
        detail.setPeriod((String) parser.get(rowNum, 2));
        detail.setPledgePrincipal((String) parser.get(rowNum, 3));
        detail.setLoanerName((String) parser.get(rowNum, 4));
        detail.setLoanerIdentityNumber((String) parser.get(rowNum, 5));
        detail.setLoanerRegistName((String) parser.get(rowNum, 6));
        detail.setLoanerAddress((String) parser.get(rowNum, 7));
        detail.setLoanerPhoneNumber((String) parser.get(rowNum, 8));
        detail.setBankInfo((String) parser.get(rowNum, 9));
        detail.setBankCardNo((String) parser.get(rowNum, 10));
        detail.setInvestorName((String) parser.get(rowNum, 11));
        detail.setInvestorIdentityNumber((String) parser.get(rowNum, 12));
        detail.setInvestorRegistName((String) parser.get(rowNum, 13));
        detail.setInvestorAddress((String) parser.get(rowNum, 14));
        detail.setInvestorPhoneNumber((String) parser.get(rowNum, 15));
        detail.setInvestorNameAll((String) parser.get(rowNum, 16));
        detail.setInvestorIdentityNumberAll((String) parser.get(rowNum, 17));
        detail.setPledgeUserName((String) parser.get(rowNum, 18));
        detail.setPledgeUserIdentityType((String)parser.get(rowNum,19));
        detail.setPledgeUserIdentityNumber((String)parser.get(rowNum,20));
        detail.setPledgeUserAddress((String)parser.get(rowNum,21));
        detail.setPledgeUserPhoneNumber((String)parser.get(rowNum,22));
        detail.setSharedPersonName((String)parser.get(rowNum,23));
        detail.setSharedPersonIdentityNumber((String)parser.get(rowNum,24));
        detail.setHouseCertCode((String)parser.get(rowNum,25));
        detail.setPledgeAddress((String)parser.get(rowNum,26));
        detail.setNumOfRoom((String)parser.get(rowNum,27));
        detail.setHouseNumber((String)parser.get(rowNum,28));
        detail.setRoomNumber((String)parser.get(rowNum,29));
        detail.setProportion((String)parser.get(rowNum,30));
        detail.setPledgeType((String)parser.get(rowNum,31));
        detail.setHouseStatus((String)parser.get(rowNum,32));
        detail.setOtherPerson((String)parser.get(rowNum,33));
        detail.setOtherPersonPhoneNumber((String)parser.get(rowNum,34));
        detail.setOtherPersonIdentityNumber((String)parser.get(rowNum,35));
        detail.setOtherPersonIdType((String)parser.get(rowNum,36));
        detail.setPledgeGrantedPersonOne((String)parser.get(rowNum,37));
        detail.setPledgeGrantedPersonOneId((String)parser.get(rowNum,38));
        detail.setPledgeGrantedPersonTwo((String)parser.get(rowNum,39));
        detail.setPledgeGrantedPersonTwoId((String)parser.get(rowNum,40));
        detail.setReverseGuarantorName((String)parser.get(rowNum,41));
        detail.setReverseGuarantorId((String)parser.get(rowNum,42));
        detail.setReverseGuarantorAddress((String)parser.get(rowNum,43));
        detail.setReverseGuarantorPhoneNumber((String)parser.get(rowNum,44));
        detail.setLoanContractCode((String)parser.get(rowNum,45));
        detail.setLoanContractCodeAll((String)parser.get(rowNum,46));
        detail.setGuaranteeContractCode((String)parser.get(rowNum,47));
        detail.setGuaranteeContractCodeAll((String)parser.get(rowNum,48));
        detail.setPledgeContractCode((String)parser.get(rowNum,49));
        detail.setProxyGuaranteeContractCode((String)parser.get(rowNum,50));
        detail.setReverseContractCode((String)parser.get(rowNum,51));
        detail.setConsultContractCode((String)parser.get(rowNum,52));
        detail.setGrantPledgeContractCode((String)parser.get(rowNum,53));
        detail.setUseFor((String)parser.get(rowNum,54));
        detail.setInterestStartDate((String)parser.get(rowNum,55));
        detail.setFirstRepaymentDate((String)parser.get(rowNum,56));
        detail.setDeadLine((String)parser.get(rowNum,57));
        detail.setRepayDay((String)parser.get(rowNum,58));
        detail.setInterestRate((String)parser.get(rowNum,59));
        detail.setConsultRate((String)parser.get(rowNum,60));
        detail.setConsultAmount((String)parser.get(rowNum,61));
        detail.setGuaranteeAmount((String)parser.get(rowNum,62));
        detail.setOneRepaymentDate((String)parser.get(rowNum,63));
        detail.setOneInterestAmount((String)parser.get(rowNum,64));
        detail.setOnePrincipalAmount((String)parser.get(rowNum,65));
        detail.setOneTotalAmount((String)parser.get(rowNum,66));
        detail.setTwoRepaymentDate((String)parser.get(rowNum,67));
        detail.setTwoInterestAmount((String)parser.get(rowNum,68));
        detail.setTwoPrincipalAmount((String)parser.get(rowNum,69));
        detail.setTwoTotalAmount((String)parser.get(rowNum,70));
        detail.setThreeRepaymentDate((String)parser.get(rowNum,71));
        detail.setThreeInterestAmount((String)parser.get(rowNum,72));
        detail.setThreePrincipalAmount((String)parser.get(rowNum,73));
        detail.setThreeTotalAmount((String)parser.get(rowNum,74));
        detail.setFourRepaymentDate((String)parser.get(rowNum,75));
        detail.setFourInterestAmount((String)parser.get(rowNum,76));
        detail.setFourPrincipalAmount((String)parser.get(rowNum,77));
        detail.setFourTotalAmount((String)parser.get(rowNum,78));
        detail.setFiveRepaymentDate((String)parser.get(rowNum,79));
        detail.setFiveInterestAmount((String)parser.get(rowNum,80));
        detail.setFivePrincipalAmount((String)parser.get(rowNum,81));
        detail.setFiveTotalAmount((String)parser.get(rowNum,82));
        detail.setSixRepaymentDate((String)parser.get(rowNum,83));
        detail.setSixInterestAmount((String)parser.get(rowNum,84));
        detail.setSixPrincipalAmount((String)parser.get(rowNum,85));
        detail.setSixTotalAmount((String)parser.get(rowNum,86));

        Logger.info(this, "taoda record detail is : " + detail.toString());

		return detail;
	}

}
