package com.lufax.print.service;

import java.io.File;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.lufax.common.exception.CSException;
import com.lufax.common.utils.DateUtils;
import com.lufax.common.utils.StringUtils;
import com.lufax.common.utils.ZipUtils;
import com.lufax.jersey.utils.Logger;
import com.lufax.print.domain.TaodaRecord;
import com.lufax.print.domain.TaodaRecordDetail;

@Service
public class TaodaZipFileGenerator {
	
	@Value("${nas.taoda.zip.path}")
	private String taodaRootDirectory;
	
	@Autowired
	private ContractTaodaPrinterFactory contractPrinterFactory;

	public String generate(TaodaRecord record) {
		
		String[] contractTypes = record.getUseFor().split(";");

		String contractRootDirectoryPath = getRooDirectoryPath(record);

        Logger.debug(this, "contract root directory path is " + contractRootDirectoryPath);
		
		//创建zip包一级目录
		File contractRootDirectory = new File(contractRootDirectoryPath);

		if(!contractRootDirectory.mkdirs()){
			Logger.warn(this, "mkdir failed for directory path : " + contractRootDirectoryPath);
			throw new CSException("mkdir failed for directory path : " + contractRootDirectoryPath);
		}
		
		List<TaodaRecordDetail> taodaDetailList = record.getTaodaRecordDetailList();
		
		for(TaodaRecordDetail recordDetail : taodaDetailList){
			
			String recordDetailDirectoryPath = getRecordDetailDirectoryName(recordDetail);

            Logger.debug(this, "record detail directory path is " + recordDetailDirectoryPath);
			
			//创建二级目录
			File recordDetailDirectory = new File(contractRootDirectory, recordDetailDirectoryPath);
			recordDetailDirectory.mkdir();
			
			//生成套打合同pdf
			for(String contractType : contractTypes){
				contractPrinterFactory.get(contractType).generate(recordDetailDirectory, record, recordDetail);
			}
		}

        String zipFileName = getRooDirectoryName(record) + ".zip";
        String zipFilePath = findAbsoluteZipFilePath(record);

        Logger.debug(this, String.format("zip file path is [%s] , zip is [%s]", zipFilePath, zipFileName));

        ZipUtils.createZipFile(contractRootDirectory, zipFilePath);

		return zipFileName;
	}
	
	private String getRooDirectoryName(TaodaRecord record) {
		String[] dayTime = DateUtils.format(DateUtils.DATE_FORMAT_TAODA_DIRECTORY, record.getCreatedAt()).split(" ");
		return "安业贷" + record.getUserType().getDescription() + "协议套打_" + dayTime[0] + "_" + dayTime[1];
	}

	private String getRooDirectoryPath(TaodaRecord record) {
		return taodaRootDirectory + "/" + getRooDirectoryName(record);
	}

	public String findAbsoluteZipFilePath(TaodaRecord record){
		return getRooDirectoryPath(record) + ".zip";
	}

	private String getRecordDetailDirectoryName(TaodaRecordDetail recordDetail) {
		return StringUtils.toString(recordDetail.getId()) + "_" 
				+ StringUtils.toString(recordDetail.getLoanerName()) + "_"
				+ StringUtils.toString(recordDetail.getBusinessCode()) + "_"
				+ StringUtils.toString(recordDetail.getInvestorName()) + "_"
				+ StringUtils.toString(recordDetail.getInvestorIdentityNumber());
	}
}
