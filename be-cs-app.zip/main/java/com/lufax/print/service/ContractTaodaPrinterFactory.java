package com.lufax.print.service;

import java.util.HashMap;
import java.util.Map;

import com.lufax.common.exception.CSException;
import com.lufax.jersey.utils.Logger;
import com.lufax.print.service.printer.ContractTaodaPrinter;


public class ContractTaodaPrinterFactory {

	private Map<String, ContractTaodaPrinter> mapping = new HashMap<String, ContractTaodaPrinter>();
	
	public void setMapping(Map<String, ContractTaodaPrinter> mapping) {
		this.mapping = mapping;
	}

	public ContractTaodaPrinter get(String contractType) {
		
		ContractTaodaPrinter printer = mapping.get(contractType);
		
		if(printer == null){
			Logger.warn(this, String.format("no contract taoda printer is defined for contractType %s", contractType));
			throw new CSException(String.format("no contract taoda printer is defined for contractType %s", contractType));
		}
		
		return printer;
	}
}
