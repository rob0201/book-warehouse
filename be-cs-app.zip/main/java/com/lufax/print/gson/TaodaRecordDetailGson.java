package com.lufax.print.gson;

import com.lufax.print.domain.TaodaRecordDetail;


public class TaodaRecordDetailGson {

    private long id;
    private long taodaRecordId;
    private String businessCode;
    private String principal;
    private String period;
    private String pledgePrincipal;
    private String loanerName;
    private String loanerIdentityNumber;
    private String loanerRegistName;
    private String loanerAddress;
    private String loanerPhoneNumber;
    private String bankInfo;
    private String bankCardNo;
    private String investorName;
    private String investorIdentityNumber;
    private String investorRegistName;
    private String investorAddress;
    private String investorPhoneNumber;
    private String investorNameAll;
    private String investorIdentityNumberAll;
    private String pledgeUserName;
    private String pledgeUserIdentityType;
    private String pledgeUserIdentityNumber;
    private String pledgeUserAddress;
    private String pledgeUserPhoneNumber;
    private String sharedPersonName;
    private String sharedPersonIdentityNumber;
    private String houseCertCode;
    private String pledgeAddress;
    private String numOfRoom;
    private String houseNumber;
    private String roomNumber;
    private String proportion;
    private String pledgeType;
    private String houseStatus;
    private String otherPerson;
    private String otherPersonPhoneNumber;
    private String otherPersonIdentityNumber;
    private String otherPersonIdType;
    private String pledgeGrantedPersonOne;
    private String pledgeGrantedPersonOneId;
    private String pledgeGrantedPersonTwo;
    private String pledgeGrantedPersonTwoId;
    private String reverseGuarantorName;
    private String reverseGuarantorId;
    private String reverseGuarantorAddress;
    private String reverseGuarantorPhoneNumber;
    private String loanContractCode;
    private String loanContractCodeAll;
    private String guaranteeContractCode;
    private String guaranteeContractCodeAll;
    private String pledgeContractCode;
    private String proxyGuaranteeContractCode;
    private String reverseContractCode;
    private String consultContractCode;
    private String grantPledgeContractCode;
    private String useFor;
    private String interestStartDate;
    private String firstRepaymentDate;
    private String deadLine;
    private String repayDay;
    private String interestRate;
    private String consultRate;
    private String consultAmount;
    private String guaranteeAmount;
    private String oneRepaymentDate;
    private String oneInterestAmount;
    private String onePrincipalAmount;
    private String oneTotalAmount;
    private String twoRepaymentDate;
    private String twoInterestAmount;
    private String twoPrincipalAmount;
    private String twoTotalAmount;
    private String threeRepaymentDate;
    private String threeInterestAmount;
    private String threePrincipalAmount;
    private String threeTotalAmount;
    private String fourRepaymentDate;
    private String fourInterestAmount;
    private String fourPrincipalAmount;
    private String fourTotalAmount;
    private String fiveRepaymentDate;
    private String fiveInterestAmount;
    private String fivePrincipalAmount;
    private String fiveTotalAmount;
    private String sixRepaymentDate;
    private String sixInterestAmount;
    private String sixPrincipalAmount;
    private String sixTotalAmount;

	public TaodaRecordDetailGson(TaodaRecordDetail detail) {
		this.id = detail.getId();
		this.taodaRecordId = detail.getTaodaRecord().getId();
		this.businessCode = detail.getBusinessCode();
        this.principal = detail.getPrincipal();
        this.period = detail.getPeriod();
        this.pledgePrincipal = detail.getPledgePrincipal();
        this.loanerName = detail.getLoanerName();
        this.loanerIdentityNumber = detail.getLoanerIdentityNumber();
        this.loanerRegistName = detail.getLoanerRegistName();
        this.loanerAddress = detail.getLoanerAddress();
        this.loanerPhoneNumber = detail.getLoanerPhoneNumber();
        this.bankInfo = detail.getBankInfo();
        this.bankCardNo =detail.getBankCardNo();
        this.investorName = detail.getInvestorName();
        this.investorIdentityNumber = detail.getInvestorIdentityNumber();
        this.investorRegistName = detail.getInvestorRegistName();
        this.investorAddress = detail.getInvestorAddress();
        this.investorPhoneNumber = detail.getInvestorPhoneNumber();
        this.investorNameAll = detail.getInvestorNameAll();
        this.investorIdentityNumberAll = detail.getInvestorIdentityNumberAll();
        this.pledgeUserName = detail.getPledgeUserName();
        this.pledgeUserIdentityType = detail.getPledgeUserIdentityType();
        this.pledgeUserIdentityNumber = detail.getPledgeUserIdentityNumber();
        this.pledgeUserAddress = detail.getPledgeUserAddress();
        this.pledgeUserPhoneNumber = detail.getPledgeUserPhoneNumber();
        this.sharedPersonName = detail.getSharedPersonName();
        this.sharedPersonIdentityNumber = detail.getSharedPersonIdentityNumber();
        this.houseCertCode = detail.getHouseCertCode();
        this.pledgeAddress = detail.getPledgeAddress();
        this.numOfRoom = detail.getNumOfRoom();
        this.houseNumber = detail.getHouseNumber();
        this.roomNumber = detail.getRoomNumber();
        this.proportion = detail.getProportion();
        this.pledgeType = detail.getPledgeType();
        this.houseStatus = detail.getHouseStatus();
        this.otherPerson = detail.getOtherPerson();
        this.otherPersonPhoneNumber = detail.getOtherPersonPhoneNumber();
        this.otherPersonIdentityNumber = detail.getOtherPersonIdentityNumber();
        this.otherPersonIdType = detail.getOtherPersonIdType();
        this.pledgeGrantedPersonOne = detail.getPledgeGrantedPersonOne();
        this.pledgeGrantedPersonOneId = detail.getPledgeGrantedPersonOneId();
        this.pledgeGrantedPersonTwo = detail.getPledgeGrantedPersonTwo();
        this.pledgeGrantedPersonTwoId = detail.getPledgeGrantedPersonTwoId();
        this.reverseGuarantorName = detail.getReverseGuarantorName();
        this.reverseGuarantorId = detail.getReverseGuarantorId();
        this.reverseGuarantorAddress = detail.getReverseGuarantorAddress();
        this.reverseGuarantorPhoneNumber = detail.getReverseGuarantorPhoneNumber();
        this.loanContractCode = detail.getLoanContractCode();
        this.loanContractCodeAll = detail.getLoanContractCodeAll();
        this.guaranteeContractCode = detail.getGuaranteeContractCode();
        this.guaranteeContractCodeAll = detail.getGuaranteeContractCodeAll();
        this.pledgeContractCode = detail.getPledgeContractCode();
        this.proxyGuaranteeContractCode = detail.getProxyGuaranteeContractCode();
        this.reverseContractCode = detail.getReverseContractCode();
        this.consultContractCode = detail.getConsultContractCode();
        this.grantPledgeContractCode = detail.getGrantPledgeContractCode();
        this.useFor = detail.getUseFor();
        this.interestStartDate = detail.getInterestStartDate();
        this.firstRepaymentDate = detail.getFirstRepaymentDate();
        this.deadLine = detail.getDeadLine();
        this.repayDay = detail.getRepayDay();
        this.interestRate = detail.getInterestRate();
        this.consultRate = detail.getConsultRate();
        this.consultAmount = detail.getConsultAmount();
        this.guaranteeAmount = detail.getGuaranteeAmount();
        
        this.oneRepaymentDate = detail.getOneRepaymentDate();
        this.oneInterestAmount = detail.getOneInterestAmount();
        this.onePrincipalAmount = detail.getOnePrincipalAmount();
        this.oneTotalAmount = detail.getOneTotalAmount();
        this.twoRepaymentDate = detail.getTwoRepaymentDate();
        this.twoInterestAmount = detail.getTwoInterestAmount();
        this.twoPrincipalAmount = detail.getTwoPrincipalAmount();
        this.twoTotalAmount = detail.getTwoTotalAmount();
        this.threeRepaymentDate = detail.getThreeRepaymentDate();
        this.threeInterestAmount = detail.getThreeInterestAmount();
        this.threePrincipalAmount = detail.getThreePrincipalAmount();
        this.threeTotalAmount = detail.getThreeTotalAmount();
        this.fourRepaymentDate = detail.getFourRepaymentDate();
        this.fourInterestAmount = detail.getFourInterestAmount();
        this.fourPrincipalAmount = detail.getFourPrincipalAmount();
        this.fourTotalAmount = detail.getFourTotalAmount();
        this.fiveRepaymentDate = detail.getFiveRepaymentDate();
        this.fiveInterestAmount = detail.getFiveInterestAmount();
        this.fivePrincipalAmount = detail.getFivePrincipalAmount();
        this.fiveTotalAmount = detail.getFiveTotalAmount();
        this.sixRepaymentDate = detail.getSixRepaymentDate();
        this.sixInterestAmount = detail.getSixInterestAmount();
        this.sixPrincipalAmount = detail.getSixPrincipalAmount();
        this.sixTotalAmount = detail.getSixTotalAmount();
	}

    public long getId() {
        return id;
    }

    public long getTaodaRecordId() {
        return taodaRecordId;
    }

    public String getBusinessCode() {
        return businessCode;
    }

    public String getPrincipal() {
        return principal;
    }

    public String getPeriod() {
		return period;
	}

	public String getPledgePrincipal() {
        return pledgePrincipal;
    }

    public String getLoanerName() {
        return loanerName;
    }

    public String getLoanerIdentityNumber() {
        return loanerIdentityNumber;
    }

    public String getLoanerRegistName() {
        return loanerRegistName;
    }

    public String getLoanerAddress() {
        return loanerAddress;
    }

    public String getLoanerPhoneNumber() {
        return loanerPhoneNumber;
    }

    public String getBankInfo() {
        return bankInfo;
    }

    public String getBankCardNo() {
        return bankCardNo;
    }

    public String getInvestorName() {
        return investorName;
    }

    public String getInvestorIdentityNumber() {
        return investorIdentityNumber;
    }

    public String getInvestorRegistName() {
        return investorRegistName;
    }

    public String getInvestorAddress() {
        return investorAddress;
    }

    public String getInvestorPhoneNumber() {
        return investorPhoneNumber;
    }

    public String getInvestorNameAll() {
        return investorNameAll;
    }

    public String getInvestorIdentityNumberAll() {
        return investorIdentityNumberAll;
    }

    public String getPledgeUserName() {
        return pledgeUserName;
    }

    public String getPledgeUserIdentityType() {
        return pledgeUserIdentityType;
    }

    public String getPledgeUserIdentityNumber() {
        return pledgeUserIdentityNumber;
    }

    public String getPledgeUserAddress() {
        return pledgeUserAddress;
    }

    public String getPledgeUserPhoneNumber() {
        return pledgeUserPhoneNumber;
    }

    public String getSharedPersonName() {
        return sharedPersonName;
    }

    public String getSharedPersonIdentityNumber() {
        return sharedPersonIdentityNumber;
    }

    public String getHouseCertCode() {
        return houseCertCode;
    }

    public String getPledgeAddress() {
        return pledgeAddress;
    }

    public String getNumOfRoom() {
        return numOfRoom;
    }

    public String getHouseNumber() {
        return houseNumber;
    }

    public String getRoomNumber() {
        return roomNumber;
    }

    public String getProportion() {
        return proportion;
    }

    public String getPledgeType() {
        return pledgeType;
    }

    public String getHouseStatus() {
        return houseStatus;
    }

    public String getOtherPerson() {
        return otherPerson;
    }

    public String getOtherPersonPhoneNumber() {
        return otherPersonPhoneNumber;
    }

    public String getOtherPersonIdentityNumber() {
        return otherPersonIdentityNumber;
    }

    public String getOtherPersonIdType() {
        return otherPersonIdType;
    }

    public String getPledgeGrantedPersonOne() {
        return pledgeGrantedPersonOne;
    }

    public String getPledgeGrantedPersonOneId() {
        return pledgeGrantedPersonOneId;
    }

    public String getPledgeGrantedPersonTwo() {
        return pledgeGrantedPersonTwo;
    }

    public String getPledgeGrantedPersonTwoId() {
        return pledgeGrantedPersonTwoId;
    }

    public String getReverseGuarantorName() {
        return reverseGuarantorName;
    }

    public String getReverseGuarantorId() {
        return reverseGuarantorId;
    }

    public String getReverseGuarantorAddress() {
        return reverseGuarantorAddress;
    }

    public String getReverseGuarantorPhoneNumber() {
        return reverseGuarantorPhoneNumber;
    }

    public String getLoanContractCode() {
        return loanContractCode;
    }

    public String getLoanContractCodeAll() {
        return loanContractCodeAll;
    }

    public String getGuaranteeContractCode() {
        return guaranteeContractCode;
    }

    public String getGuaranteeContractCodeAll() {
        return guaranteeContractCodeAll;
    }

    public String getPledgeContractCode() {
        return pledgeContractCode;
    }

    public String getProxyGuaranteeContractCode() {
        return proxyGuaranteeContractCode;
    }

    public String getReverseContractCode() {
        return reverseContractCode;
    }

    public String getConsultContractCode() {
        return consultContractCode;
    }

    public String getGrantPledgeContractCode() {
        return grantPledgeContractCode;
    }

    public String getUseFor() {
        return useFor;
    }

    public String getInterestStartDate() {
        return interestStartDate;
    }

    public String getFirstRepaymentDate() {
        return firstRepaymentDate;
    }

    public String getDeadLine() {
        return deadLine;
    }

    public String getRepayDay() {
        return repayDay;
    }

    public String getInterestRate() {
        return interestRate;
    }

    public String getConsultRate() {
        return consultRate;
    }

    public String getConsultAmount() {
        return consultAmount;
    }

    public String getGuaranteeAmount() {
        return guaranteeAmount;
    }

	public String getOneRepaymentDate() {
		return oneRepaymentDate;
	}

	public String getOneInterestAmount() {
		return oneInterestAmount;
	}

	public String getOnePrincipalAmount() {
		return onePrincipalAmount;
	}

	public String getOneTotalAmount() {
		return oneTotalAmount;
	}

	public String getTwoRepaymentDate() {
		return twoRepaymentDate;
	}

	public String getTwoInterestAmount() {
		return twoInterestAmount;
	}

	public String getTwoPrincipalAmount() {
		return twoPrincipalAmount;
	}

	public String getTwoTotalAmount() {
		return twoTotalAmount;
	}

	public String getThreeRepaymentDate() {
		return threeRepaymentDate;
	}

	public String getThreeInterestAmount() {
		return threeInterestAmount;
	}

	public String getThreePrincipalAmount() {
		return threePrincipalAmount;
	}

	public String getThreeTotalAmount() {
		return threeTotalAmount;
	}

	public String getFourRepaymentDate() {
		return fourRepaymentDate;
	}

	public String getFourInterestAmount() {
		return fourInterestAmount;
	}

	public String getFourPrincipalAmount() {
		return fourPrincipalAmount;
	}

	public String getFourTotalAmount() {
		return fourTotalAmount;
	}

	public String getFiveRepaymentDate() {
		return fiveRepaymentDate;
	}

	public String getFiveInterestAmount() {
		return fiveInterestAmount;
	}

	public String getFivePrincipalAmount() {
		return fivePrincipalAmount;
	}

	public String getFiveTotalAmount() {
		return fiveTotalAmount;
	}

	public String getSixRepaymentDate() {
		return sixRepaymentDate;
	}

	public String getSixInterestAmount() {
		return sixInterestAmount;
	}

	public String getSixPrincipalAmount() {
		return sixPrincipalAmount;
	}

	public String getSixTotalAmount() {
		return sixTotalAmount;
	}
}
