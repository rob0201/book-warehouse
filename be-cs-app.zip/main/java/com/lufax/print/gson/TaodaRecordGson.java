package com.lufax.print.gson;

import com.lufax.common.utils.DateUtils;
import com.lufax.print.domain.TaodaRecord;

public class TaodaRecordGson {
	
	private long id;
	private String createdAtDate;
	private String createdAtTime;
	private String operatorName;
	private String targetFileName;
	private String status;

	public TaodaRecordGson(TaodaRecord record, String operatorName) {
		
		this.id = record.getId();
		
		String createdAtDateTime[] = DateUtils.format(DateUtils.DATE_TIME_FORMAT_DEFAULT, record.getCreatedAt()).split(" ");
		
		this.createdAtDate = createdAtDateTime[0];
		this.createdAtTime = createdAtDateTime[1];
		this.operatorName = operatorName;
		this.targetFileName = record.getTargetFilePath();
		this.status = record.getStatus().getDescription();
	}
	
	public long getId() {
		return id;
	}

	public String getCreatedAtDate() {
		return createdAtDate;
	}

	public String getCreatedAtTime() {
		return createdAtTime;
	}

	public String getOperatorName() {
		return operatorName;
	}

	public String getTargetFileName() {
		return targetFileName;
	}

	public String getStatus() {
		return status;
	}

}
