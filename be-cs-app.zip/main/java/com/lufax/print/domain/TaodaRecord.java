package com.lufax.print.domain;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="BE_CS_TAODA_RECORD")
public class TaodaRecord {
	@Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_BE_CS_TAODA_RECORD")
    @SequenceGenerator(name = "SEQ_BE_CS_TAODA_RECORD", sequenceName = "SEQ_BE_CS_TAODA_RECORD", allocationSize = 1)
    private Long id;
	
	@Column(name = "OPERATOR_ID")
    private long operatorId;
	
	@Column(name = "TARGET_FILE_PATH")
	private String targetFilePath;

	@Enumerated(EnumType.STRING)
	@Column(name = "STATUS")
	private TaodaRecordStatus status;

	@Enumerated(EnumType.STRING)
	@Column(name = "USER_TYPE")
	private TaodaUserType userType;
	
	@Column(name = "USE_FOR")
	private String useFor;

	@Column(name = "CREATED_AT") 
    private Date createdAt;

	@Column(name = "UPDATED_AT") 
    private Date updatedAt;
	
	@OneToMany(mappedBy = "taodaRecord", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	private List<TaodaRecordDetail> taodaRecordDetailList;

	public TaodaRecord() {
	}

	public TaodaRecord(long operatorId, TaodaUserType userType, List useForList) {
		this.operatorId = operatorId;
		this.userType = userType;
		this.useFor = convertTaodaUseFor(useForList);
		this.status = TaodaRecordStatus.UNCONFIRMED;
		this.createdAt = this.updatedAt = new Date();
	}
	
	private String convertTaodaUseFor(List<String> useForList){
		String useFor = "";
		
		for(int i = 0; i < useForList.size(); i++){
			if(i == useForList.size() - 1){
				useFor += useForList.get(i);
			} else {
				useFor += useForList.get(i) + ";";
			}
		}
		return useFor;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public long getOperatorId() {
		return operatorId;
	}

	public void setOperatorId(long operatorId) {
		this.operatorId = operatorId;
	}

	public String getTargetFilePath() {
		return targetFilePath;
	}

	public void setTargetFilePath(String targetFilePath) {
		this.targetFilePath = targetFilePath;
	}

	public TaodaRecordStatus getStatus() {
		return status;
	}

	public void setStatus(TaodaRecordStatus status) {
		this.status = status;
	}
	
	public TaodaUserType getUserType() {
		return userType;
	}

	public void setUserType(TaodaUserType userType) {
		this.userType = userType;
	}

	public String getUseFor() {
		return useFor;
	}

	public void setUseFor(String useFor) {
		this.useFor = useFor;
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public Date getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	public List<TaodaRecordDetail> getTaodaRecordDetailList() {
		return taodaRecordDetailList;
	}

	public void setTaodaRecordDetailList(
			List<TaodaRecordDetail> taodaRecordDetailList) {
		this.taodaRecordDetailList = taodaRecordDetailList;
	} 
}
