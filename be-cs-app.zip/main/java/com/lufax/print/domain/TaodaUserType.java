package com.lufax.print.domain;

public enum TaodaUserType {
	
	INVESTOR("投资人"),LOANER("借款人");
	
	private String description;
	
	private TaodaUserType(String description){
		this.description = description;
	}

	public String getDescription() {
		return description;
	}

}
