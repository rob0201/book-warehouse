package com.lufax.print.domain;

public enum TaodaRecordStatus {

	UNCONFIRMED("未确认"),PROCESSING("处理中"),DONE("完成");
	
	private String description;
	
	private TaodaRecordStatus(String description){
		this.description = description;
	}

	public String getDescription() {
		return description;
	}
}
