package com.lufax.print.domain.repository;

import java.util.Date;
import java.util.List;

import javax.persistence.TypedQuery;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateUtils;
import org.springframework.stereotype.Repository;

import com.lufax.common.domain.repository.BaseRepository;
import com.lufax.print.domain.TaodaRecord;
import com.lufax.print.domain.TaodaRecordDetail;
import com.lufax.print.domain.TaodaRecordStatus;

@Repository
public class TaodaRecordRepository extends BaseRepository<TaodaRecord>{

	public long countDetailList(long recordId) {
		String hql = "select count(d) from TaodaRecordDetail d where d.taodaRecord.id = :recordId";
		return entityManager.createQuery(hql, Long.class).setParameter("recordId", recordId).getSingleResult();
	}

	public List<TaodaRecordDetail> findDetailList(long recordId, int offset, int pageSize) {
		String hql = "select d from TaodaRecordDetail d where d.taodaRecord.id = :recordId order by d.id";
		return entityManager.createQuery(hql, TaodaRecordDetail.class).setParameter("recordId", recordId).setFirstResult(offset).setMaxResults(pageSize).getResultList();
	}

	public long count(String operatorName, Date createdAt, List<TaodaRecordStatus> statusList) {
		
		String hql;
		

		Date createdAtEnd = null;
		
		if(StringUtils.isNotBlank(operatorName)){
			hql = "select count(r) from TaodaRecord r, com.lufax.common.domain.User u where r.status in (:statusList) and r.operatorId = u.id and u.credential.username like :operatorName and u.userRole = 'OPERATOR' ";
		} else {
			hql = "select count(r) from TaodaRecord r where r.status in (:statusList) ";
		}
		
		if(createdAt != null){
			createdAtEnd = DateUtils.addDays(createdAt, 1);
            hql += "and r.createdAt >= :createdAt and r.createdAt < :createdAtEnd ";
		}
		
		TypedQuery<Long> query = entityManager.createQuery(hql, Long.class);
        query.setParameter("statusList", statusList);
		if(StringUtils.isNotBlank(operatorName)){
			query.setParameter("operatorName", "%" + operatorName.toUpperCase() + "%");
		}
		if(createdAt != null){
			query.setParameter("createdAt", createdAt).setParameter("createdAtEnd", createdAtEnd);
		}
		return query.getSingleResult();
	}

	public List<TaodaRecord> find(String operatorName, Date createdAt, List<TaodaRecordStatus> statusList, int offset, int pageSize) {
		
		String hql;
		
		Date createdAtEnd = null;
		
		if(StringUtils.isNotBlank(operatorName)){
			hql = "select r from TaodaRecord r, com.lufax.common.domain.User u where r.status in (:statusList) and r.operatorId = u.id and u.credential.username like :operatorName and u.userRole = 'OPERATOR' ";
		} else {
			hql = "select r from TaodaRecord r where r.status in (:statusList) ";
		}
		
		if(createdAt != null){
			createdAtEnd = DateUtils.addDays(createdAt, 1);
            hql += "and r.createdAt >= :createdAt and r.createdAt < :createdAtEnd ";
		}
		
		hql += "order by r.id desc";
		
		TypedQuery<TaodaRecord> query = entityManager.createQuery(hql, TaodaRecord.class);
        query.setParameter("statusList", statusList);
		if(StringUtils.isNotBlank(operatorName)){
			query.setParameter("operatorName", "%" + operatorName.toUpperCase() + "%");
		}
		if(createdAt != null){
			query.setParameter("createdAt", createdAt).setParameter("createdAtEnd", createdAtEnd);
		}
		return query.setFirstResult(offset).setMaxResults(pageSize).getResultList();
	}

	public List<TaodaRecord> find(TaodaRecordStatus status, int maxNum) {
		String hql = "select r from TaodaRecord r where r.status = :status order by id";
		return entityManager.createQuery(hql, TaodaRecord.class).setParameter("status", status).setMaxResults(maxNum).getResultList();
	}


}
