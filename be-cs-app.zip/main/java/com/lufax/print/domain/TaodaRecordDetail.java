package com.lufax.print.domain;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="BE_CS_TAODA_RECORD_DETAIL")
public class TaodaRecordDetail {
	@Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_BE_CS_TAODA_RECORD_DETAIL")
    @SequenceGenerator(name = "SEQ_BE_CS_TAODA_RECORD_DETAIL", sequenceName = "SEQ_BE_CS_TAODA_RECORD_DETAIL", allocationSize = 1)
    private Long id;

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "TAODA_RECORD_ID")
    private TaodaRecord taodaRecord;

    //业务编号
	@Column(name = "BUSINESS_CODE")
	private String businessCode;

    //借款本金
    @Column(name = "PRINCIPAL")
    private String principal;
    
    //借款期限
    @Column(name = "PERIOD")
    private String period;

    //抵押金额
    @Column(name = "PLEDGE_PRINCIPAL")
    private String pledgePrincipal;

    //借款人姓名
    @Column(name = "LOANER_NAME")
    private String loanerName;

    //借款人身份证号
    @Column(name = "LOANER_IDENTITY_NUMBER")
    private String loanerIdentityNumber;

    //借款人陆金所用户名
    @Column(name = "LOANER_REGIST_NAME")
    private String loanerRegistName;

    //借款人联系地址
    @Column(name = "LOANER_ADDRESS")
    private String loanerAddress;

    //借款人联系电话
    @Column(name = "LOANER_PHONE_NUMBER")
    private String loanerPhoneNumber;

    //银行开户行
    @Column(name = "BANK_INFO")
    private String bankInfo;

    //银行帐号
    @Column(name = "BANK_CARD_NO")
    private String bankCardNo;

    //出借人姓名
	@Column(name = "INVESTOR_NAME")
	private String investorName;

    //出借人身份证号
	@Column(name = "INVESTOR_IDENTITY_NUMBER")
	private String investorIdentityNumber;

    //出借人陆金所用户名
    @Column(name = "INVESTOR_REGIST_NAME")
    private String investorRegistName;

    //出借人联系地址
	@Column(name = "INVESTOR_ADDRESS")
	private String investorAddress;

    //出借人联系电话
	@Column(name = "INVESTOR_PHONE_NUMBER")
	private String investorPhoneNumber;

    //出借人姓名(全)
    @Column(name = "INVESTOR_NAME_ALL")
    private String investorNameAll;

    //出借人身份证号(全)
    @Column(name = "INVESTOR_IDENTITY_NUMBER_ALL")
    private String investorIdentityNumberAll;

    //抵押人姓名
    @Column(name = "PLEDGE_USER_NAME")
    private String pledgeUserName;

    //抵押人证件类型
    @Column(name = "PLEDGE_USER_IDENTITY_TYPE")
    private String pledgeUserIdentityType;

    //抵押人身份证号
    @Column(name = "PLEDGE_USER_IDENTITY_NUMBER")
    private String pledgeUserIdentityNumber;

    //抵押人联系地址
    @Column(name = "PLEDGE_USER_ADDRESS")
    private String pledgeUserAddress;

    //抵押人联系地址
    @Column(name = "PLEDGE_USER_PHONE_NUMBER")
    private String pledgeUserPhoneNumber;

    //共有人姓名
    @Column(name = "SHARED_PERSON_NAME")
    private String sharedPersonName;

    //共有人身份证号
    @Column(name = "SHARED_PERSON_IDENTITY_NUMBER")
    private String sharedPersonIdentityNumber;

    //房产权利证号
    @Column(name = "HOUSE_CERT_CODE")
    private String houseCertCode;

    //抵押物地址
    @Column(name = "PLEDGE_ADDRESS")
    private String pledgeAddress;

    //房间套数
    @Column(name = "NUM_OF_ROOM")
    private String numOfRoom;

    //幢号
    @Column(name = "HOUSE_NUMBER")
    private String houseNumber;

    //室号
    @Column(name = "ROOM_NUMBER")
    private String roomNumber;

    //建筑面积
    @Column(name = "PROPORTION")
    private String proportion;

    //抵押权利种类
    @Column(name = "PLEDGE_TYPE")
    private String pledgeType;

    //建筑面积
    @Column(name = "HOUSE_STATUS")
    private String houseStatus;

    //他项权利人
    @Column(name = "OTHER_PERSON")
    private String otherPerson;

    //他项权利人联系电话
    @Column(name = "OTHER_PERSON_PHONE_NUMBER")
    private String otherPersonPhoneNumber;

    //他项权利人证件号码
    @Column(name = "OTHER_PERSON_ID_NUMBER")
    private String otherPersonIdentityNumber;

    //他项权利人证件类别
    @Column(name = "OTHER_PERSON_ID_TYPE")
    private String otherPersonIdType;

    //抵押授权委托人1
    @Column(name = "PLEDGE_GRANT_PERSON_ONE")
    private String pledgeGrantedPersonOne;

    //抵押授权委托人1身份证号
    @Column(name = "PLEDGE_GRANT_PERSON_ONE_ID")
    private String pledgeGrantedPersonOneId;

    //抵押授权委托人2
    @Column(name = "PLEDGE_GRANT_PERSON_TWO")
    private String pledgeGrantedPersonTwo;

    //抵押授权委托人2身份证号
    @Column(name = "PLEDGE_GRANT_PERSON_TWO_ID")
    private String pledgeGrantedPersonTwoId;

    //反担保专用保证人姓名
    @Column(name = "REVERSE_GUARANTOR_NAME")
    private String reverseGuarantorName;

    //反担保专用保证人身份证号
    @Column(name = "REVERSE_GUARANTOR_ID")
    private String reverseGuarantorId;

    //反担保专用保证人联系地址
    @Column(name = "REVERSE_GUARANTOR_Address")
    private String reverseGuarantorAddress;

    //反担保专用保证人联系电话
    @Column(name = "REVERSE_GUARANTOR_PHONE")
    private String reverseGuarantorPhoneNumber;

    //借款合同编号
    @Column(name = "LOAN_CONTRACT_CODE")
    private String loanContractCode;

    //借款合同编号(全)
    @Column(name = "LOAN_CONTRACT_CODE_ALL")
    private String loanContractCodeAll;

    //保证合同编号
    @Column(name = "GUARANTEE_CONTRACT_CODE")
    private String guaranteeContractCode;

    //保证合同编号(全)
    @Column(name = "GUARANTEE_CONTRACT_CODE_ALL")
    private String guaranteeContractCodeAll;

    //抵押合同编号
    @Column(name = "PLEDGE_CONTRACT_CODE")
    private String pledgeContractCode;

    //委托担保合同编号
    @Column(name = "PROXY_GUARANTEE_CONTRACT_CODE")
    private String proxyGuaranteeContractCode;

    //反担保专用合同编号
    @Column(name = "REVERSE_CONTRACT_CODE")
    private String reverseContractCode;

    //咨询服务协议编号
    @Column(name = "CONSULT_CONTRACT_CODE")
    private String consultContractCode;

    //办理抵押授权委托书编号
    @Column(name = "GRANT_PLEDGE_CONTRACT_CODE")
    private String grantPledgeContractCode;

    //借款用途
    @Column(name = "USE_FOR")
    private String useFor;

    //起息日
    @Column(name = "INTEREST_START_DATE")
    private String interestStartDate;

    //首次还息日
    @Column(name = "FIRST_REPAYMENT_DATE")
    private String firstRepaymentDate;

    //借款到期日
    @Column(name = "DEAD_LINE")
    private String deadLine;

    //结息日
	@Column(name = "REPAY_DAY")
	private String repayDay;

    //借款利率
    @Column(name = "INTEREST_RATE")
    private String interestRate;

    //咨询服务费率
    @Column(name = "CONSULT_RATE")
    private String consultRate;

    //咨询服务费金额
    @Column(name = "CONSULT_AMOUNT")
    private String consultAmount;

    //担保费金额
    @Column(name = "GUARANTEE_AMOUNT")
    private String guaranteeAmount;

    //第一期还款日
    @Column(name = "ONE_REPAYMENT_DATE")
    private String oneRepaymentDate;

    //第一期应还利息
    @Column(name = "ONE_INTEREST_AMOUNT")
    private String oneInterestAmount;

    //第一期应还利息
    @Column(name = "ONE_PRINCIPAL_AMOUNT")
    private String onePrincipalAmount;

    //第一期应还利息
    @Column(name = "ONE_TOTAL_AMOUNT")
    private String oneTotalAmount;

    //第二期还款日
    @Column(name = "TWO_REPAYMENT_DATE")
    private String twoRepaymentDate;

    //第二期应还利息
    @Column(name = "TWO_INTEREST_AMOUNT")
    private String twoInterestAmount;

    //第二期应还利息
    @Column(name = "TWO_PRINCIPAL_AMOUNT")
    private String twoPrincipalAmount;

    //第二期应还利息
    @Column(name = "TWO_TOTAL_AMOUNT")
    private String twoTotalAmount;

    //第三期还款日
    @Column(name = "THREE_REPAYMENT_DATE")
    private String threeRepaymentDate;

    //第三期应还利息
    @Column(name = "THREE_INTEREST_AMOUNT")
    private String threeInterestAmount;

    //第三期应还利息
    @Column(name = "THREE_PRINCIPAL_AMOUNT")
    private String threePrincipalAmount;

    //第三期应还利息
    @Column(name = "THREE_TOTAL_AMOUNT")
    private String threeTotalAmount;

    //第四期还款日
    @Column(name = "FOUR_REPAYMENT_DATE")
    private String fourRepaymentDate;

    //第四期应还利息
    @Column(name = "FOUR_INTEREST_AMOUNT")
    private String fourInterestAmount;

    //第四期应还利息
    @Column(name = "FOUR_PRINCIPAL_AMOUNT")
    private String fourPrincipalAmount;

    //第四期应还利息
    @Column(name = "FOUR_TOTAL_AMOUNT")
    private String fourTotalAmount;

    //第五期还款日
    @Column(name = "FIVE_REPAYMENT_DATE")
    private String fiveRepaymentDate;

    //第五期应还利息
    @Column(name = "FIVE_INTEREST_AMOUNT")
    private String fiveInterestAmount;

    //第五期应还利息
    @Column(name = "FIVE_PRINCIPAL_AMOUNT")
    private String fivePrincipalAmount;

    //第五期应还利息
    @Column(name = "FIVE_TOTAL_AMOUNT")
    private String fiveTotalAmount;

    //第六期还款日
    @Column(name = "SIX_REPAYMENT_DATE")
    private String sixRepaymentDate;

    //第六期应还利息
    @Column(name = "SIX_INTEREST_AMOUNT")
    private String sixInterestAmount;

    //第六期应还利息
    @Column(name = "SIX_PRINCIPAL_AMOUNT")
    private String sixPrincipalAmount;

    //第六期应还利息
    @Column(name = "SIX_TOTAL_AMOUNT")
    private String sixTotalAmount;



    public TaodaRecordDetail() {
	}

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public TaodaRecord getTaodaRecord() {
        return taodaRecord;
    }

    public void setTaodaRecord(TaodaRecord taodaRecord) {
        this.taodaRecord = taodaRecord;
    }

    public String getBusinessCode() {
        return businessCode;
    }

    public void setBusinessCode(String businessCode) {
        this.businessCode = businessCode;
    }

    public String getPrincipal() {
        return principal;
    }

    public void setPrincipal(String principal) {
        this.principal = principal;
    }
    
    public String getPeriod() {
		return period;
	}

	public void setPeriod(String period) {
		this.period = period;
	}

	public String getPledgePrincipal() {
        return pledgePrincipal;
    }

    public void setPledgePrincipal(String pledgePrincipal) {
        this.pledgePrincipal = pledgePrincipal;
    }

    public String getLoanerName() {
        return loanerName;
    }

    public void setLoanerName(String loanerName) {
        this.loanerName = loanerName;
    }

    public String getLoanerIdentityNumber() {
        return loanerIdentityNumber;
    }

    public void setLoanerIdentityNumber(String loanerIdentityNumber) {
        this.loanerIdentityNumber = loanerIdentityNumber;
    }

    public String getLoanerRegistName() {
        return loanerRegistName;
    }

    public void setLoanerRegistName(String loanerRegistName) {
        this.loanerRegistName = loanerRegistName;
    }

    public String getLoanerAddress() {
        return loanerAddress;
    }

    public void setLoanerAddress(String loanerAddress) {
        this.loanerAddress = loanerAddress;
    }

    public String getLoanerPhoneNumber() {
        return loanerPhoneNumber;
    }

    public void setLoanerPhoneNumber(String loanerPhoneNumber) {
        this.loanerPhoneNumber = loanerPhoneNumber;
    }

    public String getBankInfo() {
        return bankInfo;
    }

    public void setBankInfo(String bankInfo) {
        this.bankInfo = bankInfo;
    }

    public String getBankCardNo() {
        return bankCardNo;
    }

    public void setBankCardNo(String bankCardNo) {
        this.bankCardNo = bankCardNo;
    }

    public String getInvestorName() {
        return investorName;
    }

    public void setInvestorName(String investorName) {
        this.investorName = investorName;
    }

    public String getInvestorIdentityNumber() {
        return investorIdentityNumber;
    }

    public void setInvestorIdentityNumber(String investorIdentityNumber) {
        this.investorIdentityNumber = investorIdentityNumber;
    }

    public String getInvestorRegistName() {
        return investorRegistName;
    }

    public void setInvestorRegistName(String investorRegistName) {
        this.investorRegistName = investorRegistName;
    }

    public String getInvestorAddress() {
        return investorAddress;
    }

    public void setInvestorAddress(String investorAddress) {
        this.investorAddress = investorAddress;
    }

    public String getInvestorPhoneNumber() {
        return investorPhoneNumber;
    }

    public void setInvestorPhoneNumber(String investorPhoneNumber) {
        this.investorPhoneNumber = investorPhoneNumber;
    }

    public String getInvestorNameAll() {
        return investorNameAll;
    }

    public void setInvestorNameAll(String investorNameAll) {
        this.investorNameAll = investorNameAll;
    }

    public String getInvestorIdentityNumberAll() {
        return investorIdentityNumberAll;
    }

    public void setInvestorIdentityNumberAll(String investorIdentityNumberAll) {
        this.investorIdentityNumberAll = investorIdentityNumberAll;
    }

    public String getPledgeUserName() {
        return pledgeUserName;
    }

    public void setPledgeUserName(String pledgeUserName) {
        this.pledgeUserName = pledgeUserName;
    }

    public String getPledgeUserIdentityNumber() {
        return pledgeUserIdentityNumber;
    }

    public void setPledgeUserIdentityNumber(String pledgeUserIdentityNumber) {
        this.pledgeUserIdentityNumber = pledgeUserIdentityNumber;
    }

    public String getPledgeUserAddress() {
        return pledgeUserAddress;
    }

    public void setPledgeUserAddress(String pledgeUserAddress) {
        this.pledgeUserAddress = pledgeUserAddress;
    }

    public String getPledgeUserPhoneNumber() {
        return pledgeUserPhoneNumber;
    }

    public void setPledgeUserPhoneNumber(String pledgeUserPhoneNumber) {
        this.pledgeUserPhoneNumber = pledgeUserPhoneNumber;
    }

    public String getSharedPersonName() {
        return sharedPersonName;
    }

    public void setSharedPersonName(String sharedPersonName) {
        this.sharedPersonName = sharedPersonName;
    }

    public String getSharedPersonIdentityNumber() {
        return sharedPersonIdentityNumber;
    }

    public void setSharedPersonIdentityNumber(String sharedPersonIdentityNumber) {
        this.sharedPersonIdentityNumber = sharedPersonIdentityNumber;
    }

    public String getHouseCertCode() {
        return houseCertCode;
    }

    public void setHouseCertCode(String houseCertCode) {
        this.houseCertCode = houseCertCode;
    }

    public String getPledgeAddress() {
        return pledgeAddress;
    }

    public void setPledgeAddress(String pledgeAddress) {
        this.pledgeAddress = pledgeAddress;
    }

    public String getNumOfRoom() {
        return numOfRoom;
    }

    public void setNumOfRoom(String numOfRoom) {
        this.numOfRoom = numOfRoom;
    }

    public String getHouseNumber() {
        return houseNumber;
    }

    public void setHouseNumber(String houseNumber) {
        this.houseNumber = houseNumber;
    }

    public String getRoomNumber() {
        return roomNumber;
    }

    public void setRoomNumber(String roomNumber) {
        this.roomNumber = roomNumber;
    }

    public String getProportion() {
        return proportion;
    }

    public void setProportion(String proportion) {
        this.proportion = proportion;
    }

    public String getPledgeType() {
        return pledgeType;
    }

    public void setPledgeType(String pledgeType) {
        this.pledgeType = pledgeType;
    }

    public String getHouseStatus() {
        return houseStatus;
    }

    public void setHouseStatus(String houseStatus) {
        this.houseStatus = houseStatus;
    }

    public String getOtherPerson() {
        return otherPerson;
    }

    public void setOtherPerson(String otherPerson) {
        this.otherPerson = otherPerson;
    }

    public String getOtherPersonPhoneNumber() {
        return otherPersonPhoneNumber;
    }

    public void setOtherPersonPhoneNumber(String otherPersonPhoneNumber) {
        this.otherPersonPhoneNumber = otherPersonPhoneNumber;
    }

    public String getOtherPersonIdentityNumber() {
        return otherPersonIdentityNumber;
    }

    public void setOtherPersonIdentityNumber(String otherPersonIdentityNumber) {
        this.otherPersonIdentityNumber = otherPersonIdentityNumber;
    }

    public String getOtherPersonIdType() {
        return otherPersonIdType;
    }

    public void setOtherPersonIdType(String otherPersonIdType) {
        this.otherPersonIdType = otherPersonIdType;
    }

    public String getPledgeGrantedPersonOne() {
        return pledgeGrantedPersonOne;
    }

    public void setPledgeGrantedPersonOne(String pledgeGrantedPersonOne) {
        this.pledgeGrantedPersonOne = pledgeGrantedPersonOne;
    }

    public String getPledgeGrantedPersonOneId() {
        return pledgeGrantedPersonOneId;
    }

    public void setPledgeGrantedPersonOneId(String pledgeGrantedPersonOneId) {
        this.pledgeGrantedPersonOneId = pledgeGrantedPersonOneId;
    }

    public String getPledgeGrantedPersonTwo() {
        return pledgeGrantedPersonTwo;
    }

    public void setPledgeGrantedPersonTwo(String pledgeGrantedPersonTwo) {
        this.pledgeGrantedPersonTwo = pledgeGrantedPersonTwo;
    }

    public String getPledgeGrantedPersonTwoId() {
        return pledgeGrantedPersonTwoId;
    }

    public void setPledgeGrantedPersonTwoId(String pledgeGrantedPersonTwoId) {
        this.pledgeGrantedPersonTwoId = pledgeGrantedPersonTwoId;
    }

    public String getReverseGuarantorName() {
        return reverseGuarantorName;
    }

    public void setReverseGuarantorName(String reverseGuarantorName) {
        this.reverseGuarantorName = reverseGuarantorName;
    }

    public String getReverseGuarantorId() {
        return reverseGuarantorId;
    }

    public void setReverseGuarantorId(String reverseGuarantorId) {
        this.reverseGuarantorId = reverseGuarantorId;
    }

    public String getReverseGuarantorAddress() {
        return reverseGuarantorAddress;
    }

    public void setReverseGuarantorAddress(String reverseGuarantorAddress) {
        this.reverseGuarantorAddress = reverseGuarantorAddress;
    }

    public String getReverseGuarantorPhoneNumber() {
        return reverseGuarantorPhoneNumber;
    }

    public void setReverseGuarantorPhoneNumber(String reverseGuarantorPhoneNumber) {
        this.reverseGuarantorPhoneNumber = reverseGuarantorPhoneNumber;
    }

    public String getLoanContractCode() {
        return loanContractCode;
    }

    public void setLoanContractCode(String loanContractCode) {
        this.loanContractCode = loanContractCode;
    }

    public String getLoanContractCodeAll() {
        return loanContractCodeAll;
    }

    public void setLoanContractCodeAll(String loanContractCodeAll) {
        this.loanContractCodeAll = loanContractCodeAll;
    }

    public String getGuaranteeContractCode() {
        return guaranteeContractCode;
    }

    public void setGuaranteeContractCode(String guaranteeContractCode) {
        this.guaranteeContractCode = guaranteeContractCode;
    }

    public String getGuaranteeContractCodeAll() {
        return guaranteeContractCodeAll;
    }

    public void setGuaranteeContractCodeAll(String guaranteeContractCodeAll) {
        this.guaranteeContractCodeAll = guaranteeContractCodeAll;
    }

    public String getPledgeContractCode() {
        return pledgeContractCode;
    }

    public void setPledgeContractCode(String pledgeContractCode) {
        this.pledgeContractCode = pledgeContractCode;
    }

    public String getProxyGuaranteeContractCode() {
        return proxyGuaranteeContractCode;
    }

    public void setProxyGuaranteeContractCode(String proxyGuaranteeContractCode) {
        this.proxyGuaranteeContractCode = proxyGuaranteeContractCode;
    }

    public String getReverseContractCode() {
        return reverseContractCode;
    }

    public void setReverseContractCode(String reverseContractCode) {
        this.reverseContractCode = reverseContractCode;
    }

    public String getConsultContractCode() {
        return consultContractCode;
    }

    public void setConsultContractCode(String consultContractCode) {
        this.consultContractCode = consultContractCode;
    }

    public String getGrantPledgeContractCode() {
        return grantPledgeContractCode;
    }

    public void setGrantPledgeContractCode(String grantPledgeContractCode) {
        this.grantPledgeContractCode = grantPledgeContractCode;
    }

    public String getUseFor() {
        return useFor;
    }

    public void setUseFor(String useFor) {
        this.useFor = useFor;
    }

    public String getInterestStartDate() {
        return interestStartDate;
    }

    public void setInterestStartDate(String interestStartDate) {
        this.interestStartDate = interestStartDate;
    }

    public String getFirstRepaymentDate() {
        return firstRepaymentDate;
    }

    public void setFirstRepaymentDate(String firstRepaymentDate) {
        this.firstRepaymentDate = firstRepaymentDate;
    }

    public String getDeadLine() {
        return deadLine;
    }

    public void setDeadLine(String deadLine) {
        this.deadLine = deadLine;
    }

    public String getRepayDay() {
        return repayDay;
    }

    public void setRepayDay(String repayDay) {
        this.repayDay = repayDay;
    }

    public String getInterestRate() {
        return interestRate;
    }

    public void setInterestRate(String interestRate) {
        this.interestRate = interestRate;
    }

    public String getConsultRate() {
        return consultRate;
    }

    public void setConsultRate(String consultRate) {
        this.consultRate = consultRate;
    }

    public String getConsultAmount() {
        return consultAmount;
    }

    public void setConsultAmount(String consultAmount) {
        this.consultAmount = consultAmount;
    }

    public String getGuaranteeAmount() {
        return guaranteeAmount;
    }

    public void setGuaranteeAmount(String guaranteeAmount) {
        this.guaranteeAmount = guaranteeAmount;
    }

    public String getPledgeUserIdentityType() {
        return pledgeUserIdentityType;
    }

    public void setPledgeUserIdentityType(String pledgeUserIdentityType) {
        this.pledgeUserIdentityType = pledgeUserIdentityType;
    }

    public String getOneRepaymentDate() {
        return oneRepaymentDate;
    }

    public void setOneRepaymentDate(String oneRepaymentDate) {
        this.oneRepaymentDate = oneRepaymentDate;
    }

    public String getOneInterestAmount() {
        return oneInterestAmount;
    }

    public void setOneInterestAmount(String oneInterestAmount) {
        this.oneInterestAmount = oneInterestAmount;
    }

    public String getOnePrincipalAmount() {
        return onePrincipalAmount;
    }

    public void setOnePrincipalAmount(String onePrincipalAmount) {
        this.onePrincipalAmount = onePrincipalAmount;
    }

    public String getOneTotalAmount() {
        return oneTotalAmount;
    }

    public void setOneTotalAmount(String oneTotalAmount) {
        this.oneTotalAmount = oneTotalAmount;
    }

    public String getTwoRepaymentDate() {
        return twoRepaymentDate;
    }

    public void setTwoRepaymentDate(String twoRepaymentDate) {
        this.twoRepaymentDate = twoRepaymentDate;
    }

    public String getTwoInterestAmount() {
        return twoInterestAmount;
    }

    public void setTwoInterestAmount(String twoInterestAmount) {
        this.twoInterestAmount = twoInterestAmount;
    }

    public String getTwoPrincipalAmount() {
        return twoPrincipalAmount;
    }

    public void setTwoPrincipalAmount(String twoPrincipalAmount) {
        this.twoPrincipalAmount = twoPrincipalAmount;
    }

    public String getTwoTotalAmount() {
        return twoTotalAmount;
    }

    public void setTwoTotalAmount(String twoTotalAmount) {
        this.twoTotalAmount = twoTotalAmount;
    }

    public String getThreeRepaymentDate() {
        return threeRepaymentDate;
    }

    public void setThreeRepaymentDate(String threeRepaymentDate) {
        this.threeRepaymentDate = threeRepaymentDate;
    }

    public String getThreeInterestAmount() {
        return threeInterestAmount;
    }

    public void setThreeInterestAmount(String threeInterestAmount) {
        this.threeInterestAmount = threeInterestAmount;
    }

    public String getThreePrincipalAmount() {
        return threePrincipalAmount;
    }

    public void setThreePrincipalAmount(String threePrincipalAmount) {
        this.threePrincipalAmount = threePrincipalAmount;
    }

    public String getThreeTotalAmount() {
        return threeTotalAmount;
    }

    public void setThreeTotalAmount(String threeTotalAmount) {
        this.threeTotalAmount = threeTotalAmount;
    }

    public String getFourRepaymentDate() {
        return fourRepaymentDate;
    }

    public void setFourRepaymentDate(String fourRepaymentDate) {
        this.fourRepaymentDate = fourRepaymentDate;
    }

    public String getFourInterestAmount() {
        return fourInterestAmount;
    }

    public void setFourInterestAmount(String fourInterestAmount) {
        this.fourInterestAmount = fourInterestAmount;
    }

    public String getFourPrincipalAmount() {
        return fourPrincipalAmount;
    }

    public void setFourPrincipalAmount(String fourPrincipalAmount) {
        this.fourPrincipalAmount = fourPrincipalAmount;
    }

    public String getFourTotalAmount() {
        return fourTotalAmount;
    }

    public void setFourTotalAmount(String fourTotalAmount) {
        this.fourTotalAmount = fourTotalAmount;
    }

    public String getFiveRepaymentDate() {
        return fiveRepaymentDate;
    }

    public void setFiveRepaymentDate(String fiveRepaymentDate) {
        this.fiveRepaymentDate = fiveRepaymentDate;
    }

    public String getFiveInterestAmount() {
        return fiveInterestAmount;
    }

    public void setFiveInterestAmount(String fiveInterestAmount) {
        this.fiveInterestAmount = fiveInterestAmount;
    }

    public String getFivePrincipalAmount() {
        return fivePrincipalAmount;
    }

    public void setFivePrincipalAmount(String fivePrincipalAmount) {
        this.fivePrincipalAmount = fivePrincipalAmount;
    }

    public String getFiveTotalAmount() {
        return fiveTotalAmount;
    }

    public void setFiveTotalAmount(String fiveTotalAmount) {
        this.fiveTotalAmount = fiveTotalAmount;
    }

    public String getSixRepaymentDate() {
        return sixRepaymentDate;
    }

    public void setSixRepaymentDate(String sixRepaymentDate) {
        this.sixRepaymentDate = sixRepaymentDate;
    }

    public String getSixInterestAmount() {
        return sixInterestAmount;
    }

    public void setSixInterestAmount(String sixInterestAmount) {
        this.sixInterestAmount = sixInterestAmount;
    }

    public String getSixPrincipalAmount() {
        return sixPrincipalAmount;
    }

    public void setSixPrincipalAmount(String sixPrincipalAmount) {
        this.sixPrincipalAmount = sixPrincipalAmount;
    }

    public String getSixTotalAmount() {
        return sixTotalAmount;
    }

    public void setSixTotalAmount(String sixTotalAmount) {
        this.sixTotalAmount = sixTotalAmount;
    }

	public String toString() {
		return "TaodaRecordDetail [id=" + id + ", taodaRecord=" + taodaRecord
				+ ", businessCode=" + businessCode + ", principal=" + principal
				+ ", period=" + period + ", pledgePrincipal=" + pledgePrincipal
				+ ", loanerName=" + loanerName + ", loanerIdentityNumber="
				+ loanerIdentityNumber + ", loanerRegistName="
				+ loanerRegistName + ", loanerAddress=" + loanerAddress
				+ ", loanerPhoneNumber=" + loanerPhoneNumber + ", bankInfo="
				+ bankInfo + ", bankCardNo=" + bankCardNo + ", investorName="
				+ investorName + ", investorIdentityNumber="
				+ investorIdentityNumber + ", investorRegistName="
				+ investorRegistName + ", investorAddress=" + investorAddress
				+ ", investorPhoneNumber=" + investorPhoneNumber
				+ ", investorNameAll=" + investorNameAll
				+ ", investorIdentityNumberAll=" + investorIdentityNumberAll
				+ ", pledgeUserName=" + pledgeUserName
				+ ", pledgeUserIdentityType=" + pledgeUserIdentityType
				+ ", pledgeUserIdentityNumber=" + pledgeUserIdentityNumber
				+ ", pledgeUserAddress=" + pledgeUserAddress
				+ ", pledgeUserPhoneNumber=" + pledgeUserPhoneNumber
				+ ", sharedPersonName=" + sharedPersonName
				+ ", sharedPersonIdentityNumber=" + sharedPersonIdentityNumber
				+ ", houseCertCode=" + houseCertCode + ", pledgeAddress="
				+ pledgeAddress + ", numOfRoom=" + numOfRoom + ", houseNumber="
				+ houseNumber + ", roomNumber=" + roomNumber + ", proportion="
				+ proportion + ", pledgeType=" + pledgeType + ", houseStatus="
				+ houseStatus + ", otherPerson=" + otherPerson
				+ ", otherPersonPhoneNumber=" + otherPersonPhoneNumber
				+ ", otherPersonIdentityNumber=" + otherPersonIdentityNumber
				+ ", otherPersonIdType=" + otherPersonIdType
				+ ", pledgeGrantedPersonOne=" + pledgeGrantedPersonOne
				+ ", pledgeGrantedPersonOneId=" + pledgeGrantedPersonOneId
				+ ", pledgeGrantedPersonTwo=" + pledgeGrantedPersonTwo
				+ ", pledgeGrantedPersonTwoId=" + pledgeGrantedPersonTwoId
				+ ", reverseGuarantorName=" + reverseGuarantorName
				+ ", reverseGuarantorId=" + reverseGuarantorId
				+ ", reverseGuarantorAddress=" + reverseGuarantorAddress
				+ ", reverseGuarantorPhoneNumber="
				+ reverseGuarantorPhoneNumber + ", loanContractCode="
				+ loanContractCode + ", loanContractCodeAll="
				+ loanContractCodeAll + ", guaranteeContractCode="
				+ guaranteeContractCode + ", guaranteeContractCodeAll="
				+ guaranteeContractCodeAll + ", pledgeContractCode="
				+ pledgeContractCode + ", proxyGuaranteeContractCode="
				+ proxyGuaranteeContractCode + ", reverseContractCode="
				+ reverseContractCode + ", consultContractCode="
				+ consultContractCode + ", grantPledgeContractCode="
				+ grantPledgeContractCode + ", useFor=" + useFor
				+ ", interestStartDate=" + interestStartDate
				+ ", firstRepaymentDate=" + firstRepaymentDate + ", deadLine="
				+ deadLine + ", repayDay=" + repayDay + ", interestRate="
				+ interestRate + ", consultRate=" + consultRate
				+ ", consultAmount=" + consultAmount + ", guaranteeAmount="
				+ guaranteeAmount + ", oneRepaymentDate=" + oneRepaymentDate
				+ ", oneInterestAmount=" + oneInterestAmount
				+ ", onePrincipalAmount=" + onePrincipalAmount
				+ ", oneTotalAmount=" + oneTotalAmount + ", twoRepaymentDate="
				+ twoRepaymentDate + ", twoInterestAmount=" + twoInterestAmount
				+ ", twoPrincipalAmount=" + twoPrincipalAmount
				+ ", twoTotalAmount=" + twoTotalAmount
				+ ", threeRepaymentDate=" + threeRepaymentDate
				+ ", threeInterestAmount=" + threeInterestAmount
				+ ", threePrincipalAmount=" + threePrincipalAmount
				+ ", threeTotalAmount=" + threeTotalAmount
				+ ", fourRepaymentDate=" + fourRepaymentDate
				+ ", fourInterestAmount=" + fourInterestAmount
				+ ", fourPrincipalAmount=" + fourPrincipalAmount
				+ ", fourTotalAmount=" + fourTotalAmount
				+ ", fiveRepaymentDate=" + fiveRepaymentDate
				+ ", fiveInterestAmount=" + fiveInterestAmount
				+ ", fivePrincipalAmount=" + fivePrincipalAmount
				+ ", fiveTotalAmount=" + fiveTotalAmount
				+ ", sixRepaymentDate=" + sixRepaymentDate
				+ ", sixInterestAmount=" + sixInterestAmount
				+ ", sixPrincipalAmount=" + sixPrincipalAmount
				+ ", sixTotalAmount=" + sixTotalAmount + "]";
	}
    
}
