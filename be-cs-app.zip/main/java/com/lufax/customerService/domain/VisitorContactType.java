package com.lufax.customerService.domain;

public enum VisitorContactType {
	TELEPHONE_CONTACT("电话"),
	MESSAGE_CONTACT("留言"),
	UNKOWN("未知");
	private String value;
	private VisitorContactType(String value){
		this.value = value;
	}
	public String getValue() {
		return value;
	}
	
	public static VisitorContactType getVisitorContactTypeByName(String name){
		VisitorContactType[] types = VisitorContactType.values();
		for(VisitorContactType type:types){
			if(type.name().equals(name)){
				return type;
			}
		}
		return VisitorContactType.UNKOWN;
	}
    	public static VisitorContactType getByName(String name){
		if(VisitorContactType.TELEPHONE_CONTACT.value.equals(name)) {
            return VisitorContactType.TELEPHONE_CONTACT;
        } else if(VisitorContactType.MESSAGE_CONTACT.value.equals(name)) {
            return VisitorContactType.MESSAGE_CONTACT;
        } else {
		    return VisitorContactType.UNKOWN;
        }
	}
}
