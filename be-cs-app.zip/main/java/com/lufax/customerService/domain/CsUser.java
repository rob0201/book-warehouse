package com.lufax.customerService.domain;


public class CsUser {
    private String name;
    private String gender;
    private String regPhoneNo;
    private String visitPhoneNo;
    private String userName;

    public CsUser() {
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRegPhoneNo() {
        return regPhoneNo;
    }

    public void setRegPhoneNo(String regPhoneNo) {
        this.regPhoneNo = regPhoneNo;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getVisitPhoneNo() {
        return visitPhoneNo;
    }


    public void setVisitPhoneNo(String visitPhoneNo) {
        this.visitPhoneNo = visitPhoneNo;
    }

    @Override
    public String toString() {
        return "CsUser{" +
                "gender='" + gender + '\'' +
                ", name='" + name + '\'' +
                ", regPhoneNo='" + regPhoneNo + '\'' +
                ", visitPhoneNo='" + visitPhoneNo + '\'' +
                ", userName='" + userName + '\'' +
                '}';
    }
}
