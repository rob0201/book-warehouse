package com.lufax.customerService.domain;

import com.lufax.common.domain.account.Money;
import com.lufax.common.utils.Day;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "SYSTEM_FUND_RECORDS")
public class SystemFundRecord {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_SYSTEM_FUND_RECORDS")
    @SequenceGenerator(name = "SEQ_SYSTEM_FUND_RECORDS", sequenceName = "SEQ_SYSTEM_FUND_RECORDS", allocationSize = 1)
    private long id;

    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "amount", column = @Column(name = "TOTAL_BALANCE"))
    })
    private Money totalBalance;

    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "amount", column = @Column(name = "TOTAL_BALANCE_DIFF"))
    })
    private Money totalBalanceDiff;

    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "amount", column = @Column(name = "RECHARGE_AMOUNT"))
    })
    private Money rechargeAmount;

    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "amount", column = @Column(name = "WITHDRAW_AMOUNT"))
    })
    private Money withdrawAmount;

    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "amount", column = @Column(name = "RETURN_TICKET_AMOUNT"))
    })
    private Money returnTicketAmount;

    @Column(name = "CREATED_AT")
    private Date createdAt;

    @Column(name = "STATISTIC_DATE")
    private Date statisticDate;

    @Column(name = "LAST_CREATED_AT")
    private Date lastCreatedAt;

    public SystemFundRecord() {
    }

    public SystemFundRecord(Money totalBalance, Money rechargeAmount, Money withdrawAmount, Money returnTicketAmount, Money totalBalanceDiff, Date lastCreatedAt) {
        this.totalBalance = totalBalance;
        this.rechargeAmount = rechargeAmount;
        this.withdrawAmount = withdrawAmount;
        this.returnTicketAmount = returnTicketAmount;
        this.totalBalanceDiff = totalBalanceDiff;
        this.lastCreatedAt = lastCreatedAt;
        this.createdAt = new Date();
        this.statisticDate = new Day(createdAt).yesterday();
    }

    public Money getReturnTicketAmount() {
        return returnTicketAmount;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public Date getStatisticDate() {
        return statisticDate;
    }

    public Money getWithdrawAmount() {
        return withdrawAmount;
    }

    public Money getRechargeAmount() {
        return rechargeAmount;
    }

    public Money getTotalBalance() {
        return totalBalance;
    }

    public void setStatisticDate(Date statisticDate) {
        this.statisticDate = statisticDate;
    }

    public Money getTotalBalanceDiff() {
        return totalBalanceDiff;
    }

    public Date getLastCreatedAt() {
        return lastCreatedAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public long id() {
        return id;
    }


    @Override
    public String toString() {
        String lastCreatedAtString = lastCreatedAt == null ? "-" : lastCreatedAt.toString();
        String createdAtString = createdAt == null ? "-" : createdAt.toString();
        return String.format("[totalBalance:%s, rechargeAmount:%s, withdrawAmount:%s, totalBalanceDiff:%s, staticDate:%s, lastCreatedAt:%s, createAt:%s]",
                totalBalance.toString(), rechargeAmount.toString(), withdrawAmount.toString(), totalBalanceDiff.toString(),
                statisticDate.toString(), lastCreatedAtString, createdAtString);
    }
}
