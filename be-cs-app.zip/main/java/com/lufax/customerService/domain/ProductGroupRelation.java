package com.lufax.customerService.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.lufax.common.domain.product.Product;

@Entity
@Table(name="T_PRODUCT_GROUP_RELATION")
public class ProductGroupRelation {
	@Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_PRODUCT_GROUP_RELATION_ID")
    @SequenceGenerator(name = "SEQ_PRODUCT_GROUP_RELATION_ID", sequenceName = "SEQ_PRODUCT_GROUP_RELATION_ID", allocationSize = 1)
	private long id ;
	
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "PRODUCT_ID")
    private Product productRelation;
	
	@Column(name="product_group")
    private String productGroup;
	
	@Column(name="expire_date")
    private Date expireDate;
	
	@Column(name="is_valid")
    private boolean isValid;
	
	@Column(name="create_date")
    private Date createDate;
	
	@Column(name="invalid_date")
    private Date invalidDate;
	
	public ProductGroupRelation(){}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}


	public Product getProductRelation() {
		return productRelation;
	}

	public void setProductRelation(Product productRelation) {
		this.productRelation = productRelation;
	}

	public String getProductGroup() {
		return productGroup;
	}

	public void setProductGroup(String productGroup) {
		this.productGroup = productGroup;
	}

	public Date getExpireDate() {
		return expireDate;
	}

	public void setExpireDate(Date expireDate) {
		this.expireDate = expireDate;
	}

	public boolean isValid() {
		return isValid;
	}

	public void setValid(boolean isValid) {
		this.isValid = isValid;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public Date getInvalidDate() {
		return invalidDate;
	}

	public void setInvalidDate(Date invalidDate) {
		this.invalidDate = invalidDate;
	}
	
	
}
