package com.lufax.customerService.domain;


import javax.persistence.*;

@Entity
@Table(name = "cs_service_type")
public class CsServiceType {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_cs_service_type_id")
    @SequenceGenerator(name = "seq_cs_service_type_id", sequenceName = "seq_cs_service_type_id", allocationSize = 1)
    private Long id;

    @Column(name = "code")
    private String code;

    @Column(name = "name")
    private String name;

    @Column(name = "parent_id")
    private long parentId;

    public CsServiceType() {

    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public long getParentId() {
        return parentId;
    }

    public void setParentId(long parentId) {
        this.parentId = parentId;
    }
}
