package com.lufax.customerService.domain;

import javax.persistence.*;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: caoyanfei079
 * Date: 12-10-17
 * Time: 下午8:10
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(name = "AVAYA_EVENT_HISTORY")
public class AvayaPhoneHistory {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_avaya_event_history")
    @SequenceGenerator(name = "seq_avaya_event_history", sequenceName = "seq_avaya_event_history", allocationSize = 1)
    private Long id;
    @Column(name = "ani")
    private String ani;
    @Column(name = "dani")
    private String dani;
    @Column(name = "clientNo")
    private String clientNo;
    @Column(name = "callType")
    private String callType;
    @Column(name = "isIVR")
    private String isIVR;
    @Column(name = "event")
    private String event;
    @Column(name = "fcd")
    private Date fcd;
    @Column(name = "fcu")
    private String fcu;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getAni() {
        return ani;
    }

    public void setAni(String ani) {
        this.ani = ani;
    }

    public String getDani() {
        return dani;
    }

    public void setDani(String dani) {
        this.dani = dani;
    }

    public String getClientNo() {
        return clientNo;
    }

    public void setClientNo(String clientNo) {
        this.clientNo = clientNo;
    }

    public String getCallType() {
        return callType;
    }

    public void setCallType(String callType) {
        this.callType = callType;
    }

    public String getIVR() {
        return isIVR;
    }

    public void setIVR(String IVR) {
        isIVR = IVR;
    }

    public String getEvent() {
        return event;
    }

    public void setEvent(String event) {
        this.event = event;
    }

    public Date getFcd() {
        return fcd;
    }

    public void setFcd(Date fcd) {
        this.fcd = fcd;
    }

    public String getFcu() {
        return fcu;
    }

    public void setFcu(String fcu) {
        this.fcu = fcu;
    }
}
