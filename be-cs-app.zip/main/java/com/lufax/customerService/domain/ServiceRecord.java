package com.lufax.customerService.domain;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "SERVICE_RECORDS")
public class ServiceRecord {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_SERVICE_RECORDS")
    @SequenceGenerator(name = "SEQ_SERVICE_RECORDS", sequenceName = "SEQ_SERVICE_RECORDS", allocationSize = 1)
    private Long id;

    @Column(name = "CUSTOMER_ID")
    private long customerId;

    @Column(name = "USER_ID")
    private long userId;

    @Enumerated(EnumType.STRING)
    @Column(name = "SERVICE_TYPE")
    private ServiceType serviceType;

    @Column(name = "CREATED_AT")
    private Date createdAt;

    public ServiceRecord() {
    }

    public ServiceRecord(ServiceType serviceType, long userId, long customerId) {
        this.serviceType = serviceType;
        this.createdAt = new Date();
        this.userId = userId;
        this.customerId = customerId;
    }

    public ServiceType getServiceType() {
        return serviceType;
    }

    public long getUserId() {
        return userId;
    }

    public long getCustomerId() {
        return customerId;
    }

    public Long getId() {
        return id;
    }

    public Date getCreatedAt() {
        return createdAt;
    }
}
