package com.lufax.customerService.domain;

import com.lufax.common.domain.BizParameters;
import com.lufax.common.domain.Loan;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class PointInterestRate implements Cloneable{
    private Date executeDate;
    private BigDecimal interestRate0To6;
    private BigDecimal interestRate6To12;
    private BigDecimal interestRate12To24;
    private BigDecimal interestRate24To36;
    private BigDecimal interestRate36More;
    private BigDecimal interestFloatRate;
    private List<RateChangePlan> rateChangePlans = new ArrayList<RateChangePlan>();

    public PointInterestRate(Date executeDate) {
        this.executeDate = executeDate;
    }

    public PointInterestRate(Date executeDate, BigDecimal interestRate0To6, BigDecimal interestRate6To12, BigDecimal interestRate12To24, BigDecimal interestRate24To36, BigDecimal interestRate36More, BigDecimal interestFloatRate) {
        this.executeDate = executeDate;
        this.interestRate0To6 = interestRate0To6;
        this.interestRate6To12 = interestRate6To12;
        this.interestRate12To24 = interestRate12To24;
        this.interestRate24To36 = interestRate24To36;
        this.interestRate36More = interestRate36More;
        this.interestFloatRate = interestFloatRate;
    }

    public void setInterestRate(RateChangePlan rateChangePlan) {
        rateChangePlans.add(rateChangePlan);

        String code = rateChangePlan.getParameterCode();
        BigDecimal value = rateChangePlan.getParameterValue();

        if (BizParameters.INTEREST_RATE_0TO6.equals(code)) {
            this.interestRate0To6 = value;
        } else if (BizParameters.INTEREST_RATE_6TO12.equals(code)) {
            this.interestRate6To12 = value;
        } else if (BizParameters.INTEREST_RATE_12TO24.equals(code)) {
            this.interestRate12To24 = value;
        } else if (BizParameters.INTEREST_RATE_24TO36.equals(code)) {
            this.interestRate24To36 = value;
        } else if (BizParameters.INTEREST_RATE_36_MORE.equals(code)) {
            this.interestRate36More = value;
        } else {
            this.interestFloatRate = value;
        }
    }

    public BigDecimal getBaseInterestRate(int numberOfInstalments) {
        if (numberOfInstalments <= 6)
            return interestRate0To6;
        else if (numberOfInstalments > 6 && numberOfInstalments <= 12)
            return interestRate6To12;
        else if (numberOfInstalments > 12 && numberOfInstalments <= 24)
            return interestRate12To24;
        else if (numberOfInstalments > 24 && numberOfInstalments <= 36)
            return interestRate24To36;
        return interestRate36More;
    }

    public Date calculateActualExecuteDate(Loan loan) {
        for (int i = 1; i < Integer.MAX_VALUE; i++) {
            Date startDate = loan.calculateStartDateForRepaymentPlan(i);
            if (startDate.compareTo(executeDate) >= 0) {
                return startDate;
            }
        }
        return null;
    }

    public List<RateChangePlan> getRateChangePlans() {
        return rateChangePlans;
    }

    public Date getExecuteDate() {
        return executeDate;
    }

    public void setExecuteDate(Date executeDate) {
        this.executeDate = executeDate;
    }

    public BigDecimal getInterestRate0To6() {
        return interestRate0To6;
    }

    public void setInterestRate0To6(BigDecimal interestRate0To6) {
        this.interestRate0To6 = interestRate0To6;
    }

    public BigDecimal getInterestRate6To12() {
        return interestRate6To12;
    }

    public void setInterestRate6To12(BigDecimal interestRate6To12) {
        this.interestRate6To12 = interestRate6To12;
    }

    public BigDecimal getInterestRate12To24() {
        return interestRate12To24;
    }

    public void setInterestRate12To24(BigDecimal interestRate12To24) {
        this.interestRate12To24 = interestRate12To24;
    }

    public BigDecimal getInterestRate24To36() {
        return interestRate24To36;
    }

    public void setInterestRate24To36(BigDecimal interestRate24To36) {
        this.interestRate24To36 = interestRate24To36;
    }

    public BigDecimal getInterestRate36More() {
        return interestRate36More;
    }

    public void setInterestRate36More(BigDecimal interestRate36More) {
        this.interestRate36More = interestRate36More;
    }

    public BigDecimal getInterestFloatRate() {
        return interestFloatRate;
    }

    public void setInterestFloatRate(BigDecimal interestFloatRate) {
        this.interestFloatRate = interestFloatRate;
    }

    @Override
    public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
}
