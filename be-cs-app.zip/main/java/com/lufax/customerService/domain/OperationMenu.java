package com.lufax.customerService.domain;

public enum OperationMenu {
    USER_LIST,
    USER_BASIC_INFO,
    LOAN_REQUEST,
    LOAN_HISTORY,
    LOANS,
    INVESTMENTS,
    INVESTMENT_REQUEST,
    INVESTMENT_HISTORY,
    WITHDRAW_RECORD,
    RECHARGE_RECORD,
    FUND_RECORD,
    SMS_RECORD,
    UNKNOWN   ;
    public static OperationMenu getOperationMenuByName(String name){
        OperationMenu[] operationMenus=OperationMenu.values();
        for(OperationMenu operationMenu:operationMenus)
            if(operationMenu.name().equalsIgnoreCase(name))
                return operationMenu;
        return UNKNOWN;

    }

}
