package com.lufax.customerService.domain;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "CUSTOMER_OPERATIONS_LOGS")
public class OperationsLog {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_CUSTOMER_OPS_LOGS")
    @SequenceGenerator(name = "SEQ_CUSTOMER_OPS_LOGS", sequenceName = "SEQ_CUSTOMER_OPS_LOGS", allocationSize = 1)
    @Column(name = "ID")
    private long id;

    @Enumerated(EnumType.STRING)
    @Column(name = "OPERATION_MENU")
    private OperationMenu operationMenu;

    //    @Enumerated(EnumType.STRING)
    @Column(name = "OPERATION_TYPE")
    private String operationType;

    @Column(name = "OPERATION_DATA")
    private String operationData;

    @Column(name = "USER_ID")
    private long userId;

    @Column(name = "CUSTOMER_ID")
    private long customerId;

    @Column(name = "CREATED_AT")
    private Date createdAt;

    public OperationsLog() {
    }

    public OperationsLog(OperationMenu operationMenu, OperationType operationType, String operationData, long userId, long customerId) {
        this.operationMenu = operationMenu;
        this.operationType = (operationType != null) ? operationType.name() : null;
        this.operationData = operationData;
        this.userId = userId;
        this.customerId = customerId;
        this.createdAt = new Date();
    }

    public OperationMenu getOperationMenu() {
        return operationMenu;
    }

    public OperationType getOperationType() {
        return OperationType.getOperationTypeByName(operationType);
    }

    public String getOperationData() {
        return operationData;
    }

    public long getUserId() {
        return userId;
    }

    public long getCustomerId() {
        return customerId;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public long getId() {
        return id;
    }
}
