package com.lufax.customerService.domain;


import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "member_bind_auth")
public class MemberBindAuth {
    @EmbeddedId
    private MemberBindAuthId id;

    @Column(name = "bindflag")
    private String bindFlag;

    @Column(name = "fcu")
    private String fcu;

    @Column(name = "fcd")
    private Date fcd;

    @Column(name = "lcu")
    private String lcu;

    @Column(name = "lcd")
    private Date lcd;

    public MemberBindAuth() {

    }

    public MemberBindAuthId getId() {
        return id;
    }

    public void setId(MemberBindAuthId id) {
        this.id = id;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof MemberBindAuth)) return false;

        MemberBindAuth auth = (MemberBindAuth) o;

        if (bindFlag != null ? !bindFlag.equals(auth.bindFlag) : auth.bindFlag != null) return false;
        if (fcd != null ? !fcd.equals(auth.fcd) : auth.fcd != null) return false;
        if (fcu != null ? !fcu.equals(auth.fcu) : auth.fcu != null) return false;
        if (id != null ? !id.equals(auth.id) : auth.id != null) return false;
        if (lcd != null ? !lcd.equals(auth.lcd) : auth.lcd != null) return false;
        if (lcu != null ? !lcu.equals(auth.lcu) : auth.lcu != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id != null ? id.hashCode() : 0;
        result = 31 * result + (bindFlag != null ? bindFlag.hashCode() : 0);
        result = 31 * result + (fcu != null ? fcu.hashCode() : 0);
        result = 31 * result + (fcd != null ? fcd.hashCode() : 0);
        result = 31 * result + (lcu != null ? lcu.hashCode() : 0);
        result = 31 * result + (lcd != null ? lcd.hashCode() : 0);
        return result;
    }
}

