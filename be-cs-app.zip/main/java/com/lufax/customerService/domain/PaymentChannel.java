package com.lufax.customerService.domain;


public enum PaymentChannel {
    CMS("CMS"),
    ALIPAY("支付宝"),
    OFFLINE("站外"),
    MANUAL("人工"),
    UNKNOWN("unknown");

    private String value;

    PaymentChannel(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
    public static PaymentChannel getPaymentChannelByName(String name){
        PaymentChannel[] paymentChannels=PaymentChannel.values();
        for(PaymentChannel paymentChannel:paymentChannels)
            if(paymentChannel.name().equalsIgnoreCase(name))
                return paymentChannel;
        return UNKNOWN;
    }
}
