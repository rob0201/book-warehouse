package com.lufax.customerService.domain;

/**
 * Created by IntelliJ IDEA. User: DENGGANG715 Date: 12-5-17 Time: 下午5:02 To
 * change this template use File | Settings | File Templates.
 */
public enum ManualCapitalStatementType {
	WITHDRAW("取现"),
	RECHARGE("充值");

	private String value;

	private ManualCapitalStatementType(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}

}
