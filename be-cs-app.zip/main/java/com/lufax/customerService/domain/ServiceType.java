package com.lufax.customerService.domain;

public enum ServiceType {
    COMPANY,
    LOANER,
    LOANEE,
    OTHER,
    UNKNOWN;
    public static ServiceType getServiceTypeByName(String name){
        ServiceType[] serviceTypes=ServiceType.values();
        for(ServiceType serviceType:serviceTypes)
            if(serviceType.name().equalsIgnoreCase(name))
                return serviceType;
        return UNKNOWN;
    }

}
