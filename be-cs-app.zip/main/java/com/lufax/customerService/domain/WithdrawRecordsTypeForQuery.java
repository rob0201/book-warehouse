package com.lufax.customerService.domain;


import com.lufax.common.domain.WithdrawStatus;
import com.lufax.common.web.helper.ConstantsHelper;

import java.util.List;

import static java.util.Arrays.asList;

public enum WithdrawRecordsTypeForQuery {
    ALL(ConstantsHelper.ALL_WITHDRAW_RECORDS_REASON_FOR_RARE_WORDS,null),
    FAILURE(WithdrawStatus.FAILURE.getValue(),asList(WithdrawStatus.FAILURE)),
    SUCCESS(WithdrawStatus.SUCCESS.getValue(),asList(WithdrawStatus.SUCCESS)),
    PROCESSING(WithdrawStatus.PROCESSING.getValue(),asList(WithdrawStatus.PROCESSING)),
    NEW(WithdrawStatus.NEW.getValue(),asList(WithdrawStatus.NEW));

    String value;
    List<WithdrawStatus> withdrawStatuses;
    WithdrawRecordsTypeForQuery(String value, List<WithdrawStatus> withdrawStatuses){
        this.value=value;
        this.withdrawStatuses=withdrawStatuses;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public List<WithdrawStatus> getWithdrawStatuses() {
        return withdrawStatuses;
    }

    public void setWithdrawStatuses(List<WithdrawStatus> withdrawStatuses) {
        this.withdrawStatuses = withdrawStatuses;
    }
}
