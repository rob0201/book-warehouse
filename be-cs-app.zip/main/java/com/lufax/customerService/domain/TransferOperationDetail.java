package com.lufax.customerService.domain;

public enum TransferOperationDetail {
	OPERATE_INVESTMENT_SUCCESS("投资成功", ""),
    OPERATE_TRANSFER_APPLIED("转让申请提交成功", "申请转让价格%s元"),
    OPERATE_SYSTEM_PREPAY_CANCEL("转让下架", "系统自动操作（提前还款）"),
    OPERATE_SYSTEM_EXPIRE_CANCEL("转让下架", "系统自动操作（信息发布超过时限未成交）"),
    OPERATE_MANUAL_CANCEL("转让下架", "用户操作"),
    OPERATE_TRANSFER_SUCCESS("转让交易成功", "收转让金额%s元，  付转让交易手续费%s元"),
    OPERATE_COLLECTION_DONE("收款结束", "");
	private String display;
    private String comment;
    private TransferOperationDetail(String display, String comment) {
    	this.display = display;
    	this.comment = comment;
    }
	public String getDisplay() {
		return display;
	}
	public String getComment() {
		return comment;
	}
    
}
