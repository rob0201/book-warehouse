package com.lufax.customerService.domain;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "cs_service_records")
public class CsServiceRecord {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_cs_service_records_id")
    @SequenceGenerator(name = "seq_cs_service_records_id", sequenceName = "seq_cs_service_records_id", allocationSize = 1)
    private Long id;

    @Column(name = "customer_id")
    private Long customerId;

    @Column(name = "visitor_id")
    private Long visitorId;
    
    @Column(name= "mkt_msg_pool_id")
    private Long messagePoolId;

    @Column(name = "CREATED_AT")
    private Date createdAt;

    @Column(name = "CONSULTATION")
    private String consultation;

    @Column(name = "QUERY")
    private String query;

    @Column(name = "TODOOPTION")
    private String todoOption;

    @Column(name = "SENDOPTION")
    private String sendOption;

    @Column(name = "OTHER")
    private String other;

    @Column(name = "REMARK")
    private String remark;

    @Column(name = "ISURGENT")
    private Boolean isUrgent = false;

    public String getConsultation() {
        return consultation;
    }

    public void setConsultation(String consultation) {
        this.consultation = consultation;
    }

    public String getQuery() {
        return query;
    }

    public void setQuery(String query) {
        this.query = query;
    }

    public String getTodoOption() {
        return todoOption;
    }

    public void setTodoOption(String todoOption) {
        this.todoOption = todoOption;
    }

    public String getSendOption() {
        return sendOption;
    }

    public void setSendOption(String sendOption) {
        this.sendOption = sendOption;
    }

    public String getOther() {
        return other;
    }

    public void setOther(String other) {
        this.other = other;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public Boolean getUrgent() {
        return isUrgent;
    }

    public void setUrgent(Boolean urgent) {
        isUrgent = urgent;
    }

    public CsServiceRecord() {

    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public Long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getVisitorId() {
        return visitorId;
    }

    public void setVisitorId(Long visitorId) {
        this.visitorId = visitorId;
    }

	public Long getMessagePoolId() {
		return messagePoolId;
	}

	public void setMessagePoolId(Long messagePoolId) {
		this.messagePoolId = messagePoolId;
	}
    
}
