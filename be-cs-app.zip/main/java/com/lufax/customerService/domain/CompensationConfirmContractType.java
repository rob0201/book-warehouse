package com.lufax.customerService.domain;

import static com.lufax.common.web.helper.ConstantsHelper.PDF_SUFFIX;
public enum CompensationConfirmContractType {
        CONFIRMCONTRACT("p2pCompensationConfirmContract.vm");

    private String template;

    CompensationConfirmContractType(String template) {
        this.template = template;
    }

    public String getTemplate() {
        return template;
    }

    public String contractNameOf(Compensation compensation) {
        return String.format("%s_%s.%s", compensation.getLoanCode(), toString().toLowerCase(), PDF_SUFFIX);
    }
}
