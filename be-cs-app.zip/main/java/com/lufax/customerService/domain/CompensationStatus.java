package com.lufax.customerService.domain;


public enum CompensationStatus {

    ONGOING("代偿中","COMPENSATION_ING"),
    DONE("代偿完成","COMPENSATION_COMPLETED"),
    DELAY("代偿滞后","COMPENSATION_LAG"),
    WAITING_FINANCE_CONFIRM("等待财务确认","WAITING_FINANCE_CONFIRM");

    private String desc;
    private String value;


    CompensationStatus(String desc, String value) {
        this.desc = desc;
        this.value = value;
    }

    public String getDesc() {
        return desc;
    }

    public String getValue() {
        return value;
    }
}
