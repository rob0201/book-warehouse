package com.lufax.customerService.domain;


import static com.lufax.common.web.helper.ConstantsHelper.PDF_SUFFIX;

public enum CompensationApplyContractType {
    APPLYCONTRACT("p2pCompensationApplyContract.vm");

    private String template;

    CompensationApplyContractType(String template) {
        this.template = template;
    }

    public String getTemplate() {
        return template;
    }

    public String contractNameOf(Compensation compensation) {
        return String.format("%s_%s.%s", compensation.getLoanCode(), toString().toLowerCase(), PDF_SUFFIX);
    }
}
