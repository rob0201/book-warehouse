package com.lufax.customerService.domain;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;

@Entity
@Table(name = "RATE_CHANGE_PLANS")
public class RateChangePlan {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_RATE_CHANGE_PLANS")
    @SequenceGenerator(name = "SEQ_RATE_CHANGE_PLANS", sequenceName = "SEQ_RATE_CHANGE_PLANS", allocationSize = 1)
    private long id;

    @Column(name = "PARAMETER_CODE")
    private String parameterCode;

    @Column(name = "PARAMETER_VALUE")
    private BigDecimal parameterValue;

    @Column(name = "EXECUTE_DATE")
    private Date executeDate;

    //    @Enumerated(EnumType.STRING)
    @Column(name = "STATUS")
    private String rateChangePlanStatus;

    @Column(name = "OPERATOR_ID")
    private Long operatorId;

    @Column(name = "AUDITOR_ID")
    private Long auditorId;

    @Column(name = "CREATED_AT")
    private Date createdAt;

    @Column(name = "UPDATED_AT")
    private Date updatedAt;

    public RateChangePlan() {
    }

    public RateChangePlan(String parameterCode, BigDecimal parameterValue, Date executeDate, RateChangePlanStatus rateChangePlanStatus, Long operatorId, Long auditorId) {
        this.parameterCode = parameterCode;
        this.parameterValue = parameterValue;
        this.executeDate = executeDate;
        this.rateChangePlanStatus = (rateChangePlanStatus != null) ? rateChangePlanStatus.name() : null;
        this.operatorId = operatorId;
        this.auditorId = auditorId;
    }

    public String getParameterCode() {
        return parameterCode;
    }

    public BigDecimal getParameterValue() {
        return parameterValue;
    }

    public Date getExecuteDate() {
        return executeDate;
    }

    public RateChangePlanStatus getRateChangePlanStatus() {
        return RateChangePlanStatus.getRateChangePlanStatusByName(rateChangePlanStatus);
    }

    public void setRateChangePlanStatus(RateChangePlanStatus rateChangePlanStatus) {
        this.rateChangePlanStatus = (rateChangePlanStatus != null) ? rateChangePlanStatus.name() : null;
        this.updatedAt = new Date();
    }
}
