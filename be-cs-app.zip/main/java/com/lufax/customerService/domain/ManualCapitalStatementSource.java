package com.lufax.customerService.domain;

/**
 * Created by IntelliJ IDEA.
 * User: DENGGANG715
 * Date: 12-5-17
 * Time: 下午5:03
 * To change this template use File | Settings | File Templates.
 */
public enum ManualCapitalStatementSource {
    MANUAL,
    COMPENSATION,
    RARE_WORDS,
    OFFLINE;
}
