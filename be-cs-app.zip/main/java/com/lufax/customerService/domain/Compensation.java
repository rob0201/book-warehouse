package com.lufax.customerService.domain;

import com.lufax.common.domain.account.Money;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "COMPENSATIONS")
public class Compensation {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_COMPENSATIONS")
    @SequenceGenerator(name = "SEQ_COMPENSATIONS", sequenceName = "SEQ_COMPENSATIONS", allocationSize = 1)
    private long id;

    @Column(name = "LOAN_CODE")
    private String loanCode;

    @Embedded
    @AttributeOverrides({@AttributeOverride(name = "amount", column = @Column(name = "APPLIED_AMOUNT"))})
    private Money appliedAmount;

    @Embedded
    @AttributeOverrides({@AttributeOverride(name = "amount", column = @Column(name = "OVERDUE_PRINCIPAL"))})
    private Money overduePrincipal;

    @Embedded
    @AttributeOverrides({@AttributeOverride(name = "amount", column = @Column(name = "OVERDUE_INTEREST"))})
    private Money overdueInterest;

    @Embedded
    @AttributeOverrides({@AttributeOverride(name = "amount", column = @Column(name = "OVERDUE_PENALTY"))})
    private Money overduePenalty;

    @Embedded
    @AttributeOverrides({@AttributeOverride(name = "amount", column = @Column(name = "REMAINED_PRINCIPAL"))})
    private Money remainedPrincipal;

    @Embedded
    @AttributeOverrides({@AttributeOverride(name = "amount", column = @Column(name = "UNCALCULATE_INTEREST"))})
    private Money unCalculateInterest;

    @Embedded
    @AttributeOverrides({@AttributeOverride(name = "amount", column = @Column(name = "COMPENSATE_AMOUNT"))})
    private Money compensateAmount;

    @Column(name = "COMPENSATE_AT")
    private Date compensateAt;

    @Column(name = "STATUS")
    @Enumerated(EnumType.STRING)
    private CompensationStatus status;

    @Column(name = "IS_SEND_TO_XINBAO_COMPENSATED")
    private Boolean isSendToXinBaoHaveCompensated;

    @Column(name = "INPUT_DATE")
    private Date inputDate;

    @Column(name = "UPDATE_TIME")
    private Date updateTime;

    public Compensation() {
    }

    public Compensation(String loanCode, Money appliedAmount, Money overduePrincipal, Money overdueInterest, Money overduePenalty, Money remainedPrincipal, Money unCalculateInterest, Money compensateAmount, CompensationStatus status, Date compensateDate, Date inputDate) {
        this.loanCode = loanCode;
        this.appliedAmount = appliedAmount;
        this.overduePrincipal = overduePrincipal;
        this.overdueInterest = overdueInterest;
        this.overduePenalty = overduePenalty;
        this.remainedPrincipal = remainedPrincipal;
        this.unCalculateInterest = unCalculateInterest;
        this.compensateAmount = compensateAmount;
        this.status = status;
        this.compensateAt = compensateDate;
        this.inputDate = inputDate;
        this.updateTime = new Date();
    }


    public String getLoanCode() {
        return loanCode;
    }

    public Money getAppliedAmount() {
        return appliedAmount;
    }

    public Money getOverduePrincipal() {
        return overduePrincipal;
    }

    public Money getOverdueInterest() {
        return overdueInterest;
    }

    public Money getOverduePenalty() {
        return overduePenalty;
    }

    public Money getRemainedPrincipal() {
        return remainedPrincipal;
    }

    public Money getUnCalculateInterest() {
        return unCalculateInterest;
    }

    public Money getCompensateAmount() {
        return compensateAmount;
    }

    public Date getCompensateAt() {
        return compensateAt;
    }

    public CompensationStatus getStatus() {
        return status;
    }

    public void setLoanCode(String loanCode) {
        this.loanCode = loanCode;
    }

    public void setIsSendToXinBaoHaveCompenstaed(Boolean isSendToXinBaoHaveCompenstaed) {
        this.isSendToXinBaoHaveCompensated = isSendToXinBaoHaveCompenstaed;
    }

    public void setStatus(CompensationStatus status) {
        this.status = status;
    }

    public String getApplyContractName(CompensationApplyContractType contractType) {
        return contractType.contractNameOf(this);
    }

    public String getConfirmContractName(CompensationConfirmContractType contractType) {
        return contractType.contractNameOf(this);
    }

    public Boolean getSendToXinBaoHaveCompensated() {
        return isSendToXinBaoHaveCompensated;
    }

    public Date getInputDate() {
        return inputDate;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public long id() {
        return id;
    }


}
