package com.lufax.customerService.domain;


import javax.persistence.*;

@Entity
@Table(name = "cs_service_detail")
public class CsServiceDetail {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_cs_service_detail_id")
    @SequenceGenerator(name = "seq_cs_service_detail_id", sequenceName = "seq_cs_service_detail_id", allocationSize = 1)
    private Long id;

    @Column(name = "service_type_id")
    private Long serviceTypeId;

    @Column(name = "service_detail")
    private String serviceDetail;

    @Column(name = "service_record_id")
    private Long serviceRecordId;

    public CsServiceDetail() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getServiceDetail() {
        return serviceDetail;
    }

    public void setServiceDetail(String serviceDetail) {
        this.serviceDetail = serviceDetail;
    }

    public Long getServiceRecordId() {
        return serviceRecordId;
    }

    public void setServiceRecordId(Long serviceRecordId) {
        this.serviceRecordId = serviceRecordId;
    }

    public Long getServiceTypeId() {
        return serviceTypeId;
    }

    public void setServiceTypeId(Long serviceTypeId) {
        this.serviceTypeId = serviceTypeId;
    }
}
