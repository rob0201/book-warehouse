package com.lufax.customerService.domain;

import com.lufax.common.domain.product.AdminOperationType;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name="ADMIN_OPERATION_LOGS")
public class AdminOperationLog {
    @Id
    @GeneratedValue(strategy=GenerationType.SEQUENCE,generator="SEQ_ADMIN_OPERATION_LOGS")
    @SequenceGenerator(name="SEQ_ADMIN_OPERATION_LOGS", sequenceName="SEQ_ADMIN_OPERATION_LOGS", allocationSize=1)
    private long id;

  @Column(name="RELATION_ID")
  private long relationId;

    @Enumerated(EnumType.STRING)
    @Column(name="ADMIN_OPERATION_TYPE")
    private AdminOperationType adminOperationType;

//    @OneToOne(fetch=FetchType.LAZY)
//    @JoinColumn(name="OPERATOR",unique=true,nullable=false)
//    private User user;
    @Column(name="OPERATOR")
    private long userId;

    @Column(name="CREATED_AT")
    private Date createdAt;

    @Column(name="NOTE_INFORMATION")
    private String noteInformation;

    public AdminOperationLog(){

    }

    public AdminOperationLog(long userId, long relationId, String noteInformation, AdminOperationType adminOperationType){
        this.adminOperationType=adminOperationType;
        this.noteInformation=noteInformation;
        this.userId=userId;
        this.relationId=relationId;
        Date date =new Date();
        this.createdAt=date;
    }

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public long getId() {
        return id;
    }



    public AdminOperationType getAdminOperationType() {
        return adminOperationType;
    }

    public void setAdminOperationType(AdminOperationType adminOperationType) {
        this.adminOperationType = adminOperationType;
    }

//    public User getUser() {
//        return user;
//    }
//
//    public void setUser(User user) {
//        this.user = user;
//    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public String getNoteInformation() {
        return noteInformation;
    }

    public void setNoteInformation(String noteInformation) {
        this.noteInformation = noteInformation;
    }

    public long getRelationId() {
        return relationId;
    }

    public void setRelationId(long relationId) {
        this.relationId = relationId;
    }
}
