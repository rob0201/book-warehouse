package com.lufax.customerService.domain;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;

@Embeddable
public class MemberBindAuthId implements Serializable {
    @Column(name = "party_no")
    private String partyNo;

    @Column(name = "auth_service_type")
    private String authType;

    public MemberBindAuthId() {

    }

    public String getPartyNo() {
        return partyNo;
    }

    public void setPartyNo(String partyNo) {
        this.partyNo = partyNo;
    }

    public String getAuthType() {
        return authType;
    }

    public void setAuthType(String authType) {
        this.authType = authType;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof MemberBindAuthId)) return false;

        MemberBindAuthId that = (MemberBindAuthId) o;

        if (authType != null ? !authType.equals(that.authType) : that.authType != null) return false;
        if (partyNo != null ? !partyNo.equals(that.partyNo) : that.partyNo != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = partyNo != null ? partyNo.hashCode() : 0;
        result = 31 * result + (authType != null ? authType.hashCode() : 0);
        return result;
    }
}
