package com.lufax.customerService.domain;

/**
 * Created by IntelliJ IDEA.
 * User: DENGGANG715
 * Date: 12-5-17
 * Time: 下午5:04
 * To change this template use File | Settings | File Templates.
 */
public enum ManualCapitalStatementStatus {
    NEW("未回销"),
    AUTDING("待审核"),
    PROCESSING("打回"),
    CLOSED("已关闭"),
    FAILED("取现失败"),
    SUCCESS("已回销");
    
    private String value;
    
    private ManualCapitalStatementStatus(String value){
    	this.value = value;
    }

	public String getValue() {
		return value;
	}
    
}
