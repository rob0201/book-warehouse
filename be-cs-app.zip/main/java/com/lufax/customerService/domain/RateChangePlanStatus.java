package com.lufax.customerService.domain;

public enum RateChangePlanStatus {
    CREATED,
    VALID,
    DONE,
    UNKNOWN;
    public static RateChangePlanStatus getRateChangePlanStatusByName(String status){
        RateChangePlanStatus[] rateChangePlanStatuses=RateChangePlanStatus.values();
        for(RateChangePlanStatus rateChangePlanStatus:rateChangePlanStatuses)
            if(rateChangePlanStatus.name().equalsIgnoreCase(status))
                return rateChangePlanStatus;
        return UNKNOWN;
    }
}
