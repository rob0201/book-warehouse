package com.lufax.customerService.domain.repository;

import com.lufax.common.domain.repository.BaseRepository;
import com.lufax.common.utils.DateUtils;
import com.lufax.customerService.domain.RateChangePlan;
import org.springframework.stereotype.Repository;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

import static com.lufax.customerService.domain.RateChangePlanStatus.*;

@Repository
public class RateChangePlanRepository extends BaseRepository<RateChangePlan> {

    public List<RateChangePlan> findRateChangeToExecute(Date date) {
        Date endOfToday = DateUtils.endOfDay(date);
        return entityManager.createQuery("select rcp from RateChangePlan rcp where " +
                "rcp.rateChangePlanStatus=:status and rcp.executeDate<:endOfToday", RateChangePlan.class)
                .setParameter("status", CREATED.name()).setParameter("endOfToday", endOfToday).getResultList();
    }

    public List<RateChangePlan> findRateChangeToApply() {
        return entityManager.createQuery("select rcp from RateChangePlan rcp where " +
                "rcp.rateChangePlanStatus=:status ", RateChangePlan.class)
                .setParameter("status", VALID.name()).getResultList();
    }

    public List<RateChangePlan> findRateChangePlanValidAndDone() {
        return entityManager.createQuery("select rcp from RateChangePlan rcp where " +
                "rcp.rateChangePlanStatus in(:status) order by rcp.executeDate asc", RateChangePlan.class)
                .setParameter("status", Arrays.asList(VALID.name(), DONE.name())).getResultList();
    }
}
