package com.lufax.customerService.domain.repository;


import com.lufax.common.domain.repository.BaseRepository;
import com.lufax.customerService.domain.CsServiceDetail;
import org.springframework.stereotype.Repository;

@Repository
public class CsServiceDetailRepository extends BaseRepository<CsServiceDetail> {

}
