package com.lufax.customerService.domain.repository;

import com.lufax.common.domain.repository.BaseRepository;
import com.lufax.customerService.domain.CsVisitor;
import org.springframework.stereotype.Repository;

@Repository
public class CsVisitorRepository extends BaseRepository<CsVisitor> {

}
