package com.lufax.customerService.domain.repository;


import com.lufax.common.domain.repository.BaseRepository;
import com.lufax.customerService.domain.CsServiceRecord;
import org.springframework.stereotype.Repository;

@Repository
public class CsServiceRecordRepository extends BaseRepository<CsServiceRecord> {

}
