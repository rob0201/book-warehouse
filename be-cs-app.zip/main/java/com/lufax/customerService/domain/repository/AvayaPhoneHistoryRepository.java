package com.lufax.customerService.domain.repository;

import com.lufax.common.domain.repository.BaseRepository;
import com.lufax.customerService.domain.AvayaPhoneHistory;
import org.springframework.stereotype.Repository;

/**
 * Created by IntelliJ IDEA.
 * User: caoyanfei079
 * Date: 12-10-18
 * Time: 下午6:34
 * To change this template use File | Settings | File Templates.
 */
@Repository
public class AvayaPhoneHistoryRepository extends BaseRepository<AvayaPhoneHistory> {
}
