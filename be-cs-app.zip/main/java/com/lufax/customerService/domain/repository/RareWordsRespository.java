package com.lufax.customerService.domain.repository;

import com.lufax.common.domain.repository.BaseRepository;
import com.lufax.common.utils.DevLog;
import com.lufax.customerService.domain.RareWords;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class RareWordsRespository extends BaseRepository<RareWords> {


    public RareWordsRespository(){

    }

    public List<RareWords> findAllRareWords(int maxNum, int offset){
        return entityManager.createQuery("select rw from RareWords rw", RareWords.class).setMaxResults(maxNum).setFirstResult(offset).getResultList();
    }
    public Long countOfRareWords(){
        return entityManager.createQuery("select  count (w) from RareWords w",Long.class).getSingleResult();
    }
     public List<RareWords> findAllRareWords(){
        return entityManager.createQuery("select rareWords from RareWords rareWords", RareWords.class).getResultList();
    }
     public boolean findAllRareWordCount(String rareWord){
    	 long count = entityManager.createQuery("select count(rareWords) from RareWords rareWords where rareWords.word=:rareWord", Long.class).setParameter("rareWord", rareWord.trim()).getSingleResult();
    	 DevLog.info(this, String.format("The rareWord:[%s], count is :[%s]", rareWord,count));
    	 if(count>0){
    		 return false;
    	 }
    	 return true;
     }
}
