package com.lufax.customerService.domain.repository;


import org.springframework.stereotype.Repository;

@Repository
public class CsServiceTypeRepository {
}
