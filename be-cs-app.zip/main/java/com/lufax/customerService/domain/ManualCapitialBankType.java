package com.lufax.customerService.domain;

/**
 * Created by IntelliJ IDEA.
 * User: DENGGANG715
 * Date: 12-5-18
 * Time: 下午3:13
 * To change this template use File | Settings | File Templates.
 */
public enum ManualCapitialBankType {
     BANK_OF_PINGAN("bank of pingan","pingan"),
    BANK_OF_SHEN_DEVELOP("bank of shen develop","shen develop")
   ;
    private String name;
    private String chineseName;
    ManualCapitialBankType(String name, String chineseName){
        this.name=name;
        this.chineseName=chineseName;

    }
}
