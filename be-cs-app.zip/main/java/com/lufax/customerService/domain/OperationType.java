package com.lufax.customerService.domain;

public enum OperationType {

    LOAN_REQUEST("贷款请求"),
    SEND_USER_NAME("短信发送用户账号"),
    UNKNOWN("unknown");

    private String value;

    OperationType(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
    public  static OperationType getOperationTypeByName(String name){
        OperationType[] operationTypes=OperationType.values();
        for(OperationType operationType:operationTypes)
            if(operationType.name().equalsIgnoreCase(name))
                return operationType;
        return UNKNOWN;
    }
}
