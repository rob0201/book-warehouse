package com.lufax.customerService.domain;


import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "CS_VISITOR")
public class CsVisitor {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_cs_visitor_id")
    @SequenceGenerator(name = "seq_cs_visitor_id", sequenceName = "seq_cs_visitor_id", allocationSize = 1)
    private Long id;

    @Column(name = "name")
    private String name;

    @Column(name = "sys_user_name")
    private String userName;

    @Column(name = "gender")
    private String gender;

    @Column(name = "visit_phone_no")
    private String visitPhoneNo;

    @Column(name = "register_phone_no")
    private String registerPhoneNo;

    @Column(name = "address")
    private String address;

    @Column(name = "sys_user_id")
    private Long userId;

    @Column(name = "remark")
    private String remark;

    @Column(name = "visit_count")
    private Integer visitCount;

    @Column(name = "last_visit_time")
    private Date lastVisitTime;
    
    @Enumerated(EnumType.STRING)
    @Column(name = "vistor_contact_source")
    private VisitorContactType contactSourceType;

    @Column(name="contract_mobile")
    private String contractMobile;

    @Column(name="contract_phone")
    private String contractPhone;


    public CsVisitor() {
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Date getLastVisitTime() {
        return lastVisitTime;
    }

    public void setLastVisitTime(Date lastVisitTime) {
        this.lastVisitTime = lastVisitTime;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRegisterPhoneNo() {
        return registerPhoneNo;
    }

    public void setRegisterPhoneNo(String registerPhoneNo) {
        this.registerPhoneNo = registerPhoneNo;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public Integer getVisitCount() {
        return visitCount;
    }

    public void setVisitCount(Integer visitCount) {
        this.visitCount = visitCount;
    }

    public String getVisitPhoneNo() {
        return visitPhoneNo;
    }

    public void setVisitPhoneNo(String visitPhoneNo) {
        this.visitPhoneNo = visitPhoneNo;
    }

	public VisitorContactType getContactSourceType() {
		return contactSourceType;
	}
	
	public String getContactSourceTypeName() {
		return contactSourceType.name();
	}


	public void setContactSourceType(VisitorContactType contactSourceType) {
		this.contactSourceType = contactSourceType;
	}

    public String getContractMobile() {
        return contractMobile;
    }

    public void setContractMobile(String contractMobile) {
        this.contractMobile = contractMobile;
    }

    public String getContractPhone() {
        return contractPhone;
    }

    public void setContractPhone(String contractPhone) {
        this.contractPhone = contractPhone;
    }

    @Override
    public String toString() {
        return "CsVisitor{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", userName='" + userName + '\'' +
                ", gender='" + gender + '\'' +
                ", visitPhoneNo='" + visitPhoneNo + '\'' +
                ", registerPhoneNo='" + registerPhoneNo + '\'' +
                ", address='" + address + '\'' +
                ", userId=" + userId +
                ", remark='" + remark + '\'' +
                ", visitCount=" + visitCount +
                ", lastVisitTime=" + lastVisitTime +
                ", contactSourceType=" + contactSourceType +
                ", contractMobile='" + contractMobile + '\'' +
                ", contractPhone='" + contractPhone + '\'' +
                '}';
    }
}
