package com.lufax.customerService.domain;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "RARE_WORDS")
public class RareWords {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_RARE_WORDS")
    @SequenceGenerator(name = "SEQ_RARE_WORDS", sequenceName = "SEQ_RARE_WORDS", allocationSize = 1)
    private long id;
    @Column(name = "WORD")
    private String word;

    @Column(name="CREATED_BY")
    private String createdBy;

    @Column(name = "CREATED_AT")
    private Date createdAt;

    @Column(name="UPDATED_AT")
    private Date updatedAt;

    @Column(name="UPDATED_BY")
    private String updatedBy;

    @Column(name="IS_AVAILABLE")
     private boolean isAvailable;



    public RareWords(){

    }
    public RareWords(String createdBy, String word ) {
        this.createdBy=createdBy;
        this.word = word;
        Date date= new Date();
        this.createdAt=date;
        this.updatedAt=date;
        this.isAvailable=true;
    }


    public String getWord() {
        return word;
    }

    public void setWord(String word) {
        this.word = word;
        this.createdAt=new Date();
    }

    public long id() {
        return id;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Date updatedAt) {
        this.updatedAt = updatedAt;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public boolean isAvailable() {
        return isAvailable;
    }

    public void setAvailable(boolean available) {
        isAvailable = available;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }
}
