package com.lufax.customerService.domain;

import java.util.Date;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.ColumnResult;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EntityResult;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.Table;

import com.lufax.common.domain.WithdrawRecord;
import com.lufax.common.domain.account.Money;


@SqlResultSetMapping(
name="ManualCapitalStatementResults",
entities={@EntityResult(entityClass=ManualCapitalStatement.class)},
columns={ @ColumnResult(name="accountUsername"),
		  @ColumnResult(name="fcuUserName"),
		  @ColumnResult(name="lcuUserName"),
          @ColumnResult(name="BANK_ACCOUNT_CODE"),
          @ColumnResult(name="BANK_NAME")}
)
@Entity
@Table(name = "MANUAL_CAPATIAL_STATEMENT")
public class ManualCapitalStatement {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_MANUAL_CAPATIAL_STATEMENT")
    @SequenceGenerator(name = "SEQ_MANUAL_CAPATIAL_STATEMENT", sequenceName = "SEQ_MANUAL_CAPATIAL_STATEMENT", allocationSize = 1)
    private Long id;
    
    @Column(name = "ACCOUNT_ID")
    private String accountId;    
    
    @Embedded
    @AttributeOverrides({@AttributeOverride(name = "amount", column = @Column(name = "AMOUNT"))})
    private Money amount;

    @Column(name = "OPERATION_TYPE")
    @Enumerated(EnumType.STRING)
    private ManualCapitalStatementType type;
    
    @Column(name="OPERATION_RELATION_ID")
    private Long operationRelationId;  
    
    @Column(name = "BANK_ACCOUNT")
    private String bankAccount;
    
    @Column(name = "BANK_TRANSACTION_NO")
    private String bankTransactionNo;
    
    @Column(name = "MANUAL_CAPATIAL_STATEMENT_DESC")
    private String desc;
    
    @Column(name="EOA_NO")
    private String eoaNo;    

    @Column(name = "SOURCE_TYPE")
    @Enumerated(EnumType.STRING)
    private ManualCapitalStatementSource source;
    
    @Column(name="SOURCE_RELATION_ID")
    private String sourceRelationId;
    

    @Column(name = "STATUS")
    @Enumerated(EnumType.STRING)
    private ManualCapitalStatementStatus status;
    
    @Column(name = "REMARK")
    private String remark;
    
    @Column(name = "FCD")
    private Date fcd;
    
    @Column(name="FCU")
    private String fcu;

    @Column(name="LCD")
    private Date lcd;
    
    @Column(name="LCU")
    private String lcu;


    public ManualCapitalStatement() {
        this.status = ManualCapitalStatementStatus.NEW;
        this.fcd=new Date();
    }

    public ManualCapitalStatement(Money amount, String sourceRelationId, ManualCapitalStatementSource manualCapitalStatementSource, ManualCapitalStatementType manualCapitalStatementType, ManualCapitalStatementStatus manualCapitalStatementStatus) {
        this.source= manualCapitalStatementSource;
        this.status= manualCapitalStatementStatus;
        this.type= manualCapitalStatementType;
        this.amount = amount;
        this.sourceRelationId = sourceRelationId;
        this.fcd=new Date();
    }
    
    public ManualCapitalStatement(WithdrawRecord record) {
        this.source= ManualCapitalStatementSource.RARE_WORDS;
        this.type= ManualCapitalStatementType.WITHDRAW;
        this.amount = record.getWithdrawAmount();
        this.sourceRelationId = record.id()+"";
        this.operationRelationId = record.id();
        this.fcd=new Date();
    }


    public Money getAmount() {
        return amount;
    }

    

    public void setAmount(Money amount) {
        this.amount = amount;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public ManualCapitalStatementType getType() {
        return type;
    }

    public void setType(ManualCapitalStatementType type) {
        this.type = type;
    }

    public ManualCapitalStatementSource getSource() {
        return source;
    }

    public void setSource(ManualCapitalStatementSource source) {
        this.source = source;
    }

    public ManualCapitalStatementStatus getStatus() {
        return status;
    }

    public void setStatus(ManualCapitalStatementStatus status) {
        this.status = status;
    }

    public String getBankAccount() {
        return bankAccount;
    }

    public void setBankAccount(String bankAccount) {
        this.bankAccount = bankAccount;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

	public String getAccountId() {
		return accountId;
	}

	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

	public String getBankTransactionNo() {
		return bankTransactionNo;
	}

	public void setBankTransactionNo(String bankTransactionNo) {
		this.bankTransactionNo = bankTransactionNo;
	}

	public String getEoaNo() {
		return eoaNo;
	}

	public void setEoaNo(String eoaNo) {
		this.eoaNo = eoaNo;
	}

	public Date getFcd() {
		return fcd;
	}

	public void setFcd(Date fcd) {
		this.fcd = fcd;
	}

	public String getFcu() {
		return fcu;
	}

	public void setFcu(String fcu) {
		this.fcu = fcu;
	}

	public Date getLcd() {
		return lcd;
	}

	public void setLcd(Date lcd) {
		this.lcd = lcd;
	}

	public String getLcu() {
		return lcu;
	}

	public void setLcu(String lcu) {
		this.lcu = lcu;
	}

	public Long getOperationRelationId() {
		return operationRelationId;
	}

	public void setOperationRelationId(Long operationRelationId) {
		this.operationRelationId = operationRelationId;
	}

	public String getSourceRelationId() {
		return sourceRelationId;
	}

	public void setSourceRelationId(String sourceRelationId) {
		this.sourceRelationId = sourceRelationId;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	@Override
	public String toString() {
		return "ManualCapitalStatement [accountId=" + accountId + ", amount="
				+ amount + ", type=" + type + ", operationRelationId="
				+ operationRelationId + ", bankAccount=" + bankAccount
				+ ", bankTransactionNo=" + bankTransactionNo + ", desc=" + desc
				+ ", eoaNo=" + eoaNo + ", source=" + source
				+ ", sourceRelationId=" + sourceRelationId + ", status="
				+ status + ", remark=" + remark + ", fcd=" + fcd + ", fcu="
				+ fcu + ", lcd=" + lcd + ", lcu=" + lcu + "]";
	}
	
}
