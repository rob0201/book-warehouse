package com.lufax.customerService.pojo;

public enum MarketLevel {

	LEVEL1("一级市场"),LEVEL2("二级市场");
	
	private String value;
	
	MarketLevel(String value){
		this.value = value;
	}

	public String getValue() {
		return value;
	}

}
