package com.lufax.customerService.pojo;

public enum CollectWay {
    SERIALIZE("串行"),
    CONCURRENT("并行"),
    UNKNOWN("unknown");

    private String value;

    private CollectWay(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
    public static CollectWay getCollectWayByName(String name){
        CollectWay[] collectWays=CollectWay.values();
        for (CollectWay collectWay:collectWays)
            if (collectWay.name().equalsIgnoreCase(name))
                return collectWay;
        return UNKNOWN;

    }
}
