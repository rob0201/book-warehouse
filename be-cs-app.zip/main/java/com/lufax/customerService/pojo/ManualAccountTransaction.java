package com.lufax.customerService.pojo;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.lufax.common.domain.TransactionType;
import com.lufax.common.domain.User;
import com.lufax.common.domain.account.Account;

@Entity
@Table(name = "MANUAL_ACC_TRANSACTION")
public class ManualAccountTransaction {
	
	@Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_MANUAL_ACC_TRANSACTION")
    @SequenceGenerator(name = "SEQ_MANUAL_ACC_TRANSACTION", sequenceName = "SEQ_MANUAL_ACC_TRANSACTION", allocationSize = 1)
	private long id;

	//转出虚拟帐户
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "ACCOUNT_OUT_ID")
	private Account accountOut;
	
	//转入虚拟帐户
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "ACCOUNT_IN_ID")
	private Account accountIn;
	
	//资金转出类型
	@Enumerated(EnumType.STRING)
	@Column(name = "TRANSACTION_OUT_TYPE")
	private TransactionType transactionOutType;
	
	//资金转入类型
	@Enumerated(EnumType.STRING)
	@Column(name = "TRANSACTION_IN_TYPE")
	private TransactionType transactionInType;
	
	//转账金额
	@Column(name = "AMOUNT")
	private BigDecimal amount;
	
	//备注
	@Column(name = "REMARK")
	private String remark;
	
	//状态
	@Enumerated(EnumType.STRING)
	@Column(name = "STATUS")
	private ManualAccountTransactionStatus status;
	
	//申请人
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "APPLY_BY")
	private User applier;
	
	//审批人
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "APPROVE_BY")
	private User approver;
	
	//失败原因
	@Column(name = "ERROR_MSG")
	private String errorMsg;
	
	//申请时间
	@Temporal(TemporalType.DATE)
	@Column(name = "APPLY_AT")
	private Date applyAt;
	
	//更新时间
	@Temporal(TemporalType.DATE)
	@Column(name = "UPDATE_AT")
	private Date updateAt;

	public ManualAccountTransaction() {
	}
	
	public ManualAccountTransaction(Account accountOut, Account accountIn, TransactionType transactionOutType, TransactionType transactionInType, BigDecimal amount, User applier, String remark) {
		this.accountOut = accountOut;
		this.accountIn = accountIn;
		this.transactionOutType = transactionOutType;
		this.transactionInType = transactionInType;
		this.amount = amount;
		this.applier = applier;
		this.applyAt = new Date();
		this.status = ManualAccountTransactionStatus.WAIT_APPROVE;
		this.remark = remark;
	}

	public long getId() {
		return id;
	}

	private void setId(long id) {
		this.id = id;
	}

	public Account getAccountOut() {
		return accountOut;
	}

	public void setAccountOut(Account accountOut) {
		this.accountOut = accountOut;
	}

	public Account getAccountIn() {
		return accountIn;
	}

	public void setAccountIn(Account accountIn) {
		this.accountIn = accountIn;
	}

	public TransactionType getTransactionOutType() {
		return transactionOutType;
	}

	public void setTransactionOutType(TransactionType transactionOutType) {
		this.transactionOutType = transactionOutType;
	}

	public TransactionType getTransactionInType() {
		return transactionInType;
	}

	public void setTransactionInType(TransactionType transactionInType) {
		this.transactionInType = transactionInType;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public ManualAccountTransactionStatus getStatus() {
		return status;
	}

	public void setStatus(ManualAccountTransactionStatus status) {
		this.status = status;
	}

	public User getApplier() {
		return applier;
	}

	public void setApplier(User applier) {
		this.applier = applier;
	}

	public User getApprover() {
		return approver;
	}

	public void setApprover(User approverId) {
		this.approver = approverId;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public Date getApplyAt() {
		return applyAt;
	}

	public void setApplyAt(Date applyAt) {
		this.applyAt = applyAt;
	}

	public Date getUpdateAt() {
		return updateAt;
	}

	public void setUpdateAt(Date updateAt) {
		this.updateAt = updateAt;
	}
	
}
