package com.lufax.customerService.pojo;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.lufax.common.domain.User;

@Entity
@Table(name = "BUY_REQUEST_POOL")
public class BuyRequestPool {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_BUY_REQUEST_POOL")
    @SequenceGenerator(name = "SEQ_BUY_REQUEST_POOL", sequenceName = "SEQ_BUY_REQUEST_POOL", allocationSize = 1)
    private Long id;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "BUYER_ID")
    private User buyer;

    @Column(name = "PRODUCT_ID")
    private Long productId;

    @Column(name = "TARGET_SHARES")
    private BigDecimal targetShares;

    @Column(name = "TARGET_PRICE")
    private BigDecimal targetPrice;

    @Column(name = "ACTUAL_SHARES")
    private BigDecimal actualShares;

    @Enumerated(EnumType.STRING)
    @Column(name = "MARKET_LEVEL")
    private MarketLevel level;

    @Column(name = "CREATE_AT")
    private Date createAt;

    @Column(name = "UPDATE_AT")
    private Date updateAt;

    @Enumerated(EnumType.STRING)
    @Column(name = "STATUS")
    private BuyRequestStatus status;

    @Column(name = "ACCOUNT_FROZEN_NO")
    private Long accountFrozenNo;
    
    @Column(name = "SALE_REQUEST_POOL_ID")
    private Long saleRequestPoolId;

    public BuyRequestPool() {
    	this.createAt = new Date();
    }

    public BuyRequestPool(Long productId, User buyer, BigDecimal purchaseAmount, BigDecimal purchaseShares) {
        this.buyer = buyer;
        this.productId = productId;
        this.targetShares = purchaseShares;
        this.targetPrice = purchaseAmount.divide(purchaseShares, 2, RoundingMode.DOWN);
        this.actualShares = BigDecimal.ZERO;
        this.createAt = new Date();
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public User getBuyer() {
        return buyer;
    }

    public void setBuyer(User buyer) {
        this.buyer = buyer;
    }

    public Long getProductId() {
        return productId;
    }

    public void setProductId(Long productId) {
        this.productId = productId;
    }

    public BigDecimal getTargetShares() {
        return targetShares;
    }

    public void setTargetShares(BigDecimal targetShares) {
        this.targetShares = targetShares;
    }

    public BigDecimal getTargetPrice() {
        return targetPrice;
    }

    public void setTargetPrice(BigDecimal targetPrice) {
        this.targetPrice = targetPrice;
    }

    public BigDecimal getActualShares() {
        return actualShares;
    }

    public void setActualShares(BigDecimal actualShares) {
        this.actualShares = actualShares;
    }
    
    public MarketLevel getLevel() {
		return level;
	}

	public void setLevel(MarketLevel level) {
		this.level = level;
	}

	public Date getCreateAt() {
        return createAt;
    }

    public void setCreateAt(Date createAt) {
        this.createAt = createAt;
    }

    public Date getUpdateAt() {
        return updateAt;
    }

    public void setUpdateAt(Date updateAt) {
        this.updateAt = updateAt;
    }

    public BuyRequestStatus getStatus() {
        return status;
    }

    public void setStatus(BuyRequestStatus status) {
        this.status = status;
    }

    public Long getAccountFrozenNo() {
        return accountFrozenNo;
    }

    public void setAccountFrozenNo(Long accountFrozenNo) {
        this.accountFrozenNo = accountFrozenNo;
    }

	public Long getSaleRequestPoolId() {
		return saleRequestPoolId;
	}

	public void setSaleRequestPoolId(Long saleRequestPoolId) {
		this.saleRequestPoolId = saleRequestPoolId;
	}
    
}
