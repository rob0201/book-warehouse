package com.lufax.customerService.pojo;

public enum RepayAuditStatus {
	WAIT_AUDIT("待审核"),
	AUDIT_FAILED("审核失败"),
	AUDIT_SUCCESS("审核成功");

    private String value;

    private RepayAuditStatus(String status) {
        this.value = status;
    }

    public String getValue() {
        return value;
    }

}
