package com.lufax.customerService.pojo;

public enum BuyRequestStatus {
	
	WAIT_TO_PROCESS("待处理"), WAIT_CONFIRM("等待确认"), SUCCESS("投资成功"), FAIL("投资失败"),
	FREEZE_FAIL("冻结失败"), REQUEST_FAIL("申请失败"), FINISH_COLLECT("收款结束");

	private String value;
	
	BuyRequestStatus(String value){
		this.value = value;
	}

	public String getValue() {
		return value;
	}
	
	

}
