package com.lufax.customerService.pojo;

public enum SMETemplateType {
	
	CONTRACT;

}
