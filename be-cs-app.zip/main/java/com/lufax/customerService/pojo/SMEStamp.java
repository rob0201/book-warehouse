package com.lufax.customerService.pojo;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "SME_STAMP")
public class SMEStamp {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_SME_STAMP")
    @SequenceGenerator(name = "SEQ_SME_STAMP", sequenceName = "SEQ_SME_STAMP", allocationSize = 1)
    private long id;

    @Column(name = "NAME")
    private String name;//印章名称

    @Column(name = "LOCATION_X")
    private BigDecimal locationX;//印章水平位置

    @Column(name = "LOCATION_Y")
    private BigDecimal locationY;//印章垂直位置
    
    @Column(name = "REMARK")
    private String remark;//备注
    
    @Temporal(TemporalType.DATE)
    @Column(name = "CREATE_AT")
    private Date createAt;//创建时间
    
    @Column(name = "CREATOR")
    private long creatorId;//创建人
    
    public SMEStamp(){}

	public long getId() {
		return id;
	}

	private void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public BigDecimal getLocationX() {
		return locationX;
	}

	public void setLocationX(BigDecimal locationX) {
		this.locationX = locationX;
	}

	public BigDecimal getLocationY() {
		return locationY;
	}

	public void setLocationY(BigDecimal locationY) {
		this.locationY = locationY;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Date getCreateAt() {
		return createAt;
	}

	public void setCreateAt(Date createAt) {
		this.createAt = createAt;
	}

	public long getCreatorId() {
		return creatorId;
	}

	public void setCreatorId(long creatorId) {
		this.creatorId = creatorId;
	}
}