package com.lufax.customerService.pojo;

public enum AssetStatus {
    WAIT_AUDIT("等待审核"),
    DURING_INSERT("录入"),
    BEFORE_NOTICE("预告前"),
    DURING_NOTICE("预告中"),
    DURING_COLLECTION("募集中"),
    WAIT_CONTRACT_CONFIRM("等待合同确认"),
    COLLECT_SUCCESS("募集成功"),
    COLLECT_FAIL("募集失败"),
    UNKONWN("unkonwn");

    private String value;

    private AssetStatus(String status) {
        this.value = status;
    }

    public String getValue() {
        return value;
    }

    public static void main(String arg[]){
        AssetStatus assetStatus=null;
        assetStatus=AssetStatus.valueOf("WAIT_AUDIT");
//        AssetStatus assetStatus2="WAIT_AUDIT";
    }
    public static AssetStatus getAssetStatusByName(String name){
        AssetStatus[]  assetStatuses=AssetStatus.values();
        for(AssetStatus assetStatus:assetStatuses)
            if(assetStatus.name().equalsIgnoreCase(name))
                return assetStatus;
        return UNKONWN;
    }
}
