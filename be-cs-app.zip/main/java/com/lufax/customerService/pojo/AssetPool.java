package com.lufax.customerService.pojo;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.lufax.common.domain.User;

@Entity
@Table(name = "SME_ASSET_POOL")
public class AssetPool  {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_SME_ASSET_POOL")
    @SequenceGenerator(name = "SEQ_SME_ASSET_POOL", sequenceName = "SEQ_SME_ASSET_POOL", allocationSize = 1)
    private long id;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ASSET_ID")
    private Asset asset;

    @OneToOne(mappedBy = "assetPool",fetch = FetchType.EAGER)
    private ExtProductSME extProductSME;

    @Column(name = "NAME")
    private String name;

    @Column(name = "MANAGE_CHARGE")
    private BigDecimal manageCharge;

    @Column(name = "FCD")
    private Date fcd;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "FCU")
    private User fcu;

    @Column(name = "LCD")
    private Date lcd;

    @Column(name = "LCU")
    private String lcu;
    
    @OneToOne(mappedBy = "assetPool",fetch = FetchType.LAZY)
    private ExtProductSME product;


    public AssetPool() {
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Asset getAsset() {
        return asset;
    }

    public void setAsset(Asset asset) {
        this.asset = asset;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public BigDecimal getManageCharge() {
        return manageCharge;
    }

    public void setManageCharge(BigDecimal manageCharge) {
        this.manageCharge = manageCharge;
    }

    public Date getFcd() {
        return fcd;
    }

    public void setFcd(Date fcd) {
        this.fcd = fcd;
    }

    public User getFcu() {
        return fcu;
    }

    public void setFcu(User fcu) {
        this.fcu = fcu;
    }

    public Date getLcd() {
        return lcd;
    }

    public void setLcd(Date lcd) {
        this.lcd = lcd;
    }

    public String getLcu() {
        return lcu;
    }

    public void setLcu(String lcu) {
        this.lcu = lcu;
    }

	public final ExtProductSME getExtProductSME() {
		return extProductSME;
	}

	public final void setExtProductSME(ExtProductSME extProductSME) {
		this.extProductSME = extProductSME;
	}

	public ExtProductSME getProduct() {
		return product;
	}
	
//	@Override
//	public String toString() {
//		return "AssetPool [id=" + id + ", asset=" + asset + ", extProductSME=" + extProductSME + ", name=" + name + ", manageCharge=" + manageCharge + ", fcd=" + fcd + ", fcu=" + fcu + ", lcd=" + lcd + ", lcu=" + lcu + "]";
//	}

   
}
