package com.lufax.customerService.pojo;

public enum RepaymentWay {
	EQUALMONTHLYPRINCIPAL("每月等额本金"),
    ONCEREPAY("一次还本付息"),
    SAMEPRINCANDINST("每月等额本息"),
    SAMEPRINCIPAL("每月还息,到期还本");

    private String value;

    private RepaymentWay(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
    public static RepaymentWay getRepaymentWayByName(String name){
        RepaymentWay[] repaymentWays=RepaymentWay.values();
        for(RepaymentWay repaymentWay:repaymentWays)
            if(repaymentWay.name().equalsIgnoreCase(name))
                return repaymentWay;
        throw new RuntimeException(String.format("RepaymentWay [%s] does not exist", name));
    }
}
