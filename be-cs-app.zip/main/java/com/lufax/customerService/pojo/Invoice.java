package com.lufax.customerService.pojo;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "SME_INVOICE")
public class Invoice {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_SME_INVOICE")
    @SequenceGenerator(name = "SEQ_SME_INVOICE", sequenceName = "SEQ_SME_INVOICE")
    private long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ASSET_POOL_ID")
    private AssetPool assetPool;

    @Column(name = "SERIALIZE_NO")
    private String serializeNo;

    @Column(name = "INVOICE_NO")
    private String invoiceNo;

    @Column(name = "BUYER")
    private String buyer;

    @Column(name = "SALER")
    private String saler;

    @Column(name = "ACCOUNTS")
    private BigDecimal accounts;

    @Column(name = "CREATE_DATE")
    private Date createDate;

    @Column(name = "DEADLINE")
    private Date deadLine;

    @Column(name = "FCD")
    private Date fcd;

    @Column(name = "FCU")
    private String fcu;

    @Column(name = "LCD")
    private Date lcd;

    @Column(name = "LCU")
    private String lcu;

    public Invoice() {
    }

    public AssetPool getAssetPool() {
        return assetPool;
    }

    public void setAssetPool(AssetPool assetPool) {
        this.assetPool = assetPool;
    }

    public String getSerializeNo() {
        return serializeNo;
    }

    public void setSerializeNo(String serializeNo) {
        this.serializeNo = serializeNo;
    }

    public String getInvoiceNo() {
        return invoiceNo;
    }

    public void setInvoiceNo(String invoiceNo) {
        this.invoiceNo = invoiceNo;
    }

    public String getBuyer() {
        return buyer;
    }

    public void setBuyer(String buyer) {
        this.buyer = buyer;
    }

    public String getSaler() {
        return saler;
    }

    public void setSaler(String saler) {
        this.saler = saler;
    }

    public BigDecimal getAccounts() {
        return accounts;
    }

    public void setAccounts(BigDecimal accounts) {
        this.accounts = accounts;
    }

    public Date getDeadLine() {
        return deadLine;
    }

    public void setDeadLine(Date deadLine) {
        this.deadLine = deadLine;
    }

    public Date getFcd() {
        return fcd;
    }

    public void setFcd(Date fcd) {
        this.fcd = fcd;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getFcu() {
        return fcu;
    }

    public void setFcu(String fcu) {
        this.fcu = fcu;
    }

    public Date getLcd() {
        return lcd;
    }

    public void setLcd(Date lcd) {
        this.lcd = lcd;
    }

    public String getLcu() {
        return lcu;
    }

    public void setLcu(String lcu) {
        this.lcu = lcu;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }
}
