package com.lufax.customerService.pojo;

public enum SMEProductType {
	HUIXIN("汇鑫"),JYT("金盈通"),ANYEDAI("稳盈-安业贷"),YINGTONG("盈通");
    
    private String value;
    
    SMEProductType(String value){
           this.value = value;
    }

    public String getValue() {
           return value;
    } 
}
