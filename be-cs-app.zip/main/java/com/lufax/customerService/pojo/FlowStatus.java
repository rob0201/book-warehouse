package com.lufax.customerService.pojo;

public enum FlowStatus {
	WAIT_SECOND_CONFIRM("等待确认"),//等待二次确认
	PRODUCT_CONFIRM_REJECT("拒绝"),//拒绝
	PRODUCT_CONFIRMED("已确认"),//已确认
    BEFORE_NOTICE("预告前"),//预告前
    DURING_NOTICE("预告中"),//预告中
    DURING_COLLECTION("募集中"),//募集中
    WAIT_CONTRACT_CONFIRM("等待合同确认"),//等待合同确认
    COLLECT_SUCCESS("募集成功"),//募集成功
    COLLECT_FAIL("募集失败"),//募集失败
    FINISH_REPAY("还款结束"),//还款结束
    UNKNOW("未知");//未知状态(容错)

    private String value;

    private FlowStatus(String status) {
        this.value = status;
    }

    public String getValue() {
        return value;
    }
    
    public static FlowStatus getStatus(String statusName) {
    	
    	FlowStatus[] statusList = FlowStatus.values();
    	for (FlowStatus status : statusList) {
    		if (status.name().equalsIgnoreCase(statusName)) {
    			return status;
    		}
    	}
    	return UNKNOW;
    }

}
