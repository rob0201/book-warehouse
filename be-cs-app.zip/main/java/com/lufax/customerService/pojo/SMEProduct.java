package com.lufax.customerService.pojo;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Version;

@Entity
@Table(name = "SME_PRODUCT")
@Inheritance(strategy = InheritanceType.JOINED)
@DiscriminatorColumn(name = "PRODUCT_CATEGORY")
public class SMEProduct {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_SME_PRODUCT")
    @SequenceGenerator(name = "SEQ_SME_PRODUCT", sequenceName = "SEQ_SME_PRODUCT", allocationSize = 1) 
    public long id;
    
    //    '产品名称'
    @Column(name = "NAME")
    private String name;

    //    '产品编号'
    @Column(name = "CODE")
    private String code;

    //    '预期收益率'
    @Column(name = "INTEREST_RATE")
    private BigDecimal interestRateYear;
    
    //    '目标募集额'
    @Column(name = "TARGET_FUNDS")
    private BigDecimal targetFunds;

    //    '实际募集额'
    @Column(name = "ACTUAL_FUNDS")
    private BigDecimal actualFunds;

    //    '当日单价'
    @Column(name = "UNIT_PRICE")
    private BigDecimal unitPrice;
    
    //    '最低投资份额'
    @Column(name = "MIN_INVEST_SHARES")
    private BigDecimal minInvestShares;
    
    //    '递增投资份额'
    @Column(name = "INCREASE_INVESTMENT_SHARES")
    private BigDecimal increaseInvestmnetShares;
    
    //    '产品类型'
    @Enumerated(EnumType.STRING)
    @Column(name = "PRODUCT_CATEGORY")
    private ProductCategory category;
    
    //    '状态'
    @Enumerated(EnumType.STRING)
    @Column(name = "STATUS")
    private FlowStatus flowStatus;

    //    '创建时间'
    @Column(name = "FCD")
    private Date fcd;

    //    '创建人'
    @Column(name = "FCU")
    private String fcu;

    //    '修改时间'
    @Column(name = "LCD")
    private Date lcd;

    //    '修改人'
    @Column(name = "LCU")
    private String lcu;
    
    @Version
    @Column(name = "VERSION")
    private Long version;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "CONTRACT_TEMPLATE_ID")
    private SMETemplate contractTemplate;
    
	public SMEProduct() {
		super();
	}


	public long getId() {
		return id;
	}


	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getCode() {
		return code;
	}


	public void setCode(String code) {
		this.code = code;
	}


	public BigDecimal getInterestRateYear() {
		return interestRateYear;
	}


	public void setInterestRateYear(BigDecimal interestRateYear) {
		this.interestRateYear = interestRateYear;
	}


	public BigDecimal getTargetFunds() {
		return targetFunds;
	}


	public void setTargetFunds(BigDecimal targetFunds) {
		this.targetFunds = targetFunds;
	}


	public BigDecimal getActualFunds() {
		return actualFunds;
	}


	public void setActualFunds(BigDecimal actualFunds) {
		this.actualFunds = actualFunds;
	}

	public BigDecimal getUnitPrice() {
		return unitPrice;
	}


	public void setUnitPrice(BigDecimal unitPrice) {
		this.unitPrice = unitPrice;
	}


	public BigDecimal getMinInvestShares() {
		return minInvestShares;
	}


	public void setMinInvestShares(BigDecimal minInvestShares) {
		this.minInvestShares = minInvestShares;
	}


	public BigDecimal getIncreaseInvestmnetShares() {
		return increaseInvestmnetShares;
	}


	public void setIncreaseInvestmnetShares(BigDecimal increaseInvestmnetShares) {
		this.increaseInvestmnetShares = increaseInvestmnetShares;
	}


	public ProductCategory getCategory() {
		return category;
	}


	public void setCategory(ProductCategory category) {
		this.category = category;
	}


	public FlowStatus getFlowStatus() {
		return flowStatus;
	}


	public void setFlowStatus(FlowStatus flowStatus) {
		this.flowStatus = flowStatus;
	}


	public Long getVersion() {
		return version;
	}

	public Date getFcd() {
		return fcd;
	}

	public void setFcd(Date fcd) {
		this.fcd = fcd;
	}


	public String getFcu() {
		return fcu;
	}


	public void setFcu(String fcu) {
		this.fcu = fcu;
	}


	public Date getLcd() {
		return lcd;
	}


	public void setLcd(Date lcd) {
		this.lcd = lcd;
	}


	public String getLcu() {
		return lcu;
	}


	public void setLcu(String lcu) {
		this.lcu = lcu;
	}


	public void setVersion(Long version) {
		this.version = version;
	}
	
	public SMETemplate getContractTemplate() {
		return contractTemplate;
	}


	public void setContractTemplate(SMETemplate contractTemplate) {
		this.contractTemplate = contractTemplate;
	}


	@Override
	public String toString() {
		return "SMEProduct [id=" + id + ", name=" + name + ", code=" + code + ", interestRateYear=" + interestRateYear + ", targetFunds=" + targetFunds + ", actualFunds=" + actualFunds + ", unitPrice=" + unitPrice + ", minInvestShares=" + minInvestShares + ", increaseInvestmnetShares=" + increaseInvestmnetShares + ", category=" + category + ", flowStatus=" + flowStatus + ", fcd=" + fcd + ", fcu=" + fcu + ", lcd=" + lcd + ", lcu=" + lcu + ", version=" + version + "]";
	}
}