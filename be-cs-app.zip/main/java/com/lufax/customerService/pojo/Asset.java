package com.lufax.customerService.pojo;

import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


@Entity
@Table(name = "SME_ASSET")
public class Asset {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_SME_ASSET")
    @SequenceGenerator(name = "SEQ_SME_ASSET", sequenceName = "SEQ_SME_ASSET", allocationSize = 1)
    private long id;
    @Column(name="DEPOSIT_WATER")
    private Long depositWater;
    @Column(name = "NAME")
    private String name;
    @Column(name = "CODE")
    private String code;
    @Column(name = "COLLECT_START_DATE")
    private Date collectStartDate;
    @Column(name = "COLLECT_END_DATE")
    private Date collectEndDate;
    @Column(name = "TARGET_FUNDS")
    private double targetFunds;
    @Column(name = "ACTUAL_FUNDS")
    private double actualFunds;
    @Column(name = "MIN_FUNDS")
    private double minFunds;
    @Column(name = "ADVANCED_ANNOUNCEMENT_TIME")
    private Date advancedAnnouncementTime;
    @Column(name = "COLLECT_WAY")
    private String collectWay;
    @Enumerated(EnumType.STRING)
    @Column(name = "STATUS")
    private AssetStatus status;
    @Column(name = "VERSION")
    private long version;
    @Column(name = "FCD")
    private Date fcd;
    @Column(name = "FCU")
    private String fcu;
    @Column(name = "LCD")
    private Date lcd;
    @Column(name = "LCU")
    private String lcu;
    //    '产品类型'
    @Enumerated(EnumType.STRING)
    @Column(name = "PRODUCT_TYPE")
    private SMEProductType smeProductType;
    
    @OneToMany(mappedBy = "asset", fetch = FetchType.LAZY)
    private List<AssetPool> assetPools;
    
    public Asset() {
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public Date getCollectStartDate() {
        return collectStartDate;
    }

    public void setCollectStartDate(Date collectStartDate) {
        this.collectStartDate = collectStartDate;
    }

    public Date getCollectEndDate() {
        return collectEndDate;
    }

    public void setCollectEndDate(Date collectEndDate) {
        this.collectEndDate = collectEndDate;
    }

    public double getTargetFunds() {
        return targetFunds;
    }

    public void setTargetFunds(double targetFunds) {
        this.targetFunds = targetFunds;
    }

    public double getActualFunds() {
        return actualFunds;
    }

    public void setActualFunds(double actualFunds) {
        this.actualFunds = actualFunds;
    }

    public double getMinFunds() {
        return minFunds;
    }

    public void setMinFunds(double minFunds) {
        this.minFunds = minFunds;
    }

    public Date getAdvancedAnnouncementTime() {
        return advancedAnnouncementTime;
    }

    public void setAdvancedAnnouncementTime(Date advancedAnnouncementTime) {
        this.advancedAnnouncementTime = advancedAnnouncementTime;
    }

    public CollectWay getCollectWay() {
        return CollectWay.getCollectWayByName(collectWay);
    }

    public void setCollectWay(CollectWay collectWay) {
        this.collectWay = (collectWay != null) ? collectWay.name() : null;
    }

    public AssetStatus getStatus() {
        return status;
    }

    public void setStatus(AssetStatus status) {
        this.status = status;
    }

    public long getVersion() {
        return version;
    }

    public void setVersion(long version) {
        this.version = version;
    }

    public Date getFcd() {
        return fcd;
    }

    public void setFcd(Date fcd) {
        this.fcd = fcd;
    }

    public String getFcu() {
        return fcu;
    }

    public void setFcu(String fcu) {
        this.fcu = fcu;
    }

    public Long getDepositWater() {
		return depositWater;
	}

	public void setDepositWater(Long depositWater) {
		this.depositWater = depositWater;
	}

	public void setCollectWay(String collectWay) {
		this.collectWay = collectWay;
	}

	public Date getLcd() {
        return lcd;
    }

    public void setLcd(Date lcd) {
        this.lcd = lcd;
    }

    public String getLcu() {
        return lcu;
    }

    public void setLcu(String lcu) {
        this.lcu = lcu;
    }
    
    public SMEProductType getSmeProductType() {
		return smeProductType;
	}

	public void setSmeProductType(SMEProductType smeProductType) {
		this.smeProductType = smeProductType;
	}
	
	public List<AssetPool> getAssetPools() {
		return assetPools;
	}

	public String toString() {
        return "Asset{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", code='" + code + '\'' +
                ", collectStartDate=" + collectStartDate +
                ", collectEndDate=" + collectEndDate +
                ", targetFunds=" + targetFunds +
                ", actualFunds=" + actualFunds +
                ", minFunds=" + minFunds +
                ", advancedAnnouncementTime=" + advancedAnnouncementTime +
                ", collectWay=" + collectWay +
                ", status=" + status +
                ", version=" + version +
                ", fcd=" + fcd +
                ", fcu='" + fcu + '\'' +
                ", lcd=" + lcd +
                ", lcu='" + lcu + '\'' +
//                ", assetPool=" + assetPool +
                '}';
    }

}
