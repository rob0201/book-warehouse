package com.lufax.customerService.pojo;

import java.util.Date;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.lufax.common.domain.account.Money;

@Entity
@Table(name = "SME_REPAY_APPLY")
public class RepayApply {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_SME_REPAY_APPLY")
    @SequenceGenerator(name = "SEQ_SME_REPAY_APPLY", sequenceName = "SEQ_SME_REPAY_APPLY", allocationSize = 1)
    private long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "REPAYMENT_PLAN_ID")
    private SMERepaymentPlans repaymentPlan;


    @Column(name = "REPAYMENT_ACCOUNT_ID ")
    private long repaymentAccountId;

    @Embedded
    @AttributeOverrides({@AttributeOverride(name = "amount", column = @Column(name = "PRINCIPAL"))})
    private Money principal;

    @Embedded
    @AttributeOverrides({@AttributeOverride(name = "amount", column = @Column(name = "INTEREST"))})
    private Money interest;
    
     @Column(name = "IS_ADVANCED_REPAY")
     private Boolean isAdvancedRepay;

    @Temporal(TemporalType.DATE)
    @Column(name = "REPAYMENT_DATE")
    private Date repaymentDate;

    @Embedded
    @AttributeOverrides({@AttributeOverride(name = "amount", column = @Column(name = "MANAGE_PENALTY"))})
    private Money managePenalty;

    @Embedded
    @AttributeOverrides({@AttributeOverride(name = "amount", column = @Column(name = "MANAGE_PENALTY_PUNISH_INTEREST"))})
    private Money managePenaltyPunishInterest;

    @Embedded
    @AttributeOverrides({@AttributeOverride(name = "amount", column = @Column(name = "ADVANCED_REPAY_PENALTY"))})
    private Money advancedRepayPenalty;

    @Embedded
    @AttributeOverrides({@AttributeOverride(name = "amount", column = @Column(name = "TRANSFER_FUND"))})
    private Money transferFund;

    @Enumerated(EnumType.STRING)
    @Column(name = "STATUS")
    private RepayAuditStatus status;

    @Temporal(TemporalType.DATE)
    @Column(name = "CREATED_AT")
    private Date createdAt;
    
    @Temporal(TemporalType.DATE)
    @Column(name = "UPDATED_AT")
    private Date updatedAt;
    
    @Column(name = "APPLYER_ID ")
    private Long applyerId;
    
    @Column(name = "APPROVER_ID")
    private Long approverId;

    @Column(name = "IS_ALL_REPAYED")
	private Boolean isAllRepayed;

    @Column(name = "REMARK")
    private String remark;//备注

    public RepayApply() {
    }

    public long getId() {
        return id;
    }

    private void setId(long id) {
        this.id = id;
    }


    public SMERepaymentPlans getRepaymentPlan() {
        return repaymentPlan;
    }

    public void setRepaymentPlanId(SMERepaymentPlans repaymentPlan) {
        this.repaymentPlan = repaymentPlan;

    }

    public long getRepaymentAccountId() {
        return repaymentAccountId;
    }

    public void setRepaymentAccountId(long repaymentAccountId) {
        this.repaymentAccountId = repaymentAccountId;
    }

    public Money getPrincipal() {
        return principal;
    }

    public void setPrincipal(Money principal) {
        this.principal = principal;
    }

    public Money getInterest() {
        return interest;
    }

    public void setInterest(Money interest) {
        this.interest = interest;
    }

    public Boolean getAdvancedRepay() {
        return isAdvancedRepay;
    }

    public void setAdvancedRepay(Boolean advancedRepay) {
        isAdvancedRepay = advancedRepay;
    }

    public Date getRepaymentDate() {
        return repaymentDate;
    }

    public void setRepaymentDate(Date repaymentDate) {
        this.repaymentDate = repaymentDate;
    }


    public Money getAdvancedRepayPenalty() {
        return advancedRepayPenalty;
    }

    public void setAdvancedRepayPenalty(Money advancedRepayPenalty) {
        this.advancedRepayPenalty = advancedRepayPenalty;
    }

    public Money getTransferFund() {
        return transferFund;
    }

    public void setTransferFund(Money transferFund) {
        this.transferFund = transferFund;
    }

    public RepayAuditStatus getStatus() {
        return status;
    }

    public void setStatus(RepayAuditStatus status) {
        this.status = status;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public Date getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Date updatedAt) {
        this.updatedAt = updatedAt;
    }

    public Long getApplyerId() {
        return applyerId;
    }

    public void setApplyerId(Long applyerId) {
        this.applyerId = applyerId;
    }

    public Long getApproverId() {
        return approverId;
    }

    public void setApproverId(Long approvedId) {
        this.approverId = approvedId;
    }

    public Boolean getAllRepayed() {
        return isAllRepayed;
    }

    public void setAllRepayed(Boolean allRepayed) {
        isAllRepayed = allRepayed;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public Money getManagePenalty() {
        return managePenalty;
    }

    public void setManagePenalty(Money managePenalty) {
        this.managePenalty = managePenalty;
    }

    public Money getManagePenaltyPunishInterest() {
        return managePenaltyPunishInterest;
    }

    public void setManagePenaltyPunishInterest(Money managePenaltyPunishInterest) {
        this.managePenaltyPunishInterest = managePenaltyPunishInterest;
    }

    @Override
	public String toString() {
		return "RepayApply [id=" + id + ", repaymentPlan=" + repaymentPlan + ", repaymentAccount=" + repaymentAccountId + ", principal=" + principal + ", interest=" + interest + ", isAdvancedRepay=" + isAdvancedRepay + ", repaymentDate=" + repaymentDate + ", managePenalty=" + ", advancedRepayPenalty=" + advancedRepayPenalty + ", transferFund=" + transferFund + ", status=" + status + ", createdAt=" + createdAt + ", updatedAt=" + updatedAt + ", applyerId=" + applyerId + ", approverId=" + approverId + "]";
	}
    
    
}
