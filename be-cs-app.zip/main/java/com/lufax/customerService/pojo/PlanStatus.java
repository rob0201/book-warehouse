package com.lufax.customerService.pojo;

import java.util.ArrayList;
import java.util.List;

public enum PlanStatus {
	UNPAID(Type.ONGOING, "未付", "9"), 
	PROCESSING(Type.ONGOING, "代扣中", "6"), 
	OVERDUE(Type.ONGOING, "逾期", "2"), 
	PAID(Type.SETTLED, "已付清", "1"), 
	PREPAID(Type.SETTLED, "提前还清", "4");

	private Type type;
	private String value;
	private String code;

	PlanStatus(Type type, String value, String code) {
		this.type = type;
		this.value = value;
		this.code = code;
	}

	public String getValue() {
		return value;
	}

	public String getCode() {
		return code;
	}

	public boolean isSettled() {
		return Type.SETTLED == type;
	}

	public boolean isOngoing() {
		return Type.ONGOING == type;
	}

	public static enum Type {
		ONGOING, SETTLED;

		public List<PlanStatus> getStatuses() {
			List<PlanStatus> result = new ArrayList<PlanStatus>();
			for (PlanStatus status : PlanStatus.values()) {
				if (this.equals(status.type)) {
					result.add(status);
				}
			}
			return result;
		}
	}
}
