package com.lufax.customerService.pojo;


import java.util.Date;
import java.util.List;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Version;

import com.lufax.common.domain.account.Money;

@Entity
@Table(name = "SME_COLLECTION_PLANS")
public class SMECollectionPlan {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_SME_COLLECTION_PLANS")
	@SequenceGenerator(name = "SEQ_SME_COLLECTION_PLANS", sequenceName = "SEQ_SME_COLLECTION_PLANS", allocationSize = 1)
	private long id;

	@Column(name = "PERIOD")
	private int planNumber;

	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "amount", column = @Column(name = "AMOUNT")) })
	private Money amount;

	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "amount", column = @Column(name = "PRINCIPAL")) })
	private Money principal;

	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "amount", column = @Column(name = "INTEREST")) })
	private Money interest;

	@Enumerated(EnumType.STRING)
	@Column(name = "STATUS")
	private CollectionPlanStatus status;

	@Version
	@Column(name = "VERSION")
	private long version;

	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "amount", column = @Column(name = "MANAGE_PENALTY")) })
	private Money managePenalty;// 管理违约金

	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "amount", column = @Column(name = "MANAGE_PENALTY_PUNISH_INTEREST")) })
	private Money managePenaltyPunishInterest;// 管理违约金罚息

	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "amount", column = @Column(name = "ADVANCED_REPAY_PENALTY")) })
	private Money advancedRepayPenalty;// 提前还款违约金

	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "amount", column = @Column(name = "TRANSFER_FUND")) })
	private Money transferFund;// 应付转让款

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "USER_PRODUCT_ACCOUNT_ID")
	private UserProductAccount userProductAccount;

	@Temporal(TemporalType.DATE)
	@Column(name = "CREATED_AT")
	private Date createdAt;

	@Temporal(TemporalType.DATE)
	@Column(name = "UPDATED_AT")
	private Date updatedAt;

	@Temporal(TemporalType.DATE)
	@Column(name = "LAST_COLLECT_DATE")
	private Date lastCollectDate;
	
	@Column(name = "REPAYMENT_PLAN_ID")
	private Long repaymentPlanId;
	
	@OneToMany(mappedBy = "collectionPlan")
	@OrderBy(" createdAt asc ")
	private List<SMECollectionRecord> collectionRecords;

	public SMECollectionPlan() {
	}

	public long getId() {
		return id;
	}

	private void setId(long id) {
		this.id = id;
	}

	public int getPlanNumber() {
		return planNumber;
	}

	public void setPlanNumber(int planNumber) {
		this.planNumber = planNumber;
	}

	public Money getAmount() {
		return amount;
	}

	public void setAmount(Money amount) {
		this.amount = amount;
	}

	public Money getPrincipal() {
		return principal;
	}

	public void setPrincipal(Money principal) {
		this.principal = principal;
	}

	public Money getInterest() {
		return interest;
	}

	public void setInterest(Money interest) {
		this.interest = interest;
	}

	public CollectionPlanStatus getStatus() {
		return status;
	}

	public void setStatus(CollectionPlanStatus status) {
		this.status = status;
	}

	public long getVersion() {
		return version;
	}

	public void setVersion(long version) {
		this.version = version;
	}

	public Money getManagePenalty() {
		return managePenalty;
	}

	public void setManagePenalty(Money managePenalty) {
		this.managePenalty = managePenalty;
	}

	public Money getManagePenaltyPunishInterest() {
		return managePenaltyPunishInterest;
	}

	public void setManagePenaltyPunishInterest(Money managePenaltyPunishInterest) {
		this.managePenaltyPunishInterest = managePenaltyPunishInterest;
	}

	public Money getAdvancedRepayPenalty() {
		return advancedRepayPenalty;
	}

	public void setAdvancedRepayPenalty(Money advancedRepayPenalty) {
		this.advancedRepayPenalty = advancedRepayPenalty;
	}

	public Money getTransferFund() {
		return transferFund;
	}

	public void setTransferFund(Money transferFund) {
		this.transferFund = transferFund;
	}

	public UserProductAccount getUserProductAccount() {
		return userProductAccount;
	}

	public void setUserProductAccount(UserProductAccount userProductAccount) {
		this.userProductAccount = userProductAccount;
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public Date getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	public Date getLastCollectDate() {
		return lastCollectDate;
	}

	public void setLastCollectDate(Date lastCollectDate) {
		this.lastCollectDate = lastCollectDate;
	}
	
	public Long getRepaymentPlanId() {
		return repaymentPlanId;
	}

	public void setRepaymentPlanId(Long repaymentPlanId) {
		this.repaymentPlanId = repaymentPlanId;
	}
	
	public List<SMECollectionRecord> getCollectionRecords() {
		return collectionRecords;
	}

	public String toString() {
		return "SMECollectionPlan [id=" + id + ", planNumber=" + planNumber + ", amount=" + amount + ", principal=" + principal + ", interest=" + interest + ", status=" + status + ", version=" + version + ", managePenalty=" + managePenalty + ", managePenaltyPunishInterest=" + managePenaltyPunishInterest + ", advancedRepayPenalty=" + advancedRepayPenalty + ", transferFund=" + transferFund + ", userProductAccount=" + userProductAccount + ", createdAt=" + createdAt + ", updatedAt=" + updatedAt + ", lastCollectDate=" + lastCollectDate + "]";
	}
	
	

}
