package com.lufax.customerService.pojo;

import java.util.Date;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Version;

import com.lufax.common.domain.account.Money;


@Entity
@Table(name = "SME_REPAYMENT_PLANS")
public class SMERepaymentPlans {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_SME_REPAYMENT_PLANS")
    @SequenceGenerator(name = "SEQ_SME_REPAYMENT_PLANS", sequenceName = "SEQ_SME_REPAYMENT_PLANS", allocationSize = 1)
    private long id;

    @Column(name = "PERIOD")
    private int planNumber;//期数

    @Embedded
    @AttributeOverrides({@AttributeOverride(name = "amount", column = @Column(name = "AMOUNT"))})
    private Money amount;//计划还款总额

    @Embedded
    @AttributeOverrides({@AttributeOverride(name = "amount", column = @Column(name = "PRINCIPAL"))})
    private Money principal;//计划还款本金

    @Embedded
    @AttributeOverrides({@AttributeOverride(name = "amount", column = @Column(name = "INTEREST"))})
    private Money interest;//计划还款利息

    @Enumerated(EnumType.STRING)
    @Column(name = "STATUS")
    private RepaymentPlanStatus status;//状态

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "PRODUCT_ID")
    private ExtProductSME extProductSME;

    @Version
    @Column(name = "VERSION")
    private long version;

    @Embedded
    @AttributeOverrides({@AttributeOverride(name = "amount", column = @Column(name = "ADVANCED_REPAY_PENALTY"))})
    private Money advancedRepayPenalty;//提前还款违约金
    
    @Embedded
    @AttributeOverrides({@AttributeOverride(name = "amount", column = @Column(name = "TRANSFER_FUND"))})
    private Money transferFund;//本期应付转让款
    
    @Temporal(TemporalType.DATE)
    @Column(name = "LAST_REPAY_DATE")
    private Date lastRepayDate;
    
    @Temporal(TemporalType.DATE)
    @Column(name = "CREATED_AT")
    private Date createdAt;
    
    @Temporal(TemporalType.DATE)
    @Column(name = "UPDATED_AT")
    private Date updatedAt;
    
    @Column(name = "OPERATER_ID")
    private Long operaterId;
    
    public SMERepaymentPlans() {}


	public long getId() {
		return id;
	}

	private void setId(long id) {

		this.id = id;
	}

	public int getPlanNumber() {
		return planNumber;
	}

	public void setPlanNumber(int planNumber) {
		this.planNumber = planNumber;

	}

	public Money getAmount() {
		return amount;
	}


	public void setAmount(Money amount) {
		this.amount = amount;
	}

	public Money getPrincipal() {
		return principal;
	}

	public void setPrincipal(Money principal) {
		this.principal = principal;
	}

	public Money getInterest() {
		return interest;
	}


	public void setInterest(Money interest) {
		this.interest = interest;
	}

	public RepaymentPlanStatus getStatus() {
		return status;
	}


	void setStatus(RepaymentPlanStatus status) {
		this.status = status;
	}


	public ExtProductSME getExtProductSME() {
		return extProductSME;
	}

	public void setExtProductSME(ExtProductSME extProductSME) {
		this.extProductSME = extProductSME;
	}

	public long getVersion() {
		return version;
	}

	public void setVersion(long version) {
		this.version = version;
	}


	public Money getAdvancedRepayPenalty() {
		return advancedRepayPenalty;
	}

	public void setAdvancedRepayPenalty(Money advancedRepayPenalty) {
		this.advancedRepayPenalty = advancedRepayPenalty;
	}


	public Money getTransferFund() {
		return transferFund;

	}

	public void setTransferFund(Money transferFund) {
		this.transferFund = transferFund;
	}

	public Date getLastRepayDate() {
		return lastRepayDate;
	}


	public void setLastRepayDate(Date lastRepayDate) {
		this.lastRepayDate = lastRepayDate;
	}

	public Date getCreatedAt() {
		return createdAt;

	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public Date getUpdatedAt() {
		return updatedAt;
	}


	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;

	}

	public Long getOperaterId() {
		return operaterId;
	}


	public void setOperaterId(Long operaterId) {
		this.operaterId = operaterId;
	}
    

}