package com.lufax.customerService.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "SME_TEMPLATE_PARAM")
public class SMETemplateParam {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_SME_TEMPLATE_PARAM")
    @SequenceGenerator(name = "SEQ_SME_TEMPLATE_PARAM", sequenceName = "SEQ_SME_TEMPLATE_PARAM", allocationSize = 1)
    private long id;
    
    @Column(name = "NAME")
    private String name;//模板参数名称
    
    @Column(name = "DESCRIPTION")
    private String description;//模板参数描述
    
    public SMETemplateParam(){}

	public long getId() {
		return id;
	}

	private void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
}
