package com.lufax.customerService.pojo;

public enum ReleaseVirtualAccountWay {
    AGENCY_DEBTOR_SPV_SME("AGENCY_DEBTOR_SPV_SME"),
    INVESTER_LEGALPERSON("INVESTER_LEGALPERSON"),
    UNKNOWN("unknown");

    private String value;

    private ReleaseVirtualAccountWay(String status) {
        this.value = status;
    }

    public String getValue() {
        return value;
    }
    public static ReleaseVirtualAccountWay getReleaseVirtualAccountWayByName(String name){
        ReleaseVirtualAccountWay[] releaseVirtualAccountWays=ReleaseVirtualAccountWay.values();
        for(ReleaseVirtualAccountWay releaseVirtualAccountWay:releaseVirtualAccountWays)
            if(releaseVirtualAccountWay.name().equalsIgnoreCase(name))
                return releaseVirtualAccountWay;
        return UNKNOWN;
    }
}
