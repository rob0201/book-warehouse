package com.lufax.customerService.pojo;

public enum InvestRequestStatus {
  /*待处理、已冻结、成功、失败*/
    WAIT_TO_PROCESS("待处理"),
    FROZEN("等待合同确认"),
    GATHERING("正在收款"),
    SUCCESS("成功"),
    FROZEN_TRANSFER_SUCCESS("冻结款转账成功"),
    FREEZE_FAILED("产品冻结失败"),
    FUNDS_FREEZE_FAILED("资金冻结失败"),
    FUNDS_FREEZE_SUCCESS("资金冻结成功"),
    FUNDS_UNFREEZE_FAILED("资金解冻失败"),
    FUNDS_UNFREEZE_SUCCESS("资金解冻成功"),
    FAILED("失败"),
    UNKONWN("unkonwn");
    private String value;

    private InvestRequestStatus(String status) {
        this.value = status;
    }

    public String getValue() {
        return value;
    }
    public static InvestRequestStatus getInvestRequestStatusByName(String status){
        InvestRequestStatus[] investRequestStatuses=InvestRequestStatus.values();
        for(InvestRequestStatus investRequestStatus:investRequestStatuses)
            if(investRequestStatus.name().equalsIgnoreCase(status))
                return investRequestStatus;
        return UNKONWN;
    }

}
