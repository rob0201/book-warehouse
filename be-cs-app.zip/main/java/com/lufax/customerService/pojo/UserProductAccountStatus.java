package com.lufax.customerService.pojo;

public enum UserProductAccountStatus {

    EFFECTIVE,INVALID;
}
