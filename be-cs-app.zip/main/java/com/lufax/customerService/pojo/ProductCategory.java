package com.lufax.customerService.pojo;

public enum ProductCategory {
	SME,P2P;
}
