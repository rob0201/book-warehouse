package com.lufax.customerService.pojo;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.lufax.common.domain.User;


@Entity
@Table(name = "SME_INVEST_REQUEST")
public class SMEInvestmentRequest {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_INVESTMENT_REQUEST")
    @SequenceGenerator(name = "SEQ_INVESTMENT_REQUEST", sequenceName = "SEQ_INVESTMENT_REQUEST", allocationSize = 1)
    private Long id;
    @Column(name = "PRODUCT_ID")
    private Long productId;
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "INVESTOR_ID", unique = true, nullable = false)
    private User investor;
    @Column(name = "PURCHASE_AMOUNT")
    private BigDecimal purchaseAmount;
    @Column(name = "PURCHASE_AT")
    private Date purchaseAt;
    //    @Enumerated(EnumType.STRING)
    @Column(name = "PURCHASE_STATUS")
    private String purchaseStatus;
    @Column(name = "PRODUCT_FREEZE_NO")
    private Long productFreezeNo;
    @Column(name = "FROZEN_CAPITAL_AMOUNT")
    private BigDecimal frozenCapitalAmount;
    @Column(name = "FROZEN_SERIAL_NO")
    private String frozenSerialNo;
    @Enumerated(EnumType.STRING)
    @Column(name = "FUNDS_FROZEN_STATUS")
    private InvestRequestStatus fundsFreezeStatus;
    @Column(name = "SHARES")
    private BigDecimal shares;
    @Column(name = "FCD")
    private Date FCD;
    @Column(name = "FCU")
    private String FCU;
    @Column(name = "LCD")
    private Date LCD;
    @Column(name = "LCU")
    private String LCU;

    public SMEInvestmentRequest() {
    }

    public SMEInvestmentRequest(BigDecimal purchaseAmount, Long productId, User investor) {
        this.purchaseAmount = purchaseAmount;
        this.productId = productId;
        this.investor = investor;
    }


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }


    public Long getProductId() {
        return productId;
    }

    public void setProductId(Long productId) {
        this.productId = productId;
    }

    public User getInvestor() {
        return investor;
    }

    public void setInvestor(User investor) {
        this.investor = investor;
    }

    public BigDecimal getPurchaseAmount() {
        return purchaseAmount;
    }

    public void setPurchaseAmount(BigDecimal purchaseAmount) {
        this.purchaseAmount = purchaseAmount;
    }


    public Long getProductFreezeNo() {
        return productFreezeNo;
    }

    public void setProductFreezeNo(Long productFreezeNo) {
        this.productFreezeNo = productFreezeNo;
    }

    public BigDecimal getFrozenCapitalAmount() {
        return frozenCapitalAmount;
    }

    public void setFrozenCapitalAmount(BigDecimal frozenCapitalAmount) {
        this.frozenCapitalAmount = frozenCapitalAmount;
    }

    public String getFrozenSerialNo() {
        return frozenSerialNo;
    }

    public void setFrozenSerialNo(String frozenSerialNo) {
        this.frozenSerialNo = frozenSerialNo;
    }

    public InvestRequestStatus getPurchaseStatus() {
        return InvestRequestStatus.getInvestRequestStatusByName(purchaseStatus);
    }

    public void setPurchaseStatus(InvestRequestStatus purchaseStatus) {
        this.purchaseStatus = (purchaseStatus != null) ? purchaseStatus.name() : null;
    }

    public InvestRequestStatus getFundsFreezeStatus() {
        return fundsFreezeStatus;
    }

    public void setFundsFreezeStatus(InvestRequestStatus fundsFreezeStatus) {
        this.fundsFreezeStatus = fundsFreezeStatus;
    }

    public BigDecimal getShares() {
        return shares;
    }

    public void setShares(BigDecimal shares) {
        this.shares = shares;
    }


    public String getFCU() {
        return FCU;
    }

    public void setFCU(String FCU) {
        this.FCU = FCU;
    }

    public Date getPurchaseAt() {
        return purchaseAt;
    }

    public void setPurchaseAt(Date purchaseAt) {
        this.purchaseAt = purchaseAt;
    }

    public Date getFCD() {
        return FCD;
    }

    public void setFCD(Date FCD) {
        this.FCD = FCD;
    }

    public Date getLCD() {
        return LCD;
    }

    public void setLCD(Date LCD) {
        this.LCD = LCD;
    }

    public String getLCU() {
        return LCU;
    }

    public void setLCU(String LCU) {
        this.LCU = LCU;
    }

    @Override
    public String toString() {
        return "InvestmentRequest{" +
                "id=" + id +
                ", productId=" + productId +
                ", investor=" + investor +
                ", purchaseAmount=" + purchaseAmount +
                ", purchaseAt=" + purchaseAt +
                ", purchaseStatus=" + purchaseStatus +
                ", productFreezeNo=" + productFreezeNo +
                ", frozenCapitalAmount=" + frozenCapitalAmount +
                ", frozenSerialNo='" + frozenSerialNo + '\'' +
                ", fundsFreezeStatus=" + fundsFreezeStatus +
                ", shares=" + shares +
                ", FCD=" + FCD +
                ", FCU='" + FCU + '\'' +
                ", LCD=" + LCD +
                ", LCU='" + LCU + '\'' +
                '}';
    }
}
