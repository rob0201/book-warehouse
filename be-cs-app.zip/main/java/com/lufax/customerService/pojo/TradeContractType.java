package com.lufax.customerService.pojo;


import java.util.Date;

import com.lufax.common.utils.DateUtils;

public enum TradeContractType {
	INVESTMENT("investment.vm"),
    UNKNOWN("unknown");

    private String template;

    TradeContractType(String template) {
        this.template = template;
    }

    public String getTemplate() {
        return template;
    }

    public static String codeOf(String code) {
        return String.format("10-0001-%s-%s", DateUtils.formatDateAsString(new Date()), code.substring(code.length() - 6));
    }

    public static String contractNameOf(String contractNo) {
        return String.format("SME%s%s", contractNo, ".pdf");
    }
    public static TradeContractType getTradeContractTypeByName(String name){
        TradeContractType[] tradeContractTypes=TradeContractType.values();
        for(TradeContractType tradeContractType:tradeContractTypes)
            if(tradeContractType.name().equalsIgnoreCase(name))
                return tradeContractType;
        return UNKNOWN;
    }

}
