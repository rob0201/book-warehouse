package com.lufax.customerService.pojo;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "SME_ENTERPRISE")
public class SmeEnterprise {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_SME_ENTERPRISE")
    @SequenceGenerator(name = "SEQ_SME_ENTERPRISE", sequenceName = "SEQ_SME_ENTERPRISE", allocationSize = 1)
    private long id;
    @Column(name = "NAME")
    private String name;

    @Column(name = "VIRTUAL_NUMBER")
    private Long virtualNumber;

    @Column(name = "ACTUAL_NUMBER")
    private Long actualNumber;

    @Column(name = "FCD")
    private Date fcd;

    @Column(name = "FCU")
    private String fcu;

    @Column(name = "LCD")
    private Date lcd;

    @Column(name = "LCU")
    private String lcu;

     @Column(name = "VERSION")
    private String version;


    public SmeEnterprise() {
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Long getVirtualNumber() {
        return virtualNumber;
    }

    public void setVirtualNumber(Long virtual_number) {
        this.virtualNumber = virtual_number;
    }

    public Long getActualNumber() {
        return actualNumber;
    }

    public void setActualNumber(Long actual_number) {
        this.actualNumber = actual_number;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public Date getFcd() {
        return fcd;
    }

    public void setFcd(Date fcd) {
        this.fcd = fcd;
    }

    public String getFcu() {
        return fcu;
    }

    public void setFcu(String fcu) {
        this.fcu = fcu;
    }

    public Date getLcd() {
        return lcd;
    }

    public void setLcd(Date lcd) {
        this.lcd = lcd;
    }

    public String getLcu() {
        return lcu;
    }

    public void setLcu(String lcu) {
        this.lcu = lcu;
    }

    @Override
    public String toString() {
        return "SmeEnterprise{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", virtualNumber=" + virtualNumber +
                ", actualNumber=" + actualNumber +
                ", fcd=" + fcd +
                ", fcu='" + fcu + '\'' +
                ", lcd=" + lcd +
                ", lcu='" + lcu + '\'' +
                ", version='" + version + '\'' +
                '}';
    }
}
