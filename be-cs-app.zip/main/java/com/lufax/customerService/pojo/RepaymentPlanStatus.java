package com.lufax.customerService.pojo;

import java.util.ArrayList;
import java.util.List;

public enum RepaymentPlanStatus {
	UNPAID(Type.ONGOING, "未还"), 
	PART_PAID(Type.ONGOING, "部分还款"), 
	PAID(Type.SETTLED, "已还");

	Type type;
	private String value;

	RepaymentPlanStatus(Type type, String value) {
		this.type = type;
		this.value = value;
	}

	public String getValue() {
		return value;
	}

	public boolean isSettled() {
		return Type.SETTLED == type;
	}

	public boolean isOngoing() {
		return Type.ONGOING == type;
	}
	
	public static String convertValueToName(String value){
		for (RepaymentPlanStatus status : RepaymentPlanStatus.values()) {
			if (status.getValue().equals(value)) {
				return status.name();
			}
		}
		return null;
	}

	public static enum Type {
		ONGOING, SETTLED;

		public List<RepaymentPlanStatus> getStatuses() {
			List<RepaymentPlanStatus> result = new ArrayList<RepaymentPlanStatus>();
			for (RepaymentPlanStatus status : RepaymentPlanStatus.values()) {
				if (this.equals(status.type)) {
					result.add(status);
				}
			}
			return result;
		}
	}
}
