package com.lufax.customerService.pojo;

import java.util.Date;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.lufax.common.domain.account.Money;

@Entity
@Table(name = "SME_REPAYMENT_RECORD")
public class SMERepaymentRecord {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_SME_REPAYMENT_RECORD")
	@SequenceGenerator(name = "SEQ_SME_REPAYMENT_RECORD", sequenceName = "SEQ_SME_REPAYMENT_RECORD", allocationSize = 1)
	private long id;

	@Column(name = "RECORD_NUMBER")
	private int recordNumber;

	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "amount", column = @Column(name = "AMOUNT")) })
	private Money amount;

	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "amount", column = @Column(name = "PRINCIPAL")) })
	private Money principal;

	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "amount", column = @Column(name = "INTEREST")) })
	private Money interest;

	@Temporal(TemporalType.DATE)
	@Column(name = "CREATED_AT")
	private Date createdAt;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "REPAYMENT_PLAN_ID")
	private SMERepaymentPlans plan;

	@Enumerated(EnumType.STRING)
	@Column(name = "STATUS")
	private RecordStatus status;

	@Temporal(TemporalType.DATE)
	@Column(name = "UPDATED_AT")
	private Date updatedAt;

	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "amount", column = @Column(name = "MANAGE_PENALTY")) })
	private Money managePenalty;// 管理违约金

	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "amount", column = @Column(name = "MANAGE_PENALTY_PUNISH_INTEREST")) })
	private Money managePenaltyPunishInterest;// 管理违约金罚息

	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "amount", column = @Column(name = "ADVANCED_REPAY_PENALTY")) })
	private Money advancedRepayPenalty;// 提前还款违约金

	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "amount", column = @Column(name = "TRANSFER_FUND")) })
	private Money transferFund;// 应收转让款

	@Column(name = "REPAYMENT_ACCOUNT_ID")
	private long repaymentAccountId;

	@Temporal(TemporalType.DATE)
	@Column(name = "REPAYMENT_DATE")
	private Date repaymentDate;

	@Column(name = "IS_ADVANCED_REPAY")
	private Boolean isAdvancedRepay;

	public SMERepaymentRecord() {
	}

	public long getId() {
		return id;
	}

	private void setId(long id) {
		this.id = id;
	}

	public int getRecordNumber() {
		return recordNumber;
	}

	public void setRecordNumber(int recordNumber) {
		this.recordNumber = recordNumber;
	}

	public Money getAmount() {
		return amount;
	}

	public void setAmount(Money amount) {
		this.amount = amount;
	}

	public Money getPrincipal() {
		return principal;
	}

	public void setPrincipal(Money principal) {
		this.principal = principal;
	}

	public Money getInterest() {
		return interest;
	}

	public void setInterest(Money interest) {
		this.interest = interest;
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public SMERepaymentPlans getPlan() {
		return plan;
	}

	public void setPlan(SMERepaymentPlans plan) {
		this.plan = plan;
	}

	public RecordStatus getStatus() {
		return status;
	}

	public void setStatus(RecordStatus status) {
		this.status = status;
	}

	public Date getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	public Money getAdvancedRepayPenalty() {
		return advancedRepayPenalty;
	}

	public void setAdvancedRepayPenalty(Money advancedRepayPenalty) {
		this.advancedRepayPenalty = advancedRepayPenalty;
	}

	public Money getTransferFund() {
		return transferFund;
	}

	public void setTransferFund(Money transferFund) {
		this.transferFund = transferFund;
	}

	public long getRepaymentAccountId() {
		return repaymentAccountId;
	}

	public void setRepaymentAccountId(long repaymentAccountId) {
		this.repaymentAccountId = repaymentAccountId;
	}

	public Date getRepaymentDate() {
		return repaymentDate;
	}

	public void setRepaymentDate(Date repaymentDate) {
		this.repaymentDate = repaymentDate;
	}

	public Boolean getIsAdvancedRepay() {
		return isAdvancedRepay;
	}

	public void setIsAdvancedRepay(Boolean isAdvancedRepay) {
		this.isAdvancedRepay = isAdvancedRepay;
	}

	public Money getManagePenalty() {
		return managePenalty;
	}

	public void setManagePenalty(Money managePenalty) {
		this.managePenalty = managePenalty;
	}

	public Money getManagePenaltyPunishInterest() {
		return managePenaltyPunishInterest;
	}

	public void setManagePenaltyPunishInterest(Money managePenaltyPunishInterest) {
		this.managePenaltyPunishInterest = managePenaltyPunishInterest;
	}
	
	

}
