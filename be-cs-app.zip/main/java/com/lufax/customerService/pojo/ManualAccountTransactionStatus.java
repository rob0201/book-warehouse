package com.lufax.customerService.pojo;

public enum ManualAccountTransactionStatus {

	WAIT_APPROVE("待审核"), PROCESSING("处理中"), SUCCESS("成功"), FAIL("失败");

	private String value;

	ManualAccountTransactionStatus(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}

	public static ManualAccountTransactionStatus convert(String value) {
		ManualAccountTransactionStatus[] statuses = ManualAccountTransactionStatus.values();
		for (ManualAccountTransactionStatus status : statuses) {
			if (status.name().equalsIgnoreCase(value)) {
				return status;
			}
		}
		return null;
	}

}
