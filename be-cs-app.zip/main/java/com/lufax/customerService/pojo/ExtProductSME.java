package com.lufax.customerService.pojo;


import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.ColumnResult;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.EntityResult;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.FieldResult;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.Table;

import com.lufax.common.domain.User;

@SqlResultSetMapping(
name="ExtProductSMEResults",
entities={@EntityResult(entityClass=ExtProductSME.class),
		  @EntityResult(entityClass=SMEProduct.class,
		  fields=@FieldResult(name="id",column="PRODUCT_ID"))
		  },
columns={@ColumnResult(name="planNumbers")}
)

@Entity
@DiscriminatorValue(value = "SME")
@Table(name = "EXT_PRODUCT_SME")
public class ExtProductSME extends SMEProduct{
//    @Id
//    private long id;
//	
	 //    '协议编号'
    @Column(name = "AGGREMENT_CODE")
    private String aggrementCode;
    
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ASSET_POOL_ID")
    private AssetPool assetPool;

    @Column(name="DISCOUNT_RATE")
    private BigDecimal discountRate;
    //    '募集成功最低额'
    @Column(name = "MIN_FUNDS")
    private BigDecimal minFunds;
    
    //    '产品说明书'
    @Column(name = "ILLUSTRATION")
    private String illustration;
    
    //    '产品发行成功公告'
    @Column(name = "SUCCESS_NOTICE")
    private String successNotice;
    
    //    '产品发行失败公告'
    @Column(name = "FAIL_NOTICE")
    private String failNotice;
    
    //    '募集开始时间'
    @Column(name = "COLLECT_START_DATE")
    private Date collectStartDate;
    
    //    '募集结束时间'
    @Column(name = "COLLECT_END_DATE")
    private Date collectEndDate;
    
    //    '序列号'
    @Column(name = "SERIALIZE_NUMBER")
    private int serializeNumber;
    
    //    '显示进度条'
    @Column(name = "PROCESS")
    private BigDecimal process;
    
    //    '可投资份额'
    @Column(name = "CAN_INVEST_AMOUNT")
    private BigDecimal canInvestAmount;
    
    //    '锁定的份额'
    @Column(name = "FREEZE_AMOUNT")
    private BigDecimal freezeAmount;
    
    @Column(name = "IS_WITHDRAW")
    private Boolean isWithdraw;// 是否已放款
    
	@Column(name = "INTEREST_START_DATE")
	private Date interestStartDate; // 起息日;
	
	@Column(name = "DEAD_LINE")
	private Date deadLine; // 到期日;
	
	@Column(name = "ACCOUNTS_RECEIVE_DATE")
	private Date accountsReceiveDate; // 兑现日;
	
	@Column(name = "REPAYMENT_WAY")
	private String repaymentWay; // 还款计划方式;
	
	@Column(name = "PROPORTION_EARLY_REPAY")
	private BigDecimal proportionEarlyRepay; // 提前还款违约金比例;
	
	@Column(name = "LATE_FLOATING_RATIO")
	private BigDecimal lateFloatingRatio; // 逾期罚息上浮比例;
	
	@Column(name = "ISSUER_FEE_RATE")
	private BigDecimal issuerFeeRate; // 融资方交易管理费率;
	
	@Column(name = "ISSUER_FEE_REPAYMENT_WAY")
	private String issuerFeeRepaymentWay; // 融资方交易管理费收取方式;
	
	@Column(name = "INVESTOR_FEE_RATE")
	private BigDecimal investorFeeRate; // 投资人交易管理费;
	
	@Column(name = "INVESTOR_FEE_REPAYMENT_WAY")
	private String investorFeeRepaymentWay; // 投资人交易管理费收取方式;
	
	@Column(name = "DESCRIPTION")
	private String description; // 产品比较描述;
	
    //    '最高投资额'
    @Column(name = "MAX_INVEST_AMOUNT")
    private BigDecimal maxInvestAmount;
    
	@Column(name = "PAY_WAY")
	private String payWay; // 支付渠道;
    
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "DEBTOR_ID")
	private SmeEnterprise debtor;// 融资企业
    
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "AGENCY_ID")
	private SmeEnterprise agency;// 中介商
    
	@Column(name = "AGENCY_FEE_RATE")
	private BigDecimal agencyFeeRate;// 中介商交易管理费率;
	
	@Column(name = "AGENCY_FEE_REPAYMENT_WAY")
	private String agencyFeeRepaymentWay;// 中介中间商管理费率收取模式交易管理费率;
    
	@Column(name = "LOAN_MANAGER_FEE_RATE")
	private BigDecimal loanManagerFeeRate;// 贷后管理商交易管理费率
	
	@Column(name = "LOAN_MANAGER_FEE_REPAYMENT_WAY")
	private String loanManagerFeeRepaymentWay;// 贷后管理商管理费率收取模式
	
	@Enumerated(EnumType.STRING)
	@Column(name = "RELEASE_VIRTUAL_ACCOUNT_WAY")
	private ReleaseVirtualAccountWay releaseVirtualAccountWay;// 放款方式
	
	@Column(name = "REPAYMENT_DATE")
	private Long repaymentDate;// 还款日
	
	@Column(name = "REPAYMENT_FROM")
	private String repaymentFrom;// 还款来源
	
	@Column(name = "REPAYMENT_FROM_START_DATE")
	private Date repaymentFromStartDate;// 还款来源启动日
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "LOAN_MANAGER_ID")
	private SmeEnterprise loanManager;// 贷后管理商
	
	 //    '预期总收益'
    @Column(name = "TOTAL_INCOME")
    private BigDecimal totalIncome;
    
    @Enumerated(EnumType.STRING)
	@Column(name = "PRODUCT_TYPE")
	private SMEProductType productType;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name="LEGAL_PERSON_ID")
    private User legalPerson;
    
    @Column(name = "LOAN_PERIOD")
	private String loanPeriod;// 期限
	
	public ExtProductSME() {
		super();
	}
	
    public  BigDecimal getDiscountRate() {
		return discountRate;
	}
    
	public  void setDiscountRate(BigDecimal discountRate) {
		this.discountRate = discountRate;
	}
	
	public BigDecimal getMinFunds() {
        return minFunds;
    }

	public void setMinFunds(BigDecimal minFunds) {
        this.minFunds = minFunds;
    }

    public String getIllustration() {
        return illustration;
    }

    public void setIllustration(String illustration) {
        this.illustration = illustration;
    }

    public String getSuccessNotice() {
        return successNotice;
    }

    public void setSuccessNotice(String successNotice) {
        this.successNotice = successNotice;
    }

    public String getFailNotice() {
        return failNotice;
    }

    public void setFailNotice(String failNotice) {
        this.failNotice = failNotice;
    }

    public Date getCollectStartDate() {
        return collectStartDate;
    }

    public void setCollectStartDate(Date collectStartDate) {
        this.collectStartDate = collectStartDate;
    }

    public Date getCollectEndDate() {
        return collectEndDate;
    }

    public void setCollectEndDate(Date collectEndDate) {
        this.collectEndDate = collectEndDate;
    }

    public int getSerializeNumber() {
        return serializeNumber;
    }

    public void setSerializeNumber(int serializeNumber) {
        this.serializeNumber = serializeNumber;
    }

    public BigDecimal getProcess() {
        return process;
    }

    public void setProcess(BigDecimal process) {
        this.process = process;
    }

    public BigDecimal getCanInvestAmount() {
        return canInvestAmount;
    }

    public void setCanInvestAmount(BigDecimal canInvestAmount) {
        this.canInvestAmount = canInvestAmount;
    }

    public BigDecimal getFreezeAmount() {
        return freezeAmount;
    }

    public void setFreezeAmount(BigDecimal freezeAmount) {
        this.freezeAmount = freezeAmount;
    }

    public AssetPool getAssetPool() {
        return assetPool;
    }

    public void setAssetPool(AssetPool assetPool) {
        this.assetPool = assetPool;
    }

	public BigDecimal getMaxInvestAmount() {
		return maxInvestAmount;
	}

	public void setMaxInvestAmount(BigDecimal maxInvestAmount) {
		this.maxInvestAmount = maxInvestAmount;
	}

	public Boolean getIsWithdraw() {
		return isWithdraw;
	}

	public void setIsWithdraw(Boolean isWithdraw) {
		this.isWithdraw = isWithdraw;
	}

	public Date getInterestStartDate() {
		return interestStartDate;
	}

	public void setInterestStartDate(Date interestStartDate) {
		this.interestStartDate = interestStartDate;
	}

	public Date getDeadLine() {
		return deadLine;
	}

	public void setDeadLine(Date deadLine) {
		this.deadLine = deadLine;
	}

	public Date getAccountsReceiveDate() {
		return accountsReceiveDate;
	}

	public void setAccountsReceiveDate(Date accountsReceiveDate) {
		this.accountsReceiveDate = accountsReceiveDate;
	}

	public String getRepaymentWay() {
		return repaymentWay;
	}

	public void setRepaymentWay(String repaymentWay) {
		this.repaymentWay = repaymentWay;
	}

	public BigDecimal getProportionEarlyRepay() {
		return proportionEarlyRepay;
	}

	public void setProportionEarlyRepay(BigDecimal proportionEarlyRepay) {
		this.proportionEarlyRepay = proportionEarlyRepay;
	}

	public BigDecimal getLateFloatingRatio() {
		return lateFloatingRatio;
	}

	public void setLateFloatingRatio(BigDecimal lateFloatingRatio) {
		this.lateFloatingRatio = lateFloatingRatio;
	}

	public BigDecimal getIssuerFeeRate() {
		return issuerFeeRate;
	}

	public void setIssuerFeeRate(BigDecimal issuerFeeRate) {
		this.issuerFeeRate = issuerFeeRate;
	}

	public String getIssuerFeeRepaymentWay() {
		return issuerFeeRepaymentWay;
	}

	public void setIssuerFeeRepaymentWay(String issuerFeeRepaymentWay) {
		this.issuerFeeRepaymentWay = issuerFeeRepaymentWay;
	}

	public BigDecimal getInvestorFeeRate() {
		return investorFeeRate;
	}

	public void setInvestorFeeRate(BigDecimal investorFeeRate) {
		this.investorFeeRate = investorFeeRate;
	}

	public String getInvestorFeeRepaymentWay() {
		return investorFeeRepaymentWay;
	}

	public void setInvestorFeeRepaymentWay(String investorFeeRepaymentWay) {
		this.investorFeeRepaymentWay = investorFeeRepaymentWay;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getPayWay() {
		return payWay;
	}

	public void setPayWay(String payWay) {
		this.payWay = payWay;
	}

	public SmeEnterprise getDebtor() {
		return debtor;
	}

	public void setDebtor(SmeEnterprise debtor) {
		this.debtor = debtor;
	}

	public SmeEnterprise getAgency() {
		return agency;
	}

	public void setAgency(SmeEnterprise agency) {
		this.agency = agency;
	}

	public BigDecimal getAgencyFeeRate() {
		return agencyFeeRate;
	}

	public void setAgencyFeeRate(BigDecimal agencyFeeRate) {
		this.agencyFeeRate = agencyFeeRate;
	}

	public String getAgencyFeeRepaymentWay() {
		return agencyFeeRepaymentWay;
	}

	public void setAgencyFeeRepaymentWay(String agencyFeeRepaymentWay) {
		this.agencyFeeRepaymentWay = agencyFeeRepaymentWay;
	}

	public SmeEnterprise getLoanManager() {
		return loanManager;
	}

	public void setLoanManager(SmeEnterprise loanManager) {
		this.loanManager = loanManager;
	}

	public BigDecimal getLoanManagerFeeRate() {
		return loanManagerFeeRate;
	}

	public void setLoanManagerFeeRate(BigDecimal loanManagerFeeRate) {
		this.loanManagerFeeRate = loanManagerFeeRate;
	}

	public String getLoanManagerFeeRepaymentWay() {
		return loanManagerFeeRepaymentWay;
	}

	public void setLoanManagerFeeRepaymentWay(String loanManagerFeeRepaymentWay) {
		this.loanManagerFeeRepaymentWay = loanManagerFeeRepaymentWay;
	}

	public ReleaseVirtualAccountWay getReleaseVirtualAccountWay() {
		return releaseVirtualAccountWay;
	}

	public void setReleaseVirtualAccountWay(
			ReleaseVirtualAccountWay releaseVirtualAccountWay) {
		this.releaseVirtualAccountWay = releaseVirtualAccountWay;
	}

	public Long getRepaymentDate() {
		return repaymentDate;
	}

	public void setRepaymentDate(Long repaymentDate) {
		this.repaymentDate = repaymentDate;
	}

	public String getRepaymentFrom() {
		return repaymentFrom;
	}

	public void setRepaymentFrom(String repaymentFrom) {
		this.repaymentFrom = repaymentFrom;
	}

	public Date getRepaymentFromStartDate() {
		return repaymentFromStartDate;
	}

	public void setRepaymentFromStartDate(Date repaymentFromStartDate) {
		this.repaymentFromStartDate = repaymentFromStartDate;
	}

	public BigDecimal getTotalIncome() {
		return totalIncome;
	}

	public void setTotalIncome(BigDecimal totalIncome) {
		this.totalIncome = totalIncome;
	}

	public String getAggrementCode() {
		return aggrementCode;
	}

	public void setAggrementCode(String aggrementCode) {
		this.aggrementCode = aggrementCode;
	}

	public SMEProductType getProductType() {
		return productType;
	}

	public void setProductType(SMEProductType productType) {
		this.productType = productType;
	}

	public User getLegalPerson() {
		return legalPerson;
	}

	public void setLegalPerson(User legalPerson) {
		this.legalPerson = legalPerson;
	}

	public String getLoanPeriod() {
		return loanPeriod;
	}

	public void setLoanPeriod(String loanPeriod) {
		this.loanPeriod = loanPeriod;
	}
	
	
//	@Override
//	public String toString() {
//		return "ExtProductSME";
//	}
}