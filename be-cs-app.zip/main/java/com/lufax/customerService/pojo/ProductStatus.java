package com.lufax.customerService.pojo;

public enum ProductStatus {
    WAIT_AUDIT("等待审核"),
    BEFORE_NOTICE("预告前"),
    DURING_NOTICE("预告中"),
    DURING_COLLECTION("募集中"),
    WAIT_CONTRACT_CONFIRM("等待合同确认"),
    COLLECT_SUCCESS("募集成功"),
    COLLECT_FAIL("募集失败"),
    UNKNOWN("unknown");

    private String value;

    private ProductStatus(String status) {
        this.value = status;
    }

    public String getValue() {
        return value;
    }
    public  static ProductStatus getProductStatusByName(String status){
        ProductStatus[] productStatuses=ProductStatus.values();
        for(ProductStatus productStatus:productStatuses)
            if(productStatus.name().equalsIgnoreCase(status))
                return productStatus;
        return UNKNOWN;
    }
}
