package com.lufax.customerService.pojo;

import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "SME_TEMPLATE")
public class SMETemplate {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_SME_TEMPLATE")
	@SequenceGenerator(name = "SEQ_SME_TEMPLATE", sequenceName = "SEQ_SME_TEMPLATE", allocationSize = 1)
	private long id;

	@Column(name = "NAME")
	private String name;// 模板名称
	
	@Column(name = "DISPLAYNAME")
	private String displayName;// 模板显示名称

	@Enumerated(EnumType.STRING)
	@Column(name = "TYPE")
	private SMETemplateType type;// 模板类型

	@Column(name = "INFO")
	private String info;// 模板信息

	@Column(name = "FILE_NAME")
	private String fileName;// 模板文件名

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "STAMP_ID")
	private SMEStamp stamp;// 印章

	@Temporal(TemporalType.DATE)
	@Column(name = "CREATE_AT")
	private Date createAt;// 创建时间

	@Column(name = "CREATOR")
	private long creatorId;// 创建人

	@ManyToMany(fetch = FetchType.LAZY)
	@JoinTable(name = "SME_TEMPLATE_TEMPLATE_PARAM", joinColumns = @JoinColumn(name = "TEMPLATE_ID"), inverseJoinColumns = @JoinColumn(name = "TEMPLATE_PARAM_ID"))
	private List<SMETemplateParam> templateParams;

	public SMETemplate() {
	}

	public long getId() {
		return id;
	}

	private void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	public SMETemplateType getType() {
		return type;
	}

	public void setType(SMETemplateType type) {
		this.type = type;
	}

	public String getInfo() {
		return info;
	}

	public void setInfo(String info) {
		this.info = info;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public SMEStamp getStamp() {
		return stamp;
	}

	public void setStamp(SMEStamp stamp) {
		this.stamp = stamp;
	}

	public Date getCreateAt() {
		return createAt;
	}

	public void setCreateAt(Date createAt) {
		this.createAt = createAt;
	}

	public long getCreatorId() {
		return creatorId;
	}

	public void setCreatorId(long creatorId) {
		this.creatorId = creatorId;
	}

	public List<SMETemplateParam> getTemplateParams() {
		return templateParams;
	}
}