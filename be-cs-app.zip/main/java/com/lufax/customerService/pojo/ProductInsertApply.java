package com.lufax.customerService.pojo;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.lufax.common.domain.User;

@Entity
@Table(name = "PRODUCT_INSERT_APPLY")
public class ProductInsertApply {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_PRODUCT_INSERT_APPLY")
	@SequenceGenerator(name = "SEQ_PRODUCT_INSERT_APPLY", sequenceName = "SEQ_PRODUCT_INSERT_APPLY", allocationSize = 1)
	private long id;
	
      //  '产品名称'
    @Column(name = "NAME")
    private String name;

    //    '产品编号'
    @Column(name = "CODE")
    private String code;
    
    @Enumerated(EnumType.STRING)
   	@Column(name = "PRODUCT_TYPE")
   	private SMEProductType productType;
    
   //  '状态'
    @Enumerated(EnumType.STRING)
    @Column(name = "STATUS")
    private FlowStatus flowStatus;
	
    //借款人
	 @ManyToOne(fetch = FetchType.LAZY)
	 @JoinColumn(name="LEGAL_PERSON_ID")
	 private User legalPerson;
	
    @Column(name = "TARGET_FUNDS")
    private BigDecimal targetFunds;//    '目标募集额'
    
    @Column(name = "LOAN_PERIOD")
   	private String loanPeriod;  // 期限
    
	@Column(name = "DEAD_LINE")
	private Date deadLine; // 到期日;
	
	 //    '预期收益率'
    @Column(name = "INTEREST_RATE")
    private BigDecimal interestRateYear;
    
    @Enumerated(EnumType.STRING)
    @Column(name = "REPAYMENT_WAY")
	private RepaymentWay repaymentWay; // 还款计划方式;
    
    
    //    '上架时间'
    @Column(name = "COLLECT_START_DATE")
    private Date collectStartDate;
    
    //    '下架时间'
    @Column(name = "COLLECT_END_DATE")
    private Date collectEndDate;
    
    @Enumerated(EnumType.STRING)
	@Column(name = "RELEASE_VIRTUAL_ACCOUNT_WAY")
	private ReleaseVirtualAccountWay releaseVirtualAccountWay;// 放款方式
    
    //    '创建时间'
    @Column(name = "CREATE_AT")
    private Date createAt;

    //    '创建人'
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name="APPLYER")
    private User applyer;

    //    '修改时间'
    @Column(name = "UPDATE_AT")
    private Date updateAt;

    //    '修改人'
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name="APPROVER")
    private User approver;
    
    // Cango modify : add the 金盈通  20120919
    @Column(name = "UNIT_PRICE")
    private BigDecimal unitPrice; //'募集单价
    
    @Column(name = "MIN_INVEST_SHARES")
    private BigDecimal minInvestShares; //'最低投资份额
    
    @Column(name = "INCREASE_INVESTMENT_SHARES")
    private BigDecimal increaseInvestmentShares; //'递增投资份额
    
    @Column(name = "CONTRACT_TEMPLATE_ID")
    private String contractTemplateId; //'合同模板ID
    
    @Column(name = "ASSET_POOL_ID")
    private Long assetPoolId; //二级资产池ID

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ASSET_POOL_ID",insertable= false,updatable = false)
    private AssetPool assetPool;
    
    @Column(name = "MIN_FUNDS")
    private BigDecimal minFunds; //募集成功最低额
    
    @Column(name = "ILLUSTRATION")
    private String illustration ; //产品说明书
    
    @Column(name = "SUCCESS_NOTICE")
    private String successNotice ; //产品发行成功公告
    
    @Column(name = "FAIL_NOTICE")
    private String failNotice ; //产品发行失败公告
    
    @Column(name = "SERIALIZE_NUMBER")
    private String serializeNumber ; //序列号
    
    @Column(name = "PROCESS ")
    private BigDecimal process ; //显示进度条
    
    @Column(name = "INTEREST_START_DATE ")
    private Date interestStartDate ; //起息日
    
    @Column(name = "ACCOUNTS_RECEIVE_DATE ")
    private Date accountsReceiveDate ; //兑现日
    
    @Column(name = "PROPORTION_EARLY_REPAY ")
    private BigDecimal proportionEarlyRepay ; //提前还款违约金比例
    
    @Column(name = "LATE_FLOATING_RATIO ")
    private BigDecimal lateFloatingRatio ; //逾期罚息上浮比例
    
    @Column(name = "ISSUER_FEE_RATE ")
    private BigDecimal issuerFeeRate ; //融资方交易管理费率
    
    @Column(name = "ISSUER_FEE_REPAYMENT_WAY ")
    private String issuerFeeRepaymentWay ; //融资方交易管理费收取方式
    
    @Column(name = "INVESTOR_FEE_RATE ")
    private BigDecimal investorFeeRate ; //投资人交易管理费
    
    @Column(name = "INVESTOR_FEE_REPAYMENT_WAY ")
    private String investorFeeRepaymentWay ; //投资人交易管理费收取方式
    
    @Column(name = "DESCRIPTION  ")
    private String description ; //产品比较描述
    
    @Column(name = "MAX_INVEST_AMOUNT ")
    private BigDecimal maxInvestAmount ; //最高投资额
    
    @Column(name = "PAY_WAY ")
    private String payWay ; //支付渠道
    
    @Column(name = "DEBTOR_ID")
    private String debtorId ; //核心企业（融资方）

    @ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "DEBTOR_ID",insertable= false,updatable = false)
    private SmeEnterprise debtor ; //中介商

    public SmeEnterprise getDebtor() {
        return debtor;
    }

    @Column(name = "AGENCY_ID ")
    private String agencyId ; //中介商

    @ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "AGENCY_ID",insertable= false,updatable = false)
    private SmeEnterprise agency ; //中介商

    public SmeEnterprise getAgency() {
        return agency;
    }

    @Column(name = "AGENCY_FEE_RATE ")
    private BigDecimal agencyFeeRate ; //中介商交易管理费率
    
    @Column(name = "AGENCY_FEE_REPAYMENT_WAY ")
    private String agencyFeeRepaymentWay ; //中间商管理费率收取模式
    
    @Column(name = "LOAN_MANAGER_FEE_RATE ")
    private BigDecimal loanManagerFeeRate ; //贷后管理商交易管理费率
    
    @Column(name = "LOAN_MANAGER_FEE_REPAYMENT_WAY ")
    private String loanManagerFeeRepaymentWay ; //贷后管理商管理费率收取模式
    
    @Column(name = "REPAYMENT_FROM ")
    private String repaymentFrom ; //还款来源
    
    @Column(name = "REPAYMENT_FROM_START_DATE ")
    private Date repaymentFromStartDate ; //还款来源启动日
    
    @Column(name = " LOAN_MANAGER_ID ")
    private String loanManagerId ; //贷后管理商

    @ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "LOAN_MANAGER_ID",insertable= false,updatable = false)
    private SmeEnterprise loanManager; //中介商

    public SmeEnterprise getLoanManager() {
        return loanManager;
    }

    @Column(name = " DISCOUNT_RATE ")
    private BigDecimal discountRate ; //资产折扣比例
    
    @Column(name = " AGGREMENT_CODE ")
    private String aggrementCode ; //协议编号
    
    @Column(name = " REPAYMENT_DATE ")
    private Long repaymentDate; //还款日
    
    @Column(name = " TOTAL_INCOME ")
    private BigDecimal totalIncome ; //预期总收益(不含本金)
	public long getId() {
		return id;
	}

	public BigDecimal getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(BigDecimal unitPrice) {
		this.unitPrice = unitPrice;
	}

	public BigDecimal getMinInvestShares() {
		return minInvestShares;
	}

	public void setMinInvestShares(BigDecimal minInvestShares) {
		this.minInvestShares = minInvestShares;
	}

	public BigDecimal getIncreaseInvestmentShares() {
		return increaseInvestmentShares;
	}

	public void setIncreaseInvestmentShares(BigDecimal increaseInvestmentShares) {
		this.increaseInvestmentShares = increaseInvestmentShares;
	}

	public String getContractTemplateId() {
		return contractTemplateId;
	}

	public void setContractTemplateId(String contractTemplateId) {
		this.contractTemplateId = contractTemplateId;
	}

	public Long getAssetPoolId() {
		return assetPoolId;
	}

	public void setAssetPoolId(long assetPoolId) {
		this.assetPoolId = assetPoolId;
	}

	public BigDecimal getMinFunds() {
		return minFunds;
	}

	public void setMinFunds(BigDecimal minFunds) {
		this.minFunds = minFunds;
	}

	public String getIllustration() {
		return illustration;
	}

	public void setIllustration(String illustration) {
		this.illustration = illustration;
	}

	public String getSuccessNotice() {
		return successNotice;
	}

	public void setSuccessNotice(String successNotice) {
		this.successNotice = successNotice;
	}

	public String getFailNotice() {
		return failNotice;
	}

	public void setFailNotice(String failNotice) {
		this.failNotice = failNotice;
	}

	public String getSerializeNumber() {
		return serializeNumber;
	}

	public void setSerializeNumber(String serializeNumber) {
		this.serializeNumber = serializeNumber;
	}

	public BigDecimal getProcess() {
		return process;
	}

	public void setProcess(BigDecimal process) {
		this.process = process;
	}

	public Date getInterestStartDate() {
		return interestStartDate;
	}

	public void setInterestStartDate(Date interestStartDate) {
		this.interestStartDate = interestStartDate;
	}

	public Date getAccountsReceiveDate() {
		return accountsReceiveDate;
	}

	public void setAccountsReceiveDate(Date accountsReceiveDate) {
		this.accountsReceiveDate = accountsReceiveDate;
	}

	public BigDecimal getProportionEarlyRepay() {
		return proportionEarlyRepay;
	}

	public void setProportionEarlyRepay(BigDecimal proportionEarlyRepay) {
		this.proportionEarlyRepay = proportionEarlyRepay;
	}

	public BigDecimal getLateFloatingRatio() {
		return lateFloatingRatio;
	}

	public void setLateFloatingRatio(BigDecimal lateFloatingRatio) {
		this.lateFloatingRatio = lateFloatingRatio;
	}

	public BigDecimal getIssuerFeeRate() {
		return issuerFeeRate;
	}

	public void setIssuerFeeRate(BigDecimal issuerFeeRate) {
		this.issuerFeeRate = issuerFeeRate;
	}

	public String getIssuerFeeRepaymentWay() {
		return issuerFeeRepaymentWay;
	}

	public void setIssuerFeeRepaymentWay(String issuerFeeRepaymentWay) {
		this.issuerFeeRepaymentWay = issuerFeeRepaymentWay;
	}

	public BigDecimal getInvestorFeeRate() {
		return investorFeeRate;
	}

	public void setInvestorFeeRate(BigDecimal investorFeeRate) {
		this.investorFeeRate = investorFeeRate;
	}

	public String getInvestorFeeRepaymentWay() {
		return investorFeeRepaymentWay;
	}

	public void setInvestorFeeRepaymentWay(String investorFeeRepaymentWay) {
		this.investorFeeRepaymentWay = investorFeeRepaymentWay;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public BigDecimal getMaxInvestAmount() {
		return maxInvestAmount;
	}

	public void setMaxInvestAmount(BigDecimal maxInvestAmount) {
		this.maxInvestAmount = maxInvestAmount;
	}

	public String getPayWay() {
		return payWay;
	}

	public void setPayWay(String payWay) {
		this.payWay = payWay;
	}

	public String getDebtorId() {
		return debtorId;
	}

	public void setDebtorId(String debtorId) {
		this.debtorId = debtorId;
	}

	public String getAgencyId() {
		return agencyId;
	}

	public void setAgencyId(String agencyId) {
		this.agencyId = agencyId;
	}

	public BigDecimal getAgencyFeeRate() {
		return agencyFeeRate;
	}

	public void setAgencyFeeRate(BigDecimal agencyFeeRate) {
		this.agencyFeeRate = agencyFeeRate;
	}

	public String getAgencyFeeRepaymentWay() {
		return agencyFeeRepaymentWay;
	}

	public void setAgencyFeeRepaymentWay(String agencyFeeRepaymentWay) {
		this.agencyFeeRepaymentWay = agencyFeeRepaymentWay;
	}

	public BigDecimal getLoanManagerFeeRate() {
		return loanManagerFeeRate;
	}

	public void setLoanManagerFeeRate(BigDecimal loanManagerFeeRate) {
		this.loanManagerFeeRate = loanManagerFeeRate;
	}

	public String getLoanManagerFeeRepaymentWay() {
		return loanManagerFeeRepaymentWay;
	}

	public void setLoanManagerFeeRepaymentWay(String loanManagerFeeRepaymentWay) {
		this.loanManagerFeeRepaymentWay = loanManagerFeeRepaymentWay;
	}

	public String getRepaymentFrom() {
		return repaymentFrom;
	}

	public void setRepaymentFrom(String repaymentFrom) {
		this.repaymentFrom = repaymentFrom;
	}

	public Date getRepaymentFromStartDate() {
		return repaymentFromStartDate;
	}

	public void setRepaymentFromStartDate(Date repaymentFromStartDate) {
		this.repaymentFromStartDate = repaymentFromStartDate;
	}

	public String getLoanManagerId() {
		return loanManagerId;
	}

	public void setLoanManagerId(String loanManagerId) {
		this.loanManagerId = loanManagerId;
	}

	public BigDecimal getDiscountRate() {
		return discountRate;
	}

	public void setDiscountRate(BigDecimal discountRate) {
		this.discountRate = discountRate;
	}

	public String getAggrementCode() {
		return aggrementCode;
	}

	public void setAggrementCode(String aggrementCode) {
		this.aggrementCode = aggrementCode;
	}

	public Long getRepaymentDate() {
		return repaymentDate;
	}

	public void setRepaymentDate(long repaymentDate) {
		this.repaymentDate = repaymentDate;
	}

	public BigDecimal getTotalIncome() {
		return totalIncome;
	}

	public void setTotalIncome(BigDecimal totalIncome) {
		this.totalIncome = totalIncome;
	}
////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public FlowStatus getFlowStatus() {
		return flowStatus;
	}

	public void setFlowStatus(FlowStatus flowStatus) {
		this.flowStatus = flowStatus;
	}

	public User getLegalPerson() {
		return legalPerson;
	}

	public void setLegalPerson(User legalPerson) {
		this.legalPerson = legalPerson;
	}

	public BigDecimal getTargetFunds() {
		return targetFunds;
	}

	public void setTargetFunds(BigDecimal targetFunds) {
		this.targetFunds = targetFunds;
	}

	public String getLoanPeriod() {
		return loanPeriod;
	}

	public void setLoanPeriod(String loanPeriod) {
		this.loanPeriod = loanPeriod;
	}

	public Date getDeadLine() {
		return deadLine;
	}

	public void setDeadLine(Date deadLine) {
		this.deadLine = deadLine;
	}

	public BigDecimal getInterestRateYear() {
		return interestRateYear;
	}

	public void setInterestRateYear(BigDecimal interestRateYear) {
		this.interestRateYear = interestRateYear;
	}

	public RepaymentWay getRepaymentWay() {
		return repaymentWay;
	}

	public void setRepaymentWay(RepaymentWay repaymentWay) {
		this.repaymentWay = repaymentWay;
	}

	public Date getCollectStartDate() {
		return collectStartDate;
	}

	public void setCollectStartDate(Date collectStartDate) {
		this.collectStartDate = collectStartDate;
	}

	public Date getCollectEndDate() {
		return collectEndDate;
	}

	public void setCollectEndDate(Date collectEndDate) {
		this.collectEndDate = collectEndDate;
	}

	public ReleaseVirtualAccountWay getReleaseVirtualAccountWay() {
		return releaseVirtualAccountWay;
	}

	public void setReleaseVirtualAccountWay(ReleaseVirtualAccountWay releaseVirtualAccountWay) {
		this.releaseVirtualAccountWay = releaseVirtualAccountWay;
	}

	public Date getCreateAt() {
		return createAt;
	}

	public void setCreateAt(Date createAt) {
		this.createAt = createAt;
	}

	public User getApplyer() {
		return applyer;
	}

	public void setApplyer(User applyer) {
		this.applyer = applyer;
	}

	public Date getUpdateAt() {
		return updateAt;
	}

	public void setUpdateAt(Date updateAt) {
		this.updateAt = updateAt;
	}

	public User getApprover() {
		return approver;
	}

	public void setApprover(User approver) {
		this.approver = approver;
	}

	public SMEProductType getProductType() {
		return productType;
	}

	public void setProductType(SMEProductType productType) {
		this.productType = productType;
	}

    public AssetPool getAssetPool() {
        return assetPool;
    }
}
