package com.lufax.customerService.pojo;

public enum RecordStatus {
	  ONGOING, DONE, CANCEL
}

