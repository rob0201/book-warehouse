package com.lufax.customerService.pojo;

import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "SME_INVESTMENTS")
public class SMEInvestment {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_INVESTMENT")
    @SequenceGenerator(name = "SEQ_INVESTMENT", sequenceName = "SEQ_INVESTMENT", allocationSize = 1)
    private Long id;

    @Column(name = "PRODUCT_ID")
    private Long productId;

    @Column(name = "INVESTOR_ID")
    private Long investorId;

    @Column(name = "INVEST_REQUEST_ID")
    private Long investmentRequestID;

    @Column(name = "INVESTMENT_AMOUNT")
    private BigDecimal investmentAmount;
    @Column(name = "INVESTMENT_CONFIRM_AT")
    private Timestamp investmentConfirmAt;
    @Column(name = "INVESTMENT_STATUS")
    private String investmentStatus;
    @Column(name = "SHARES")
    private BigDecimal shares;
    @Column(name = "FCD")
    private Timestamp FCD;
    @Column(name = "FCU")
    private String FCU;
    @Column(name = "LCD")
    private Timestamp LCD;
    @Column(name = "LCU")
    private String LCU;

    public SMEInvestment() {
    }

    public SMEInvestment(Long productId, Long investorId, Long investmentRequestID, BigDecimal investmentAmount, Timestamp investmentConfirmAt, String investmentStatus, BigDecimal shares, Timestamp FCD, String FCU, Timestamp LCD, String LCU) {
        this.productId = productId;
        this.investorId = investorId;
        this.investmentRequestID = investmentRequestID;
        this.investmentAmount = investmentAmount;
        this.investmentConfirmAt = investmentConfirmAt;
        this.investmentStatus = investmentStatus;
        this.shares = shares;
        this.FCD = FCD;
        this.FCU = FCU;
        this.LCD = LCD;
        this.LCU = LCU;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getProductId() {
        return productId;
    }

    public void setProductId(Long productId) {
        this.productId = productId;
    }

    public Long getInvestorId() {
        return investorId;
    }

    public void setInvestorId(Long investorId) {
        this.investorId = investorId;
    }

    public Long getInvestmentRequestID() {
        return investmentRequestID;
    }

    public void setInvestmentRequestID(Long investmentRequestID) {
        this.investmentRequestID = investmentRequestID;
    }

    public BigDecimal getInvestmentAmount() {
        return investmentAmount;
    }

    public void setInvestmentAmount(BigDecimal investmentAmount) {
        this.investmentAmount = investmentAmount;
    }

    public Timestamp getInvestmentConfirmAt() {
        return investmentConfirmAt;
    }

    public void setInvestmentConfirmAt(Timestamp investmentConfirmAt) {
        this.investmentConfirmAt = investmentConfirmAt;
    }

    public String getInvestmentStatus() {
        return investmentStatus;
    }

    public void setInvestmentStatus(String investmentStatus) {
        this.investmentStatus = investmentStatus;
    }

    public BigDecimal getShares() {
        return shares;
    }

    public void setShares(BigDecimal shares) {
        this.shares = shares;
    }

    public Timestamp getFCD() {
        return FCD;
    }

    public void setFCD(Timestamp FCD) {
        this.FCD = FCD;
    }

    public String getFCU() {
        return FCU;
    }

    public void setFCU(String FCU) {
        this.FCU = FCU;
    }

    public Timestamp getLCD() {
        return LCD;
    }

    public void setLCD(Timestamp LCD) {
        this.LCD = LCD;
    }

    public String getLCU() {
        return LCU;
    }

    public void setLCU(String LCU) {
        this.LCU = LCU;
    }
}
