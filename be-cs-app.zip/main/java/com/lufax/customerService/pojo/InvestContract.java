package com.lufax.customerService.pojo;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "SME_INVEST_CONTRACTS")
public class InvestContract {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_SME_INVEST_CONTRACTS")
    @SequenceGenerator(name = "SEQ_SME_INVEST_CONTRACTS", sequenceName = "SEQ_SME_INVEST_CONTRACTS", allocationSize = 1)
    private long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "INVEST_ID")
    private BuyRequestPool buyRequestPool;

    @Enumerated(EnumType.STRING)
    @Column(name = "CONTRACT_TYPE")
    private TradeContractType contractType;

    @Column(name = "STORE_ID")
    private String storeId;

    @Column(name = "CREATED_AT")
    private Date createdAt;

    @Column(name = "UPDATED_AT")
    private Date updatedAt;

    public InvestContract() {
    }

    public InvestContract(BuyRequestPool buyRequestPool, TradeContractType contractType, String storeId) {
        this.buyRequestPool = buyRequestPool;
        this.contractType = contractType;
        this.storeId = storeId;
        this.createdAt = this.updatedAt = new Date();
    }

    public String getStoreId() {
        return storeId;
    }

    public TradeContractType getContractType() {
        return contractType;
    }

    public boolean isInvestContract() {
        return TradeContractType.INVESTMENT == contractType;
    }

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public BuyRequestPool getBuyRequestPool() {
		return buyRequestPool;
	}

	public void setBuyRequestPool(BuyRequestPool buyRequestPool) {
		this.buyRequestPool = buyRequestPool;
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public Date getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	public void setContractType(TradeContractType contractType) {
		this.contractType = contractType;
	}

	public void setStoreId(String storeId) {
		this.storeId = storeId;
	}
    
}
