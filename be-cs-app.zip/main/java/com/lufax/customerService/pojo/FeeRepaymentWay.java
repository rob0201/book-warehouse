package com.lufax.customerService.pojo;

public enum FeeRepaymentWay {
    BEFORE("前期收"),
    MONTHLY("每月收"),
    MATURE("到期收"),
    UNKNOWN("unknown");

    private String value;
    private FeeRepaymentWay(String status) {
        this.value = status;
    }

    public String getValue() {
        return value;
    }
    public static FeeRepaymentWay getFeeRepaymentWayByName(String name){
        FeeRepaymentWay[] feeRepaymentWays=FeeRepaymentWay.values();
        for(FeeRepaymentWay feeRepaymentWay:feeRepaymentWays)
            if(feeRepaymentWay.name().equalsIgnoreCase(name))
                return feeRepaymentWay;
        return UNKNOWN;
    }
}
