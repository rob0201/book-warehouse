package com.lufax.customerService.pojo;

import java.util.ArrayList;
import java.util.List;

public enum CollectionPlanStatus {
	UNCOLLECTED(CollectType.ONGOING, "未收"), 
	PART_COLLECTED(CollectType.ONGOING, "部分收款"), 
	COLLECTED(CollectType.SETTLED, "已收");

	private CollectType type;
	private String value;

	CollectionPlanStatus(CollectType type, String value) {
		this.type = type;
		this.value = value;
	}

	public String getValue() {
		return value;
	}

	public boolean isSettled() {
		return CollectType.SETTLED == type;
	}

	public boolean isOngoing() {
		return CollectType.ONGOING == type;
	}
	
	public static CollectionPlanStatus convert(RepaymentPlanStatus repaymentPlanStatus) {
		if (RepaymentPlanStatus.PAID.equals(repaymentPlanStatus)) {
			return CollectionPlanStatus.COLLECTED;
		} else if (RepaymentPlanStatus.PART_PAID.equals(repaymentPlanStatus)) {
			return CollectionPlanStatus.PART_COLLECTED;
		} else if (RepaymentPlanStatus.UNPAID.equals(repaymentPlanStatus)) {
			return CollectionPlanStatus.UNCOLLECTED;
		}
		
		return null;
	}

	public static enum CollectType {
		ONGOING, SETTLED;

		public List<RepaymentPlanStatus> getStatuses() {
			List<RepaymentPlanStatus> result = new ArrayList<RepaymentPlanStatus>();
			for (RepaymentPlanStatus status : RepaymentPlanStatus.values()) {
				if (this.equals(status.type)) {
					result.add(status);
				}
			}
			return result;
		}
	}
	
}
