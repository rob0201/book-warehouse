package com.lufax.customerService.pojo;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "USER_PRODUCT_ACCOUNT")
public class UserProductAccount {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_USER_PRODUCT_ACCOUNT")
    @SequenceGenerator(name = "SEQ_USER_PRODUCT_ACCOUNT", sequenceName = "SEQ_USER_PRODUCT_ACCOUNT", allocationSize = 1)
    private Long id;

    @Column(name = "OWNER_ID")
    private Long ownerId;

    @Column(name = "PRODUCT_ID")
    private Long productId;

    @Column(name = "SHARES")
    private BigDecimal shares;

    @Column(name = "FREEZE_SHARES")
    private BigDecimal freezeShares;

    @Enumerated(EnumType.STRING)
    @Column(name = "STATUS")
    private UserProductAccountStatus status;
    
    public UserProductAccount(){}

    public UserProductAccount(Long ownerId, Long productId, BigDecimal shares, BigDecimal freezeShares, UserProductAccountStatus status) {
        this.ownerId = ownerId;
        this.productId = productId;
        this.shares = shares;
        this.freezeShares = freezeShares;
        this.status = status;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getOwnerId() {
        return ownerId;
    }

    public void setOwnerId(Long ownerId) {
        this.ownerId = ownerId;
    }

    public Long getProductId() {
        return productId;
    }

    public void setProductId(Long productId) {
        this.productId = productId;
    }

    public BigDecimal getShares() {
        return shares;
    }

    public void setShares(BigDecimal shares) {
        this.shares = shares;
    }

    public BigDecimal getFreezeShares() {
        return freezeShares;
    }

    public void setFreezeShares(BigDecimal freezeShares) {
        this.freezeShares = freezeShares;
    }

    public UserProductAccountStatus getStatus() {
        return status;
    }

    public void setStatus(UserProductAccountStatus status) {
        this.status = status;
    }
}
