package com.lufax.customerService.pojo;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "MANUAL_ACC_TRANS_HISTORY")
public class ManualAccountTransactionHistory {
	
	@Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_MANUAL_ACC_TRANS_HISTORY")
    @SequenceGenerator(name = "SEQ_MANUAL_ACC_TRANS_HISTORY", sequenceName = "SEQ_MANUAL_ACC_TRANS_HISTORY", allocationSize = 1)
	private long id;
	
	//转账申请ID
	@Column(name = "MANUAL_ACC_TRANS_ID")
	private long manualAccountTransactionId;
	
	//更新前状态
	@Enumerated(EnumType.STRING)
	@Column(name = "BEFORE_STATUS")
	private ManualAccountTransactionStatus before;
	
	//更新后状态
	@Enumerated(EnumType.STRING)
	@Column(name = "AFTER_STATUS")
	private ManualAccountTransactionStatus after;
	
	//修改人ID
	@Column(name = "MODIFIER")
	private long modifierId;
	
	//更新时间
	@Temporal(TemporalType.DATE)
	@Column(name = "UPDATE_AT")
	private Date updateAt;

	public ManualAccountTransactionHistory() {
	}

	public ManualAccountTransactionHistory(long manualAccountTransactionId, ManualAccountTransactionStatus before, ManualAccountTransactionStatus after, long modifierId) {
		this.manualAccountTransactionId = manualAccountTransactionId;
		this.before = before;
		this.after = after;
		this.modifierId = modifierId;
		this.updateAt = new Date();
	}

	public long getId() {
		return id;
	}

	private void setId(long id) {
		this.id = id;
	}

	public long getManualAccountTransactionId() {
		return manualAccountTransactionId;
	}

	public void setManualAccountTransactionId(long manualAccountTransactionId) {
		this.manualAccountTransactionId = manualAccountTransactionId;
	}

	public ManualAccountTransactionStatus getBefore() {
		return before;
	}

	public void setBefore(ManualAccountTransactionStatus before) {
		this.before = before;
	}

	public ManualAccountTransactionStatus getAfter() {
		return after;
	}

	public void setAfter(ManualAccountTransactionStatus after) {
		this.after = after;
	}

	public long getModifierId() {
		return modifierId;
	}

	public void setModifierId(long modifierId) {
		this.modifierId = modifierId;
	}

	public Date getUpdateAt() {
		return updateAt;
	}

	public void setUpdateAt(Date updateAt) {
		this.updateAt = updateAt;
	}

}
