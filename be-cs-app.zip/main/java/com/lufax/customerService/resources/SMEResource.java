package com.lufax.customerService.resources;


import com.google.gson.Gson;
import com.lufax.common.domain.User;
import com.lufax.common.resources.ServiceProvider;
import com.lufax.common.resources.gsonTemplate.Pagination;
import com.lufax.common.utils.BEProperties;
import com.lufax.common.utils.DevLog;
import com.lufax.customerService.domain.OperationMenu;
import com.lufax.customerService.domain.OperationType;
import com.lufax.customerService.domain.OperationsLog;
import com.lufax.customerService.resources.gsonTemplate.CustomerServiceSmeInvestRequestGson;
import com.lufax.customerService.resources.gsonTemplate.CustomerServiceSmeInvestmentGson;
import com.lufax.customerService.service.CustomerOperationsLogService;
import com.lufax.jersey.client.JerseyService;
import com.lufax.customerService.dao.BuyRequestPoolDAO;
import com.lufax.customerService.dao.CollectionPlanDAO;
import com.lufax.customerService.dao.ExtProductSMEDAO;
import com.lufax.customerService.dao.InvestContractDAO;
import com.lufax.customerService.pojo.*;
import com.sun.jersey.api.client.ClientResponse;
import org.apache.commons.lang.StringUtils;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class SMEResource {
    private JerseyService smeJerseyService;
    private BEProperties beProperties;
    private User user;
    private CustomerOperationsLogService customerOperationLogService;
    private User customerRepresentative;
    private BuyRequestPoolDAO buyRequestPoolDAO;
    private CollectionPlanDAO collectionPlanDAO;
    private InvestContractDAO investContractDAO;
    private ExtProductSMEDAO extProductSMEDAO;
    private static final int DEFAULT_PAGE_SIZE = 5;


    public SMEResource(User customerRepresentative, User user, ServiceProvider serviceProvider) {
        this.user = user;
        this.customerRepresentative = customerRepresentative;
        this.smeJerseyService = serviceProvider.getSmeJerseyService();
        this.beProperties = serviceProvider.getBeProperties();
        this.customerOperationLogService = serviceProvider.getCustomerOperationsLogService();
        this.buyRequestPoolDAO = serviceProvider.getBuyRequestPoolDAO();
        this.collectionPlanDAO = serviceProvider.getCollectionPlanDAO();
        this.extProductSMEDAO = serviceProvider.getExtProductSMEDAO();
        this.investContractDAO = serviceProvider.getInvestContractDAO();
    }


    // 投资请求
    @GET
    @Path("investmentRequests/{pageNum}")
    @Produces(value = MediaType.APPLICATION_JSON)
    public String getInvestmentReqFromSME(@PathParam("pageNum") String pageNum) {
        long userId = user.id();
        int _pageNum = Integer.valueOf(pageNum);

        long totalNum = buyRequestPoolDAO.countInvestRequest(userId);
        if (totalNum == 0) {
            return new Gson().toJson(new Pagination(DEFAULT_PAGE_SIZE, totalNum, _pageNum, new ArrayList<CustomerServiceSmeInvestRequestGson>()));
        }

        List<BuyRequestPool> buyRequestPoolList = buyRequestPoolDAO.findInvestRequest(userId, (_pageNum - 1) * DEFAULT_PAGE_SIZE, DEFAULT_PAGE_SIZE);

        List<CustomerServiceSmeInvestRequestGson> customerServiceSmeInvestmentList = new ArrayList<CustomerServiceSmeInvestRequestGson>(buyRequestPoolList.size());
        for (BuyRequestPool buyRequestPool : buyRequestPoolList) {
            ExtProductSME product = extProductSMEDAO.load(buyRequestPool.getProductId());
            List<SMECollectionPlan> collectionPlans = collectionPlanDAO.findCollectionPlanByProductIdAndUserId(product.getId(), userId);
            customerServiceSmeInvestmentList.add(new CustomerServiceSmeInvestRequestGson(buyRequestPool, product, collectionPlans.size()));
        }

        return new Gson().toJson(new Pagination(DEFAULT_PAGE_SIZE, totalNum, _pageNum, customerServiceSmeInvestmentList));

    }


    // 投资历史
    @GET
    @Path("investmentHistory/{pageNum}")
    @Produces(value = MediaType.APPLICATION_JSON)
    public String getInvestmentHisFromSME(@PathParam("pageNum") String pageNum) {
        long userId = user.id();
        int _pageNum = Integer.valueOf(pageNum);

        long totalNum = buyRequestPoolDAO.countInvestHistory(userId);
        if (totalNum == 0) {
            return new Gson().toJson(new Pagination(DEFAULT_PAGE_SIZE, totalNum, _pageNum, new ArrayList<CustomerServiceSmeInvestmentGson>()));
        }

        List<UserProductAccount> userProductAccountList = buyRequestPoolDAO.findInvestHistory(userId, (_pageNum - 1) * DEFAULT_PAGE_SIZE, DEFAULT_PAGE_SIZE);
        List<CustomerServiceSmeInvestmentGson> customerServiceSmeInvestmentList = new ArrayList<CustomerServiceSmeInvestmentGson>(userProductAccountList.size());
        List<BuyRequestStatus> statuses = new ArrayList<BuyRequestStatus>();
        statuses.add(BuyRequestStatus.FINISH_COLLECT);
        for (UserProductAccount userProductAccount : userProductAccountList) {
            ExtProductSME product = extProductSMEDAO.load(userProductAccount.getProductId());
            List<SMECollectionPlan> collectionPlans = collectionPlanDAO.findCollectionPlanByProductIdAndUserId(product.getId(), userId);
            BuyRequestPool buyRequestPool = buyRequestPoolDAO.findBuyRequestPoolWithUserAndProduct(userProductAccount.getOwnerId(), userProductAccount.getProductId(), statuses);
            InvestContract investContract = null;
            if (null != buyRequestPool) {
                investContract = investContractDAO.findByInvestAndType(buyRequestPool, TradeContractType.INVESTMENT);
            }
            customerServiceSmeInvestmentList.add(new CustomerServiceSmeInvestmentGson(buyRequestPool, product, collectionPlans, investContract));
        }

        return new Gson().toJson(new Pagination(DEFAULT_PAGE_SIZE, totalNum, _pageNum, customerServiceSmeInvestmentList));
    }


    // 正在收款
    @GET
    @Path("investments/{pageNum}")
    @Produces(value = MediaType.APPLICATION_JSON)
    public String getInvestmentFromSME(@PathParam("pageNum") String pageNum) {
        long userId = user.id();
        int _pageNum = Integer.valueOf(pageNum);

        long totalNum = buyRequestPoolDAO.countInvestGathering(userId);
        if (totalNum == 0) {
            return new Gson().toJson(new Pagination(DEFAULT_PAGE_SIZE, totalNum, _pageNum, new ArrayList<CustomerServiceSmeInvestmentGson>()));
        }
        List<UserProductAccount> userProductAccountList = buyRequestPoolDAO.findInvestGathering(userId, (_pageNum - 1) * DEFAULT_PAGE_SIZE, DEFAULT_PAGE_SIZE);
        List<BuyRequestStatus> statuses = new ArrayList<BuyRequestStatus>();
        statuses.add(BuyRequestStatus.SUCCESS);
        List<CustomerServiceSmeInvestmentGson> customerServiceSmeInvestmentList = new ArrayList<CustomerServiceSmeInvestmentGson>(userProductAccountList.size());
        for (UserProductAccount userProductAccount : userProductAccountList) {
            ExtProductSME product = extProductSMEDAO.load(userProductAccount.getProductId());
            List<SMECollectionPlan> collectionPlans = collectionPlanDAO.findCollectionPlanByProductIdAndUserId(product.getId(), userId);
            BuyRequestPool buyRequestPool = buyRequestPoolDAO.findBuyRequestPoolWithUserAndProduct(userProductAccount.getOwnerId(), userProductAccount.getProductId(), statuses);
            InvestContract investContract = null;
            if (null != buyRequestPool) {
                investContract = investContractDAO.findByInvestAndType(buyRequestPool, TradeContractType.INVESTMENT);
            }
            customerServiceSmeInvestmentList.add(new CustomerServiceSmeInvestmentGson(buyRequestPool, product, collectionPlans, investContract));
        }

        return new Gson().toJson(new Pagination(DEFAULT_PAGE_SIZE, totalNum, _pageNum, customerServiceSmeInvestmentList));
    }

    @GET
    @Path("getInvestmentCountSme")
    @Produces(value = MediaType.APPLICATION_JSON)
    public String getInvestmentCountSme() {
        long userId = user.id();
        try {
            String url = String.format(beProperties.getRemoteSmeProductCount(), userId);
            DevLog.info(this, String.format("the host is [%s], the service is [%s]", smeJerseyService.getHost().getHostURI(), url));
            ClientResponse totalCount = smeJerseyService.getInstance(url).getResource().get(ClientResponse.class);
            if (totalCount.getStatus() != 200) {
                DevLog.error(this, "sme getInvestmentCountSme' status is [%s]:----------" + totalCount.getStatus());
                totalCount.close();
                throw new WebApplicationException(Response.status(totalCount.getStatus()).entity("获取SME记录数").build());
            }
            String result = "{\"totalCount\":\"%s\"}";
            return String.format(result, totalCount.getEntity(String.class));
        } catch (Exception e) {
            DevLog.error(this, String.format("The exception is [%s]", e));
            return "{\"totalCount\":0}";
        }
    }

    @GET
    @Path("collectPlan/{productId}")
    @Produces(value = MediaType.APPLICATION_JSON)
    public String getCollectPlanFromSme(@PathParam("productId") String productId) {
        long userId = user.id();
        try {
            String url = String.format(beProperties.getRemoteSmeCollectPlan(), userId, productId);
            DevLog.info(this, String.format("the host is [%s], the service is [%s]", smeJerseyService.getHost().getHostURI(), url));
            ClientResponse tmp = smeJerseyService.getInstance(url).withUser(String.valueOf(userId)).getResource().get(ClientResponse.class);
            if (tmp.getStatus() != 200) {
                DevLog.error(this, "sme getInvestmentCountSme' status is [%s]:----------" + tmp.getStatus());
                tmp.close();
                throw new WebApplicationException(Response.status(tmp.getStatus()).entity("获取SME收款记录").build());
            }
            String result = tmp.getEntity(String.class);
            DevLog.info(this, "sme collect plan:------------------" + result);
            return result;
        } catch (Exception e) {
            DevLog.error(this, String.format("The exception is [%s]", e));
            return "{\"totalShouldCollectAmount\":0,\"totalActualCollectAmount\":0,\"collectPlanGsons\":[]}";
        }
    }

    @GET
    @Path("collectPlanDetail/{collectPlanId}")
    @Produces(value = MediaType.APPLICATION_JSON)
    public String getCollectPlanDetailFromSme(@PathParam("collectPlanId") String collectPlanId) {
        long userId = user.id();
        ClientResponse tmp = null;
        try {
            String url = String.format(beProperties.getRemoteSmeCollectPlanDetail(), userId, collectPlanId);
            DevLog.info(this, String.format("the host is [%s], the service is [%s]", smeJerseyService.getHost().getHostURI(), url));
            tmp = smeJerseyService.getInstance(url).withUser(String.valueOf(userId)).getResource().get(ClientResponse.class);
            if (tmp.getStatus() != 200) {
                DevLog.error(this, "sme collectPlanDetail' status is [%s]:----------" + tmp.getStatus());
                tmp.close();
                throw new WebApplicationException(Response.status(tmp.getStatus()).entity("获取SME收款详细记录").build());
            }
            String result = tmp.getEntity(String.class);
            DevLog.info(this, "sme collection plan detail:---------------" + result);
            return result;
        } catch (Exception e) {
            DevLog.error(this, String.format("The exception is [%s]", e));
            return "{\"collectPlanDetailGson\":[],\"collectRecordDetailGsons\":[]}";
        }
    }

    @GET
    @Path("productCollectRecord/{productId}")
    @Produces(value = MediaType.APPLICATION_JSON)
    public String getProductCollectRecordFromSme(@PathParam("productId") String productId) {
        long userId = user.id();
        try {
            String url = String.format(beProperties.getRemoteSmeProductCollectRecord(), userId, productId);
            DevLog.info(this, String.format("the host is [%s], the service is [%s]", smeJerseyService.getHost().getHostURI(), url));
            ClientResponse tmp = smeJerseyService.getInstance(url).withUser(String.valueOf(userId)).getResource().get(ClientResponse.class);
            if (tmp.getStatus() != 200) {
                DevLog.error(this, "sme productCollectRecord' status is [%s]:----------" + tmp.getStatus());
                tmp.close();
                throw new WebApplicationException(Response.status(tmp.getStatus()).entity("获取SME产品收款记录").build());
            }
            String result = tmp.getEntity(String.class);
            DevLog.info(this, "SME history of collection detail:------------------" + result);
            return result;
        } catch (Exception e) {
            DevLog.error(this, String.format("The exception is [%s]", e));
            return "{\"purchaseAmount\":0,\"collectBetween\":0,\"totalPeriod\":0,\"interestRate\":0,\"receiveAmount\":0,\"collectRecordDetailGsons\":[]}";
        }
    }

    @GET
    @Path("/investments/pdf")
    public Response getSmePdf(@QueryParam("pdfUrl") String pdfUrl) {
        long userId = user.id();
        DevLog.info(this, String.format("the userId is [%s], the pdfUrl is [%s]", userId, pdfUrl));
        if (StringUtils.isEmpty(pdfUrl)) {
            throw new WebApplicationException(Response.status(Response.Status.NOT_FOUND).entity("请求失败").build());
        }
        ClientResponse clientResponse = null;
        try {
            clientResponse = smeJerseyService.getInstance(pdfUrl).withUser(String.valueOf(userId)).getResource().get(ClientResponse.class);
            int returnStatus = clientResponse.getStatus();
            DevLog.info(this, String.format("The clientResponse's status is [%s]", returnStatus));
            if (200 == returnStatus) {
                return Response.ok().entity(clientResponse.getEntityInputStream()).header("Content-Disposition", String.format("inline; filename=%s", new Date().getTime() + ".pdf")).header("Extension", "pdf").build();
            }
            return Response.status(Response.Status.BAD_REQUEST).entity("系统繁忙").build();
        } catch (Exception e) {
            throw new WebApplicationException(Response.status(Response.Status.BAD_REQUEST).entity("系统繁忙").build());
        }
    }

    private void writeOperationLog(OperationMenu logType) {
        writeOperationLog(logType, null, "");
    }

    private void writeOperationLog(OperationMenu logType, OperationType operationType, String operationData) {
        customerOperationLogService.logCustomerOperations(new OperationsLog(logType, operationType, operationData, user.id(), customerRepresentative.id()));
    }
}
