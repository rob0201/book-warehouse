package com.lufax.customerService.resources;


import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.lufax.common.utils.DevLog;
import com.lufax.customerService.domain.OperationMenu;
import com.lufax.customerService.domain.OperationType;
import com.lufax.customerService.domain.OperationsLog;
import com.lufax.customerService.service.CustomerOperationsLogService;
import org.apache.commons.lang.StringUtils;

import com.google.gson.Gson;
import com.lufax.common.domain.InvestmentRequestStatus;
import com.lufax.common.domain.TradingStatus;
import com.lufax.common.domain.User;
import com.lufax.common.domain.repository.InvestmentRepository;
import com.lufax.common.domain.repository.InvestmentRequestRepository;
import com.lufax.common.resources.ServiceProvider;
import com.lufax.common.resources.gsonTemplate.PaginationGson;
import com.lufax.common.utils.DevLog;
import com.lufax.common.web.helper.ConstantsHelper;
import com.lufax.customerService.resources.gsonTemplate.CustomerServiceInvestmentRequestGson;
import com.lufax.customerService.service.CustomerServiceInvestmentService;
import com.lufax.jersey.client.JerseyService;
import com.sun.jersey.api.client.ClientResponse;

import static com.lufax.customerService.domain.OperationMenu.INVESTMENT_REQUEST;

public class P2PResource {
    private User user;
    private JerseyService p2pJerseyService;
    private InvestmentRepository investmentRepository;
    private InvestmentRequestRepository investmentRequestRepository;
    private CustomerServiceInvestmentService customerServiceInvestmentService;
    private CustomerOperationsLogService customerOperationsLogService;
    private User customerRepresentative;
    

    public P2PResource(User customerRepresentative, User user, ServiceProvider serviceProvider) {
        this.customerRepresentative = customerRepresentative;
        this.p2pJerseyService = serviceProvider.getP2pJerseyService();
        this.user = user;
        this.investmentRepository = serviceProvider.getInvestmentRepository();
        this.investmentRequestRepository = serviceProvider.getInvestmentRequestRepository();
        this.customerServiceInvestmentService = serviceProvider.getCustomerServiceInvestmentService();
        this.customerOperationsLogService = serviceProvider.getCustomerOperationsLogService();
    }
    /**
     * p2p投资请求查询
     * @param pageNum
     * @return
     */
    @GET
    @Path("/investment-requests/{pageNum}")
    @Produces(value = MediaType.APPLICATION_JSON)
    public String investRequest(@PathParam("pageNum") int pageNum){
                try {
            writeOperationLog(OperationMenu.INVESTMENT_REQUEST);
        } catch (Exception e) {
            DevLog.error(this,"Failed to write the log.",e);
        }
    	DevLog.info(this, String.format("the userId is [%s], the pageNum is [%s]", user.id(),pageNum));
    	List<String> statuses = new ArrayList<String>();
    	statuses.add(InvestmentRequestStatus.FAIL.name());
        statuses.add(InvestmentRequestStatus.LOW_BALANCE.name());
        statuses.add(InvestmentRequestStatus.NEW.name());
    	long totalCount = investmentRequestRepository.countForLoanerByStatus(user, statuses);
    	PaginationGson paginationGson = new PaginationGson(ConstantsHelper.RECENT_LIMIT, totalCount, pageNum);
        if (totalCount > 0) {
        	List<CustomerServiceInvestmentRequestGson> investmentRequestGsons = customerServiceInvestmentService.getInvestmentRequests(user, statuses, ConstantsHelper.RECENT_LIMIT,(paginationGson.getCurrentPage() - 1) * ConstantsHelper.RECENT_LIMIT);
            paginationGson.setData(investmentRequestGsons);
        }
    	return new Gson().toJson(paginationGson);
    }
    /**
     * 投资历史及正在收款查询
     * type:ONGOING 为正在收款
     * type:SETTLED 为投资历史
     * @param pageNum
     * @param type
     * @return
     */
    @GET
    @Path("/investments/{pageNum}")
    @Produces(value = MediaType.APPLICATION_JSON)
    public String investmenting(@PathParam("pageNum")int pageNum,@QueryParam("type") TradingStatus.Type type){
        try {
            if(TradingStatus.Type.ONGOING.equals(type)) {
                writeOperationLog(OperationMenu.INVESTMENTS);
            } else {
                writeOperationLog(OperationMenu.INVESTMENT_HISTORY);
            }
        } catch (Exception e) {
            DevLog.error(this,"Failed to write the log.",e);
        }
    	DevLog.info(this, String.format("the userId is [%s], the pageNum is [%s]", user.id(),pageNum));
    	long totalCount = investmentRepository.countInvestmentsByStatusAndUser(user, type);
    	PaginationGson paginationGson = new PaginationGson(ConstantsHelper.RECENT_LIMIT, totalCount, pageNum);
        if (totalCount > 0) {
            paginationGson.setData(customerServiceInvestmentService.getInvestmentByStatusAndUser(user, type, ConstantsHelper.RECENT_LIMIT, (paginationGson.getCurrentPage() - 1) * ConstantsHelper.RECENT_LIMIT));
        }
        return new Gson().toJson(paginationGson);
    }
    private void writeOperationLog(OperationMenu logType, OperationType operationType, String operationData) {
        customerOperationsLogService.logCustomerOperations(new OperationsLog(logType, operationType, operationData, user.id(), customerRepresentative.id()));
    }

    private void writeOperationLog(OperationMenu logType) {
        writeOperationLog(logType, null, "");
    }
    /**
     * 合同查看
     * @param pdfUrl
     * @return
     */
    @GET
    @Path("/investments/pdf")
    public Response getSmePdf(@QueryParam("pdfUrl") String pdfUrl) {
    	long userId = user.id();
    	DevLog.info(this, String.format("the userId is [%s], the pdfUrl is [%s]", userId,pdfUrl));
        if (StringUtils.isEmpty(pdfUrl)) {
            throw new WebApplicationException(Response.status(Response.Status.NOT_FOUND).entity("请求失败").build());
        }
        ClientResponse clientResponse = null;
        try {
        	if(pdfUrl.indexOf("compensate-apply-contract-download")>0 || pdfUrl.indexOf("compensate-confirm-contract-download")>0 || pdfUrl.endsWith("download")){//修正bug3898：当从p2p获取的信息时，相关的地址已经有download，无需再加上download
        		DevLog.info(this, String.format("This is in compensate-contract-download and url is [%s]", pdfUrl));
        		clientResponse = p2pJerseyService.getInstance(pdfUrl).withUser(String.valueOf(userId)).getResource().get(ClientResponse.class);
        	}else{
        		DevLog.info(this, String.format("This is in contract and url is [%s]", pdfUrl));
        		clientResponse = p2pJerseyService.getInstance(pdfUrl + "/download").withUser(String.valueOf(userId)).getResource().get(ClientResponse.class);
        	}
            int returnStatus = clientResponse.getStatus();
            DevLog.info(this, String.format("The clientResponse's status is [%s]", returnStatus));
            if (200 == returnStatus) {
                return Response.ok().entity(clientResponse.getEntityInputStream()).header("Content-Disposition", String.format("inline; filename=%s", new Date().getTime()+".pdf")).header("Extension", "pdf").build();
            }
            return Response.status(Response.Status.BAD_REQUEST).entity("系统繁忙").build();
        } catch (Exception e) {
            throw new WebApplicationException(Response.status(Response.Status.BAD_REQUEST).entity("系统繁忙").build());
        }
    }
/**
    @GET
    @Path("/transaction-overview")
    @Produces(value = MediaType.APPLICATION_JSON)
    public String userTransactionOverview() {
    	long userId = user.id();
        try {
            String url = String.format(beProperties.getRemoteP2pTransactionUrl(), userId);
            Logger.info(this, String.format("The p2phost is [%s], the service is [%s]", p2pJerseyService.getHost().getHostURI(), url));
            ClientResponse clientResponse =  p2pJerseyService.getInstance(url).getResource().get(ClientResponse.class);
            if(clientResponse.getStatus()!=200){
            	Logger.error(this, "p2p transaction-overview' status is [%s]:----------" + clientResponse.getStatus());
            	throw new WebApplicationException(Response.status(clientResponse.getStatus()).entity("获取p2p交易").build());
            }
            String result = clientResponse.getEntity(String.class);
            Logger.info(this, "p2p transaction-overview:+++++++++++++++++++" + result);
            return result;
        } catch (Exception e) {
            Logger.error(this, String.format("The exception is [%s]", e));
            return "{\"waitingConfirmLoanRequestStatistics\":0,\"waitingInvestLoanRequestStatistics\":0,\"waitingConfirmInvestmentRequestStatistics\":0,\"ongoingLoanStatistics\":0,\"overdueRepaymentStatistics\":0,"
                    + "\"settledLoanStatistics\":0,\"ongoingInvestmentStatistics\":0,\"overduedCollectionStatistics\":0,\"settledInvestmentStatistics\":0}";
        }
    }

    @GET
    @Path("/loan-requests/{pageNum}")
    @Produces(value = MediaType.APPLICATION_JSON)
    public String userLoanRequests(@PathParam("pageNum") String pageNum,
                                   @QueryParam("createdAtFrom") String createdAtFrom,
                                   @QueryParam("createdAtTo") String createdAtTo,
                                   @QueryParam("statusWaitingCheck") String statusWaitingCheck,
                                   @QueryParam("statusFail") String statusFail) {
        if (createdAtFrom == null) {
            createdAtFrom = "";
        }
        if (createdAtTo == null) {
            createdAtTo = "";
        }
        if (statusWaitingCheck == null) {
            statusWaitingCheck = "";
        }
        if (statusFail == null) {
            statusFail = "";
        }
    	long userId = user.id();
        try {
            String url = String.format(beProperties.getRemoteP2pLoanRequestUrl(),userId, pageNum);
            Logger.info(this, String.format("The p2phost is [%s], the service is [%s]", p2pJerseyService.getHost().getHostURI(), url));
            ClientResponse clientResponse = p2pJerseyService.getInstance(url).getResource()
                    .queryParam("startAtFrom", createdAtFrom)
                    .queryParam("startAtTo", createdAtTo)
                    .queryParam("scheduledEndAtFrom", statusWaitingCheck)
                    .queryParam("scheduledEndAtTo", statusFail)
                    .get(ClientResponse.class);
            if(clientResponse.getStatus()!=200){
            	Logger.error(this, "p2p loan-requests' status is [%s]:----------" + clientResponse.getStatus());
            	throw new WebApplicationException(Response.status(clientResponse.getStatus()).entity("获取p2p贷款").build());
            }
            String result = clientResponse.getEntity(String.class);
            Logger.info(this, "p2p loan-requests:+++++++++++++++++++" + result);
            return result;
        } catch (UniformInterfaceException e) {
            Logger.error(this, String.format("The exception is [%s]", e));
            return "{\"totalPage\":0,\"prePage\":0,\"nextPage\":0,\"currentPage\":0,\"totalCount\":0,\"data\":[]}";
        }
    }

    @GET
    @Path("/loans/{pageNum}")
    @Produces(value = MediaType.APPLICATION_JSON)
    public String getLoansPagination(@QueryParam("statusType") final TradingStatus.Type statusType,
                                     @QueryParam("startAtFrom") String startAtFrom,
                                     @QueryParam("startAtTo") String startAtTo,
                                     @QueryParam("scheduledEndAtFrom") String endAtFrom,
                                     @QueryParam("scheduledEndAtTo") String endAtTo,
                                     @PathParam("pageNum") int pageNum) {
        if (startAtFrom == null) {
            startAtFrom = "";
        }
        if (startAtFrom == null) {
            startAtFrom = "";
        }
        if (endAtFrom == null) {
            endAtFrom = "";
        }
        if (endAtTo == null) {
            endAtTo = "";
        }
    	long userId = user.id();
        try {
            String url = String.format(beProperties.getRemoteP2pLoanDetailUrl(), userId, pageNum);
            Logger.info(this, String.format("The p2phost is [%s], the service is [%s]", p2pJerseyService.getHost().getHostURI(), url));
            ClientResponse clientResponse= p2pJerseyService.getInstance(url).getResource()
                    .queryParam("statusType", statusType.name())
                    .queryParam("startAtFrom", startAtFrom)
                    .queryParam("startAtTo", startAtTo)
                    .queryParam("scheduledEndAtFrom", endAtFrom)
                    .queryParam("scheduledEndAtTo", endAtTo)
                    .get(ClientResponse.class);
            if(clientResponse.getStatus()!=200){
            	Logger.error(this, "p2p loans' status is [%s]:----------" + clientResponse.getStatus());
            	throw new WebApplicationException(Response.status(clientResponse.getStatus()).entity("获取p2p贷款记录").build());
            }
            String result = clientResponse.getEntity(String.class);
            Logger.info(this, "p2p loans:+++++++++++++++++++" + result);
            return result;
        } catch (UniformInterfaceException e) {
            Logger.error(this, String.format("The exception is [%s]", e));
            return "{\"totalPage\":0,\"prePage\":0,\"nextPage\":0,\"currentPage\":0,\"totalCount\":0,\"data\":[]}";
        }
    }

    @GET
    @Path("loans/{loanId}/repayment-history")
    @Produces(value = MediaType.APPLICATION_JSON)
    public String getRepaymentHistory(@PathParam("loanId") String loanId) {
    	long userId = user.id();
    	try {
            String url = String.format(beProperties.getRemoteP2pRepaymentHistoryUrl(), userId, loanId);
            Logger.info(this, String.format("The p2phost is [%s], the service is [%s]", p2pJerseyService.getHost().getHostURI(), url));
            ClientResponse clientResponse = p2pJerseyService.getInstance(url).getResource().get(ClientResponse.class);
            if(clientResponse.getStatus()!=200){
            	Logger.error(this, "p2p repayment-history' status is [%s]:----------" + clientResponse.getStatus());
            	throw new WebApplicationException(Response.status(clientResponse.getStatus()).entity("获取p2p还款历史记录").build());
            }
            String result = clientResponse.getEntity(String.class);
            Logger.info(this, "p2p repayment-history:+++++++++++++++++++" + result);
            return result;
        } catch (Exception e) {
            Logger.error(this, String.format("The exception is [%s]", e));
            return "{\"data\":[]}";
        }
    }

    @GET
    @Path("loans/{loanId}/repayment-details")
    @Produces(value = MediaType.APPLICATION_JSON)
    public String getRepaymentDetail(@PathParam("loanId") String loanId) {
    	long userId = user.id();
        try {
            String url = String.format(beProperties.getRemoteP2pRepaymentDetailUrl(), userId, loanId);
            Logger.info(this, String.format("The p2phost is [%s], the service is [%s]", p2pJerseyService.getHost().getHostURI(), url));
            ClientResponse clientResponse = p2pJerseyService.getInstance(url).getResource().get(ClientResponse.class);
            if(clientResponse.getStatus()!=200){
            	Logger.error(this, "p2p repayment-details' status is [%s]:----------" + clientResponse.getStatus());
            	throw new WebApplicationException(Response.status(clientResponse.getStatus()).entity("获取p2p还款历史详细记录").build());
            }
            String result = clientResponse.getEntity(String.class);
            Logger.info(this, "p2p repayment-details:+++++++++++++++++++" + result);
            return result;
        } catch (Exception e) {
            Logger.error(this, String.format("The exception is [%s]", e));
            return "{\"data\":[]}";
        }
    }

    @POST
    @Path("loans/{loanId}/repay")
    public Response repay(@FormParam("includeCurrentPlan") boolean includeCurrentPlan,
                          @PathParam("loanId") String loanId) throws IOException {
    	long userId = user.id();
        try {
            String url = String.format(beProperties.getRemoteP2pLoanRepayUrl(), userId, loanId);
            Logger.info(this, String.format("The p2phost is [%s], the service is [%s]", p2pJerseyService.getHost().getHostURI(), url));
            Form form = new Form();
            form.add("includeCurrentPlan", String.valueOf(includeCurrentPlan));
            ClientResponse clientResponse = p2pJerseyService.getInstance(url).getResource()
                    .post(ClientResponse.class, form);
            if(clientResponse.getStatus()!=200){
            	Logger.error(this, "p2p loans repay' status is [%s]:----------" + clientResponse.getStatus());
            	throw new WebApplicationException(Response.status(clientResponse.getStatus()).entity("获取p2p还款记录").build());
            }
            return Response.status(clientResponse.getStatus()).entity(clientResponse.getEntity(String.class)).build();
        } catch (UniformInterfaceException e) {
            Logger.error(this, String.format("The exception is [%s]", e));
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
        }
    }

    @GET
    @Path("/investments/{pageNum}")
    @Produces(value = MediaType.APPLICATION_JSON)
    public String getInvestments(@PathParam("pageNum") int pageNum,
                                 @QueryParam("statusType") TradingStatus.Type statusType,
                                 @QueryParam("startDate") String startDateStart,
                                 @QueryParam("startDateEnd") String startDateEnd,
                                 @QueryParam("endDate") String endDateStart,
                                 @QueryParam("endDateEnd") String endDateEnd) {
    	long userId = user.id();
        if (startDateStart == null) {
            startDateStart = "";
        }
        if (startDateEnd == null) {
            startDateEnd = "";
        }
        if (endDateStart == null) {
            endDateStart = "";
        }
        if (endDateEnd == null) {
            endDateEnd = "";
        }
        try {
        	
            String url = String.format(beProperties.getRemoteP2pInvestmentsUrl(), userId, pageNum);
            Logger.info(this, String.format("The p2phost is [%s], the service is [%s]", p2pJerseyService.getHost().getHostURI(), url));
            ClientResponse tmp = p2pJerseyService.getInstance(url).withUser(String.valueOf(userId)).getResource()
                    .queryParam("statusType", statusType.name())
                    .queryParam("startDateStart", startDateStart)
                    .queryParam("startDateEnd", startDateEnd)
                    .queryParam("endDateStart", endDateStart)
                    .queryParam("endDateEnd", endDateEnd)
                    .get(ClientResponse.class);
            if(tmp.getStatus()!=200){
            	Logger.error(this, "p2p investments' status is [%s]:----------" + tmp.getStatus());
            	throw new WebApplicationException(Response.status(tmp.getStatus()).entity("获取p2p收款记录失败").build());
            }
            String result = tmp.getEntity(String.class);
            Logger.info(this, "p2p investments:+++++++++++++++++++" + result);
            return result;
        } catch (UniformInterfaceException e) {
            Logger.error(this, String.format("The exception is [%s]", e));
            return "{\"totalPage\":0,\"prePage\":0,\"nextPage\":0,\"currentPage\":0,\"totalCount\":0,\"data\":[]}";
        }

    }

    @GET
    @Path("/investment-history/{pageNum}")
    @Produces(value = MediaType.APPLICATION_JSON)
    public String getInvestments(@PathParam("pageNum") int pageNum,
                                 @QueryParam("statusType") TradingStatus.Type statusType,
                                 @QueryParam("startDate") String startDate,
                                 @QueryParam("endDate") String endDate) {
    	long userId = user.id();
        if (startDate == null) {
            startDate = "";
        }
        if (endDate == null) {
            endDate = "";
        }
        try {
            String url = String.format(beProperties.getRemoteP2pInvestmentHistoryUrl(), userId, pageNum);
            Logger.info(this, String.format("The p2phost is [%s], the service is [%s]", p2pJerseyService.getHost().getHostURI(), url));
            ClientResponse tmp = p2pJerseyService.getInstance(url).withUser(String.valueOf(userId)).getResource()
                    .queryParam("statusType", statusType.name())
                    .queryParam("startDate", startDate)
                    .queryParam("endDate", endDate)
                    .get(ClientResponse.class);
            if(tmp.getStatus()!=200){
            	Logger.error(this, "p2p investment-history' status is [%s]:----------" + tmp.getStatus());
            	throw new WebApplicationException(Response.status(tmp.getStatus()).entity("获取p2p收款记录失败").build());
            }
            String result = tmp.getEntity(String.class);
            Logger.info(this, "p2p investment-history:+++++++++++++++++++" + result);
            return result;
        } catch (UniformInterfaceException e) {
            Logger.error(this, String.format("The exception is [%s]", e));
            return "{\"totalPage\":0,\"prePage\":0,\"nextPage\":0,\"currentPage\":0,\"totalCount\":0,\"data\":[]}";
        }
    }

    @GET
    @Path("/investment-requests/{pageNum}")
    @Produces(value = MediaType.APPLICATION_JSON)
    public String userInvestmentRequests(@PathParam("pageNum") int pageNum,
                                         @QueryParam("startDate") String startDate,
                                         @QueryParam("endDate") String endDate,
                                         @QueryParam("status1") String status1,
                                         @QueryParam("status2") String status2,
                                         @QueryParam("status3") String status3,
                                         @QueryParam("status4") String status4
    ) {
    	long userId = user.id();
        if (startDate == null) {
            startDate = "";
        }
        if (endDate == null) {
            endDate = "";
        }
        if (status1 == null) {
            status1 = "";
        }
        if (status2 == null) {
            status2 = "";
        }
        if (status3 == null) {
            status3 = "";
        }
        if (status4 == null) {
            status4 = "";
        }
        try {
            String url = String.format(beProperties.getRemoteP2pInvestRequestUrl(), userId, pageNum);
            Logger.info(this, String.format("The p2phost is [%s], the service is [%s]", p2pJerseyService.getHost().getHostURI(), url));
            ClientResponse temp = p2pJerseyService.getInstance(url).withUser(String.valueOf(userId)).getResource()
                    .queryParam("startDate", startDate)
                    .queryParam("endDate", endDate)
                    .queryParam("status1", status1)
                    .queryParam("status2", status2)
                    .queryParam("status3", status3)
                    .queryParam("status4", status4)
                    .get(ClientResponse.class);
            if(temp.getStatus()!=200){
            	Logger.error(this, "p2p investment-requests' status is [%s]:----------" + temp.getStatus());
            	throw new WebApplicationException(Response.status(temp.getStatus()).entity("获取p2p投资请求记录失败").build());
            }
            String result = temp.getEntity(String.class);
            Logger.info(this, "p2p investment-requests:+++++++++++++++++++" + result);
            return result;
        } catch (UniformInterfaceException e) {
            Logger.error(this, String.format("The exception is [%s]", e));
            return "{\"totalPage\":0,\"prePage\":0,\"nextPage\":0,\"currentPage\":0,\"totalCount\":0,\"data\":[]}";
        }
    }

    @GET
    @Path("/investments/collection-history/{investmentId}")
    @Produces(value = MediaType.APPLICATION_JSON)
    public String getCollectionHistories(@PathParam("investmentId") String investmentId) {
    	long userId = user.id();
        try {
            String url = String.format(beProperties.getRemoteP2pCollectionHistoryUrl(), userId, investmentId);
            Logger.info(this, String.format("The p2phost is [%s], the service is [%s]", p2pJerseyService.getHost().getHostURI(), url));
            ClientResponse tmp = p2pJerseyService.getInstance(url).withUser(String.valueOf(userId)).getResource().get(ClientResponse.class);
            if(tmp.getStatus()!=200){
            	Logger.error(this, "p2p collection-history' status is [%s]:----------" + tmp.getStatus());
            	throw new WebApplicationException(Response.status(tmp.getStatus()).entity("获取p2p货款历史记录失败").build());
            }
            String result = tmp.getEntity(String.class);
            Logger.info(this, "p2p collection history detail:++++++++++++++" + result);
            return result;
        } catch (Exception e) {
            Logger.error(this, String.format("The exception is [%s]", e));
            return "{\"data\":[]}";
        }
    }

    @GET
    @Path("/investments/collection-details/{investmentId}")
    @Produces(value = MediaType.APPLICATION_JSON)
    public String getCollectionDetails(@PathParam("investmentId") String investmentId) {
    	long userId = user.id();
        try {
            String url = String.format(beProperties.getRemoteP2pCollectionDetailsUrl(), userId, investmentId);
            Logger.info(this, String.format("The p2phost is [%s], the service is [%s]", p2pJerseyService.getHost().getHostURI(), url));
            ClientResponse tmp = p2pJerseyService.getInstance(url).withUser(String.valueOf(userId)).getResource().get(ClientResponse.class);
            if(tmp.getStatus()!=200){
            	Logger.error(this, "p2p collection-history' status is [%s]:----------" + tmp.getStatus());
            	throw new WebApplicationException(Response.status(tmp.getStatus()).entity("获取p2p货款历史详细记录失败").build());
            }
            String result = tmp.getEntity(String.class);
            Logger.info(this, "p2p collection details:+++++++++++++++++++" + result);
            return result;
        } catch (Exception e) {
            Logger.error(this, String.format("The exception is [%s]", e));
            return "{\"data\":[]}";
        }
    }

    @GET
    @Path("/investments/pdf")
    public Response getSmePdf(@QueryParam("pdfUrl") String pdfUrl) {
    	long userId = user.id();
        if (StringUtils.isEmpty(pdfUrl)) {
            throw new WebApplicationException(Response.status(Response.Status.NOT_FOUND).entity("请求失败").build());
        }
        ClientResponse clientResponse = null;
        try {
            clientResponse = p2pJerseyService.getInstance(pdfUrl + "/download").withUser(String.valueOf(userId)).getResource().get(ClientResponse.class);
            if (clientResponse.getStatus() == 200) {
                return Response.ok().entity(clientResponse.getEntityInputStream()).header("Content-Disposition", String.format("inline; filename=%s", new Date().getTime()+".pdf")).header("Extension", "pdf").build();
            }
            return Response.status(Response.Status.BAD_REQUEST).entity("系统繁忙").build();
        } catch (Exception e) {
            throw new WebApplicationException(Response.status(Response.Status.BAD_REQUEST).entity("系统繁忙").build());
        }
    }**/

}
