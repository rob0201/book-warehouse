package com.lufax.customerService.resources;

import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import com.google.gson.stream.MalformedJsonException;
import com.lufax.common.domain.CollectionDetail;
import com.lufax.common.domain.CollectionPlan;
import com.lufax.common.utils.DevLog;

import com.lufax.customerService.domain.AvayaPhoneHistory;
import com.lufax.customerService.domain.repository.AvayaPhoneHistoryRepository;
import com.lufax.jersey.usercontext.UserContext;
import com.lufax.jersey.usercontext.UserContextUtils;
import com.sun.jersey.api.core.InjectParam;
import org.apache.commons.lang.StringUtils;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: caoyanfei079
 * Date: 12-10-17
 * Time: 下午8:12
 * To change this template use File | Settings | File Templates.
 */
@Path("/avaya/history")
public class AvayaPhoneHistoryResource {
    @InjectParam
    private AvayaPhoneHistoryRepository avayaPhoneHistoryRepository;

    @GET
    @Path("add")
    public Response getCollectionDetails(@QueryParam("avayaMessage") String avayaMessage) {
        try{
            AvayaPhoneHistory aph = new Gson().fromJson(avayaMessage, AvayaPhoneHistory.class);
            aph.setId(null);
            aph.setFcd(new Date());
            UserContext uc = UserContextUtils.getCurrentUserContext();
            if (uc!= null  && !StringUtils.isEmpty(uc.getUserId())) {
                aph.setFcu(uc.getUserId());
            } else {
                aph.setFcu("system");
            }

            DevLog.debug(this,"The aph string is [" + avayaMessage + "] the aph is [" + aph + "]");
            avayaPhoneHistoryRepository.persist(aph);
        }catch (JsonSyntaxException e) {
            DevLog.info(this, "The data [" + avayaMessage + "] is not right format, ignore it");
        }
        DevLog.debug(this,"The aph success");

        return Response.ok().entity("success").build();
    }
    public static void main(String[] args) {
        try{
            String avayaMessage = "{clientNo:}";
            new Gson().fromJson(avayaMessage, AvayaPhoneHistory.class);
        }catch (JsonSyntaxException e) {
            System.out.println(e);
        }
    }
}
