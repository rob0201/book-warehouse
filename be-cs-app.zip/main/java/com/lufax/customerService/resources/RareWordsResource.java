package com.lufax.customerService.resources;


import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.google.gson.Gson;
import com.lufax.common.metadata.User;
import com.lufax.common.resources.ServiceProvider;
import com.lufax.common.resources.gsonTemplate.PaginationGson;
import com.lufax.common.resources.providers.AbstractExcelStreamingOutProvider;
import com.lufax.common.resources.providers.HtmlExcelStreamingOutProvider;
import com.lufax.common.web.filter.UsersContextFilter;
import com.lufax.common.web.helper.ConstantsHelper;
import com.lufax.customerService.domain.RareWords;
import com.lufax.customerService.resources.gsonTemplate.RareWordsGson;
import com.lufax.customerService.service.RareWordsService;
import com.lufax.jersey.usercontext.UserContextUtils;


public class RareWordsResource {

    private RareWordsService rareWordsService;

    public RareWordsResource(ServiceProvider serviceProvider) {
        this.rareWordsService = serviceProvider.getRareWordsService();
    }


    @GET
    @Path("/pages/{pageNum}")
    @Produces(value = MediaType.APPLICATION_JSON)
    public String getAllRareWords(@PathParam("pageNum") int pageNum) {
        long totalCount = rareWordsService.countOfRareWords();
        PaginationGson paginationGson = new PaginationGson(ConstantsHelper.PAGE_LIMIT, totalCount, pageNum);
        if (totalCount > 0) {
            List<RareWords> rareWordses = rareWordsService.findAllRareWords(ConstantsHelper.PAGE_LIMIT, (paginationGson.getCurrentPage() - 1) * ConstantsHelper.PAGE_LIMIT);
            paginationGson.setData(extractGson(rareWordses));
        }
        String result = new Gson().toJson(paginationGson);
        return result;
    }

    @GET
    @Path("/update")
    public Response updateRareWords(@QueryParam("isAvailable") boolean isAvailable, @QueryParam("id") Long id) {

    	Date updatedAt = new Date();
        User operator = (User) UserContextUtils.getUserParameter(UsersContextFilter.USER_KEY);
        String updatedBy =operator.getName();
        RareWords rareWords = rareWordsService.load(id);
        rareWords.setAvailable(isAvailable);
        rareWords.setUpdatedAt(updatedAt);
        rareWords.setUpdatedBy(updatedBy);
        rareWordsService.update(rareWords);
        
        return Response.status(Response.Status.OK).build();
    }

    @GET
    @Path("/delete")
    public Response deleteRareWords(@QueryParam("id") Long id) {
        RareWords rareWords = rareWordsService.load(id);
        rareWordsService.remove(rareWords);
        return Response.status(Response.Status.OK).build();
    }

    @GET
    @Produces(value = MediaType.APPLICATION_OCTET_STREAM)
    public Response downloadExcel() {
        String[] headerName = new String[]{
                ConstantsHelper.RARE_WORDS_EXCEL_ID,
                ConstantsHelper.RARE_WORDS_EXCEL_WORDS,
                ConstantsHelper.RARE_WORDS_EXCEL_CREATED_BY,
                ConstantsHelper.RARE_WORDS_EXCEL_CREATED_AT,
                ConstantsHelper.RARE_WORDS_EXCEL_UPDATED_BY,
                ConstantsHelper.RARE_WORDS_EXCEL_UPDATED_AT,
                ConstantsHelper.RARE_WORDS_EXCEL_IS_AVAILABLE,
        };
        String[] headKey = headerName;
        List data = new ArrayList<Map>();
        List<RareWords> rareWordses = rareWordsService.findAllRareWords();
        AbstractExcelStreamingOutProvider excelStreamingOutProvider = new HtmlExcelStreamingOutProvider(null, headerName, headKey);
        excelStreamingOutProvider.generateFileDataWithMap(extractRareWordsToExcel(rareWordses, headKey));
        return Response.ok(excelStreamingOutProvider).header("Content-Disposition", "attachment; filename=" + ConstantsHelper.RARE_WORDS_EXCEL_NAME + ".xls").build();


    }

    private List<RareWordsGson> extractGson(List<RareWords> rareWordses) {
        List<RareWordsGson> rareWordsGsons = new ArrayList<RareWordsGson>();
        for (RareWords rareWords : rareWordses) {
            rareWordsGsons.add(new RareWordsGson(rareWords));
        }
        return rareWordsGsons;
    }

    private List<Map> extractRareWordsToExcel(List<RareWords> rareWordses, String[] keys) {
        List<Map> result = new ArrayList<Map>();
        for (RareWords rareWords : rareWordses) {
            Map map = new HashMap();
            map.put(keys[0], rareWords.id());
            map.put(keys[1], rareWords.getWord());
            map.put(keys[2], rareWords.getCreatedBy());
            map.put(keys[3], rareWords.getCreatedAt());
            map.put(keys[4], rareWords.getUpdatedBy());
            map.put(keys[5], rareWords.getUpdatedAt());
            map.put(keys[6], rareWords.isAvailable());
            result.add(map);
        }
        return result;
    }


}
