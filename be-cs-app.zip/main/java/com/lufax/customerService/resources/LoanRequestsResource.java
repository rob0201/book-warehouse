package com.lufax.customerService.resources;

import static org.apache.commons.collections.CollectionUtils.isNotEmpty;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.GET;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.apache.commons.lang.StringUtils;

import com.google.gson.Gson;
import com.lufax.common.domain.ASGuaranteedNote;
import com.lufax.common.domain.ASLoanRequest;
import com.lufax.common.domain.Loan;
import com.lufax.common.domain.LoanRequest;
import com.lufax.common.domain.User;
import com.lufax.common.domain.WithdrawRecord;
import com.lufax.common.domain.repository.ASGuaranteedNoteRepository;
import com.lufax.common.domain.repository.ASLoanRequestRepository;
import com.lufax.common.domain.repository.LoanRepository;
import com.lufax.common.domain.repository.LoanRequestRepository;
import com.lufax.common.resources.ServiceProvider;
import com.lufax.common.utils.DateUtils;
import com.lufax.common.utils.DevLog;
import com.lufax.customerService.resources.gsonTemplate.LoanRequestGson;

public class LoanRequestsResource {

    private User user;
    private LoanRequestRepository loanRequestRepository;
    private ASLoanRequestRepository asloanRequestRepository;
    private ASGuaranteedNoteRepository asGuaranteedNoteRepository;
    private LoanRepository loanRepository;
    

    public LoanRequestsResource(User user, ServiceProvider serviceProvider) {
        this.user = user;
        this.loanRequestRepository = serviceProvider.getLoanRequestRepository();
        this.asloanRequestRepository = serviceProvider.getAsLoanRequestRepository();
        this.loanRepository = serviceProvider.getLoanRepository();
        this.asGuaranteedNoteRepository = serviceProvider.getAsGuaranteedNoteRepository();
    }

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public String getLoanRequestsByUserId() {
    	// get the loanRequest from xin bao
        List<LoanRequest> loanRequests = loanRequestRepository.findAllForLoanee(user);
        List<LoanRequestGson> result =  extractGson(loanRequests);
        // get the loanrequest from anshuo
        List<ASLoanRequest> asLoanRequest = asloanRequestRepository.findAllForLoanee(user);
        result.addAll(extractGsonByAs(asLoanRequest));
        // sort
        Collections.sort(result, new LoanRequestGsonComparator());
        return new Gson().toJson(result);
    }

    private List<LoanRequestGson> extractGson(List<LoanRequest> loanRequests) {
        List<LoanRequestGson> loanRequestGsons = new ArrayList<LoanRequestGson>();
        for (LoanRequest loanRequest : loanRequests) {
            WithdrawRecord withdrawRecord = null;
            if (loanRequest.isSuccess()) {
                Loan loan = loanRepository.findByLoanRequestCode(loanRequest.getCode());
                if (isNotEmpty(loan.getWithdrawRecords())) {
                    withdrawRecord = loan.getWithdrawRecords().get(0);
                }
            }
            LoanRequestGson loanRequestGson = LoanRequestGson.instanceOfCS(loanRequest, withdrawRecord);
            loanRequestGsons.add(loanRequestGson);
        }
        return loanRequestGsons;
    }
    private List<LoanRequestGson> extractGsonByAs(List<ASLoanRequest> asloanRequests) {
        List<LoanRequestGson> loanRequestGsons = new ArrayList<LoanRequestGson>();
        for (ASLoanRequest asloanRequest : asloanRequests) {
        	ASGuaranteedNote asGuaranteedNote = asGuaranteedNoteRepository.findByAsLoanRequestId(asloanRequest.getId());
        	DevLog.debug(this, "The resutl is [" + asGuaranteedNote + "]");
        	if(asGuaranteedNote == null) {
        		LoanRequestGson loanRequestGson = LoanRequestGson.instanceOfAS(asloanRequest, null, false);
                loanRequestGsons.add(loanRequestGson);
        	} else {
        		LoanRequestGson loanRequestGson = LoanRequestGson.instanceOfAS(asloanRequest, asGuaranteedNote.getTotalRepayAmount(), asGuaranteedNote.isBaiLinDai());
                loanRequestGsons.add(loanRequestGson);
        	}
            
        }
        return loanRequestGsons;
    }
    private static class LoanRequestGsonComparator implements Comparator<LoanRequestGson> {

		public int compare(LoanRequestGson o1, LoanRequestGson o2) {
			if(getOrder(o1.getStatus()) != getOrder(o2.getStatus())) {
				return getOrder(o1.getStatus()) - getOrder(o2.getStatus());
			}
			if(o1 == null|| StringUtils.isEmpty(o1.getCreatedAt())) {
				return 1;
			}
			if(o2 == null ||StringUtils.isEmpty(o2.getCreatedAt())) {
				return -1;
			}
			SimpleDateFormat format = new SimpleDateFormat(DateUtils.DATE_TIME_FORMAT_DEFAULT);
			try {
				Date o1Date = format.parse(o1.getCreatedAt());
				Date o2Date = format.parse(o1.getCreatedAt());
				if(o1Date != null && o2Date != null) {
					if( o1Date.getTime() > o2Date.getTime()) {
						return 1;
					} else if ( o1Date.getTime() == o2Date.getTime()) {
						return 0;
					} else {
						return 1;
					}
				} else {
					return 1;
				}
			} catch (ParseException e) {
				DevLog.error(this, "Please check the date string : o1 [" + o1.getCreatedAt() + "] o2 [" + o2.getCreatedAt() + "]",e);
				return 1;
			}
			
			
		}
	    private int getOrder(String status){
	    	Map<String,Integer> order = new HashMap<String, Integer>();
	    	order.put( "待审核",0);
	    	order.put( "待投资",1);
	    	order.put( "失败(审核失败)",2);
	    	order.put( "投资完成",3);
	    	order.put( "成功",4);
	    	order.put( "失败(申请审核超时)",5);
	    	if(order.containsKey(status)) {
	    		return order.get(status);
	    	} else {
	    		return Integer.MAX_VALUE;
	    	}
	    }
    }

}
