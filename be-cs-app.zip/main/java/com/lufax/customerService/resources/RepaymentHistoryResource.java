package com.lufax.customerService.resources;

import com.google.gson.Gson;
import com.lufax.common.domain.Loan;
import com.lufax.common.domain.RepaymentDetail;
import com.lufax.common.domain.RepaymentPlan;
import com.lufax.common.domain.repository.BizParametersRepository;
import com.lufax.customerService.resources.gsonTemplate.RepaymentHistoryGson;
import org.apache.commons.collections.CollectionUtils;

import javax.ws.rs.GET;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import java.util.ArrayList;
import java.util.List;

public class RepaymentHistoryResource {
    private Loan loan;
    private BizParametersRepository bizParametersRepository;

    public RepaymentHistoryResource(Loan loan, BizParametersRepository bizParametersRepository) {
        this.loan = loan;
        this.bizParametersRepository = bizParametersRepository;
    }

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public String getRepaymentDetails() {
        List<RepaymentDetail> repaymentDetails = new ArrayList<RepaymentDetail>();
        for (RepaymentPlan repaymentPlan : loan.getRepaymentPlans()) {
            if (repaymentPlan.isSettled() && CollectionUtils.isNotEmpty(repaymentPlan.getSettledRecords())) {
                repaymentDetails.add(new RepaymentDetail(repaymentPlan));
            }
        }
        RepaymentHistoryGson repaymentHistoryGson = new RepaymentHistoryGson(repaymentDetails);
        return new Gson().toJson(repaymentHistoryGson);
    }
}
