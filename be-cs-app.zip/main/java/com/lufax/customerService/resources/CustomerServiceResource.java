package com.lufax.customerService.resources;

import com.lufax.common.resources.ServiceProvider;
import com.sun.jersey.api.core.InjectParam;

import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.Path;
import javax.ws.rs.core.Context;

@Path("customer-service")
public class CustomerServiceResource extends AuthenticatedRequiredRootResource {

    @InjectParam
    private ServiceProvider serviceProvider;
    @Context
    private HttpServletResponse response;

    @Path("/users")
    public CustomersResource users() {
        return new CustomersResource(currentUser(), serviceProvider, response);
    }
}
