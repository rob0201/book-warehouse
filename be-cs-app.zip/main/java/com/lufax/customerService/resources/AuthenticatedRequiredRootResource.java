package com.lufax.customerService.resources;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;

import com.lufax.common.domain.User;
import com.lufax.common.domain.repository.UserRepository;
import com.lufax.common.utils.DevLog;
import com.lufax.common.web.filter.UsersContextFilter;
import com.lufax.jersey.usercontext.UserContextUtils;
import com.sun.jersey.api.core.InjectParam;

public abstract class AuthenticatedRequiredRootResource {
	@Context
	protected HttpServletRequest servletRequest;

	@InjectParam
	private UserRepository userRepository;

	private User currentUser;

	protected User currentUser() {
		if (currentUser == null) {
			com.lufax.common.metadata.User beUser = (com.lufax.common.metadata.User) UserContextUtils.getUserParameter(UsersContextFilter.USER_KEY);
			if (beUser != null && beUser.getP2pUserId() != null) {
				currentUser = userRepository.load(new Long(beUser.getP2pUserId()));
			} else {
				DevLog.error(this, "Can't get the current user. It's authorized. current be user is  is [" + beUser + "]");
				throw new WebApplicationException(Response.Status.UNAUTHORIZED);
			}
		}
		return currentUser;
	}
	protected void setCurrentUser(User user) {
		currentUser = user;
	}
}
