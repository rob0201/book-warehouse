package com.lufax.customerService.resources;


import com.lufax.common.metadata.User;
import com.lufax.common.resources.ServiceProvider;
import com.lufax.common.utils.DevLog;
import com.lufax.common.web.filter.UsersContextFilter;
import com.lufax.jersey.usercontext.UserContextUtils;
import com.lufax.customerService.service.RareWordsService;
import com.sun.jersey.api.core.InjectParam;

import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.Response;

@Path("/customer-rare-words")
public class RareWordsesResource extends AuthenticatedRequiredRootResource {
    @InjectParam
    private ServiceProvider serviceProvider;
    @InjectParam
    private RareWordsService rareWordsService;

    @POST
    public Response generateRareWords(@FormParam("rareWords") String rareWords) {
        DevLog.debug(this, "start to generate rare words   :" + rareWords);
        if (rareWords == null || rareWords.length() == 0) {
            DevLog.debug(this, "there is no rare words :" + rareWords);
            return Response.status(Response.Status.NO_CONTENT).build();
        }
        User operator = (User) UserContextUtils.getUserParameter(UsersContextFilter.USER_KEY);
        String result = rareWordsService.generateRareWords(operator.getName(), rareWords);
        if("repeat".equals(result)){
        	return Response.status(Response.Status.CONFLICT).entity("生僻字已存在！").build();
        }
        return Response.status(Response.Status.OK).entity("生僻字保存成功！").build();
    }

    @Path("/rare-words-list")
    public RareWordsResource getAllRareWords() {
        return new RareWordsResource(serviceProvider);
    }

    @Path("/download-rare-words")
    public RareWordsResource downloadRareWords() {
        DevLog.info(this, "start to download rare words");
        return new RareWordsResource(serviceProvider);
    }

    @Path("/update-rare-words")
    public RareWordsResource updateRareWords() {
        return new RareWordsResource(serviceProvider);
    }

    @Path("/delete-rare-words")
    public RareWordsResource deleteRareWords() {
        return new RareWordsResource(serviceProvider);
    }

}
