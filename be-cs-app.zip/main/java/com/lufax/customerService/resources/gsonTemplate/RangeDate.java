package com.lufax.customerService.resources.gsonTemplate;

import java.util.Date;

public class RangeDate{
	private Date beginDate;
	private Date endDate;
	public Date getBeginDate() {
		return beginDate;
	}
	public void setBeginDate(Date beginDate) {
		this.beginDate = beginDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	@Override
	public String toString() {
		return "RangeDate [beginDate=" + beginDate + ", endDate=" + endDate
				+ "]";
	}
	
}
