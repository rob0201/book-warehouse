package com.lufax.customerService.resources.gsonTemplate;

import com.lufax.common.domain.CollectionDetail;
import com.lufax.common.domain.CollectionRecord;
import com.lufax.common.domain.PlanStatus;
import com.lufax.common.utils.DateUtils;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class CollectionDetailGson {
    private int recordNumber;
    private int recordSequence;
    private String payTime;
    private String endAt;
    private BigDecimal amount;
    private BigDecimal principal;
    private BigDecimal interest;
    private BigDecimal managementFee;
    private BigDecimal penalValue;
    private BigDecimal overduePenaltyToCollect;
    private boolean overdue;
    private String status;
    private boolean isRateChange;
    private BigDecimal interestRate;

    private BigDecimal collectedAmount;
    private BigDecimal collectedPrincipal;
    private BigDecimal collectedInterest;
    private BigDecimal paidManagementFee;
    private BigDecimal collectedOverduePenalty;
    private BigDecimal paidUpAmount;

    private BigDecimal remainingAmount;
    private BigDecimal remainingPrincipal;
    private BigDecimal remainingInterest;
    private BigDecimal remainingManagementFee;
    private BigDecimal remainingOverduePenalty;
	
	private List<CollectionRecordGson> collectionRecords = new ArrayList<CollectionRecordGson>();

    public CollectionDetailGson() {
    }
    public CollectionDetailGson(CollectionDetail collectionDetail) {
        this.recordNumber = collectionDetail.getPlanNumber();
        this.payTime = DateUtils.formatDate(collectionDetail.getPayTime());
        this.endAt = DateUtils.formatDate(collectionDetail.getEndAt());
        this.status = collectionDetail.getStatus().getValue();
        
        this.principal = collectionDetail.getPrincipal().getAmount();
        this.interest = collectionDetail.getInterest().getAmount();
//        this.managementFee = collectionDetail.getManagementFee().getAmount();
//        this.managementFee = collectionDetail.getPaidManagementFee().getAmount();
        
        if(PlanStatus.PAID.equals(collectionDetail.getStatus()) || PlanStatus.PREPAID.equals(collectionDetail.getStatus()) || PlanStatus.COMP_DONE.equals(collectionDetail.getStatus())) {
        	this.managementFee = collectionDetail.getPaidManagementFee().getAmount();
        } else {
        	this.managementFee = collectionDetail.getManagementFee().getAmount();
        }
        this.amount = collectionDetail.getAmount().getAmount().subtract(this.managementFee);
        
        this.penalValue = collectionDetail.getCollectedPenalValue().getAmount();
        this.overdue = collectionDetail.isOverdue();
        this.overduePenaltyToCollect = collectionDetail.getOverduePenaltyToCollect().getAmount();

        this.collectedAmount = collectionDetail.getCollectedAmount().getAmount().subtract(this.managementFee);
        this.collectedPrincipal = collectionDetail.getCollectedPrincipal().getAmount();
        this.collectedInterest = collectionDetail.getCollectedInterest().getAmount();
        this.paidManagementFee = collectionDetail.getPaidManagementFee().getAmount();
        this.collectedOverduePenalty = collectionDetail.getCollectedOverduePenalty().getAmount();
        this.paidUpAmount = collectionDetail.getNetIncome().getAmount();
        
        this.isRateChange = collectionDetail.isRateChange();
        this.interestRate = collectionDetail.getInterestRate();

        remainingAmount = collectionDetail.getRemainingAmount().getAmount();
        remainingPrincipal = collectionDetail.getRemainingPrincipal().getAmount();
        remainingInterest = collectionDetail.getRemainingInterest().getAmount();
        remainingManagementFee = collectionDetail.getRemainingManagementFee().getAmount();
        remainingOverduePenalty = collectionDetail.getRemainingOverduePenalty().getAmount();

        for (CollectionRecord collectionRecord : collectionDetail.getCollectionRecords()) {
            this.collectionRecords.add(new CollectionRecordGson(collectionRecord));
        }
    }

	public String getPayTime() {
        return payTime;
    }

    public String getEndAt() {
        return endAt;
    }

    public String getStatus() {
        return status;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public BigDecimal getPrincipal() {
        return principal;
    }

    public BigDecimal getInterest() {
        return interest;
    }

    public BigDecimal getManagementFee() {
        return managementFee;
    }

    public BigDecimal getPenalValue() {
        return penalValue;
    }

    public int getRecordNumber() {
        return recordNumber;
    }

    public BigDecimal getOverduePenaltyToCollect() {
		return overduePenaltyToCollect;
	}

	public boolean isOverdue() {
		return overdue;
	}

	public BigDecimal getCollectedAmount() {
		return collectedAmount;
	}

	public BigDecimal getCollectedPrincipal() {
		return collectedPrincipal;
	}

	public BigDecimal getCollectedInterest() {
		return collectedInterest;
	}

	public BigDecimal getPaidManagementFee() {
		return paidManagementFee;
	}

	public BigDecimal getCollectedOverduePenalty() {
		return collectedOverduePenalty;
	}

	public BigDecimal getPaidUpAmount() {
		return paidUpAmount;
	}

	public BigDecimal getRemainingAmount() {
		return remainingAmount;
	}

	public BigDecimal getRemainingPrincipal() {
		return remainingPrincipal;
	}

	public BigDecimal getRemainingInterest() {
		return remainingInterest;
	}

	public BigDecimal getRemainingManagementFee() {
		return remainingManagementFee;
	}

	public BigDecimal getRemainingOverduePenalty() {
		return remainingOverduePenalty;
	}

	public List<CollectionRecordGson> getCollectionRecords() {
		return collectionRecords;
	}

	@Override
    public boolean equals(Object o) {
        return EqualsBuilder.reflectionEquals(this, o);
    }

    @Override
    public int hashCode() {
        return HashCodeBuilder.reflectionHashCode(this);
    }

	public boolean isRateChange() {
		return isRateChange;
	}

	public int getRecordSequence() {
		return recordSequence;
	}

	public void setRecordSequence(int recordSequence) {
		this.recordSequence = recordSequence;
	}

	public BigDecimal getInterestRate() {
		return interestRate;
	}
	public void setRecordNumber(int recordNumber) {
		this.recordNumber = recordNumber;
	}
	public void setPayTime(String payTime) {
		this.payTime = payTime;
	}
	public void setEndAt(String endAt) {
		this.endAt = endAt;
	}
	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}
	public void setPrincipal(BigDecimal principal) {
		this.principal = principal;
	}
	public void setInterest(BigDecimal interest) {
		this.interest = interest;
	}
	public void setManagementFee(BigDecimal managementFee) {
		this.managementFee = managementFee;
	}
	public void setPenalValue(BigDecimal penalValue) {
		this.penalValue = penalValue;
	}
	public void setOverduePenaltyToCollect(BigDecimal overduePenaltyToCollect) {
		this.overduePenaltyToCollect = overduePenaltyToCollect;
	}
	public void setOverdue(boolean overdue) {
		this.overdue = overdue;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public void setRateChange(boolean isRateChange) {
		this.isRateChange = isRateChange;
	}
	public void setInterestRate(BigDecimal interestRate) {
		this.interestRate = interestRate;
	}
	public void setCollectedAmount(BigDecimal collectedAmount) {
		this.collectedAmount = collectedAmount;
	}
	public void setCollectedPrincipal(BigDecimal collectedPrincipal) {
		this.collectedPrincipal = collectedPrincipal;
	}
	public void setCollectedInterest(BigDecimal collectedInterest) {
		this.collectedInterest = collectedInterest;
	}
	public void setPaidManagementFee(BigDecimal paidManagementFee) {
		this.paidManagementFee = paidManagementFee;
	}
	public void setCollectedOverduePenalty(BigDecimal collectedOverduePenalty) {
		this.collectedOverduePenalty = collectedOverduePenalty;
	}
	public void setPaidUpAmount(BigDecimal paidUpAmount) {
		this.paidUpAmount = paidUpAmount;
	}
	public void setRemainingAmount(BigDecimal remainingAmount) {
		this.remainingAmount = remainingAmount;
	}
	public void setRemainingPrincipal(BigDecimal remainingPrincipal) {
		this.remainingPrincipal = remainingPrincipal;
	}
	public void setRemainingInterest(BigDecimal remainingInterest) {
		this.remainingInterest = remainingInterest;
	}
	public void setRemainingManagementFee(BigDecimal remainingManagementFee) {
		this.remainingManagementFee = remainingManagementFee;
	}
	public void setRemainingOverduePenalty(BigDecimal remainingOverduePenalty) {
		this.remainingOverduePenalty = remainingOverduePenalty;
	}
	public void setCollectionRecords(List<CollectionRecordGson> collectionRecords) {
		this.collectionRecords = collectionRecords;
	}
    
    
}
