package com.lufax.customerService.resources.gsonTemplate;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import com.lufax.common.utils.DateUtils;
import com.lufax.customerService.pojo.CollectionPlanStatus;
import com.lufax.customerService.pojo.SMECollectionPlan;
import com.lufax.customerService.pojo.SMECollectionRecord;

public class CustomerServiceSmeCollectionDetailGson {
	
	//期数
	private int recordNumber;
    //还款日
	private String payTime;
    //还款截至时间
	private String endAt;
    //还款金额
	private BigDecimal amount;
    //本金
	private BigDecimal principal;
	//利息
	private BigDecimal interest;
    //管理费
	private BigDecimal managementFee;
    //违约金
	private BigDecimal penalValue;
    //逾期罚金
	private BigDecimal overduePenaltyToCollect;
    //是否逾期
	private boolean overdue;
    //状态
	private String status;
	private String resourceStatus;
    //利率是否变动
	private boolean isRateChange;
    //利率
	private BigDecimal interestRate;
	//转让款
	private BigDecimal transferAmount;
	//已收金额
    private BigDecimal collectedAmount = BigDecimal.ZERO;
    //已收本金
    private BigDecimal collectedPrincipal = BigDecimal.ZERO;
    //已收利息
    private BigDecimal collectedInterest = BigDecimal.ZERO;
    //已付管理违约金
    private BigDecimal paidManagementFee = BigDecimal.ZERO;
    //已收逾期管理违约金
    private BigDecimal collectedOverduePenalty = BigDecimal.ZERO;
    //已收提前还款违约金
    private BigDecimal collectedPenalValue = BigDecimal.ZERO;
    //
    private BigDecimal paidUpAmount = BigDecimal.ZERO;
	//转让款
	private BigDecimal paidtransferAmount = BigDecimal.ZERO;
    //未付金额
    private BigDecimal remainingAmount = BigDecimal.ZERO;
    //未付本金
    private BigDecimal remainingPrincipal = BigDecimal.ZERO;
    //未付利息
    private BigDecimal remainingInterest = BigDecimal.ZERO;
    //未付管理费
    private BigDecimal remainingManagementFee = BigDecimal.ZERO;
    //未付逾期违约金
    private BigDecimal remainingOverduePenalty = BigDecimal.ZERO;
    //已收收款记录
    private List<CustomerServiceSmeCollectionRecordGson> collectionRecords = new ArrayList<CustomerServiceSmeCollectionRecordGson>();
    
	public CustomerServiceSmeCollectionDetailGson(SMECollectionPlan collectionPlan) {
		this.recordNumber = collectionPlan.getPlanNumber();
		this.payTime = DateUtils.formatDate(collectionPlan.getLastCollectDate());
		this.amount = collectionPlan.getAmount().getAmount();
		this.principal = collectionPlan.getPrincipal().getAmount();
		this.interest = collectionPlan.getInterest().getAmount();
		this.managementFee = BigDecimal.ZERO;
		this.penalValue = collectionPlan.getAdvancedRepayPenalty()==null?BigDecimal.ZERO:collectionPlan.getAdvancedRepayPenalty().getAmount();
		this.overduePenaltyToCollect = collectionPlan.getManagePenaltyPunishInterest()==null?BigDecimal.ZERO:collectionPlan.getManagePenaltyPunishInterest().getAmount();
		this.status = convertStatus(collectionPlan.getStatus());
		this.resourceStatus = collectionPlan.getStatus().name();
		this.transferAmount = collectionPlan.getTransferFund().getAmount();
		
		List<SMECollectionRecord> collectionRecordList = collectionPlan.getCollectionRecords();
		if(collectionRecordList != null){
			for(SMECollectionRecord collectionRecord : collectionRecordList){
				CustomerServiceSmeCollectionRecordGson customerServiceSmeCollectionRecordGson = new CustomerServiceSmeCollectionRecordGson(collectionRecord); 
				collectionRecords.add(customerServiceSmeCollectionRecordGson);
				this.collectedAmount = this.collectedAmount.add(customerServiceSmeCollectionRecordGson.getAmount());
				this.collectedPrincipal = this.collectedPrincipal.add(customerServiceSmeCollectionRecordGson.getPrincipal());
				this.collectedInterest = this.collectedInterest.add(customerServiceSmeCollectionRecordGson.getInterest());
				this.collectedPenalValue = this.collectedPenalValue.add(customerServiceSmeCollectionRecordGson.getPenalValue());
				this.collectedOverduePenalty = this.collectedOverduePenalty.add(customerServiceSmeCollectionRecordGson.getOverduePenalValue());
				this.paidManagementFee = this.paidManagementFee.add(customerServiceSmeCollectionRecordGson.getManagementFee());
				this.paidtransferAmount = this.paidtransferAmount.add(customerServiceSmeCollectionRecordGson.getTransferAmount());
			}
			
		}
		this.remainingAmount = this.amount.subtract(this.collectedAmount);
		this.remainingPrincipal = this.principal.subtract(this.collectedPrincipal);
		this.remainingInterest = this.interest.subtract(this.collectedInterest);
		this.remainingOverduePenalty = this.overduePenaltyToCollect.subtract(this.collectedOverduePenalty);
	}


	private String convertStatus(CollectionPlanStatus status) {
		return status.getValue();
	}

	public int getRecordNumber() {
		return recordNumber;
	}

	public String getPayTime() {
		return payTime;
	}

	public String getEndAt() {
		return endAt;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public BigDecimal getPrincipal() {
		return principal;
	}

	public BigDecimal getInterest() {
		return interest;
	}

	public BigDecimal getManagementFee() {
		return managementFee;
	}

	public BigDecimal getPenalValue() {
		return penalValue;
	}

	public BigDecimal getOverduePenaltyToCollect() {
		return overduePenaltyToCollect;
	}

	public boolean isOverdue() {
		return overdue;
	}

	public String getStatus() {
		return status;
	}

	public boolean isRateChange() {
		return isRateChange;
	}

	public BigDecimal getInterestRate() {
		return interestRate;
	}

	public BigDecimal getCollectedAmount() {
		return collectedAmount;
	}

	public BigDecimal getCollectedPrincipal() {
		return collectedPrincipal;
	}

	public BigDecimal getCollectedInterest() {
		return collectedInterest;
	}

	public BigDecimal getPaidManagementFee() {
		return paidManagementFee;
	}

	public BigDecimal getCollectedOverduePenalty() {
		return collectedOverduePenalty;
	}

	public BigDecimal getPaidUpAmount() {
		return paidUpAmount;
	}

	public BigDecimal getRemainingAmount() {
		return remainingAmount;
	}

	public BigDecimal getRemainingPrincipal() {
		return remainingPrincipal;
	}

	public BigDecimal getRemainingInterest() {
		return remainingInterest;
	}

	public BigDecimal getRemainingManagementFee() {
		return remainingManagementFee;
	}

	public BigDecimal getRemainingOverduePenalty() {
		return remainingOverduePenalty;
	}

	public List<CustomerServiceSmeCollectionRecordGson> getCollectionRecords() {
		return collectionRecords;
	}

	public BigDecimal getCollectedPenalValue() {
		return collectedPenalValue;
	}

	public BigDecimal getTransferAmount() {
		return transferAmount;
	}

	public BigDecimal getPaidtransferAmount() {
		return paidtransferAmount;
	}


	public String getResourceStatus() {
		return resourceStatus;
	}
	
}
