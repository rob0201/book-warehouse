package com.lufax.customerService.resources.gsonTemplate;

import com.lufax.common.domain.RepaymentRecord;
import com.lufax.common.utils.DateUtils;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

import java.math.BigDecimal;

public class RepaymentRecordGson {
    private int planNumber;
    private String payTime;
    private BigDecimal amount;
    private BigDecimal principal;
    private BigDecimal interest;
    private BigDecimal managementFee;
    private BigDecimal insuranceFee;
    private BigDecimal penalValue;
    private BigDecimal overduePenalValue;


    public RepaymentRecordGson(RepaymentRecord repaymentRecord) {
        this.planNumber = repaymentRecord.getRecordNumber();
        this.payTime = DateUtils.formatDate(repaymentRecord.getUpdatedAt());
        this.amount = repaymentRecord.getAmount().getAmount();
        this.principal = repaymentRecord.getPrincipal().getAmount();
        this.interest = repaymentRecord.getInterest().getAmount();
        this.managementFee = repaymentRecord.getManagementFee().getAmount();
        this.insuranceFee = repaymentRecord.getInsuranceFee().getAmount();
        this.penalValue = repaymentRecord.getPenalValue().getAmount();
        this.overduePenalValue = repaymentRecord.getOverduePenalValue().getAmount();
    }

    @Override
    public boolean equals(Object o) {
        return EqualsBuilder.reflectionEquals(this, o);
    }

    @Override
    public int hashCode() {
        return HashCodeBuilder.reflectionHashCode(this);
    }

    public BigDecimal getPenalValue() {
        return penalValue;
    }
}
