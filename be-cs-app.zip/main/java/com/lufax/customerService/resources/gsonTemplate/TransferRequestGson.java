package com.lufax.customerService.resources.gsonTemplate;

import java.util.Date;

import com.lufax.common.domain.product.TransferRequest;
import com.lufax.common.domain.product.TransferRequestStatus;

public class TransferRequestGson {
	    private long id;
	    private long investmentId;
	    private long transferUserId;
	    private TransferRequestStatus transferRequestStatus;
	    private Boolean scanFlag;
	    private String remark;
	    private Date createdAt;
	    private String code;
	    private Date updatedAt;
	public TransferRequestGson(TransferRequest transferRequest){
		this.id = transferRequest.id();
		this.investmentId = transferRequest.getInvestment().getId();
		this.transferUserId = transferRequest.getTransferUserId();
		this.transferRequestStatus = transferRequest.getStatus();
		this.scanFlag = transferRequest.getScanFlag();
		this.remark = transferRequest.getRemark();
		this.createdAt = transferRequest.getCreatedAt();
		this.updatedAt = transferRequest.getUpdatedAt();
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public long getInvestmentId() {
		return investmentId;
	}
	public void setInvestmentId(long investmentId) {
		this.investmentId = investmentId;
	}
	public long getTransferUserId() {
		return transferUserId;
	}
	public void setTransferUserId(long transferUserId) {
		this.transferUserId = transferUserId;
	}
	public TransferRequestStatus getTransferRequestStatus() {
		return transferRequestStatus;
	}
	public void setTransferRequestStatus(TransferRequestStatus transferRequestStatus) {
		this.transferRequestStatus = transferRequestStatus;
	}
	public Boolean getScanFlag() {
		return scanFlag;
	}
	public void setScanFlag(Boolean scanFlag) {
		this.scanFlag = scanFlag;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public Date getCreatedAt() {
		return createdAt;
	}
	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public Date getUpdatedAt() {
		return updatedAt;
	}
	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}
	
}
