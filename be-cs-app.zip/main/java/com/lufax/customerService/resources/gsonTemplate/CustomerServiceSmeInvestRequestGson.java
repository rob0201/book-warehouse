package com.lufax.customerService.resources.gsonTemplate;

import java.math.BigDecimal;

import com.lufax.common.utils.DateUtils;
import com.lufax.common.utils.ProductUtils;
import com.lufax.customerService.pojo.BuyRequestPool;
import com.lufax.customerService.pojo.BuyRequestStatus;
import com.lufax.customerService.pojo.ExtProductSME;

public class CustomerServiceSmeInvestRequestGson {
	//贷款请求号
	private String loanRequestCode;
    //贷款金额
	private BigDecimal loanRequestAmount;
    //利率
	private BigDecimal interestRate;
    //期限
	private String numberOfInstalments;
    //投资请求日期
	private String investmentRequestDate;
    //状态
	private String status;
    //贷款号
	private String loanCode;
    //状态的值
	private String statusDescription;
    //产品名称
    private String productName ;
    //产品Id
    private long productId ;
    
	public CustomerServiceSmeInvestRequestGson(BuyRequestPool buyRequestPool,ExtProductSME product, int numberOfInstalments) {
		this.loanRequestAmount = buyRequestPool.getActualShares()==BigDecimal.ZERO?buyRequestPool.getTargetShares().multiply(buyRequestPool.getTargetPrice()):buyRequestPool.getActualShares().multiply(buyRequestPool.getTargetPrice());
		this.interestRate = product.getInterestRateYear();
		this.numberOfInstalments = ProductUtils.resolveCountOfInstalments(product);
		this.investmentRequestDate = DateUtils.formatDate(buyRequestPool.getCreateAt());
		this.status = buyRequestPool.getStatus().name();
		this.productName = product.getName();
		this.productId = product.getId();
		//TODO:
		this.loanRequestCode = null;
		this.loanCode = null;
		this.statusDescription = buyRequestPool.getStatus()==null?"未知":buyRequestPool.getStatus().getValue();
	}

	private String convertStatus(BuyRequestStatus status) {
		return status.getValue();
	}

	public String getLoanRequestCode() {
		return loanRequestCode;
	}

	public BigDecimal getLoanRequestAmount() {
		return loanRequestAmount;
	}

	public BigDecimal getInterestRate() {
		return interestRate;
	}

	public String getNumberOfInstalments() {
		return numberOfInstalments;
	}

	public String getInvestmentRequestDate() {
		return investmentRequestDate;
	}

	public String getStatus() {
		return status;
	}

	public String getLoanCode() {
		return loanCode;
	}

	public String getStatusDescription() {
		return statusDescription;
	}

	public String getProductName() {
		return productName;
	}

	public long getProductId() {
		return productId;
	}
	
}
