package com.lufax.customerService.resources.gsonTemplate;

import java.math.BigDecimal;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

import com.lufax.common.domain.Investment;
import com.lufax.common.domain.product.Product;
import com.lufax.common.utils.DateUtils;

public class CustomerServiceInvestmentHistoryGson {
	private long id;
    private long productId;
    private String productName;
    private String productCode;
    private BigDecimal principal;
    private BigDecimal totalCollectedAmount;
    private int countOfInstalments;

    private String investmentApplyDate;
    private String startAt;
    private String scheduledEndedAt;

    private boolean overdue;
    private boolean compensate;
    private boolean compensateDone;
    private String transferRequestStatus;
    private boolean isSecondaryMarketOpen;

    public CustomerServiceInvestmentHistoryGson(Investment investment, boolean isSecondaryMarketOpen) {
        Product product = investment.getProduct();

        this.id = investment.id();
        this.productId = product.id();
        if("TIME_SPLIT".equals(investment.getProduct().getProductType())) {
        	this.productName = "稳盈-接利贷";
        } else {
        	this.productName = "稳盈-安e贷";
        }
        this.productCode = product.getProductCode();
        this.investmentApplyDate = DateUtils.formatDate(investment.getInvestmentRequest().getCreatedAt());

        if (product.isPrimary()) {
            this.startAt = DateUtils.formatDate(investment.getLoan().getStartAt());
        } else if (product.isSecondary()) {
            this.startAt = DateUtils.formatDate(investment.getCreatedAt());
        }
        this.scheduledEndedAt = getEndAt(investment);
        this.principal = investment.getPrincipal().getAmount();
        this.totalCollectedAmount = getCollectedAmount(investment);
        this.countOfInstalments = investment.getRealNumberOfInstalments();
        this.transferRequestStatus = investment.getTransferRequestStatus().toString();
        this.overdue = investment.isOverdue();
        this.compensate = investment.isCompensate();
        this.compensateDone = investment.isCompensateDone();
        this.isSecondaryMarketOpen = isSecondaryMarketOpen;
    }

    private String getEndAt(Investment investment) {
        if (investment.isTransferred()) {
            return DateUtils.formatDate(investment.getLatestTransferRequest().getCreatedAt());
        } else {
            return DateUtils.formatDate(investment.getLoan().getEndedAt());
        }
    }

    private BigDecimal getCollectedAmount(Investment investment) {
        if (investment.isTransferred()) {
            return investment.getAllCollectedTotalNetAmount().add(investment.getTransferPriceDeductTransferFee()).getAmount();
        }
        return investment.getAllCollectedTotalNetAmount().getAmount();
    }

    public long getId() {
        return id;
    }


    public BigDecimal getPrincipal() {
        return principal;
    }

    public int getCountOfInstalments() {
        return countOfInstalments;
    }

    public String getScheduledEndedAt() {
        return scheduledEndedAt;
    }

    public String getProductCode() {
        return productCode;
    }

    public String getStartAt() {
        return startAt;
    }

    public String getInvestmentApplyDate() {
        return investmentApplyDate;
    }

    public boolean isCompensateDone() {
        return compensateDone;
    }

    public String getTransferRequestStatus() {
        return transferRequestStatus;
    }

    public boolean isCompensate() {
        return compensate;
    }

    @Override
    public boolean equals(Object o) {
        return EqualsBuilder.reflectionEquals(this, o);
    }

    @Override
    public int hashCode() {
        return HashCodeBuilder.reflectionHashCode(this);
    }

    public boolean isOverdue() {
        return overdue;
    }
}
