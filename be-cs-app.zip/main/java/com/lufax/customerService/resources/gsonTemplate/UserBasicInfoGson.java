package com.lufax.customerService.resources.gsonTemplate;


import com.lufax.common.domain.EmailVerifyStatus;
import com.lufax.common.domain.MemberCustomer;
import com.lufax.common.domain.RiskVerifyStatus;
import com.lufax.common.domain.User;
import com.lufax.common.utils.DateUtils;

import java.util.List;

public class UserBasicInfoGson {
    private long userId;
    private String name;
    private String userName;
    private String gender;
    private String type;
    private String number;
    private String birthDay;
    private String status;//实名认证
    private String url;
    private String mobileNo;
    private String email;
    private String bankAccount;
    private String sendSmsUrl;
    private String cardBindStatus;
    private String emailVerifyStatus;
    private String riskVerifyStatus;
    private List<UserBankAutoInfoGson> userBankAutoInfoGsons;


    public UserBasicInfoGson(User user,MemberCustomer memberCustomer,List<UserBankAutoInfoGson> userBankAutoInfoGsons) {
        this.userId = user.id();
//        this.userId = 1748291;
        this.userName = user.getUsername();
        if (null != user.getIdentity()) {
            this.name = user.getIdentity().getName();
            this.gender = user.getIdentity().getGender().getChineseDes();
            this.type = user.getIdentity().getIdentity().getType().getChineseDes();
            this.number = user.getIdentity().getIdentity().getNumber();
            this.birthDay = DateUtils.formatDateForXinbao(user.getIdentity().getBirthDay());
        }
        this.cardBindStatus=user.getCardBindStatus();
        this.status = user.getStatus().getValue();
        this.mobileNo = user.getMobileNo();
        this.email = user.getEmail();
        this.bankAccount = user.getBankIdentity() == null ? "" : user.getBankIdentity().getBankAccount();
        this.url = "/customerService/users/" + this.userId + "/basicInfo";
        this.sendSmsUrl = "service/customer-service/users/" + this.userId + "/sendUserName";
        if(EmailVerifyStatus.SUCCESS.getValue().equals(memberCustomer.getEmailVerifyStatus())){
            this.emailVerifyStatus="已验证";
        }
        else{
            this.emailVerifyStatus="未验证";
        }

        this.riskVerifyStatus=RiskVerifyStatus.getRiskVerifyStatus(memberCustomer.getRiskVerifyStatus()).getRiskVerifyStatusDesc();
        this.userBankAutoInfoGsons=userBankAutoInfoGsons;
    }

    public UserBasicInfoGson(User user) {
        this.userId = user.id();
//        this.userId = 1748291;
        this.userName = user.getUsername();
        if (null != user.getIdentity()) {
            this.name = user.getIdentity().getName();
            this.gender = user.getIdentity().getGender().getChineseDes();
            this.type = user.getIdentity().getIdentity().getType().getChineseDes();
            this.number = user.getIdentity().getIdentity().getNumber();
            this.birthDay = DateUtils.formatDateForXinbao(user.getIdentity().getBirthDay());
        }
        this.cardBindStatus=user.getCardBindStatus();
        this.status = user.getStatus().getValue();
        this.mobileNo = user.getMobileNo();
        this.email = user.getEmail();
        this.bankAccount = user.getBankIdentity() == null ? "" : user.getBankIdentity().getBankAccount();
        this.url = "/customerService/users/" + this.userId + "/basicInfo";
        this.sendSmsUrl = "service/customer-service/users/" + this.userId + "/sendUserName";
    }

    public String getName() {
        return name;
    }

    public String getUserName() {
        return userName;
    }

    public String getGender() {
        return gender;
    }

    public String getType() {
        return type;
    }

    public String getNumber() {
        return number;
    }

    public String getBirthDay() {
        return birthDay;
    }

    public String getStatus() {
        return status;
    }

    public String getMobileNo() {
        return this.mobileNo;
    }

    public String getEmail() {
        return email;
    }

    public String getBankAccount() {
        return bankAccount;
    }

    public String getSendSmsUrl() {
        return sendSmsUrl;
    }

    public void setSendSmsUrl(String sendSmsUrl) {
        this.sendSmsUrl = sendSmsUrl;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public String getCardBindStatus() {
        return cardBindStatus;
    }

    public void setCardBindStatus(String cardBindStatus) {
        this.cardBindStatus = cardBindStatus;
    }

    public String getEmailVerifyStatus() {
        return emailVerifyStatus;
    }

    public void setEmailVerifyStatus(String emailVerifyStatus) {
        this.emailVerifyStatus = emailVerifyStatus;
    }

    public String getRiskVerifyStatus() {
        return riskVerifyStatus;
    }

    public void setRiskVerifyStatus(String riskVerifyStatus) {
        this.riskVerifyStatus = riskVerifyStatus;
    }

    public List<UserBankAutoInfoGson> getUserBankAutoInfoGsons() {
        return userBankAutoInfoGsons;
    }

    public void setUserBankAutoInfoGsons(List<UserBankAutoInfoGson> userBankAutoInfoGsons) {
        this.userBankAutoInfoGsons = userBankAutoInfoGsons;
    }
}
