package com.lufax.customerService.resources.gsonTemplate;

import com.lufax.common.domain.Loan;
import com.lufax.common.domain.RepaymentDetail;
import com.lufax.common.domain.RepaymentPlan;

import java.util.ArrayList;
import java.util.List;

public class RepaymentDetailsGson {
    private List<RepaymentDetailGson> repaymentDetailsBeforeRecent = new ArrayList<RepaymentDetailGson>();
    private List<RepaymentDetailGson> recentRepaymentDetails = new ArrayList<RepaymentDetailGson>();
    private List<RepaymentDetailGson> repaymentDetailsAfterRecent = new ArrayList<RepaymentDetailGson>();
    private int payablePlanNumber = 0;

    public RepaymentDetailsGson(Loan loan) {
        for (RepaymentPlan plan : loan.getRepaymentPlans()) {
            if (plan.isOverdue() || plan.isProcessing()) {
                recentRepaymentDetails.add(new RepaymentDetailGson(new RepaymentDetail(plan)));
            }
        }

        RepaymentPlan currentRepaymentPlan = loan.getCurrentRepaymentPlan();
        if (currentRepaymentPlan != null) {
            putNormalRepaymentDetailTo(recentRepaymentDetails, loan, currentRepaymentPlan.getPlanNumber() - 1, currentRepaymentPlan.getPlanNumber() + 1);
        } else if (loan.getRepaymentPlan(1).isUnpaid()) {
            recentRepaymentDetails.add(new RepaymentDetailGson(new RepaymentDetail(loan.getRepaymentPlan(1))));
        }

        putNonRecentRepaymentDetails(loan);

        setPayablePlanNumber(loan, currentRepaymentPlan);
    }

    private void setPayablePlanNumber(Loan loan, RepaymentPlan currentRepaymentPlan) {
        if (currentRepaymentPlan != null && !currentRepaymentPlan.isSettled()) {
            payablePlanNumber = currentRepaymentPlan.getPlanNumber();

            RepaymentPlan previousPlan = loan.getRepaymentPlan(payablePlanNumber - 1);
            if (previousPlan != null && (previousPlan.isOverdue() || previousPlan.isProcessing()) && !currentRepaymentPlan.isDueToPay()) {
                payablePlanNumber = previousPlan.getPlanNumber();
            }
        }

        if (currentRepaymentPlan == null && !loan.getRepaymentPlan(1).isUnpaid()) {
            payablePlanNumber = loan.getNumberOfInstalments();
        }
    }

    private void putNonRecentRepaymentDetails(Loan loan) {
        if (recentRepaymentDetails.isEmpty()) return;
        int minPlanNumber = recentRepaymentDetails.get(0).getPlanNumber();
        int maxPlanNumber = recentRepaymentDetails.get(recentRepaymentDetails.size() - 1).getPlanNumber();
        for (int i = 1; i < minPlanNumber; i++) {
            repaymentDetailsBeforeRecent.add(new RepaymentDetailGson(new RepaymentDetail(loan.getRepaymentPlan(i))));
        }
        for (int i = maxPlanNumber + 1; i <= loan.getNumberOfInstalments(); i++) {
            repaymentDetailsAfterRecent.add(new RepaymentDetailGson(new RepaymentDetail(loan.getRepaymentPlan(i))));
        }
    }

    private void putNormalRepaymentDetailTo(List<RepaymentDetailGson> repaymentDetailGsons, Loan loan, int startIndex, int endIndex) {
        for (int i = startIndex; i <= endIndex; i++) {
            if (i > 0 && i <= loan.getNumberOfInstalments()) {
                RepaymentPlan repaymentPlan = loan.getRepaymentPlan(i);
                if (!repaymentPlan.isOverdue() && !repaymentPlan.isProcessing()) {
                    repaymentDetailGsons.add(new RepaymentDetailGson(new RepaymentDetail(repaymentPlan)));
                }
            }
        }
    }

    public List<RepaymentDetailGson> getRepaymentDetailsBeforeRecent() {
        return repaymentDetailsBeforeRecent;
    }

    public List<RepaymentDetailGson> getRecentRepaymentDetails() {
        return recentRepaymentDetails;
    }

    public List<RepaymentDetailGson> getRepaymentDetailsAfterRecent() {
        return repaymentDetailsAfterRecent;
    }

    public int getPayablePlanNumber() {
        return payablePlanNumber;
    }
}
