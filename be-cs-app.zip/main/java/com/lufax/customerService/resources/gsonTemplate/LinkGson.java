package com.lufax.customerService.resources.gsonTemplate;

import com.lufax.common.resources.LinkRelationType;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

import javax.ws.rs.core.UriBuilder;

public class LinkGson {
    public static final String SERVICE_BASE_PATH = "service";
    public static final String ADMIN_BASE_PATH = "../../" + SERVICE_BASE_PATH + "/operation/p2p";
    private String href;
    private LinkRelationType relation;

    public LinkGson(String href, LinkRelationType relation) {
        this(SERVICE_BASE_PATH, href, relation);
    }

    private LinkGson(String basePath, String href, LinkRelationType relation) {
        this.href = UriBuilder.fromPath(basePath).path(href).build().toString();
        this.relation = relation;
    }

    public static LinkGson admin(String href) {
        return new LinkGson(ADMIN_BASE_PATH, href, LinkRelationType.RELATED);
    }

    public String getHref() {
        return href;
    }

    public LinkRelationType getLinkRelationType() {
        return relation;
    }

    @Override
    public boolean equals(Object o) {
        return EqualsBuilder.reflectionEquals(this, o);
    }

    @Override
    public int hashCode() {
        return HashCodeBuilder.reflectionHashCode(this);
    }
}
