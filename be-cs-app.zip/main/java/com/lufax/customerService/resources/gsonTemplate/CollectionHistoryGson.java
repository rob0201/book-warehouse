package com.lufax.customerService.resources.gsonTemplate;

import static com.lufax.common.utils.BigDecimalUtils.add;
import static com.lufax.common.utils.BigDecimalUtils.subtract;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

import com.lufax.common.domain.CollectionDetail;
import com.lufax.common.domain.CollectionRecord;
import com.lufax.common.domain.Investment;
import com.lufax.common.domain.PlanStatus;
import com.lufax.common.domain.TradeContract;
import com.lufax.common.domain.TradingStatus;
import com.lufax.common.domain.account.Money;
import com.lufax.common.utils.DevLog;
//import com.lufax.common.utils.DevLog;

public class CollectionHistoryGson {
    private BigDecimal totalPenalValue = BigDecimal.ZERO;
    private BigDecimal totalOverduePenalValue = BigDecimal.ZERO;
    private BigDecimal totalPrincipal = BigDecimal.ZERO;
    private BigDecimal totalInterest = BigDecimal.ZERO;
    private BigDecimal totalAmount = BigDecimal.ZERO;
    private BigDecimal totalManagementFee = BigDecimal.ZERO;
    private BigDecimal totalInvestmentManagementFee = BigDecimal.ZERO;
    private BigDecimal totalInvestmentTransactionFee = BigDecimal.ZERO;
    private BigDecimal transferAmount =  BigDecimal.ZERO;
    
    private List<CollectionDetailGson> collectionDetails = new ArrayList<CollectionDetailGson>();
    

    public void setCollectionDetails(List<CollectionDetailGson> collectionDetails) {
		this.collectionDetails = collectionDetails;
	}

	public CollectionHistoryGson(ArrayList<CollectionDetail> collectionDetailsList, Investment investment) {
		List<CollectionDetail> collectionDetailList= convertSplitProduct(judeRateChange(collectionDetailsList),investment);

    	int i=1;
        for (CollectionDetail collectionDetail : collectionDetailList) {
            this.totalPenalValue = add(this.totalPenalValue, collectionDetail.getCollectedPenalValue().getAmount());
            this.totalOverduePenalValue = add(this.totalOverduePenalValue, collectionDetail.getCollectedOverduePenalty().getAmount());
            this.totalPrincipal = add(this.totalPrincipal, collectionDetail.getCollectedPrincipal().getAmount());
            this.totalInterest = add(this.totalInterest, collectionDetail.getCollectedInterest().getAmount());
            this.totalManagementFee = add(this.totalManagementFee, collectionDetail.getPaidManagementFee().getAmount());
            this.totalInvestmentManagementFee = add(this.totalInvestmentManagementFee, collectionDetail.getPaidInvestmentManagementFee().getAmount());
            this.totalInvestmentTransactionFee = add(this.totalInvestmentTransactionFee,collectionDetail.getPaidInvestmentTransactionFee().getAmount());
            CollectionDetailGson collectionDetailGson = new CollectionDetailGson(collectionDetail);
            collectionDetailGson.setRecordSequence(i);
            this.collectionDetails.add(collectionDetailGson);
            i++;
        }
        this.totalInvestmentTransactionFee=investment.getProduct().getBuyerTransactionFee();
        this.totalAmount = subtract(add(add(add(this.totalPenalValue, this.totalInterest), this.totalPrincipal), this.totalOverduePenalValue), this.totalManagementFee);
    }
	private CollectionRecordGson getSplitProductPaymentPricipal(BigDecimal remainAmount, String payTime, int planNumber) {
    	CollectionRecordGson record = new CollectionRecordGson();
    	record.setAmount(remainAmount);
    	record.setInterest(BigDecimal.ZERO);
    	record.setManagementFee(BigDecimal.ZERO);
    	record.setOverduePenalValue(BigDecimal.ZERO);
    	record.setPaidUpAmount(BigDecimal.ZERO);
    	record.setPayTime(payTime);
    	record.setPenalValue(BigDecimal.ZERO);
    	record.setPlanNumber(planNumber);
    	record.setPrincipal(remainAmount);
    	return record;
    }
    
    public CollectionHistoryGson(ArrayList<CollectionDetail> collectionDetailsList, Investment investment,BigDecimal transferAmount) {
    	this.transferAmount = transferAmount;
    	List<CollectionDetail> collectionDetailList= convertSplitProduct(judeRateChange(collectionDetailsList),investment);
    	int i=1;
        for (CollectionDetail collectionDetail : collectionDetailList) {
            this.totalPenalValue = add(this.totalPenalValue, collectionDetail.getCollectedPenalValue().getAmount());
            this.totalOverduePenalValue = add(this.totalOverduePenalValue, collectionDetail.getCollectedOverduePenalty().getAmount());
            this.totalPrincipal = add(this.totalPrincipal, collectionDetail.getCollectedPrincipal().getAmount());
            this.totalInterest = add(this.totalInterest, collectionDetail.getCollectedInterest().getAmount());
            this.totalManagementFee = add(this.totalManagementFee, collectionDetail.getPaidManagementFee().getAmount());
            this.totalInvestmentManagementFee = add(this.totalInvestmentManagementFee, collectionDetail.getPaidInvestmentManagementFee().getAmount());
            CollectionDetailGson collectionDetailGson = new CollectionDetailGson(collectionDetail);
            collectionDetailGson.setRecordSequence(i);
            this.collectionDetails.add(collectionDetailGson);
            i++;
        }
        this.totalInvestmentTransactionFee=investment.getProduct().getBuyerTransactionFee();
        this.totalAmount = subtract(add(add(add(this.totalPenalValue, this.totalInterest), this.totalPrincipal), this.totalOverduePenalValue), this.totalManagementFee);
    }

    public BigDecimal getTotalPenalValue() {
        return totalPenalValue;
    }

    public BigDecimal getTotalPrincipal() {
        return totalPrincipal;
    }

    public BigDecimal getTotalInterest() {
        return totalInterest;
    }

    public BigDecimal getTotalAmount() {
        return totalAmount;
    }

    public BigDecimal getTotalManagementFee() {
        return totalManagementFee;
    }

    public List<CollectionDetailGson> getCollectionDetails() {
        return this.collectionDetails;
    }

    public BigDecimal getTotalOverduePenalValue() {
		return totalOverduePenalValue;
	}

	public BigDecimal getTotalInvestmentManagementFee() {
		return totalInvestmentManagementFee;
	}

	public BigDecimal getTotalInvestmentTransactionFee() {
		return totalInvestmentTransactionFee;
	}

	public void setTotalInvestmentTransactionFee(BigDecimal totalInvestmentTransactionFee) {
        this.totalInvestmentTransactionFee = totalInvestmentTransactionFee;
        recalculateTotalPaidAmount();
    }

    private void recalculateTotalPaidAmount() {
        this.totalAmount = this.totalAmount.subtract(this.totalInvestmentTransactionFee).subtract(this.totalInvestmentManagementFee);
    }
	
	@Override
    public boolean equals(Object o) {
        return EqualsBuilder.reflectionEquals(this, o);
    }

    @Override
    public int hashCode() {
        return HashCodeBuilder.reflectionHashCode(this);
    }
    
    private ArrayList<CollectionDetail> judeRateChange(ArrayList<CollectionDetail> collectionDetails){
    	ArrayList<CollectionDetail> collectionDetailList = collectionDetails;
    	if(collectionDetailList.size()==0){
    		return collectionDetailList;
    	}
    	collectionDetails.get(0).setRateChange(false);
    	for(int i=0;i<collectionDetailList.size();i++){
//    		DevLog.debug(this, String.format("The [%s] 's interestRate is [%s]", i,collectionDetailList.get(i).getInterestRate()));
			if(i>=collectionDetailList.size()-1){
				break;
			}
    		if(collectionDetailList.get(i).getInterestRate().compareTo(collectionDetailList.get(i+1).getInterestRate())==0){
				collectionDetailList.get(i+1).setRateChange(false);
			}else{
				collectionDetailList.get(i+1).setRateChange(true);
			}
		}
    	// convert the collectionDetails
    	return collectionDetails;
    }
    
    private List<CollectionDetail> convertSplitProduct(ArrayList<CollectionDetail> collectionDetails, Investment investment) {
    	if(collectionDetails == null || collectionDetails.isEmpty()) {
    		return Collections.EMPTY_LIST;
    	}
    	ArrayList<CollectionDetail> result = new ArrayList<CollectionDetail>();
    	if(investment.getProduct().isSplited()) {
    		
    		boolean isEnd = false;
    		int endRecordNumber = 0;
    		boolean isPrePaid = false;
    		BigDecimal remindAmount = BigDecimal.ZERO;
    		
    		for(int i = 0 ; i < collectionDetails.size();i++ ) {
    			CollectionDetail detail = collectionDetails.get(i);
    			if(isEnd) {
    				remindAmount = remindAmount.add(detail.getPrincipal().getAmount());
    			}
    			if(i< investment.getNumberOfInstalments() ) {
					result.add(detail);
					if(i == investment.getNumberOfInstalments() -1 && !isEnd && PlanStatus.PAID.equals(detail.getStatus())) {
    					isEnd = true;
    					endRecordNumber = i;
    				}
				}
    			if(PlanStatus.PREPAID.equals(detail.getStatus()) && !isEnd) {
    				return result;
    			} else {
    				// TODO
    			}
    			
    			
//    			DevLog.debug(this, "is end [" + isEnd + "] endRecordNumber [" + endRecordNumber + "] reminad amount[" + remindAmount + "]");
    		}
    		// 如果是最后一期，需要增加一条额外的还款记录：本金=剩余本金的和
    		if(isEnd) {
    				if(TradingStatus.PREPAID.equals(investment.getStatus()) && PlanStatus.PAID.equals(collectionDetails.get(investment.getLengthOfPeriods() - 1).getStatus())) {
    					CollectionDetail detail = result.get(endRecordNumber);
    					CollectionDetail temp = collectionDetails.get(investment.getLengthOfPeriods());
    					CollectionRecord records = temp.getCollectionRecords().get(0);
    					
    					detail.setCollectedAmount(detail.getCollectedAmount().add(records.getAmount()));
		    			detail.setCollectedPrincipal(detail.getCollectedPrincipal().add(records.getPrincipal()));
		    			detail.setCollectedPenalValue(records.getPenalValue());
		    			detail.setAmount(detail.getAmount().add(records.getAmount()));
		    			detail.setPaidManagementFee(detail.getPaidManagementFee().add(records.getManagementFee()));
		    			detail.setPaidInvestmentManagementFee(detail.getPaidInvestmentManagementFee().add(records.getInvestmentManagementFee()));
		    			detail.setPaidInvestmentTransactionFee(detail.getPaidInvestmentTransactionFee().add(records.getInvestmentTransactionFee()));
    					detail.getCollectionRecords().add(records);
    				} if(!TradingStatus.PAID.equals(investment.getStatus()) && PlanStatus.PAID.equals(collectionDetails.get(investment.getLengthOfPeriods() - 1).getStatus())) {
    					// do nothing
    				}
    				else {
		    			CollectionDetail detail = result.get(endRecordNumber);
		    			detail.setCollectedAmount(detail.getCollectedAmount().add(Money.rmb(remindAmount)));
		    			detail.setCollectedPrincipal(detail.getCollectedPrincipal().add(Money.rmb(remindAmount)));
		    			detail.setAmount(detail.getAmount().add(Money.rmb(remindAmount)));
		    			DevLog.debug(this, "The detail is [" + detail + "]");
		    			if(detail.getCollectionRecords() != null && !detail.getCollectionRecords().isEmpty()) {
			    			CollectionRecord temp = result.get(endRecordNumber).getCollectionRecords().get(0);
			    			CollectionRecord record = new CollectionRecord();
			    			record.setAmount(Money.rmb(remindAmount));
			    			record.setCreatedAt(temp.getCreatedAt());
			    			record.setPrincipal(Money.ZERO_YUAN);
			    			record.setManagementFee(Money.ZERO_YUAN);
			    			record.setPenalValue(Money.ZERO_YUAN);
			    			record.setOverduePenalValue(Money.ZERO_YUAN);
			    			record.setInterest(Money.ZERO_YUAN);
			    			record.setStatus("DONE");
			    			detail.getCollectionRecords().add(record);
		    			}
    				}
    			
    		} else { // 未结束
    			CollectionDetail detail = result.get(investment.getNumberOfInstalments() - 1);
    			BigDecimal tempAmount = BigDecimal.ZERO;
    			for(int i =0; i < collectionDetails.size(); i++) {
    				if(i >= investment.getNumberOfInstalments()) {
    					CollectionDetail tempDetail = collectionDetails.get(i);
    					tempAmount = tempAmount.add(tempDetail.getPrincipal().getAmount());
//    					DevLog.debug(this, "The tempamount is [" + tempAmount + "]");
    				}
    			}
//    			detail.setCollectedAmount(detail.getCollectedAmount().add(Money.rmb(tempAmount)));
    			detail.setPrincipal(detail.getPrincipal().add(Money.rmb(tempAmount)));
    			detail.setAmount(detail.getAmount().add(Money.rmb(tempAmount)));
    		}
    		return result;	
    	} else {
    		return collectionDetails;
    	}
    	
    }
    

	public BigDecimal getTransferAmount() {
		return transferAmount;
	}

	public void setTotalPenalValue(BigDecimal totalPenalValue) {
		this.totalPenalValue = totalPenalValue;
	}

	public void setTotalOverduePenalValue(BigDecimal totalOverduePenalValue) {
		this.totalOverduePenalValue = totalOverduePenalValue;
	}

	public void setTotalPrincipal(BigDecimal totalPrincipal) {
		this.totalPrincipal = totalPrincipal;
	}

	public void setTotalInterest(BigDecimal totalInterest) {
		this.totalInterest = totalInterest;
	}

	public void setTotalAmount(BigDecimal totalAmount) {
		this.totalAmount = totalAmount;
	}

	public void setTotalManagementFee(BigDecimal totalManagementFee) {
		this.totalManagementFee = totalManagementFee;
	}

	public void setTotalInvestmentManagementFee(BigDecimal totalInvestmentManagementFee) {
		this.totalInvestmentManagementFee = totalInvestmentManagementFee;
	}

	public void setTransferAmount(BigDecimal transferAmount) {
		this.transferAmount = transferAmount;
	}
    
}
