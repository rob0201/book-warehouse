package com.lufax.customerService.resources.gsonTemplate;

import java.math.BigDecimal;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

import com.lufax.common.domain.InvestmentRequest;
import com.lufax.common.utils.DateUtils;

public class CustomerServiceInvestmentRequestGson {
	private String loanRequestCode;
    private String loanRequestAmount;
    private BigDecimal interestRate;
    private Integer numberOfInstalments;
    private String investmentRequestDate;
    private String status;
    private String loanCode;
    private String statusDescription;
    private String statusCustomerDescription;
    private CustomerServiceProductGson product; 
    private String productName ;
    private long productId ;
    private String productCode;
    
    public CustomerServiceInvestmentRequestGson(InvestmentRequest investmentRequest,CustomerServiceProductGson product) {
    	this.product = product;
    	this.loanRequestCode = product.getCode();
        this.loanRequestAmount = product.getPrincipal();
        this.interestRate = product.getInterestRate();
        this.numberOfInstalments = product.getNumberOfInstalments();
        this.investmentRequestDate = DateUtils.formatDateToSeconds(investmentRequest.getCreatedAt());
        this.statusDescription = investmentRequest.getStatus().getValue();
        this.statusCustomerDescription = investmentRequest.getStatus().getCustomerServiceDesc();
        this.status = investmentRequest.getStatus().toString();
        this.loanCode = investmentRequest.getLoanCode();
        if("TIME_SPLIT".equals(investmentRequest.getProduct().getProductType())) {
        	this.productName = "稳盈-接利贷";
        } else if("LOAN_REQUEST".equals(investmentRequest.getProduct().getProductType()) && "9".equals(investmentRequest.getProduct().getSourceType()) ){
        	this.productName = "稳盈-安e贷二期";
        } else {
        	this.productName = "稳盈-安e贷";
        }
        this.productId = product.getProductId();
        this.productCode = product.getCode();
    }
    
    public String getLoanRequestCode() {
        return loanRequestCode;
    }


    public String getLoanRequestAmount() {
        return loanRequestAmount;
    }

    public BigDecimal getInterestRate() {
        return interestRate;
    }

    public Integer getNumberOfInstalments() {
        return numberOfInstalments;
    }

    public String getInvestmentRequestDate() {
        return investmentRequestDate;
    }


    public String getStatus() {
        return status;
    }

    public String getLoanCode() {
        return loanCode;
    }

    public String getStatusCustomerDescription() {
        return statusCustomerDescription;
    }

    @Override
    public boolean equals(Object o) {
        return EqualsBuilder.reflectionEquals(this, o);
    }

    @Override
    public int hashCode() {
        return HashCodeBuilder.reflectionHashCode(this);
    }

	public CustomerServiceProductGson getProduct() {
		return product;
	}

	public String getProductName() {
		return productName;
	}

	public long getProductId() {
		return productId;
	}

	public String getProductCode() {
		return productCode;
	}

	public String getStatusDescription() {
		return statusDescription;
	}
    
}
