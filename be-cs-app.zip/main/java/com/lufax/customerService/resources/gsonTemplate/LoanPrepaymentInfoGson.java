package com.lufax.customerService.resources.gsonTemplate;

import com.lufax.common.domain.*;
import com.lufax.common.domain.account.Money;
import com.lufax.common.utils.DateUtils;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Map;

import static com.lufax.common.utils.BigDecimalUtils.add;

public class LoanPrepaymentInfoGson {

    private boolean prepayWithCurrent;
    private BigDecimal currentInsuranceFee = new BigDecimal("0");
    private BigDecimal currentInterest = new BigDecimal("0");
    private BigDecimal currentOverduePenaltyToPay = new BigDecimal("0");
    private BigDecimal currentManagementFee = new BigDecimal("0");
    private boolean prepayWithPrevious;
    private BigDecimal previousPrincipal = new BigDecimal("0");
    private BigDecimal previousInterest = new BigDecimal("0");
    private BigDecimal previousManagementFee = new BigDecimal("0");
    private BigDecimal previousInsuranceFee = new BigDecimal("0");
    private BigDecimal previousOverduePenaltyToPay = new BigDecimal("0");
    private BigDecimal remainingPrincipal;
    private BigDecimal penalValue;
    private BigDecimal totalAmount;
    private String prepaymentDate;
    private BigDecimal insuranceManagementFee;

    public LoanPrepaymentInfoGson(Loan loan) {
        Money normalAmount = Money.ZERO_YUAN;
        List<RepaymentPlan> payableRepaymentPlans = loan.getPayableRepaymentPlans();
        prepayWithPrevious = !payableRepaymentPlans.isEmpty();
        for (RepaymentPlan plan : payableRepaymentPlans) {
            RepaymentDetail repaymentDetail = new RepaymentDetail(plan);
            previousPrincipal = add(previousPrincipal, repaymentDetail.getRemainingPrincipal().getAmount());
            previousInterest = add(previousInterest, repaymentDetail.getRemainingInterest().getAmount());
            previousOverduePenaltyToPay = add(previousOverduePenaltyToPay, repaymentDetail.getRemainingOverduePenaltyToPay().getAmount());
            previousInsuranceFee = add(previousInsuranceFee, repaymentDetail.getRemainingInsuranceFee().getAmount());
            previousManagementFee = add(previousManagementFee, repaymentDetail.getRemainingManagementFee().getAmount());
            normalAmount = normalAmount.add(repaymentDetail.getRemainingAmount());
        }
        PrepaymentDetail loanPrepaymentDetail = new PrepaymentDetail(loan);
        prepayWithCurrent = loanPrepaymentDetail.isPrepayWithCurrent();
        currentInsuranceFee = loanPrepaymentDetail.getInsuranceFeeOfCurrentPlan().getAmount();
        currentInterest = loanPrepaymentDetail.getInterestOfCurrentPlan().getAmount();
        currentOverduePenaltyToPay = loanPrepaymentDetail.getOverduePenaltyToPayOfCurrentPlan().getAmount();
        currentManagementFee = loanPrepaymentDetail.getManagementFeeForLoaneeOfCurrentPlan().getAmount();
        prepaymentDate = DateUtils.formatDate(new Date());
        remainingPrincipal = loanPrepaymentDetail.getRemainingPrincipal().getAmount();
        penalValue = loanPrepaymentDetail.getPenalValue().getAmount();
        totalAmount = loanPrepaymentDetail.getPrepayAmount().add(normalAmount).getAmount();
    }


    public LoanPrepaymentInfoGson(Loan loan, Date date, Map<String, BigDecimal> prepayParameters) {
        Money normalAmount = Money.ZERO_YUAN;
        for (RepaymentPlan plan : loan.getRepaymentPlans()) {
            Date endAt = plan.getEndAt();
            if (plan.isUnpaid() && (date.after(endAt))) {
                plan.setStatus(PlanStatus.OVERDUE);
                loan.setStatus(TradingStatus.OVERDUE);
            }
        }
        List<RepaymentPlan> payableRepaymentPlans = loan.getPayableRepaymentPlans(date);
        prepayWithPrevious = !payableRepaymentPlans.isEmpty();
        for (RepaymentPlan plan : payableRepaymentPlans) {
            RepaymentDetail repaymentDetail = new RepaymentDetail(plan);
            previousPrincipal = add(previousPrincipal, repaymentDetail.getRemainingPrincipal().getAmount());
            previousInterest = add(previousInterest, repaymentDetail.getRemainingInterest().getAmount());
            //todo
            previousOverduePenaltyToPay = add(previousOverduePenaltyToPay, repaymentDetail.getRemainingOverduePenaltyToPay(date).getAmount());
            previousInsuranceFee = add(previousInsuranceFee, repaymentDetail.getRemainingInsuranceFee().getAmount());
            previousManagementFee = add(previousManagementFee, repaymentDetail.getRemainingManagementFee().getAmount());
            //todo
            normalAmount = normalAmount.add(repaymentDetail.getRemainingAmount(date));
        }
        PrepaymentDetail loanPrepaymentDetail = new PrepaymentDetail(loan, date, prepayParameters);
        prepayWithCurrent = loanPrepaymentDetail.isPrepayWithCurrent();
        currentInsuranceFee = loanPrepaymentDetail.getInsuranceFeeOfCurrentPlan().getAmount();
        currentInterest = loanPrepaymentDetail.getInterestOfCurrentPlan().getAmount();
        currentOverduePenaltyToPay = loanPrepaymentDetail.getOverduePenaltyToPayOfCurrentPlan().getAmount();
        currentManagementFee = loanPrepaymentDetail.getManagementFeeForLoaneeOfCurrentPlan().getAmount();
        prepaymentDate = DateUtils.formatDate(date);
        remainingPrincipal = loanPrepaymentDetail.getRemainingPrincipal().getAmount();
        penalValue = loanPrepaymentDetail.getPenalValue().getAmount();
        insuranceManagementFee = loanPrepaymentDetail.getInsuranceManagementFee().getAmount();
        totalAmount = loanPrepaymentDetail.getPrepayAmount().add(normalAmount).getAmount();
    }

    public BigDecimal getRemainingPrincipal() {
        return remainingPrincipal;
    }

    public BigDecimal getPenalValue() {
        return penalValue;
    }

}
