package com.lufax.customerService.resources.gsonTemplate;

import java.math.BigDecimal;

import com.lufax.common.utils.DateUtils;
import com.lufax.customerService.pojo.SMECollectionRecord;

public class CustomerServiceSmeCollectionRecordGson {
	//期数
	private int planNumber;
    //收款日
	private String payTime;
    //还款金额
	private BigDecimal amount;
    //还款本金
	private BigDecimal principal;
    //还款利息
	private BigDecimal interest;
    //提前还款违约金
	private BigDecimal penalValue;
    //逾期管理违约金
	private BigDecimal overduePenalValue;
    //管理违约金
	private BigDecimal managementFee;
	//转让款
	private BigDecimal transferAmount;
	
	public CustomerServiceSmeCollectionRecordGson(SMECollectionRecord collectionRecord) {
		this.planNumber = collectionRecord.getRecordNumber();
		this.payTime = DateUtils.formatDate(collectionRecord.getCreatedAt());
		this.amount = collectionRecord.getAmount().getAmount();
		this.principal = collectionRecord.getPrincipal().getAmount();
		this.interest = collectionRecord.getInterest().getAmount();
		this.penalValue = collectionRecord.getAdvancedRepayPenalty()==null?BigDecimal.ZERO:collectionRecord.getAdvancedRepayPenalty().getAmount();
		this.overduePenalValue = collectionRecord.getManagePenaltyPunishInterest().getAmount();
		this.managementFee = collectionRecord.getManagePenalty()==null?BigDecimal.ZERO:collectionRecord.getManagePenalty().getAmount();
		this.transferAmount = collectionRecord.getTransferFund().getAmount();
	}

	public int getPlanNumber() {
		return planNumber;
	}

	public String getPayTime() {
		return payTime;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public BigDecimal getPrincipal() {
		return principal;
	}

	public BigDecimal getInterest() {
		return interest;
	}

	public BigDecimal getPenalValue() {
		return penalValue;
	}

	public BigDecimal getOverduePenalValue() {
		return overduePenalValue;
	}

	public BigDecimal getManagementFee() {
		return managementFee;
	}

	public BigDecimal getTransferAmount() {
		return transferAmount;
	}
}
