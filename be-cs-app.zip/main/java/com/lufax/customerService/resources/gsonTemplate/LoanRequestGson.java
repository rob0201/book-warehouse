package com.lufax.customerService.resources.gsonTemplate;

import java.math.BigDecimal;

import com.lufax.common.domain.ASLoanRequest;
import com.lufax.common.domain.InsurancePolicy;
import com.lufax.common.domain.LoanRequest;
import com.lufax.common.domain.LoanRequestStatus;
import com.lufax.common.domain.PaymentMethodFactory;
import com.lufax.common.domain.UserRole;
import com.lufax.common.domain.WithdrawRecord;
import com.lufax.common.domain.account.Money;
import com.lufax.common.utils.DateUtils;
import com.lufax.common.utils.DevLog;
import com.lufax.common.utils.NumberUtils;

public class LoanRequestGson {
    private String code;
    private BigDecimal appliedAmount;
    private BigDecimal interestRate;
    private BigDecimal insuranceValuePerMonth;
    private BigDecimal managementFeeAmount;
    private Integer numberOfInstalments;
    private BigDecimal totalIncome;
    private BigDecimal periodicIncome;
    private String createdAt;
    private String status;
    private String loaneeUserName;
    private LinkGson adminCancelLink;
    private WithdrawRecordGson withdrawRecordGson;
    private boolean isDirectP2P = false;
    // add PRD 928 白领贷
    private boolean isBaiLingDai = false;

    public static LoanRequestGson instanceOfAdmin(LoanRequest loanRequest) {
        return new LoanRequestGson(loanRequest, UserRole.ADMIN);
    }

    public static LoanRequestGson instance(LoanRequest loanRequest) {
        return new LoanRequestGson(loanRequest, UserRole.COMMON);
    }

    public static LoanRequestGson instanceOfCS(LoanRequest loanRequest, WithdrawRecord withdrawRecord) {
    	
        LoanRequestGson loanRequestGson = new LoanRequestGson(loanRequest, UserRole.CUSTOM);
        if(isDisplayRate(loanRequest)) {
        	loanRequestGson.interestRate = BigDecimal.ZERO;
        	loanRequestGson.appliedAmount = BigDecimal.ZERO;
        	loanRequestGson.numberOfInstalments = 0;
        }
        if (withdrawRecord != null) {
            loanRequestGson.withdrawRecordGson = new WithdrawRecordGson(withdrawRecord);
        }
        return loanRequestGson;
    }
    
    public static boolean isDisplayRate(LoanRequest loanRequest){
    	return LoanRequestStatus.WAITING_CHECK.equals(loanRequest.getStatus()) || 
    			LoanRequestStatus.CHECK_SUCCESS.equals(loanRequest.getStatus()) || 
    			LoanRequestStatus.CHECK_FAILED.equals(loanRequest.getStatus()) ||
    			LoanRequestStatus.LOANEE_TELEPHONE_DENIED.equals(loanRequest.getStatus()) || 
    			LoanRequestStatus.UN_CHECK_EXPIRED.equals(loanRequest.getStatus());  
    }
    public static LoanRequestGson instanceOfAS(ASLoanRequest asloanRequest, BigDecimal totalRepayAmount, Boolean isBaiLingDai) {
        LoanRequestGson loanRequestGson = new LoanRequestGson(asloanRequest, totalRepayAmount);
        loanRequestGson.isBaiLingDai = isBaiLingDai;
        return loanRequestGson;
    }
    private LoanRequestGson(ASLoanRequest asloanRequest,BigDecimal totalRepayAmount) {
//    	"code":loanRequest.code,
//        "appliedAmount":utility.numberFormat(loanRequest.appliedAmount),
//        "interestRate":utility.percentageFormat(loanRequest.interestRate),
//        "insuranceValuePerMonth":utility.numberFormat(loanRequest.insuranceValuePerMonth),
//        "managementFeeAmount":utility.numberFormat(loanRequest.managementFeeAmount),
//        "numberOfInstalments":loanRequest.numberOfInstalments,
//        "createdAt":loanRequest.createdAt,
//        "status":composeStatus.withDrawStatus(loanRequest)};
    	code = asloanRequest.getCode();
    	if(asloanRequest.getAppliedAmount() != null) {
    		appliedAmount = NumberUtils.withCurrencyScale(asloanRequest.getAppliedAmount());
    	}
    	interestRate = asloanRequest.getInterestRate();
    	
    	insuranceValuePerMonth = BigDecimal.ZERO;//TODO
    	managementFeeAmount = BigDecimal.ZERO;//TODO
    	numberOfInstalments = asloanRequest.getNumOfInstalments();
//    	if(asloanRequest.getInterestRate() != null && numberOfInstalments != null) {
//    		PaymentMethodFactory paymentMethodFactory = new PaymentMethodFactory(asloanRequest.getInterestRate(), numberOfInstalments);
//    		this.totalIncome = NumberUtils.withCurrencyScale(paymentMethodFactory.getTotalIncomeToLoaner(Money.rmb(asloanRequest.getAppliedAmount())).getAmount());
//    	}
    	this.totalIncome = totalRepayAmount;
//    	DevLog.debug(this, String.format(" interest rate is [%s], instalments number [%s] apply amount[%s] totalIncome [%s]",asloanRequest.getInterestRate(),numberOfInstalments, asloanRequest.getAppliedAmount(), totalIncome));
    	if(asloanRequest.getCreatedAt() != null) {
    		createdAt = DateUtils.formatDate(asloanRequest.getCreatedAt(), DateUtils.DATE_TIME_FORMAT_DEFAULT);//DateUtils.formatDateToSeconds(asloanRequest.getCeatedAt());
    	}
    	if(asloanRequest.getStatus() != null) {
    		status = LoanRequestStatus.getLoanRequestStatusByName(asloanRequest.getStatus()).getCustomerServiceDesc();
    	}
    	isDirectP2P = true;
    }
    private LoanRequestGson(LoanRequest loanRequest, UserRole userRole) {
        this(loanRequest);

        if (UserRole.CUSTOM.equals(userRole)) {
            this.status = loanRequest.getStatus().getCustomerServiceDesc();
        } else {
            this.status = loanRequest.getStatus().getDesc();
        }

        if (UserRole.COMMON.equals(userRole)) {
            this.insuranceValuePerMonth = extractInsuranceValuePerMonth(loanRequest.getPolicy());
        }

        if (UserRole.ADMIN.equals(userRole)) {
            this.adminCancelLink = LinkGson.admin("/loan-requests/" + loanRequest.getCode() + "/cancel");
        }
    }

    public LoanRequestGson(LoanRequest loanRequest) {
        Money loanRequestAppliedAmount = loanRequest.getAppliedAmount();
        this.code = loanRequest.getCode();
        this.appliedAmount = NumberUtils.withCurrencyScale(loanRequestAppliedAmount.getAmount());
        this.interestRate = loanRequest.getInterestRate();
        this.managementFeeAmount = NumberUtils.withCurrencyScale(loanRequest.getManagementFeeRate().multiply(loanRequestAppliedAmount.getAmount()));
        this.numberOfInstalments = loanRequest.getNumberOfInstalments();
        PaymentMethodFactory paymentMethodFactory = new PaymentMethodFactory(interestRate, numberOfInstalments);
        this.totalIncome = NumberUtils.withCurrencyScale(paymentMethodFactory.getTotalIncomeToLoaner(loanRequestAppliedAmount).getAmount());
        DevLog.debug(this, String.format(" interest rate is [%s], instalments number [%s] apply amount [%s], totalIncome [%s]",interestRate,numberOfInstalments, loanRequestAppliedAmount, totalIncome));
        this.periodicIncome = NumberUtils.withCurrencyScale(paymentMethodFactory.getMonthlyIncomeToLoaner(loanRequestAppliedAmount).getAmount());
        this.createdAt = DateUtils.formatDate(loanRequest.getCreatedAt(), DateUtils.DATE_TIME_FORMAT_DEFAULT);
        if(loanRequest.getLoanee() != null) {
        	this.loaneeUserName = loanRequest.getLoanee().getUsername();
        }
    }

    private BigDecimal extractInsuranceValuePerMonth(InsurancePolicy policy) {
        if (policy == null) return NumberUtils.withCurrencyScale(BigDecimal.ZERO);
        return NumberUtils.withCurrencyScale(policy.getInsuranceValuePerMonth().getAmount());
    }

    public BigDecimal getManagementFeeAmount() {
        return managementFeeAmount;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public String getStatus() {
        return status;
    }

    public String getCode() {
        return code;
    }

    public BigDecimal getAppliedAmount() {
        return appliedAmount;
    }

    public BigDecimal getInterestRate() {
        return interestRate;
    }

    public BigDecimal getInsuranceValuePerMonth() {
        return insuranceValuePerMonth;
    }

    public int getNumberOfInstalments() {
        return numberOfInstalments;
    }

    public BigDecimal getTotalIncome() {
        return totalIncome;
    }

    public BigDecimal getPeriodicIncome() {
        return periodicIncome;
    }

    public String getLoaneeUserName() {
        return loaneeUserName;
    }

    public LinkGson getAdminCancelLink() {
        return adminCancelLink;
    }

    public WithdrawRecordGson getWithdrawRecordGson() {
        return withdrawRecordGson;
    }

	public boolean isBaiLingDai() {
		return isBaiLingDai;
	}

	public void setBaiLingDai(boolean isBaiLingDai) {
		this.isBaiLingDai = isBaiLingDai;
	}
    
}
