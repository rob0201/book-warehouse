package com.lufax.customerService.resources.gsonTemplate;

import java.math.BigDecimal;

import com.lufax.common.domain.TransactionType.FundType;
import com.lufax.common.domain.account.TransactionHistory;
import com.lufax.common.utils.DateUtils;

public class TransactionHistoryGson {
	private String createdAt;
    private String transactionType;
    private BigDecimal incomeAmount;
    private BigDecimal outAmount;
    private BigDecimal availableAmount;
    private BigDecimal frozenAmount;
    private String remark;
    
    public TransactionHistoryGson(TransactionHistory history){
    	this.createdAt = DateUtils.formatDate(history.getCreatedAt(), DateUtils.DATE_TIME_FORMAT_DEFAULT);
    	this.transactionType = history.getType().getValue();
    	this.incomeAmount = history.getType().getFundType().equals(FundType.INCOME)?(history.getTransactionAmount()==null?BigDecimal.ZERO:history.getTransactionAmount().getAmount()):BigDecimal.ZERO;
    	this.outAmount = history.getType().getFundType().equals(FundType.EXPENSE)?(history.getTransactionAmount()==null?BigDecimal.ZERO:history.getTransactionAmount().getAmount()):BigDecimal.ZERO;
    	this.availableAmount = history.getAvailableFund()==null?BigDecimal.ZERO:history.getAvailableFund().getAmount();
    	this.frozenAmount = history.getFrozenFund()==null?BigDecimal.ZERO:history.getFrozenFund().getAmount();
    	this.remark = history.getRemark();
    }
    
	public String getCreatedAt() {
		return createdAt;
	}
	public void setCreatedAt(String createdAt) {
		this.createdAt = createdAt;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public BigDecimal getIncomeAmount() {
		return incomeAmount;
	}
	public void setIncomeAmount(BigDecimal incomeAmount) {
		this.incomeAmount = incomeAmount;
	}
	public BigDecimal getOutAmount() {
		return outAmount;
	}
	public void setOutAmount(BigDecimal outAmount) {
		this.outAmount = outAmount;
	}
	public BigDecimal getAvailableAmount() {
		return availableAmount;
	}
	public void setAvailableAmount(BigDecimal availableAmount) {
		this.availableAmount = availableAmount;
	}
	public BigDecimal getFrozenAmount() {
		return frozenAmount;
	}
	public void setFrozenAmount(BigDecimal frozenAmount) {
		this.frozenAmount = frozenAmount;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	@Override
	public String toString() {
		return "TransactionHistoryGson [createdAt=" + createdAt
				+ ", transactionType=" + transactionType + ", incomeAmount="
				+ incomeAmount + ", outAmount=" + outAmount
				+ ", availableAmount=" + availableAmount + ", frozenAmount="
				+ frozenAmount + ", remark=" + remark + "]";
	}
    
    
}
