package com.lufax.customerService.resources.gsonTemplate;


public class MessageInfoGson {
    private String updateAt; //更新时间
    private String cmsContext; //短信内容
    private String status;
    private String createAt;//业务触发时间

    public MessageInfoGson() {
    }

    public String getUpdateAt() {
        return updateAt;
    }

    public void setUpdateAt(String updateAt) {
        this.updateAt = updateAt;
    }

    public String getCmsContext() {
        return cmsContext;
    }

    public void setCmsContext(String cmsContext) {
        this.cmsContext = cmsContext;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCreateAt() {
        return createAt;
    }

    public void setCreateAt(String createAt) {
        this.createAt = createAt;
    }
}
