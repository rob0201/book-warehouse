package com.lufax.customerService.resources.gsonTemplate;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import com.lufax.customerService.pojo.CollectionPlanStatus;
import com.lufax.customerService.pojo.SMECollectionPlan;

public class CustomerServiceSmeCollectionHistoryGson {
	//提前还款违约金
	private BigDecimal totalPenalValue = BigDecimal.ZERO;
    //实收逾期管理违约金罚息
	private BigDecimal totalOverduePenalValue = BigDecimal.ZERO;
    //实收本金
    private BigDecimal totalPrincipal = BigDecimal.ZERO;
    //实收利息
    private BigDecimal totalInterest = BigDecimal.ZERO;
    //实收总额
    private BigDecimal totalAmount = BigDecimal.ZERO;
    //实收管理违约金
    private BigDecimal totalManagementFee = BigDecimal.ZERO;
    //已付账户管理费
    private BigDecimal totalInvestmentManagementFee = BigDecimal.ZERO;
    //已付交易管理费
    private BigDecimal totalInvestmentTransactionFee = BigDecimal.ZERO;
    //实收转让金
    private BigDecimal transferAmount =  BigDecimal.ZERO;
    //期数
    private int countOfInstalments;
    //剩余期数
    private int remainingInstalments;
    //收款计划
    private List<CustomerServiceSmeCollectionDetailGson> collectionDetails = new ArrayList<CustomerServiceSmeCollectionDetailGson>();
    
    public CustomerServiceSmeCollectionHistoryGson(List<SMECollectionPlan> collectionPlans){
    	this.countOfInstalments = (collectionPlans==null?0:collectionPlans.size());
    	int i=0;
    	for(SMECollectionPlan collectionPlan : collectionPlans){
    		CustomerServiceSmeCollectionDetailGson collectionDetail = new CustomerServiceSmeCollectionDetailGson(collectionPlan); 
    		if(collectionDetail.getResourceStatus().equals(CollectionPlanStatus.UNCOLLECTED.name())){
    			i++;
    		}
    		collectionDetails.add(collectionDetail);
    		this.totalPenalValue = this.totalPenalValue.add(collectionDetail.getCollectedPenalValue());
    		this.totalOverduePenalValue = this.totalOverduePenalValue.add(collectionDetail.getCollectedOverduePenalty());
    		this.totalPrincipal = this.totalPrincipal.add(collectionDetail.getCollectedPrincipal());
    		this.totalInterest = this.totalInterest.add(collectionDetail.getCollectedInterest());
    		this.totalAmount = this.totalAmount.add(collectionDetail.getCollectedAmount());
    		this.totalManagementFee = this.totalManagementFee.add(collectionDetail.getPaidManagementFee());
    		this.transferAmount = this.transferAmount.add(collectionDetail.getPaidtransferAmount());
    	}
    	this.remainingInstalments = i;
    }

	public BigDecimal getTotalPenalValue() {
		return totalPenalValue;
	}

	public BigDecimal getTotalOverduePenalValue() {
		return totalOverduePenalValue;
	}

	public BigDecimal getTotalPrincipal() {
		return totalPrincipal;
	}

	public BigDecimal getTotalInterest() {
		return totalInterest;
	}

	public BigDecimal getTotalAmount() {
		return totalAmount;
	}

	public BigDecimal getTotalManagementFee() {
		return totalManagementFee;
	}

	public BigDecimal getTotalInvestmentManagementFee() {
		return totalInvestmentManagementFee;
	}

	public BigDecimal getTotalInvestmentTransactionFee() {
		return totalInvestmentTransactionFee;
	}

	public BigDecimal getTransferAmount() {
		return transferAmount;
	}

	public List<CustomerServiceSmeCollectionDetailGson> getCollectionDetails() {
		return collectionDetails;
	}

	public int getCountOfInstalments() {
		return countOfInstalments;
	}

	public int getRemainingInstalments() {
		return remainingInstalments;
	}
    
}
