package com.lufax.customerService.resources.gsonTemplate;

import java.util.Date;

import com.lufax.common.utils.DateUtils;

public class TransferOperateHistoryGson {
    private String operateTime;
    private String operateType;
    private String comment;
    
	public TransferOperateHistoryGson(Date operateTime, String operateType, String comment) {
		
		this.operateTime = DateUtils.formatDateToSeconds(operateTime);
		this.operateType = operateType;
		this.comment = comment;
	}
	public String getOperateTime() {
		return operateTime;
	}
	public void setOperateTime(String operateTime) {
		this.operateTime = operateTime;
	}
	public String getOperateType() {
		return operateType;
	}
	public void setOperateType(String operateType) {
		this.operateType = operateType;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
    
}
