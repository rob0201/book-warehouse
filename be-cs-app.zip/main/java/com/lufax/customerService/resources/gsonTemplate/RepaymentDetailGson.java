package com.lufax.customerService.resources.gsonTemplate;

import com.lufax.common.domain.RepaymentDetail;
import com.lufax.common.domain.RepaymentRecord;
import com.lufax.common.utils.DateUtils;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class RepaymentDetailGson {
    private BigDecimal amount;
    private BigDecimal principal;
    private BigDecimal interest;
    private BigDecimal managementFee;
    private BigDecimal insuranceFee;
    private BigDecimal penalValue;
    private BigDecimal overduePenaltyToPay;

    private BigDecimal paidAmount;
    private BigDecimal paidPrincipal;
    private BigDecimal paidInterest;
    private BigDecimal paidManagementFee;
    private BigDecimal paidInsuranceFee;
    private BigDecimal paidOverduePenalty;

    private BigDecimal remainingAmount;
    private BigDecimal remainingPrincipal;
    private BigDecimal remainingInterest;
    private BigDecimal remainingManagementFee;
    private BigDecimal remainingInsuranceFee;
    private BigDecimal remainingOverduePenalty;

    private long id;
    private int planNumber;
    private String payTime;
    private String status;
    private String endAt;
    private boolean isOnRepaymentDeadline;
    private boolean isOverdue;
    private boolean isWithholding;
    private List<RepaymentRecordGson> repaymentRecords = new ArrayList<RepaymentRecordGson>();

    public RepaymentDetailGson(RepaymentDetail repaymentDetail) {
        amount = repaymentDetail.getAmount().getAmount();
        principal = repaymentDetail.getPrincipal().getAmount();
        interest = repaymentDetail.getInterest().getAmount();
        managementFee = repaymentDetail.getManagementFee().getAmount();
        insuranceFee = repaymentDetail.getInsuranceFee().getAmount();
        penalValue = repaymentDetail.getPenalValue().getAmount();

        overduePenaltyToPay = repaymentDetail.getOverduePenaltyToPay().getAmount();

        paidAmount = repaymentDetail.getPaidAmount().getAmount();
        paidPrincipal = repaymentDetail.getPaidPrincipal().getAmount();
        paidInterest = repaymentDetail.getPaidInterest().getAmount();
        paidManagementFee = repaymentDetail.getPaidManagementFee().getAmount();
        paidInsuranceFee = repaymentDetail.getPaidInsuranceFee().getAmount();
        paidOverduePenalty = repaymentDetail.getPaidOverduePenaltyToPay().getAmount();

        remainingAmount = repaymentDetail.getRemainingAmount().getAmount();
        remainingPrincipal = repaymentDetail.getRemainingPrincipal().getAmount();
        remainingInterest = repaymentDetail.getRemainingInterest().getAmount();
        remainingManagementFee = repaymentDetail.getRemainingManagementFee().getAmount();
        remainingInsuranceFee = repaymentDetail.getRemainingInsuranceFee().getAmount();
        remainingOverduePenalty = repaymentDetail.getRemainingOverduePenaltyToPay().getAmount();

        id = repaymentDetail.id();
        planNumber = repaymentDetail.getPlanNumber();
        payTime = DateUtils.formatDate(repaymentDetail.getPayTime());
        endAt = DateUtils.formatDate(repaymentDetail.getEndAt());

        isOnRepaymentDeadline = org.apache.commons.lang.time.DateUtils.isSameDay(new Date(), repaymentDetail.getEndAt());
        isOverdue = repaymentDetail.isOverdue();
        isWithholding = repaymentDetail.isWithholding();

        status = repaymentDetail.getStatus().getValue();
        for (RepaymentRecord repaymentRecord : repaymentDetail.getRepaymentRecords()) {
            repaymentRecords.add(new RepaymentRecordGson(repaymentRecord));
        }
    }

    public String getEndAt() {
        return endAt;
    }

    public long getId() {
        return id;
    }

    public int getPlanNumber() {
        return planNumber;
    }

    public BigDecimal getPenalValue() {
        return penalValue;
    }

    public BigDecimal getInsuranceFee() {
        return insuranceFee;
    }

    public BigDecimal getManagementFee() {
        return managementFee;
    }

    public BigDecimal getInterest() {
        return interest;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public String getStatus() {
        return status;
    }

    public String getPayTime() {
        return payTime;
    }

    public BigDecimal getPrincipal() {
        return principal;
    }

    public BigDecimal getOverduePenaltyToPay() {
        return overduePenaltyToPay;
    }

    public BigDecimal getPaidAmount() {
        return paidAmount;
    }

    public BigDecimal getPaidPrincipal() {
        return paidPrincipal;
    }

    public BigDecimal getPaidInterest() {
        return paidInterest;
    }

    public BigDecimal getPaidInsuranceFee() {
        return paidInsuranceFee;
    }

    public BigDecimal getPaidOverduePenalty() {
        return paidOverduePenalty;
    }

    public boolean isOnRepaymentDeadline() {
        return isOnRepaymentDeadline;
    }

    public boolean isOverdue() {
        return isOverdue;
    }

    public boolean isWithholding() {
        return isWithholding;
    }
}
