package com.lufax.customerService.resources.gsonTemplate;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

import com.lufax.common.domain.Investment;
import com.lufax.common.domain.Loan;
import com.lufax.common.domain.PlanStatus;
import com.lufax.common.domain.TradeContractType;
import com.lufax.common.domain.TradingStatus;
import com.lufax.common.domain.account.Money;
import com.lufax.common.domain.product.Product;
import com.lufax.common.domain.product.TransferRequest;
import com.lufax.common.domain.product.TransferRequestData;
import com.lufax.common.resources.LinkRelationType;
import com.lufax.common.utils.DateUtils;
import com.lufax.customerService.domain.TransferOperationDetail;

public class CustomerServiceInvestmentGson {
	private long id;
    private String loanCode;
    private String loanRequestCode;
    private String loaneeName;
    private BigDecimal paidPrincipal = BigDecimal.ZERO;
    private BigDecimal totalInterest = BigDecimal.ZERO;
    private BigDecimal totalPaidAmount = BigDecimal.ZERO;
    private BigDecimal principal = BigDecimal.ZERO;
    private int remainingInstalments;
    private int countOfInstalments;
    private String startAt;
    private String endedAt;
    private String scheduledEndedAt;
    private String status;
    private String annualInterestRate;
    private int currentInstalment;
    private LinkGson collectionDetailsLink;
    private String contractLink;
    private String authContractLink;
    private String splitContractLink;
    private boolean overdue;
    private boolean compensate;
    private boolean isSecondaryMarket;
    private boolean isSplitProduct = false;
    private String productName;
    private String applyAt;
    private BigDecimal totalAmount = BigDecimal.ZERO;
    
    private String compensateApplyContractLink;
    private String compensateConfirmContractUrl;
    private String transferContractUrl;
    
    private boolean transferContractFlag;
   
    private List<TransferRequestGson> transferRequestGsons = new ArrayList<TransferRequestGson>();
    private CollectionHistoryGson collectionHistoryGson;
    private List<CollectionDetailGson> collectionDetailGsons;
    private List<TransferOperateHistoryGson> transferOperationHistory = new ArrayList<TransferOperateHistoryGson>();
    
//    public CustomerServiceInvestmentGson(Investment investment, Money paidPrincipal,List<CollectionDetailGson> collectionDetailGsons){
//    	Loan loan = investment.getLoan();
//        this.id = investment.id();
//        this.loanCode = loan.getCode();
//        this.loanRequestCode = investment.getProduct().getProductCode();
//        this.loaneeName = investment.getLoaneeUsername();
//        this.paidPrincipal = paidPrincipal.getAmount();
//        if("TIME_SPLIT".equals(investment.getProduct().getProductType())) {
//        	this.productName = "稳盈-接利贷";
//        } else {
//        	this.productName = "稳盈-安e贷";
//        }
//        this.totalInterest = investment.getTotalInterest().getAmount();
//        this.principal = investment.getPrincipal().getAmount();
//        this.remainingInstalments = investment.getRemainingInstalments(); //*
//        this.countOfInstalments = investment.getRealNumberOfInstalments();
//        this.startAt = DateUtils.formatDate(investment.getStartAt());
//        this.endedAt = getEndAt(investment);
//        // this.scheduledEndedAt = DateUtils.formatDate(investment.getLastCollectionPlan() != null ? investment.getLastCollectionPlan().getEndAt() : null);
//        this.scheduledEndedAt = getEndAt(investment);
//        this.status = investment.getStatus().getValue();
//        this.annualInterestRate = loan.getAnnualInterestRate().toString();
//        this.currentInstalment = investment.getCurrentPlanNumber();
//        this.overdue = investment.isOverdue();
//        this.compensate = investment.isCompensate();
//        this.collectionDetailsLink = new LinkGson("/investments/" + investment.id() + "/collection-details", LinkRelationType.RELATED);
//        this.contractLink = new LinkGson("/investments/" + investment.id() + "/contract/" + TradeContractType.LOAN, LinkRelationType.RELATED).getHref();
//        this.authContractLink = new LinkGson("/investments/" + investment.id() + "/contract/" + TradeContractType.AUTHORIZATION, LinkRelationType.RELATED).getHref();
//        this.collectionDetailGsons = collectionDetailGsons;
//        this.applyAt =  DateUtils.formatDate(investment.getInvestmentRequest().getCreatedAt()!= null ? investment.getInvestmentRequest().getCreatedAt() : null);
//    }
    
    private String getEndAt(Investment investment) {
        if (investment.getStatus().isSettled()) {
            if (investment.isTransferred()) {
                return DateUtils.formatDate((null == investment.getLatestTransferRequest()) ? new Date() : investment.getLatestTransferRequest().getCreatedAt());
            }
            return DateUtils.formatDate(investment.getLoan().getEndedAt());
        } else {
            if ("TIME_SPLIT".equals(investment.getProduct().getProductType())) {
                return DateUtils.formatDate(investment.getLastHoldingCollectionPlan().getEndAt());
            } else {
                return DateUtils.formatDate(investment.getLoan().getScheduledEndAt());
            }
        }
    }
    
    public CustomerServiceInvestmentGson(Investment investment,CollectionHistoryGson collectionHistoryGson){
    	Loan loan = investment.getLoan();
    	Product product = investment.getProduct();
        this.id = investment.id();
        this.loanCode = loan.getCode();
        this.loanRequestCode = product.getProductCode();
        this.countOfInstalments = investment.getRealNumberOfInstalments();
//        this.countOfInstalments = investment.getProduct().getNumberOfInstalments();
        this.loaneeName = investment.getLoaneeUsername();
//        if (product.isPrimary()) {
//            this.startAt = DateUtils.formatDate(investment.getLoan().getStartAt());
//        } else if (product.isSecondary()) {
//            this.startAt = DateUtils.formatDate(investment.getCreatedAt());
//        }
        this.startAt = investment.getStartAtForDisplay();
//        this.paidPrincipal = investment.getAllCollectedPrincipal().getAmount();
        
        
        
        this.remainingInstalments = investment.getRemainingInstalments(); //*
//        this.endedAt = getEndAt(investment);
        this.endedAt = investment.getEndAtForDisplay();
//        this.scheduledEndedAt = DateUtils.formatDate(investment.getLoan()!= null ? investment.getLoan().getScheduledEndAt(): null);
        this.scheduledEndedAt = investment.getEndAtForDisplay();
        this.status = investment.getStatus().getValue();
        this.annualInterestRate = loan.getAnnualInterestRate().toString();
        this.currentInstalment = investment.getCurrentPlanNumber();
        this.overdue = investment.isOverdue();
        this.compensate = investment.isCompensate();
        if (product.isPrimary() && !investment.getStatus().equals(TradingStatus.TRANSFER)) {
        	this.contractLink = new LinkGson("/investments/detail/" + investment.id() + "/contract/" + TradeContractType.LOAN, LinkRelationType.RELATED).getHref();
            this.authContractLink = new LinkGson("/investments/detail/" + investment.id() + "/contract/" + TradeContractType.AUTHORIZATION, LinkRelationType.RELATED).getHref();
            this.isSecondaryMarket = false;
            this.transferContractFlag = false;
        }else if(product.isPrimary() && investment.getStatus().equals(TradingStatus.TRANSFER)){
        	this.contractLink = new LinkGson("/investments/detail/" + investment.id() + "/contract/" + TradeContractType.LOAN, LinkRelationType.RELATED).getHref();
            this.authContractLink = new LinkGson("/investments/detail/" + investment.id() + "/contract/" + TradeContractType.AUTHORIZATION, LinkRelationType.RELATED).getHref();
            this.transferContractUrl =  new LinkGson("/investments/detail/" + investment.id() + "/secondary-contract/" + TradeContractType.TRANSFER, LinkRelationType.RELATED).getHref();
            this.isSecondaryMarket = false;
            this.transferContractFlag = true;
        } else if (product.isSecondary()) {
        	this.transferContractUrl = new LinkGson("/investments/detail/" + investment.id() + "/secondary-contract/" + TradeContractType.TRANSFER, LinkRelationType.RELATED).getHref();
            this.authContractLink = new LinkGson("/investments/detail/" + investment.id() + "/secondary-contract/" + TradeContractType.AUTHORIZATION_2ND, LinkRelationType.RELATED).getHref();
            this.isSecondaryMarket = true;
            this.transferContractFlag = false;
        } else if (product.isSplited()) {
        	this.transferContractUrl = new LinkGson("/investments/detail/" + investment.id() + "/secondary-contract/" + TradeContractType.TRANSFER, LinkRelationType.RELATED).getHref();
            this.authContractLink = new LinkGson("/investments/detail/" + investment.id() + "/secondary-contract/" + TradeContractType.AUTHORIZATION_2ND, LinkRelationType.RELATED).getHref();
            // TODO
//            "service/users/{userId}/investments/detail/{investmentId}/split-contract/{contractType}/download"
            this.splitContractLink = new LinkGson(String.format("/users/{userId}/investments/detail/{investmentId}/split-contract/{contractType}/download", investment.getLoan().id(),investment.id(), TradeContractType.TRANSFER), LinkRelationType.RELATED).getHref();
            this.isSecondaryMarket = false;
            this.transferContractFlag = false;
            this.isSplitProduct = true;
        }
        this.compensateApplyContractLink=new LinkGson("/investments/detail/" + investment.id() + "/compensate-apply-contract-download", LinkRelationType.RELATED).getHref();
        this.compensateConfirmContractUrl=new LinkGson("/investments/detail/" + investment.id() + "/compensate-confirm-contract-download", LinkRelationType.RELATED).getHref();
        this.collectionDetailsLink = new LinkGson("/investments/" + investment.id() + "/collection-details", LinkRelationType.RELATED);
//        this.collectionHistoryGson = convertCollectionHistoryGson(collectionHistoryGson,investment);
        this.collectionHistoryGson = collectionHistoryGson;
        for(TransferRequest transferRequest:investment.getTransferRequests()){
        	this.transferRequestGsons.add(new TransferRequestGson(transferRequest));
        	TransferOperateHistoryGson temp = createTransferOperateHistoryGson(investment,transferRequest);
        	if(temp != null) {
        		this.transferOperationHistory.add(createTransferOperateHistoryGson(investment,transferRequest));
        	}
        }
        if("TIME_SPLIT".equals(investment.getProduct().getProductType())) {
        	this.productName = "稳盈-接利贷";
        	this.totalAmount = collectionHistoryGson.getTotalAmount();
        	for(CollectionDetailGson detail : collectionHistoryGson.getCollectionDetails()) {
        		
        		this.paidPrincipal = this.paidPrincipal.add(detail.getCollectedPrincipal());
        		this.totalPaidAmount = this.totalPaidAmount.add(detail.getCollectedAmount());
        		this.totalInterest = this.totalInterest.add(detail.getInterest());
        	}
        } else if("LOAN_REQUEST".equals(investment.getProduct().getProductType()) && "9".equals(investment.getProduct().getSourceType()) ){
        	this.productName = "稳盈-安e贷二期";
        	this.totalAmount = investment.getTotalAmount().getAmount();
        	this.paidPrincipal = investment.getAllCollectedPrincipal().getAmount();
        	this.totalPaidAmount = getCollectedAmount(investment);
        	this.totalInterest = investment.getTotalInterest().getAmount();
        } else {
        	this.productName = "稳盈-安e贷";
        	this.totalAmount = investment.getTotalAmount().getAmount();
        	this.paidPrincipal = investment.getAllCollectedPrincipal().getAmount();
        	this.totalPaidAmount = getCollectedAmount(investment);
        	this.totalInterest = investment.getTotalInterest().getAmount();
        }
        
        this.principal = investment.getPrincipal().getAmount();
        this.applyAt =  DateUtils.formatDate(investment.getInvestmentRequest().getCreatedAt()!= null ? investment.getInvestmentRequest().getCreatedAt() : null);
        
    }
    
    private CollectionHistoryGson convertCollectionHistoryGson(CollectionHistoryGson collectionHistory, Investment investment) {
    	// if the product is split
    	if(investment.getProduct().isSplited()) {
    		List<CollectionDetailGson> gson = collectionHistory.getCollectionDetails();
    		List<CollectionDetailGson> result = new ArrayList<CollectionDetailGson>();
    		BigDecimal remainAmount = BigDecimal.ZERO;
    		
    		for(int i =0 ; i < gson.size(); i++) {
    			
    			CollectionDetailGson temp = gson.get(i);
    			
    			
    			

    			if(i< investment.getNumberOfInstalments() ) {
    				result.add(temp);
    			} else {
    				
    				CollectionDetailGson lastDetail = result.get(investment.getNumberOfInstalments()-1);
    				
    				lastDetail.setAmount(lastDetail.getAmount().add(temp.getPrincipal()));
    	    		lastDetail.setCollectedAmount(lastDetail.getCollectedAmount().add(temp.getPrincipal()));
    	    		lastDetail.setCollectedPrincipal(lastDetail.getCollectedPrincipal().add(temp.getCollectedPrincipal()));
//    	    		lastDetail.setManagementFee(lastDetail.getManagementFee().add(temp.getManagementFee()));
//    	    		lastDetail.setPaidManagementFee(lastDetail.getPaidManagementFee().add(temp.getPaidManagementFee()));
    	    		lastDetail.setPaidUpAmount(lastDetail.getPaidUpAmount().add(temp.getPaidUpAmount()));
    	    		lastDetail.setPrincipal(lastDetail.getPrincipal().add(temp.getPrincipal()));
    	    		lastDetail.setRemainingAmount(lastDetail.getRemainingAmount().add(temp.getRemainingAmount()));
//    	    		lastDetail.setRemainingManagementFee(lastDetail.getRemainingManagementFee().add(temp.getRemainingManagementFee()));
    	    		lastDetail.setRemainingPrincipal(lastDetail.getRemainingPrincipal().add(temp.getRemainingPrincipal()));
    	    		
//    	    		lastDetail.getCollectionRecords()
    	    		
    	    		remainAmount = remainAmount.add(temp.getPrincipal());
    	    		if(i == gson.size() -1 && (PlanStatus.PAID.getValue().equals(temp.getStatus()) || PlanStatus.PREPAID.getValue().equals(temp.getStatus()) || PlanStatus.TRANSFER.getValue().equals(temp.getStatus()) || PlanStatus.COMP_DONE.getValue().equals(temp.getStatus()))) {
    	    			String payTime = lastDetail.getCollectionRecords().get(0).getPayTime();
        				lastDetail.getCollectionRecords().add(getSplitProductPaymentPricipal(remainAmount, payTime, lastDetail.getCollectionRecords().size()));
//        				lastDetail.setCollectedAmount(lastDetail.getAmount());
//        				lastDetail.setPrincipal(lastDetail.getPrincipal());
//        				lastDetail.setCollectedPrincipal(lastDetail.getCollectedPrincipal());
        			}
    			}
    			//    PAID(Type.SETTLED, "已付清", "1"),
//    		    PREPAID(Type.SETTLED, "提前还清", "4"),
//    		    TRANSFER(Type.SETTLED, "已转让", "7"),
//    		    COMP_DONE(Type.SETTLED, "代偿后结清", "5"),
    			 
    		}
    		collectionHistory.setCollectionDetails(result);
    		
    		collectionHistory.setTotalAmount(BigDecimal.ZERO);
			collectionHistory.setTotalInterest(BigDecimal.ZERO);
			collectionHistory.setTotalManagementFee(BigDecimal.ZERO);
			collectionHistory.setTotalPrincipal(BigDecimal.ZERO);
    		for(CollectionDetailGson detail : result) {
    			if((PlanStatus.PAID.getValue().equals(detail.getStatus()) || PlanStatus.PREPAID.getValue().equals(detail.getStatus()) || PlanStatus.TRANSFER.getValue().equals(detail.getStatus()) || PlanStatus.COMP_DONE.getValue().equals(detail.getStatus()))) {
					collectionHistory.setTotalPrincipal(collectionHistory.getTotalPrincipal().add(detail.getPrincipal()));
					collectionHistory.setTotalAmount(collectionHistory.getTotalAmount().add(detail.getCollectedAmount()));
//					System.out.println(collectionHistory.getTotalAmount());
					collectionHistory.setTotalManagementFee(collectionHistory.getTotalManagementFee().add(detail.getManagementFee()));
					collectionHistory.setTotalInterest(collectionHistory.getTotalInterest().add(detail.getCollectedInterest()));// interest
				}
			}
    	} 
    	return collectionHistory;
    }
    
    private CollectionRecordGson getSplitProductPaymentPricipal(BigDecimal remainAmount, String payTime, int planNumber) {
    	
    	CollectionRecordGson record = new CollectionRecordGson();
    	record.setAmount(remainAmount);
    	record.setInterest(BigDecimal.ZERO);
    	record.setManagementFee(BigDecimal.ZERO);
    	record.setOverduePenalValue(BigDecimal.ZERO);
    	record.setPaidUpAmount(BigDecimal.ZERO);
    	record.setPayTime(payTime);
    	record.setPenalValue(BigDecimal.ZERO);
    	record.setPlanNumber(planNumber);
    	record.setPrincipal(remainAmount);
    	return record;
    }
    
    public long getId() {
        return id;
    }

    public String getLoanCode() {
        return loanCode;
    }

    public String getLoaneeName() {
        return loaneeName;
    }

    public BigDecimal getPaidPrincipal() {
        return paidPrincipal;
    }

    public BigDecimal getTotalInterest() {
        return totalInterest;
    }

    public BigDecimal getPrincipal() {
        return principal;
    }

    public int getRemainingInstalments() {
        return remainingInstalments;
    }

    public int getCountOfInstalments() {
        return countOfInstalments;
    }

    public String getStartAt() {
        return startAt;
    }

    public String getEndedAt() {
        return endedAt;
    }

    public String getScheduledEndedAt() {
        return scheduledEndedAt;
    }

    public String getStatus() {
        return status;
    }

    public String getAnnualInterestRate() {
        return annualInterestRate;
    }

    public String getAuthContractLink() {
        return authContractLink;
    }

    public int getCurrentInstalment() {
        return currentInstalment;
    }

    public LinkGson getCollectionDetailsLink() {
        return collectionDetailsLink;
    }

    public String getContractLink() {
        return contractLink;
    }

	@Override
    public boolean equals(Object o) {
        return EqualsBuilder.reflectionEquals(this, o);
    }

    @Override
    public int hashCode() {
        return HashCodeBuilder.reflectionHashCode(this);
    }

    public boolean isOverdue() {
        return overdue;
    }

    public boolean isCompensate() {
        return compensate;
    }

	public List<CollectionDetailGson> getCollectionDetailGsons() {
		return collectionDetailGsons;
	}

	public CollectionHistoryGson getCollectionHistoryGson() {
		return collectionHistoryGson;
	}    
	
	private BigDecimal getCollectedAmount(Investment investment) {
        if (null == investment.getLatestTransferRequest() || !investment.getLatestTransferRequest().isTransferSuccess()) {
            return investment.getIncomeBeforeTransferred().getAmount();
        }
        return investment.getIncomeBeforeTransferred().add(investment.getLatestTransferRequest().getPrincipal()).subtract(investment.getLatestTransferRequest().getTransferFee()).getAmount();
    }

	public String getLoanRequestCode() {
		return loanRequestCode;
	}

	public void setLoanRequestCode(String loanRequestCode) {
		this.loanRequestCode = loanRequestCode;
	}

	public BigDecimal getTotalPaidAmount() {
		return totalPaidAmount;
	}

	public void setTotalPaidAmount(BigDecimal totalPaidAmount) {
		this.totalPaidAmount = totalPaidAmount;
	}

	public boolean isSecondaryMarket() {
		return isSecondaryMarket;
	}

	public void setSecondaryMarket(boolean isSecondaryMarket) {
		this.isSecondaryMarket = isSecondaryMarket;
	}


	public List<TransferRequestGson> getTransferRequestGsons() {
		return transferRequestGsons;
	}

	public void setTransferRequestGsons(
			List<TransferRequestGson> transferRequestGsons) {
		this.transferRequestGsons = transferRequestGsons;
	}

	public void setId(long id) {
		this.id = id;
	}

	public void setLoanCode(String loanCode) {
		this.loanCode = loanCode;
	}

	public void setLoaneeName(String loaneeName) {
		this.loaneeName = loaneeName;
	}

	public void setPaidPrincipal(BigDecimal paidPrincipal) {
		this.paidPrincipal = paidPrincipal;
	}

	public void setTotalInterest(BigDecimal totalInterest) {
		this.totalInterest = totalInterest;
	}

//	public void setPrincipal(BigDecimal principal) {
//		this.principal = principal;
//	}

	public void setRemainingInstalments(int remainingInstalments) {
		this.remainingInstalments = remainingInstalments;
	}

	public void setCountOfInstalments(int countOfInstalments) {
		this.countOfInstalments = countOfInstalments;
	}

	public void setStartAt(String startAt) {
		this.startAt = startAt;
	}

	public void setEndedAt(String endedAt) {
		this.endedAt = endedAt;
	}

	public void setScheduledEndedAt(String scheduledEndedAt) {
		this.scheduledEndedAt = scheduledEndedAt;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public void setAnnualInterestRate(String annualInterestRate) {
		this.annualInterestRate = annualInterestRate;
	}

	public void setCurrentInstalment(int currentInstalment) {
		this.currentInstalment = currentInstalment;
	}

	public void setCollectionDetailsLink(LinkGson collectionDetailsLink) {
		this.collectionDetailsLink = collectionDetailsLink;
	}

	public void setContractLink(String contractLink) {
		this.contractLink = contractLink;
	}

	public void setAuthContractLink(String authContractLink) {
		this.authContractLink = authContractLink;
	}

	public void setOverdue(boolean overdue) {
		this.overdue = overdue;
	}

	public void setCompensate(boolean compensate) {
		this.compensate = compensate;
	}

	public void setCollectionHistoryGson(CollectionHistoryGson collectionHistoryGson) {
		this.collectionHistoryGson = collectionHistoryGson;
	}

	public void setCollectionDetailGsons(
			List<CollectionDetailGson> collectionDetailGsons) {
		this.collectionDetailGsons = collectionDetailGsons;
	}

	public String getProductName() {
		return productName;
	}

	public BigDecimal getTotalAmount() {
		return totalAmount;
	}

	public String getCompensateApplyContractLink() {
		return compensateApplyContractLink;
	}

	public String getCompensateConfirmContractUrl() {
		return compensateConfirmContractUrl;
	}

	public String getApplyAt() {
		return applyAt;
	}

	public String getTransferContractUrl() {
		return transferContractUrl;
	}

	public boolean isTransferContractFlag() {
		return transferContractFlag;
	}
	private TransferOperateHistoryGson createTransferOperateHistoryGson(Investment investment, TransferRequest transferRequest) {
        if (transferRequest.isTransferApplied()) {
            return new TransferOperateHistoryGson(transferRequest.getCreatedAt(), TransferOperationDetail.OPERATE_TRANSFER_APPLIED.getDisplay(), String.format(TransferOperationDetail.OPERATE_TRANSFER_APPLIED.getComment(), transferRequest.getTransferRequestData().getTransferPrice().getAmount()));
        }
        if (transferRequest.isManualCancelled()) {
            return new TransferOperateHistoryGson(transferRequest.getCreatedAt(), TransferOperationDetail.OPERATE_MANUAL_CANCEL.getDisplay(), TransferOperationDetail.OPERATE_MANUAL_CANCEL.getComment());
        }
        if (transferRequest.isSystemExpireCancelled()) {
            return new TransferOperateHistoryGson(transferRequest.getCreatedAt(), TransferOperationDetail.OPERATE_SYSTEM_EXPIRE_CANCEL.getDisplay(), TransferOperationDetail.OPERATE_SYSTEM_EXPIRE_CANCEL.getComment());
        }
        if (transferRequest.isSystemPrepayCancelled()) {
            return new TransferOperateHistoryGson(transferRequest.getCreatedAt(), TransferOperationDetail.OPERATE_SYSTEM_PREPAY_CANCEL.getDisplay(), TransferOperationDetail.OPERATE_SYSTEM_PREPAY_CANCEL.getComment());
        }
        if (transferRequest.isTransferSuccess()) {
            TransferRequestData transferRequestData = investment.getTransferRequestOfApplied(transferRequest.getCode());
            Money transferPrincipal = (null == transferRequestData) ? Money.ZERO_YUAN : transferRequestData.getTransferPrincipal();
            Money transferFee = (null == transferRequestData) ? Money.ZERO_YUAN : transferRequestData.getTransferFee();
            return new TransferOperateHistoryGson(transferRequest.getCreatedAt(), TransferOperationDetail.OPERATE_TRANSFER_SUCCESS.getDisplay(), String.format(TransferOperationDetail.OPERATE_TRANSFER_SUCCESS.getComment(), transferPrincipal, transferFee));
        }
        return null;
    }
	
	
}
