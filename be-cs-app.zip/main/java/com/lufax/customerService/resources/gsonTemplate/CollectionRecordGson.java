package com.lufax.customerService.resources.gsonTemplate;

import com.lufax.common.domain.CollectionRecord;
import com.lufax.common.utils.DateUtils;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

import java.math.BigDecimal;

import static com.lufax.common.utils.BigDecimalUtils.subtract;

public class CollectionRecordGson {
    private int planNumber;
    private String payTime;
    private BigDecimal amount;
    private BigDecimal principal;
    private BigDecimal interest;
    private BigDecimal penalValue;
    private BigDecimal overduePenalValue;
    private BigDecimal managementFee;
    private BigDecimal paidUpAmount;

    public CollectionRecordGson(){
    }
    
    public void setPlanNumber(int planNumber) {
		this.planNumber = planNumber;
	}

	public void setPayTime(String payTime) {
		this.payTime = payTime;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public void setPrincipal(BigDecimal principal) {
		this.principal = principal;
	}

	public void setInterest(BigDecimal interest) {
		this.interest = interest;
	}

	public void setPenalValue(BigDecimal penalValue) {
		this.penalValue = penalValue;
	}

	public void setOverduePenalValue(BigDecimal overduePenalValue) {
		this.overduePenalValue = overduePenalValue;
	}

	public void setManagementFee(BigDecimal managementFee) {
		this.managementFee = managementFee;
	}

	public void setPaidUpAmount(BigDecimal paidUpAmount) {
		this.paidUpAmount = paidUpAmount;
	}

	public CollectionRecordGson(CollectionRecord collectionRecord) {
        this.planNumber = collectionRecord.getRecordNumber();
        this.payTime = DateUtils.formatDate(collectionRecord.getUpdatedAt());
        this.amount = collectionRecord.getAmount().getAmount().subtract(collectionRecord.getInvestmentManagementFee().getAmount());
        this.principal = collectionRecord.getPrincipal().getAmount();
        this.interest = collectionRecord.getInterest().getAmount();
        this.penalValue = collectionRecord.getPenalValue().getAmount();
        this.overduePenalValue = collectionRecord.getOverduePenalValue().getAmount();
//        this.managementFee = collectionRecord.getManagementFee().getAmount();
        this.managementFee = collectionRecord.getInvestmentManagementFee().getAmount();
        this.paidUpAmount = subtract(amount, managementFee);
    }

    @Override
    public boolean equals(Object o) {
        return EqualsBuilder.reflectionEquals(this, o);
    }

    @Override
    public int hashCode() {
        return HashCodeBuilder.reflectionHashCode(this);
    }

	public String getPayTime() {
		return payTime;
	}
    
}
