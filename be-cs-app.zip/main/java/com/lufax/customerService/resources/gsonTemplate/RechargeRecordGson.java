package com.lufax.customerService.resources.gsonTemplate;

import java.math.BigDecimal;

import com.lufax.common.domain.RechargeRecord;
import com.lufax.common.utils.DateUtils;

public class RechargeRecordGson {
    private String id;
    private String rechargeType;
    private BigDecimal amount;
    private BigDecimal rechargeFee;
    private BigDecimal netAmount;
    private String rechargeStatus;
    private String rechargeAt;
    private String tradeNo;
    private String errorDescription;
    private String description;

    public RechargeRecordGson(RechargeRecord rechargeRecord, String description) {
        this(rechargeRecord);
        this.description = description;
    }

     public RechargeRecordGson(RechargeRecord rechargeRecord) {
        this.id = String.valueOf(rechargeRecord.id());
        this.amount = rechargeRecord.getAmount().getAmount();
        this.rechargeFee = rechargeRecord.getRechargeFee().getAmount();
        this.netAmount = rechargeRecord.getNetAmount().getAmount();
        this.rechargeAt = DateUtils.formatDateTime(rechargeRecord.getRechargeAt());
        this.rechargeType = rechargeRecord.getRechargeType().getValue();
        this.rechargeStatus = rechargeRecord.getRechargeStatus().getValue();
        this.tradeNo = rechargeRecord.getTradeNo();
        this.errorDescription = rechargeRecord.getFailDescription();
        this.description = rechargeRecord.getRemark();
    }

    public String getId() {
        return id;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public BigDecimal getRechargeFee() {
        return rechargeFee;
    }

    public BigDecimal getNetAmount() {
        return netAmount;
    }

    public String getRechargeAt() {
        return rechargeAt;
    }

    public String getRechargeType() {
        return rechargeType;
    }

    public String getRechargeStatus() {
        return rechargeStatus;
    }

    public String getTradeNo() {
        return tradeNo;
    }

	public String getErrorDescription() {
		return errorDescription;
	}

	public void setErrorDescription(String errorDescription) {
		this.errorDescription = errorDescription;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
    
}
