package com.lufax.customerService.resources.gsonTemplate;

import com.lufax.common.domain.RepaymentDetail;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import static com.lufax.common.utils.BigDecimalUtils.add;

public class RepaymentHistoryGson {
    private BigDecimal totalAmount = BigDecimal.ZERO;
    private BigDecimal totalPrincipal = BigDecimal.ZERO;
    private BigDecimal totalInterest = BigDecimal.ZERO;
    private BigDecimal totalManagementFee = BigDecimal.ZERO;
    private BigDecimal totalInsuranceFee = BigDecimal.ZERO;
    private BigDecimal totalPenalValue = BigDecimal.ZERO;
    private BigDecimal insuranceManagementFee = BigDecimal.ZERO;
    private BigDecimal totalOverduePenalValue = BigDecimal.ZERO;
    private List<RepaymentDetailGson> repaymentDetails = new ArrayList<RepaymentDetailGson>();

    public RepaymentHistoryGson(List<RepaymentDetail> repaymentDetails) {
        for (RepaymentDetail repaymentDetail : repaymentDetails) {
            this.totalPenalValue = add(this.totalPenalValue, repaymentDetail.getPaidPenalValue().getAmount());
            this.insuranceManagementFee = add(this.insuranceManagementFee, repaymentDetail.getPaidInsuranceManagementFee().getAmount());
            this.totalPrincipal = add(this.totalPrincipal, repaymentDetail.getPaidPrincipal().getAmount());
            this.totalInsuranceFee = add(this.totalInsuranceFee, repaymentDetail.getPaidInsuranceFee().getAmount());
            this.totalInterest = add(this.totalInterest, repaymentDetail.getPaidInterest().getAmount());
            this.totalManagementFee = add(this.totalManagementFee, repaymentDetail.getPaidManagementFee().getAmount());
            this.totalOverduePenalValue = add(this.totalOverduePenalValue, repaymentDetail.getPaidOverduePenaltyToPay().getAmount());
            this.repaymentDetails.add(new RepaymentDetailGson(repaymentDetail));
        }
        this.totalAmount = add(add(add(add(add(this.totalPenalValue, this.totalInsuranceFee), this.totalInterest), this.totalManagementFee), this.totalPrincipal), this.totalOverduePenalValue).add(insuranceManagementFee);
    }

    public BigDecimal getTotalPenalValue() {
        return totalPenalValue;
    }

    public List<RepaymentDetailGson> getRepaymentDetails() {
        return repaymentDetails;
    }

    public BigDecimal getTotalPrincipal() {
        return totalPrincipal;
    }

    public BigDecimal getTotalInterest() {
        return totalInterest;
    }

    public BigDecimal getTotalManagementFee() {
        return totalManagementFee;
    }

    public BigDecimal getTotalInsuranceFee() {
        return totalInsuranceFee;
    }

    public BigDecimal getTotalAmount() {
        return totalAmount;
    }
}
