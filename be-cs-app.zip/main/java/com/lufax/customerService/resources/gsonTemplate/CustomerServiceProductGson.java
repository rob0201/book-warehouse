package com.lufax.customerService.resources.gsonTemplate;

import java.math.BigDecimal;

import com.lufax.common.domain.product.Product;
import com.lufax.common.utils.DateUtils;

public class CustomerServiceProductGson {
	private long productId;
    private String code;
    private BigDecimal interestRate;
    private int numberOfInstalments;
    private String productStatus;
    private String expiredAt;
    private String updateAt;
    private String publishedAt;
    private String price;
    private String principal;
    private String productType;

    public CustomerServiceProductGson(Product product) {
        this.productId = product.id();
        this.productStatus = product.getProductStatus();
        this.expiredAt = DateUtils.formatDate(product.getExpiredAt());
        this.updateAt = DateUtils.formatDate(product.getUpdatedAt());
        this.publishedAt = DateUtils.formatDate(product.getPublishedAt());
        this.price = product.getPrice().amountToString();
        this.principal = product.getPrincipal().amountToString();
        this.productType = product.getProductType().toString();
        this.code = product.getProductCode();
        this.numberOfInstalments = product.getNumberOfInstalments();
        this.interestRate = product.getInterestRate();
    }


    public long getProductId() {
        return productId;
    }

    public String getCode() {
        return code;
    }

    public BigDecimal getInterestRate() {
        return interestRate;
    }

    public int getNumberOfInstalments() {
        return numberOfInstalments;
    }

    public String getProductStatus() {
        return productStatus;
    }

    public String getExpiredAt() {
        return expiredAt;
    }

    public String getPublishedAt() {
        return publishedAt;
    }

    public String getPrice() {
        return price;
    }

    public String getPrincipal() {
        return principal;
    }

    public String getProductType() {
        return productType;
    }

    public String getUpdateAt() {

        return updateAt;
    }

    public void setUpdateAt(String updateAt) {
        this.updateAt = updateAt;
    }
}
