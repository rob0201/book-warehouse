package com.lufax.customerService.resources.gsonTemplate;


import com.lufax.common.utils.DateUtils;
import com.lufax.customerService.domain.RareWords;

public class RareWordsGson {

    private long id;
    private String words;
    private String createdAt;
    private String createdBy;
    private String updatedAt;
    private String updatedBy;
    private boolean isAvailable;

    public RareWordsGson(RareWords rareWords ) {
        this.words = rareWords.getWord();
        this.id= rareWords.id();
        this.createdAt= DateUtils.formatDateTime(rareWords.getCreatedAt());
        this.createdBy= rareWords.getCreatedBy();
        this.updatedBy=rareWords.getUpdatedBy();
        this.updatedAt=DateUtils.formatDateTime(rareWords.getUpdatedAt());
        this.isAvailable=rareWords.isAvailable();
    }

    public String getWords() {
        return words;
    }

    public void setWords(String words) {
        this.words = words;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }
}
