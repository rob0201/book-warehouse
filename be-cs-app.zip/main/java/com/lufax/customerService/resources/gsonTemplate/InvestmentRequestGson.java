package com.lufax.customerService.resources.gsonTemplate;

import java.math.BigDecimal;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

import com.lufax.common.domain.InvestmentRequest;
import com.lufax.common.domain.product.Product;
import com.lufax.common.utils.DateUtils;

public class InvestmentRequestGson {
    private String loanRequestCode;
    private BigDecimal loanRequestAmount;
    private BigDecimal interestRate;
    private Integer numberOfInstalments;
    private String investmentRequestDate;
    private String status;
    private String loanCode;
    private String statusDescription;
    private String statusCustomerDescription;
    private BigDecimal totalIncome;
    private long productId;
    private String productCode;
    private String productName;

    public InvestmentRequestGson(InvestmentRequest investmentRequest) {
    	Product product = investmentRequest.getProduct();
    	this.productId = product.id();
    	this.productCode = product.getProductCode();
    	this.productName = "稳盈-安e贷";
        this.loanRequestCode = investmentRequest.getLoanRequest().getCode();
        this.loanRequestAmount = investmentRequest.getLoanRequest().getAppliedAmount().getAmount();
        this.interestRate = investmentRequest.getLoanRequest().getInterestRate();
        this.numberOfInstalments = investmentRequest.getLoanRequest().getNumberOfInstalments();
        this.investmentRequestDate = DateUtils.formatDate(investmentRequest.getCreatedAt());
        this.statusDescription = investmentRequest.getStatus().getValue();
        this.statusCustomerDescription = investmentRequest.getStatus().getCustomerServiceDesc();
        this.status = investmentRequest.getStatus().toString();
        this.loanCode = investmentRequest.getLoanCode();
    }

    public String getLoanRequestCode() {
        return loanRequestCode;
    }


    public BigDecimal getLoanRequestAmount() {
        return loanRequestAmount;
    }

    public BigDecimal getInterestRate() {
        return interestRate;
    }

    public Integer getNumberOfInstalments() {
        return numberOfInstalments;
    }

    public String getInvestmentRequestDate() {
        return investmentRequestDate;
    }


    public String getStatus() {
        return status;
    }

    public String getLoanCode() {
        return loanCode;
    }

    public String getStatusCustomerDescription() {
        return statusCustomerDescription;
    }

    public BigDecimal getTotalIncome() {
		return totalIncome;
	}

	public long getProductId() {
		return productId;
	}

	public String getProductCode() {
		return productCode;
	}

	public String getProductName() {
		return productName;
	}

	@Override
    public boolean equals(Object o) {
        return EqualsBuilder.reflectionEquals(this, o);
    }

    @Override
    public int hashCode() {
        return HashCodeBuilder.reflectionHashCode(this);
    }
}
