package com.lufax.customerService.resources.gsonTemplate;

import com.lufax.common.domain.ASGuaranteedNote;
import com.lufax.common.domain.Loan;
import com.lufax.common.domain.TradeContractType;
import com.lufax.common.domain.account.Money;
import com.lufax.common.resources.LinkRelationType;
import com.lufax.common.utils.DateUtils;

import java.math.BigDecimal;

public class LoanGson {
    private long id;
    private String loanRequestCode;
    private String loanCode;
    private BigDecimal principal;
    private BigDecimal paidPrincipal;
    private int countOfInstalments;
    private int remainingInstalments;
    private String startAt;
    private String status;
    private String scheduledEndedAt;
    private String endedAt;
    private LinkGson prepaymentLink;
    private int currentInstalment;
    private Boolean ableToPrepay;
    private boolean isOverdue;
    private LinkGson repaymentDetailsLink;
    private String contractLink;
    private String withholdingContractLink;
    private BigDecimal annualInterestRate;
    private boolean hasWithholdingPlans;
    private boolean isCompensate;
    private int loanSourceType;
    private Boolean isBaiLingDai;

    public LoanGson(Loan loan, Money paidPrincipal,Boolean isBaiLingDai) {
        this.id = loan.id();
        this.loanRequestCode = loan.getLoanRequestCode();
        this.loanCode = loan.getCode();
        this.principal = loan.getPrincipal().getAmount();
        this.paidPrincipal = paidPrincipal.getAmount();
        this.countOfInstalments = loan.getNumberOfInstalments();
        this.remainingInstalments = loan.getNumberOfInstalments() - loan.getSettledInstalments();
        this.startAt = DateUtils.formatDate(loan.getStartAt());
        this.currentInstalment = loan.getCurrentInstalment();
        this.repaymentDetailsLink = new LinkGson("loans/" + loan.id() + "/repayment-details", LinkRelationType.RELATED);
        this.prepaymentLink = new LinkGson("loans/" + loan.id() + "/prepayment", LinkRelationType.RELATED);
        this.status = loan.getStatus().getValue();
        this.scheduledEndedAt = DateUtils.formatDate(loan.getLastRepaymentPlan().getEndAt());
        this.endedAt = loan.getEndedAt() == null ? null : DateUtils.formatDate(loan.getEndedAt());
        this.ableToPrepay = loan.isAbleToBePrepaid();
        this.isOverdue = loan.isOverdue();
        this.isCompensate=loan.isCompensate();
        this.contractLink = new LinkGson("loans/" + loan.id() + "/contract/" + TradeContractType.LOAN, LinkRelationType.RELATED).getHref();
        this.withholdingContractLink = new LinkGson("loans/" + loan.id() + "/contract/" + TradeContractType.WITHHOLDING, LinkRelationType.RELATED).getHref();
        this.annualInterestRate = loan.getAnnualInterestRate();
        this.hasWithholdingPlans = loan.getAllProcessingRepaymentPlans().size() > 0;
        this.loanSourceType = loan.getLoanSourceType();
        this.isBaiLingDai = isBaiLingDai;
    }

    public String getLoanRequestCode() {
        return loanRequestCode;
    }

    public BigDecimal getPaidPrincipal() {
        return paidPrincipal;
    }

    public BigDecimal getPrincipal() {
        return principal;
    }

    public int getCountOfInstalments() {
        return countOfInstalments;
    }

    public int getRemainingInstalments() {
        return remainingInstalments;
    }

    public String getStartAt() {
        return startAt;
    }

    public long getId() {
        return id;
    }

    public String getStatus() {
        return status;
    }

    public String getEndedAt() {
        return endedAt;
    }

    public String getScheduledEndedAt() {
        return scheduledEndedAt;
    }

    public LinkGson getPrepaymentLink() {
        return prepaymentLink;
    }

    public int getCurrentInstalment() {
        return currentInstalment;
    }

    public Boolean isAbleToPrepay() {
        return ableToPrepay;
    }

    public LinkGson getRepaymentDetailsLink() {
        return repaymentDetailsLink;
    }

    public String getContractLink() {
        return contractLink;
    }

    public boolean isOverdue() {
        return isOverdue;
    }
}
