package com.lufax.customerService.resources.gsonTemplate;

import java.math.BigDecimal;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

import com.lufax.common.domain.Investment;
import com.lufax.common.domain.Loan;
import com.lufax.common.domain.TradeContractType;
import com.lufax.common.domain.account.Money;
import com.lufax.common.resources.LinkRelationType;
import com.lufax.common.utils.DateUtils;

public class InvestmentGson {
    private long id;
    private String loanCode;
    private String loaneeName;
    private BigDecimal paidPrincipal;
    private BigDecimal totalInterest;
    private BigDecimal principal;
    private int remainingInstalments;
    private int countOfInstalments;
    private String startAt;
    private String endedAt;
    private String scheduledEndedAt;
    private String status;
    private String annualInterestRate;
    private int currentInstalment;
    private LinkGson collectionDetailsLink;
    private String contractLink;
    private String authContractLink;
    private boolean overdue;
    private boolean compensate;

    public InvestmentGson(Investment investment, Money paidPrincipal) {
        Loan loan = investment.getLoan();
        this.id = investment.id();
        this.loanCode = loan.getCode();
        this.loaneeName = investment.getLoaneeUsername();
        this.paidPrincipal = paidPrincipal.getAmount();
        this.totalInterest = investment.getTotalInterest().getAmount();
        this.principal = investment.getPrincipal().getAmount();
        this.remainingInstalments = investment.getRemainingInstalments(); //*
        this.countOfInstalments = investment.getNumberOfInstalments();
        this.startAt = DateUtils.formatDate(investment.getStartAt());
        this.endedAt = loan.getEndedAt() == null ? null : DateUtils.formatDate(loan.getEndedAt());
        this.scheduledEndedAt = DateUtils.formatDate(investment.getLastCollectionPlan() != null ? investment.getLastCollectionPlan().getEndAt() : null);
        this.status = investment.getStatus().getValue();
        this.annualInterestRate = loan.getAnnualInterestRate().toString();
        this.currentInstalment = investment.getCurrentPlanNumber();
        this.overdue = investment.isOverdue();
        this.compensate = investment.isCompensate();
        this.collectionDetailsLink = new LinkGson("/investments/" + investment.id() + "/collection-details", LinkRelationType.RELATED);
        this.contractLink = new LinkGson("/investments/" + investment.id() + "/contract/" + TradeContractType.LOAN, LinkRelationType.RELATED).getHref();
        this.authContractLink = new LinkGson("/investments/" + investment.id() + "/contract/" + TradeContractType.AUTHORIZATION, LinkRelationType.RELATED).getHref();
    }
    
   

    public long getId() {
        return id;
    }

    public String getLoanCode() {
        return loanCode;
    }

    public String getLoaneeName() {
        return loaneeName;
    }

    public BigDecimal getPaidPrincipal() {
        return paidPrincipal;
    }

    public BigDecimal getTotalInterest() {
        return totalInterest;
    }

    public BigDecimal getPrincipal() {
        return principal;
    }

    public int getRemainingInstalments() {
        return remainingInstalments;
    }

    public int getCountOfInstalments() {
        return countOfInstalments;
    }

    public String getStartAt() {
        return startAt;
    }

    public String getEndedAt() {
        return endedAt;
    }

    public String getScheduledEndedAt() {
        return scheduledEndedAt;
    }

    public String getStatus() {
        return status;
    }

    public String getAnnualInterestRate() {
        return annualInterestRate;
    }

    public String getAuthContractLink() {
        return authContractLink;
    }

    public int getCurrentInstalment() {
        return currentInstalment;
    }

    public LinkGson getCollectionDetailsLink() {
        return collectionDetailsLink;
    }

    public String getContractLink() {
        return contractLink;
    }

	@Override
    public boolean equals(Object o) {
        return EqualsBuilder.reflectionEquals(this, o);
    }

    @Override
    public int hashCode() {
        return HashCodeBuilder.reflectionHashCode(this);
    }

    public boolean isOverdue() {
        return overdue;
    }

    public boolean isCompensate() {
        return compensate;
    }
}
