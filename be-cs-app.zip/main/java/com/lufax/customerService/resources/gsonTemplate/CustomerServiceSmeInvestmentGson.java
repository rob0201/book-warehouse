package com.lufax.customerService.resources.gsonTemplate;

import java.math.BigDecimal;
import java.util.List;

import com.lufax.common.utils.DateUtils;
import com.lufax.common.utils.ProductUtils;
import com.lufax.customerService.pojo.BuyRequestPool;
import com.lufax.customerService.pojo.BuyRequestStatus;
import com.lufax.customerService.pojo.ExtProductSME;
import com.lufax.customerService.pojo.InvestContract;
import com.lufax.customerService.pojo.SMECollectionPlan;

public class CustomerServiceSmeInvestmentGson {
	//投资Id
	private long id;
	//产品编号
    private String loanCode;
    //交易号
    private String loanRequestCode;
    //借款人
    private String loaneeName;
    //已收本金
    private BigDecimal paidPrincipal = BigDecimal.ZERO;
    //利息
    private BigDecimal totalInterest = BigDecimal.ZERO;
    //已收金额
    private BigDecimal totalPaidAmount = BigDecimal.ZERO;
    //本金
    private BigDecimal principal = BigDecimal.ZERO;
    //总额
    private BigDecimal totalAmount = BigDecimal.ZERO;
    //剩余期数
    private int remainingInstalments;
    //总期数
    private int countOfInstalments;
    //还款起始日
    private String startAt;
    //还款日
    private String endedAt;
    //计划还款截至日
    private String scheduledEndedAt;
    //状态
    private String status;
    
    private String annualInterestRate;
    //当前期数
    private int currentInstalment;
    //合同链接地址
    private String contractLink;
    //是否逾期
    private boolean overdue;
    //产品名称
    private String productName;
    //申请时间
    private String applyAt;
    //产品类型
    private String productType;
    //产品类型名称
    private String productTypeName;
    //期限
    private String period;
    //还款历史
    private CustomerServiceSmeCollectionHistoryGson collectionHistoryGson;
    
    public CustomerServiceSmeInvestmentGson(BuyRequestPool buyRequestPool, ExtProductSME product, List<SMECollectionPlan> collectionPlans,InvestContract investContract){
    	if(null!=buyRequestPool){
    		this.id = buyRequestPool.getId();
    		this.status = convertStatus(buyRequestPool.getStatus());
    		this.principal = buyRequestPool.getTargetShares().multiply(buyRequestPool.getTargetPrice());
    		this.applyAt = DateUtils.formatDate(buyRequestPool.getCreateAt());
    	}
    	this.loanCode = product.getCode();
    	this.loaneeName = ProductUtils.getLoaneeName(product);
    	this.startAt = DateUtils.formatDate(product.getInterestStartDate());
    	this.scheduledEndedAt = DateUtils.formatDate(product.getDeadLine());
    	this.annualInterestRate = product.getInterestRateYear().toString();
    	this.productName = product.getName();
    	this.period = ProductUtils.resolveCountOfInstalments(product);
    	this.productName = product.getName();
    	this.productType = product.getProductType().name();
    	this.productTypeName = product.getProductType()==null?"未知":product.getProductType().getValue();
    	this.collectionHistoryGson = new CustomerServiceSmeCollectionHistoryGson(collectionPlans);
    	this.overdue = this.collectionHistoryGson.getTotalOverduePenalValue().compareTo(BigDecimal.ZERO)>0?true:false;
    	this.countOfInstalments = this.collectionHistoryGson.getCountOfInstalments();
    	this.remainingInstalments = this.collectionHistoryGson.getRemainingInstalments();
    	this.contractLink =(investContract==null?null:"/service/common/investments/queryPdf/"+investContract.getStoreId());
    	for(CustomerServiceSmeCollectionDetailGson customerServiceSmeCollectionDetailGson : collectionHistoryGson.getCollectionDetails()){
    		this.paidPrincipal = this.paidPrincipal.add(customerServiceSmeCollectionDetailGson.getCollectedPrincipal());
    		this.totalInterest = this.totalInterest.add(customerServiceSmeCollectionDetailGson.getInterest());
    		this.totalAmount = this.totalAmount.add(customerServiceSmeCollectionDetailGson.getAmount());
    		this.totalPaidAmount = this.totalPaidAmount.add(customerServiceSmeCollectionDetailGson.getCollectedAmount());
    	}

    	
    }

	private String convertStatus(BuyRequestStatus status) {
		//TODO:不知道有哪些状态
		return status.getValue();
	}

	public long getId() {
		return id;
	}

	public String getLoanCode() {
		return loanCode;
	}

	public String getLoanRequestCode() {
		return loanRequestCode;
	}

	public String getLoaneeName() {
		return loaneeName;
	}

	public BigDecimal getPaidPrincipal() {
		return paidPrincipal;
	}

	public BigDecimal getTotalInterest() {
		return totalInterest;
	}

	public BigDecimal getTotalPaidAmount() {
		return totalPaidAmount;
	}

	public BigDecimal getPrincipal() {
		return principal;
	}

	public int getRemainingInstalments() {
		return remainingInstalments;
	}

	public int getCountOfInstalments() {
		return countOfInstalments;
	}

	public String getStartAt() {
		return startAt;
	}

	public String getEndedAt() {
		return endedAt;
	}

	public String getScheduledEndedAt() {
		return scheduledEndedAt;
	}

	public String getStatus() {
		return status;
	}

	public String getAnnualInterestRate() {
		return annualInterestRate;
	}

	public int getCurrentInstalment() {
		return currentInstalment;
	}

	public String getContractLink() {
		return contractLink;
	}

	public boolean isOverdue() {
		return overdue;
	}

	public String getProductName() {
		return productName;
	}

	public String getApplyAt() {
		return applyAt;
	}

	public BigDecimal getTotalAmount() {
		return totalAmount;
	}

	public CustomerServiceSmeCollectionHistoryGson getCollectionHistoryGson() {
		return collectionHistoryGson;
	}

	public String getProductType() {
		return productType;
	}

	public String getProductTypeName() {
		return productTypeName;
	}
	
}
