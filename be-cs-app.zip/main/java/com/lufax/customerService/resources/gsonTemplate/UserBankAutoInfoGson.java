package com.lufax.customerService.resources.gsonTemplate;


import com.lufax.common.domain.EmailVerifyStatus;
import com.lufax.common.domain.MemberCustomer;
import com.lufax.common.domain.RiskVerifyStatus;
import com.lufax.common.domain.User;
import com.lufax.common.utils.DateUtils;

public class UserBankAutoInfoGson {
    private String bankAutoStatus; //认证状态
    private String bankName;
    private String bankAccount;
    private String authAmountTime;//认证费发送时间
    private String autoTime;//认证时间

    public UserBankAutoInfoGson() {
    }

    public String getBankAutoStatus() {
        return bankAutoStatus;
    }

    public void setBankAutoStatus(String bankAutoStatus) {
        this.bankAutoStatus = bankAutoStatus;
    }

    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName;
    }

    public String getBankAccount() {
        return bankAccount;
    }

    public void setBankAccount(String bankAccount) {
        this.bankAccount = bankAccount;
    }

    public String getAuthAmountTime() {
        return authAmountTime;
    }

    public void setAuthAmountTime(String authAmountTime) {
        this.authAmountTime = authAmountTime;
    }

    public String getAutoTime() {
        return autoTime;
    }

    public void setAutoTime(String autoTime) {
        this.autoTime = autoTime;
    }
}
