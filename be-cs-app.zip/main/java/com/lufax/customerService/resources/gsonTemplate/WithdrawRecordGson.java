package com.lufax.customerService.resources.gsonTemplate;


import com.lufax.common.domain.BranchBank;
import com.lufax.common.domain.WithdrawRecord;
import com.lufax.common.utils.DateUtils;
import com.lufax.common.utils.EncryptUtils;
import com.lufax.customerService.domain.ManualCapitalStatement;

import java.math.BigDecimal;
import java.util.Date;

public class WithdrawRecordGson {

    private String id;
    private String bankName;
    private String bankCardNo;
    private BigDecimal withdrawAmount;
    private BigDecimal withdrawFee;
    private BigDecimal actualAmount;
    private String withdrawStatus;
    private String createdAt;
    private String updatedAt;

    private String remarks;
    private String loanRequestCode;
    private String errorDescription;
    private String toAccountTime;
    private String loanerUserName;

    private String withdrawUser;
    private String branchBankName;
    private String withdrawType;
    private Boolean isApplied;

    public WithdrawRecordGson(String id, String bankName, String bankCardNo, BigDecimal withdrawAmount, BigDecimal withdrawFee,
                              BigDecimal actualAmount, String withdrawStatus, Date createdAt, Date updatedAt, String remarks,
                              String loanRequestCode, String errorDescription, Date toAccountTime, String loanerUserName,
                              String withdrawUser, String branchBankName, String withdrawType, Integer count) {
        this.id = id;
        this.bankName = bankName;
        this.bankCardNo = bankCardNo;
        this.withdrawAmount = withdrawAmount;
        this.withdrawFee = withdrawFee;
        this.actualAmount = actualAmount;
        this.withdrawStatus = withdrawStatus;
        this.createdAt = DateUtils.formatDateTime(createdAt);
        this.updatedAt = DateUtils.formatDateTime(updatedAt);
        this.remarks = remarks;
        this.loanRequestCode = loanRequestCode;
        this.errorDescription = errorDescription;
        this.toAccountTime = DateUtils.formatDateTime(toAccountTime);
        this.loanerUserName = loanerUserName;
        this.withdrawUser = withdrawUser;
        this.branchBankName = branchBankName;
        this.withdrawType = withdrawType;
        this.isApplied = (count.intValue() == 0) ? false : true;
    }

    public WithdrawRecordGson(WithdrawRecord withdrawRecord) {
        this.id = String.valueOf(withdrawRecord.id());
        this.bankName = withdrawRecord.getBankName();
        this.bankCardNo = EncryptUtils.encryptBankCardNo(withdrawRecord.getBankCardNo());
        this.withdrawAmount = withdrawRecord.getWithdrawAmount().getAmount();
        this.withdrawFee = withdrawRecord.getWithdrawFee().getAmount();
        this.actualAmount = withdrawRecord.getActualAmount().getAmount();
        this.withdrawStatus = withdrawRecord.getWithdrawStatus().getValue();
        this.createdAt = DateUtils.formatDateTime(withdrawRecord.getCreatedAt());
        this.updatedAt = DateUtils.formatDateTime(withdrawRecord.getUpdatedAt());
        this.remarks = withdrawRecord.getRemarks();
        this.loanRequestCode = withdrawRecord.getLoanRequestCode();
        this.errorDescription = withdrawRecord.getFailDescription();
        this.toAccountTime = DateUtils.formatDateTime(withdrawRecord.getUpdatedAt());
        this.loanerUserName = withdrawRecord.isSuccessful() && withdrawRecord.getLoan() != null ? withdrawRecord.getLoan().getInvestment().getLoaner().getUsername() : "";

    }

    public WithdrawRecordGson(WithdrawRecord withdrawRecord, BranchBank branchBank, ManualCapitalStatement manualCapitalStatement) {
        this.id = String.valueOf(withdrawRecord.id());
        this.bankName = withdrawRecord.getBankName();
        this.withdrawAmount = withdrawRecord.getWithdrawAmount().getAmount();
        this.withdrawFee = withdrawRecord.getWithdrawFee().getAmount();
        this.actualAmount = withdrawRecord.getActualAmount().getAmount();
        this.withdrawStatus = withdrawRecord.getWithdrawStatus().getValue();
        this.createdAt = DateUtils.formatDateTime(withdrawRecord.getCreatedAt());
        this.branchBankName = (branchBank != null) ? branchBank.getBranchName() : null;
        this.withdrawType = withdrawRecord.getWithdrawType().getValue();
        this.withdrawUser = withdrawRecord.getAccount().getUser().getUsername();
        this.bankCardNo = withdrawRecord.getBankCardNo();
        this.updatedAt = DateUtils.formatDate(withdrawRecord.getUpdatedAt());
        this.isApplied = (manualCapitalStatement != null) ? true : false;
    }

    public String id() {
        return id;
    }

    public String getBankName() {
        return bankName;
    }

    public String getBankCardNo() {
        return bankCardNo;
    }

    public BigDecimal getWithdrawAmount() {
        return withdrawAmount;
    }

    public BigDecimal getWithdrawFee() {
        return withdrawFee;
    }

    public BigDecimal getActualAmount() {
        return actualAmount;
    }

    public String getWithdrawStatus() {
        return withdrawStatus;
    }

    public String getUpdatedAt() {
        return updatedAt;
    }

    public String getRemarks() {
        return remarks;
    }

    public String getLoanerUserName() {
        return loanerUserName;
    }

    public String getLoanRequestCode() {
        return loanRequestCode;
    }

    public String getBranchBankName() {
        return branchBankName;
    }

    public void setBranchBankName(String branchBankName) {
        this.branchBankName = branchBankName;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public String getErrorDescription() {
        return errorDescription;
    }

    public void setErrorDescription(String errorDescription) {
        this.errorDescription = errorDescription;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Boolean getApplied() {
        return isApplied;
    }

    public void setApplied(Boolean applied) {
        isApplied = applied;
    }

    public String getToAccountTime() {
        return toAccountTime;
    }

    public void setToAccountTime(String toAccountTime) {
        this.toAccountTime = toAccountTime;
    }

    public String getWithdrawType() {
        return withdrawType;
    }

    public void setWithdrawType(String withdrawType) {
        this.withdrawType = withdrawType;
    }

    public String getWithdrawUser() {
        return withdrawUser;
    }

    public void setWithdrawUser(String withdrawUser) {
        this.withdrawUser = withdrawUser;
    }
}
