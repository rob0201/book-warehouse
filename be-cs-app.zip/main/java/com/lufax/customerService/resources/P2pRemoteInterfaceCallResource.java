package com.lufax.customerService.resources;


import com.lufax.common.resources.ServiceProvider;

import javax.ws.rs.Path;
import javax.ws.rs.PathParam;

public class P2pRemoteInterfaceCallResource {
    private ServiceProvider serviceProvider;
    private String customerId;

    public P2pRemoteInterfaceCallResource(String customerId, ServiceProvider serviceProvider) {
        this.serviceProvider = serviceProvider;
        this.customerId = customerId;
    }

    @Path("/loans/{loanId}")
    public P2pRemoteInterfaceLoanResource getLoan(@PathParam("loanId") String loanId) {
        return new P2pRemoteInterfaceLoanResource(customerId, loanId, serviceProvider);
    }

    @Path("/investments/{investmentId}")
    public P2pRemoteInterfaceInvestmentResource getInvestment(@PathParam("investmentId") String investmentId) {
        return new P2pRemoteInterfaceInvestmentResource(customerId,investmentId, serviceProvider);
    }
}
