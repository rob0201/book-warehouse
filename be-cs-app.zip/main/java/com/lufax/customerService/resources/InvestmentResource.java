package com.lufax.customerService.resources;

import com.lufax.common.domain.Investment;
import com.lufax.common.domain.repository.CollectionPlanRepository;
import com.lufax.common.domain.repository.TradeContractRepository;
import com.lufax.common.resources.*;
import com.lufax.common.utils.BEProperties;

import javax.ws.rs.Path;

public class InvestmentResource  {
    protected BEProperties p2pProperties;
    protected TradeContractRepository tradeContractRepository;
    private CollectionPlanRepository collectionPlanRepository;
    private Investment investment;

    public InvestmentResource() {
    }

    public InvestmentResource(Investment investment, ServiceProvider serviceProvider) {
        this.investment = investment;
        this.collectionPlanRepository = serviceProvider.getCollectionPlanRepository();
        this.p2pProperties = serviceProvider.getBEProperties();
        this.tradeContractRepository = serviceProvider.getTradeContractRepository();
    }

    @Path("collection-history")
    public CollectionHistoryResource getCollectionHistories() {
        return new CollectionHistoryResource(collectionPlanRepository, investment.id(), investment);
    }

    @Path("collection-details")
    public CollectionDetailsResource getCollectionDetails() {
        return new CollectionDetailsResource(collectionPlanRepository, investment.id());
    }


}
