package com.lufax.customerService.resources;

import com.lufax.common.resources.ServiceProvider;
import com.sun.jersey.api.core.InjectParam;

import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;

@Path("/sme-service")
public class SmeRemoteInterfaceCallsResource extends AuthenticatedRequiredRootResource {

     @InjectParam
    private ServiceProvider serviceProvider;

    @Path("sme")
    public SmeRemoteInterfaceCallResource getSmeInvestmentRequests(@QueryParam("smeRemoteInterfaceCallUrl") String smeRemoteInterfaceCallUrl) {
        return new SmeRemoteInterfaceCallResource(smeRemoteInterfaceCallUrl, serviceProvider);
    }


}
