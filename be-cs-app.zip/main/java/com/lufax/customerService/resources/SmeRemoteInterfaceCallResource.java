package com.lufax.customerService.resources;


import com.lufax.common.resources.ServiceProvider;
import com.lufax.customerService.service.SmeRemoteInterfaceCallService;

import javax.ws.rs.GET;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

public class SmeRemoteInterfaceCallResource {

    private SmeRemoteInterfaceCallService smeRemoteInterfaceCallService;
    private ServiceProvider serviceProvider;
    private String remoteInterfaceCallUrl;

    public SmeRemoteInterfaceCallResource() {

    }
    public SmeRemoteInterfaceCallResource(String remoteInterfaceCallUrl, ServiceProvider serviceProvider) {
        this.serviceProvider = serviceProvider;
        this.smeRemoteInterfaceCallService = serviceProvider.getSmeRemoteInterfaceCallService();
        this.remoteInterfaceCallUrl = remoteInterfaceCallUrl;
    }
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public String getSmeRemoteInterfaceCallResource() {
        String remoteCallResult=null;
        try{
            remoteCallResult=smeRemoteInterfaceCallService.getSmeRemoteInterfaceCallUrlByJerseyService(remoteInterfaceCallUrl);
        } catch (Throwable e){
            return null;
        }
        return remoteCallResult;
    }
}
