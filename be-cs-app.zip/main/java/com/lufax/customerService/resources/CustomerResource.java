package com.lufax.customerService.resources;

import static com.lufax.customerService.domain.OperationMenu.FUND_RECORD;
import static com.lufax.customerService.domain.OperationMenu.SMS_RECORD;
import static com.lufax.customerService.domain.OperationMenu.INVESTMENT_REQUEST;
import static com.lufax.customerService.domain.OperationMenu.LOAN_REQUEST;
import static com.lufax.customerService.domain.OperationMenu.RECHARGE_RECORD;
import static com.lufax.customerService.domain.OperationMenu.USER_BASIC_INFO;
import static com.lufax.customerService.domain.OperationMenu.WITHDRAW_RECORD;
import static com.lufax.customerService.domain.OperationType.SEND_USER_NAME;

import static com.lufax.sms.domain.SmsTemplate.CUSTOMER_SEND_USER_NAME;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.google.gson.Gson;
import com.lufax.common.domain.MemberCustomer;
import com.lufax.common.domain.TransactionTypeForQuery;
import com.lufax.common.domain.User;
import com.lufax.common.domain.account.TransactionHistory;
import com.lufax.common.domain.account.repository.TransactionHistoryRepository;
import com.lufax.common.domain.repository.MemberCustomerRepository;
import com.lufax.common.resources.ServiceProvider;
import com.lufax.common.resources.gsonTemplate.PaginationGson;
import com.lufax.common.utils.DateUtils;
import com.lufax.common.utils.DevLog;
import com.lufax.customerService.domain.OperationMenu;
import com.lufax.customerService.domain.OperationType;
import com.lufax.customerService.domain.OperationsLog;
import com.lufax.customerService.resources.gsonTemplate.*;
import com.lufax.customerService.service.CustomerOperationsLogService;
import com.lufax.jersey.utils.Logger;
import com.lufax.sms.domain.SmsMessage;
import com.lufax.sms.service.SmsService;

public class CustomerResource {
    private CustomerOperationsLogService customerOperationsLogService;
    private SmsService smsService;
    private User customerRepresentative;
    private User customer;
    private ServiceProvider serviceProvider;
    private TransactionHistoryRepository transactionHistoryRepository;
    private MemberCustomerRepository memberCustomerRepository;

    public CustomerResource(User customerRepresentative, User customer, ServiceProvider serviceProvider) {
        this.customerRepresentative = customerRepresentative;
        this.customer = customer;
        this.serviceProvider = serviceProvider;
        this.customerOperationsLogService = serviceProvider.getCustomerOperationsLogService();
        this.smsService = serviceProvider.getSmsService();
        this.transactionHistoryRepository = serviceProvider.getTransactionHistoryRepository();
        this.memberCustomerRepository=serviceProvider.getMemberCustomerRepository();
    }

    @Path("p2p")
    public P2PResource getP2PResource() {
        return new P2PResource(customerRepresentative,customer, serviceProvider);
    }

    @Path("SME")
    public SMEResource getSMEResource() {
        return new SMEResource(customerRepresentative,customer, serviceProvider);
    }

    @GET
    @Path("basicInfo")
    @Produces(value = MediaType.APPLICATION_JSON)
    public String getUserBasicInfo() {
        writeOperationLog(USER_BASIC_INFO);
        MemberCustomer memberCustomer =memberCustomerRepository.findByPartyNo(customer.getPartyNo());
        List<UserBankAutoInfoGson> userBankAutoInfoGsons=memberCustomerRepository.findBankInfoByPartyNo(customer.getPartyNo());
        return new Gson().toJson(new UserBasicInfoGson(customer,memberCustomer,userBankAutoInfoGsons));
    }

    @Path("loans")
    public LoansResource getUserLoanHistory(@QueryParam("logType") OperationMenu logType) {
        if (null != logType) {
            writeOperationLog(logType);
        }
        return new LoansResource(customer, serviceProvider);
    }

    @Path("loan-requests")
    public LoanRequestsResource getLoanRequests() {
        writeOperationLog(LOAN_REQUEST);
        return new LoanRequestsResource(customer, serviceProvider);
    }

    @Path("investment-requests")
    public InvestmentRequestsResource getInvestmentRequests() {
        writeOperationLog(INVESTMENT_REQUEST);
        return new InvestmentRequestsResource(customer, serviceProvider);
    }

    @Path("investments")
    @Produces(value = MediaType.APPLICATION_JSON)
    public InvestmentsResource userInvestments(@QueryParam("logType") OperationMenu logType) {
        if (null != logType) {
            writeOperationLog(logType);
        }
        return new InvestmentsResource(customer, serviceProvider);
    }


    @Path("withdraw-records")
    @Produces(value = MediaType.APPLICATION_JSON)
    public WithdrawRecordsResource userWithdrawOverview() {
        writeOperationLog(WITHDRAW_RECORD);
        return new WithdrawRecordsResource(customer, serviceProvider.getWithdrawalsRecordRepository());
    }

    @POST
    @Path("sendUserName")
    public Response sendUserName() {
        writeOperationLog(USER_BASIC_INFO, SEND_USER_NAME, customer.getMobileNo());
        try {
            String content = new StringBuilder().append("userName").append("|").append(customer.getUsername()).toString();
            smsService.saveMessage(customer, new SmsMessage(CUSTOMER_SEND_USER_NAME, content));
            return Response.status(Response.Status.OK).build();
        } catch (Exception e) {
            DevLog.warn(this, String.format("Failed to send sms to user, mobileNo:%s ", customer.getMobileNo()), e);
            return Response.status(Response.Status.PRECONDITION_FAILED).entity(e.getMessage()).build();
        }
    }

    @Path("/recharge-records")
    @Produces(value = MediaType.APPLICATION_JSON)
    public RechargeRecordsResource userRechargeRecords() {
        writeOperationLog(RECHARGE_RECORD);
        return new RechargeRecordsResource(customer, serviceProvider.getRechargeRecordRepository(), serviceProvider.gettBankCodeRepository());
    }

    private void writeOperationLog(OperationMenu logType) {
        writeOperationLog(logType, null, "");
    }

    private void writeOperationLog(OperationMenu logType, OperationType operationType, String operationData) {
        customerOperationsLogService.logCustomerOperations(new OperationsLog(logType, operationType, operationData, customer.id(), customerRepresentative.id()));
    }
    
    @GET
    @Path("/transaction-type-query")
    @Produces(value = MediaType.APPLICATION_JSON)
    public String getTransactionType(){
    	List<TransactionTypeDTO> dtos = new ArrayList<TransactionTypeDTO>();
    	for(TransactionTypeForQuery type : TransactionTypeForQuery.values()){
    		TransactionTypeDTO dto = new TransactionTypeDTO();
    		dto.setName(type.name());
    		dto.setValue(type.getValue());
    		dtos.add(dto);
    	}
    	return  new Gson().toJson(dtos);
    }
    
    @GET
    @Path("/fund-records/{pageNo}")
    @Produces(value = MediaType.APPLICATION_JSON)
    public String getFundRecords(@PathParam("pageNo") int pageNo,@QueryParam("transactionType") TransactionTypeForQuery transactionType, @QueryParam("createdTime") String createdTime){
    	writeOperationLog(FUND_RECORD);
    	long count = transactionHistoryRepository.findCountByAccountAndTypeWithRangeTime(customer, transactionType, getQueryRangeDate(createdTime).getBeginDate(), getQueryRangeDate(createdTime).getEndDate());
    	PaginationGson pagination =  new PaginationGson(com.lufax.common.web.helper.ConstantsHelper.PAGE_LIMIT, count, pageNo);
    	if(count >0){
    		List<TransactionHistoryGson> gsons  =  new ArrayList<TransactionHistoryGson>();
    		List<TransactionHistory> historys = transactionHistoryRepository.findByAccountAndTypeWithRangeTime(customer, transactionType, getQueryRangeDate(createdTime).getBeginDate(), getQueryRangeDate(createdTime).getEndDate(), com.lufax.common.web.helper.ConstantsHelper.PAGE_LIMIT, (pagination.getCurrentPage()-1)*com.lufax.common.web.helper.ConstantsHelper.PAGE_LIMIT);
    		for(TransactionHistory history:historys){
    			gsons.add(new TransactionHistoryGson(history));
    		}
    		pagination.setData(gsons);
    	}
    	return  new Gson().toJson(pagination);
    }

    @GET
    @Path("/quey-messages/{pageNo}")
    @Produces(value = MediaType.APPLICATION_JSON)
    public String getMessages(@PathParam("pageNo") int pageNo,@QueryParam("fromTime") String fromTimes, @QueryParam("toTime") String toTimes){
    	writeOperationLog(SMS_RECORD);
        Date fromTime=null,toTime=null;
        if(!("".equals(fromTimes) || fromTimes==null)) {
            fromTime= DateUtils.parse(DateUtils.DATE_FORMAT_DEFAULT,fromTimes);
        }
        if(!("".equals(toTimes) || toTimes==null)) {
            toTime= DateUtils.parse(DateUtils.DATE_FORMAT_DEFAULT,toTimes);
            toTime = DateUtils.add(toTime,1,Calendar.DATE);
        }
        Long count = memberCustomerRepository.countMessageInfoByMobileNo(customer.getMobileNo(),fromTime,toTime);
        PaginationGson pagination =  new PaginationGson(com.lufax.common.web.helper.ConstantsHelper.PAGE_LIMIT, count, pageNo);
        if(count >0){
            List<MessageInfoGson> gsons  =  memberCustomerRepository.findMessageInfoByMobileNo(customer.getMobileNo(),fromTime,toTime,com.lufax.common.web.helper.ConstantsHelper.PAGE_LIMIT, (pagination.getCurrentPage()-1)*com.lufax.common.web.helper.ConstantsHelper.PAGE_LIMIT);
            pagination.setData(gsons);
        }
        return new Gson().toJson(pagination);
    }
    
    private RangeDate getQueryRangeDate(String param){
    	RangeDate rangeDate = new RangeDate();
    	if("ALL".equals(param)){
    		return rangeDate;
    	}
    	if("M3".equals(param)){
    		rangeDate.setBeginDate(DateUtils.getLastMonthDate(-3));
    	}
    	if("M1".equals(param)){
    		rangeDate.setBeginDate(DateUtils.getLastMonthDate(-1));
    	}
    	if("D7".equals(param)){
    		rangeDate.setBeginDate(DateUtils.getLastDayDate(-7));
    	}
    	rangeDate.setEndDate(new Date());
    	Logger.debug(this, String.format("The rangeDate is [%s]", rangeDate.toString()));
    	return rangeDate;
    }
    
}
