package com.lufax.customerService.resources;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.apache.commons.collections.CollectionUtils;

import com.google.gson.Gson;
import com.lufax.common.domain.CollectionDetail;
import com.lufax.common.domain.CollectionPlan;
import com.lufax.common.domain.Investment;
import com.lufax.common.domain.repository.CollectionPlanRepository;
import com.lufax.common.domain.repository.CollectionRecordRepository;
import com.lufax.customerService.resources.gsonTemplate.CollectionHistoryGson;

public class CollectionHistoryResource {
    private CollectionRecordRepository collectionRecordRepository;
    private CollectionPlanRepository collectionPlanRepository;
    private long investmentId;
    private Investment investment;

    public CollectionHistoryResource() {
    }

    public CollectionHistoryResource(CollectionPlanRepository collectionPlanRepository, long investmentId, Investment investment) {
        this.collectionPlanRepository = collectionPlanRepository;
        this.investmentId = investmentId;
        this.investment = investment;
    }

    @GET
    @Produces(value = MediaType.APPLICATION_JSON)
    public String getCollectionDetails() {
        ArrayList<CollectionDetail> collectionDetails = new ArrayList<CollectionDetail>();

        List<CollectionPlan> collectionPlans = collectionPlanRepository.findAllByInvestmentId(investmentId);
        for (CollectionPlan collectionPlan : collectionPlans) {
            if (collectionPlan.isSettled() && CollectionUtils.isNotEmpty(collectionPlan.getSettledRecords())) {
                collectionDetails.add(new CollectionDetail(collectionPlan));
            }
        }
        return new Gson().toJson(new CollectionHistoryGson(collectionDetails,investment));
    }
}