package com.lufax.customerService.resources;


import java.util.Date;

import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.commons.lang.StringUtils;



import com.google.gson.Gson;
import com.lufax.common.dto.p2p.PrepaymentMeasureResultDTO;
import com.lufax.common.resources.ServiceProvider;
import com.lufax.common.utils.BEProperties;
import com.lufax.common.utils.DateUtils;
import com.lufax.common.utils.DevLog;
import com.lufax.customerService.service.AnShuoRemoteInterfaceCallService;
import com.lufax.customerService.service.P2pRemoteInterfaceCallService;
import com.lufax.customerService.service.XinbaoRemoteInterfaceCallService;
import com.lufax.jersey.usercontext.UserContext;
import com.lufax.jersey.usercontext.UserContextUtils;
import com.lufax.jersey.utils.Logger;

public class P2pRemoteInterfaceLoanResource {
    private ServiceProvider serviceProvider;
    private String customerId;
    private String loanId;
    private P2pRemoteInterfaceCallService p2pRemoteInterfaceCallService;
    private XinbaoRemoteInterfaceCallService xinbaoRemoteInterfaceCallService;
    private AnShuoRemoteInterfaceCallService anShuoRemoteInterfaceCallService;
    private String remoteInterfaceCallUrl;
    private String date;
    private BEProperties p2PProperties;

    public P2pRemoteInterfaceLoanResource(String customerId, String loanId, ServiceProvider serviceProvider) {
        this.serviceProvider = serviceProvider;
        this.p2pRemoteInterfaceCallService = serviceProvider.getP2pRemoteInterfaceCallService();
        this.xinbaoRemoteInterfaceCallService = serviceProvider.getXinbaoRemoteInterfaceCallService();
        this.anShuoRemoteInterfaceCallService = serviceProvider.getAnShuoRemoteInterfaceCallService();
        this.customerId = customerId;
        this.loanId = loanId;
        this.p2PProperties = serviceProvider.getBEProperties();
    }

    @GET
    @Path("repayment-details")
    @Produces(MediaType.APPLICATION_JSON)
    public String getRepaymentDetails(@QueryParam("loanSourceType") String loanSourceType) {
        String p2PLoansRepaymentDetailsUrl = p2PProperties.getXinbaoLoansRepaymentDetailsUrl();
        remoteInterfaceCallUrl = String.format(p2PLoansRepaymentDetailsUrl,customerId, loanId);
        return getXinbaoRemoteCallResult(remoteInterfaceCallUrl, loanSourceType);
    }

    @GET
    @Path("repayment-history")
    @Produces(MediaType.APPLICATION_JSON)
    public String getRepaymentRecords(@QueryParam("loanSourceType") String loanSourceType) {
        String p2PLoansRepaymentHistoryUrl = p2PProperties.getXinbaoLoansRepaymentHistoryUrl();
        remoteInterfaceCallUrl = String.format(p2PLoansRepaymentHistoryUrl, customerId, loanId);
        return getXinbaoRemoteCallResult(remoteInterfaceCallUrl, loanSourceType);
    }

    @GET
    @Path("prepayment")
    @Produces(MediaType.APPLICATION_JSON)
    public String getPrepaymentInformationByDate(@DefaultValue("") @QueryParam("date") String dateString) {
        String p2PLoansPrepaymentCalculatorUrl = p2PProperties.getP2PLoansPrepaymentCalculatorUrl();
        remoteInterfaceCallUrl = String.format(p2PLoansPrepaymentCalculatorUrl, customerId, loanId);
        this.date = dateString;
        if (StringUtils.isEmpty(dateString)) {
            this.date = getDefaultDate();
        }
        UserContext uc = UserContextUtils.getCurrentUserContext();
        // ECR #1261 修复生产客服提前还款测算不符合预期的接口调用逻辑
        PrepaymentMeasureResultDTO result = serviceProvider.getP2pAppService().calculatePrerepayment(new Long(uc.getUserId()), new Long(customerId), new Long(loanId), date);
        Logger.debug(this, "The invoke result is [" + result + "]");
        return new Gson().toJson(result);
    }
    
    @GET
    @Path("prepayment/apply")
    @Produces(MediaType.APPLICATION_JSON)
    public String getPrepaymentApply() {
        return p2pRemoteInterfaceCallService.getPrepaymentApply(customerId, loanId);
    }
    @GET
    @Path("prepayment/getInfo")
    @Produces(MediaType.APPLICATION_JSON)
    public String getPrepaymentGetInfo(@QueryParam("prepayEstimateRequestId") String prepayEstimateRequestId) {
        
        return p2pRemoteInterfaceCallService.getPrepaymentGetInfo(customerId, loanId, prepayEstimateRequestId);
    }

//    private String getRemoteCallResult(String remoteInterfaceCallUrl) {
//        String remoteCallResult = null;
//        remoteCallResult = p2pRemoteInterfaceCallService.getP2pRemoteInterfaceCallUrlByJerseyService(remoteInterfaceCallUrl, customerId, date);
//        if (remoteCallResult == null) {
//            DevLog.warn(this, String.format("Remote call p2p service failed ,remoteInterfaceCallUrl is %s,customerId is %s, loanId is %s", remoteInterfaceCallUrl, customerId, loanId));
//            throw new WebApplicationException(Response.Status.BAD_REQUEST);
//        }
//        return remoteCallResult;
//    }
    
    private String getXinbaoRemoteCallResult(String remoteInterfaceCallUrl, String loanSourceType) {
//    	// TODO cango add test code
//    	if(remoteInterfaceCallUrl.matches(".*detail.*")) {
//    		return new StringBuffer().append("{\"id\":1533846,\"projectName\":\"XXXXXXX\",\"isDirectP2P\":true,\"loanRequestCode\":\"1211140034\",\"startAt\":\"2012-11-15\",\"endedAt\":\"2012-11-21\"," +
//    				" \"countOfRemainsInstalments\":6,\"countOfInstalments\":12,\"totalPrincipal\":20026.00,\"forecastTotalAmount\":20668.90,\"remainsPrincipal\":20026.00,\"status\":\"XXXXXXX\"," +
//    				"\"loanContractLink\":\"service/loans/1533846/contract/LOAN\",\"withholdingContractLink\":\"service/loans/1533846/contract/WITHHOLDING\"," +
//    				" \"paidPrincipal\":20026.00,\"paidInterest\":68.90,\"paidOverduePenalValue\":26.00,\"paidInsuranceFee\":206.00,\"isShowPreRepaymentBtn\":true," +
//    				"\"repaymentPlans\":[" +
//    				" {\"planNumber\":1,\"endedAt\":\"2013-01-07\",\"toPayTotalAmount\":1787.48,\"toPayPrincipal\":1581.18,\"toPayInterest\":196.30,\"toPayOverduePenalValue\":0.00,\"toPayInsuranceFee\":10.00," +
//    				" \"status\":\"已付清\",\"isCurrent\":false,\"isRateChange\":false,\"rateTo\":8.57,\"isShowRepaymentBtn\":true,\"isWithholding\":true," +
//    				" \"repaymentRecords\":[" +
//    				" {\"payTime\":\"2013-01-07\",\"amount\":1787.48,\"principal\":1581.18,\"interest\":196.30,\"overduePenalValue\":0.00,\"insuranceFee\":10.00}," +
//    				" {\"payTime\":\"2013-01-08\",\"amount\":178.48,\"principal\":1581.18,\"interest\":196.30,\"overduePenalValue\":0.00,\"insuranceFee\":10.00}" +
//    				" ]" +
//    				" }" +
//    				"]}").toString();
//    	} else {
//    		return  "{\"id\":1533846,\"projectName\":\"XXXXXXX\",\"loanRequestCode\":\"1211140034\",\"startAt\":\"2012-11-15\",\"endedAt\":\"2012-11-21\",\"countOfInstalments\":12,\"totalPrincipal\":20026.00,\"totalAmount\":20668.90,\"status\":\"XXXXXXX\"," +
//    				"\"loanContractLink\":\"service/loans/1533846/contract/LOAN\",\"withholdingContractLink\":\"service/loans/1533846/contract/WITHHOLDING\"," +
//    				"\"paidPrincipal\":2003.22,\"paidInterest\":39.79,\"paidOverduePenalValue\":0.00,\"paidInsuranceFee\":2.33,\"paidPenalValue\":300.39,\"paidInsuranceManagementFee\":300.39," +
//    				"\"repaymentPlans\":[" +
//    				"{\"planNumber\":1,\"endedAt\":\"2012-11-21\",\"amount\":20668.90,\"principal\":20026.00,\"interest\":39.79,\"overduePenalValue\":0.00,\"insuranceFee\":2.33,\"status\":\"已还清\",\"isRateChange\":false,\"rateTo\":8.57," +
//    				"\"repaymentRecords\":[{\"payTime\":\"2012-11-21\",\"amount\":20668.90,\"principal\":20026.00,\"interest\":39.79,\"overduePenalValue\":0.00,\"insuranceFee\":2.33}]}," +
//    				"{\"planNumber\":2,\"endedAt\":\"2012-11-21\",\"amount\":20668.90,\"principal\":20026.00,\"interest\":39.79,\"overduePenalValue\":0.00,\"insuranceFee\":2.33,\"status\":\"已还清\",\"isRateChange\":true,\"rateTo\":9.57," +
//    				"\"repaymentRecords\":[{\"payTime\":\"2012-11-21\",\"amount\":20668.90,\"principal\":20026.00,\"interest\":39.79,\"overduePenalValue\":0.00,\"insuranceFee\":2.33}]}" +
//    				"]}";
//    	}
    	
    	
        String remoteCallResult = null;
        if("1".equals(loanSourceType)) {
        	remoteCallResult = xinbaoRemoteInterfaceCallService.getRemoteInterfaceCallUrlByJerseyService(remoteInterfaceCallUrl, customerId, date);
        } else if("9".equals(loanSourceType)) {
        	remoteCallResult = anShuoRemoteInterfaceCallService.getRemoteInterfaceCallUrlByJerseyService(remoteInterfaceCallUrl, customerId, date);
        } else {
        	throw new RuntimeException("The loanSourceType [" + loanSourceType + "] is not support. Please check it");
        }
        if (remoteCallResult == null) {
            DevLog.warn(this, String.format("Remote call p2p service failed ,remoteInterfaceCallUrl is %s,customerId is %s, loanId is %s", remoteInterfaceCallUrl, customerId, loanId));
            throw new WebApplicationException(Response.Status.BAD_REQUEST);
        }
        return remoteCallResult;
    }

    private String getDefaultDate() {
        return DateUtils.formatDate(new Date(), DateUtils.DATE_FORMAT_DEFAULT);
    }

}
