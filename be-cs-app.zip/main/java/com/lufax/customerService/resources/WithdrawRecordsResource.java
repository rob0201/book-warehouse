package com.lufax.customerService.resources;


import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.GET;

import com.lufax.common.domain.User;
import com.lufax.common.domain.WithdrawRecord;
import com.lufax.common.domain.repository.WithdrawRecordRepository;
import com.lufax.common.resources.gsonTemplate.GsonExtractor;
import com.lufax.customerService.resources.gsonTemplate.WithdrawRecordGson;

public class WithdrawRecordsResource {
    private User user;
    private WithdrawRecordRepository withdrawalsRecordRepository;

    public WithdrawRecordsResource(User user, WithdrawRecordRepository withdrawalsRecordRepository) {
        this.user = user;
        this.withdrawalsRecordRepository = withdrawalsRecordRepository;
    }

    @GET
    public String list() {
        List<WithdrawRecord> withdrawRecords = withdrawalsRecordRepository.findAllByAccount(user.getAccount());
        return GsonExtractor.extractGson(withdrawRecords, new ArrayList<WithdrawRecordGson>(), WithdrawRecordGson.class);
    }







}
