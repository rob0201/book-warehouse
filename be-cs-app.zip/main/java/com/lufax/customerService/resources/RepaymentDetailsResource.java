package com.lufax.customerService.resources;

import com.google.gson.Gson;
import com.lufax.common.domain.Loan;
import com.lufax.common.domain.repository.RepaymentPlanRepository;
import com.lufax.customerService.resources.gsonTemplate.RepaymentDetailsGson;
import com.lufax.common.web.helper.ConstantsHelper;

import javax.ws.rs.GET;
import javax.ws.rs.Produces;

public class RepaymentDetailsResource {
    private Loan loan;
    private RepaymentPlanRepository repaymentPlanRepository;

    public RepaymentDetailsResource(Loan loan, RepaymentPlanRepository repaymentPlanRepository) {
        this.loan = loan;
        this.repaymentPlanRepository = repaymentPlanRepository;
    }

    @GET
    @Produces(ConstantsHelper.APPLICATION_JSON_WITH_DEFAULT_CHARSET_HEADER)
    public String getRepaymentDetails() {
        // Only used to pre-load records of plan to improve performance
        repaymentPlanRepository.preloadAllByLoan(loan);
        return new Gson().toJson(new RepaymentDetailsGson(loan), RepaymentDetailsGson.class);
    }

}

