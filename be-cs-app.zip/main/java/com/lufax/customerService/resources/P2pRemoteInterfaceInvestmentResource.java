package com.lufax.customerService.resources;


import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.lufax.common.resources.ServiceProvider;
import com.lufax.common.utils.DevLog;
import com.lufax.common.utils.BEProperties;
import com.lufax.customerService.service.P2pRemoteInterfaceCallService;

public class P2pRemoteInterfaceInvestmentResource {
    private P2pRemoteInterfaceCallService p2pRemoteInterfaceCallService;
    private String remoteInterfaceCallUrl;
    private String customerId;
    private String investmentId;
    private BEProperties p2PProperties;

    public P2pRemoteInterfaceInvestmentResource(String customerId, String investmentId, ServiceProvider serviceProvider) {
        this.customerId = customerId;
        this.investmentId = investmentId;
        this.p2pRemoteInterfaceCallService = serviceProvider.getP2pRemoteInterfaceCallService();
        this.p2PProperties = serviceProvider.getBEProperties();
    }

    @GET
    @Path("collection-history")
    @Produces(MediaType.APPLICATION_JSON)
    public String getCollectionHistories() {
        String p2PInvestmentCollectionHistoryUrl = p2PProperties.getP2PInvestmentCollectionHistoryUrl();
        remoteInterfaceCallUrl = String.format(p2PInvestmentCollectionHistoryUrl, investmentId);
        return getRemoteCallResult(remoteInterfaceCallUrl);
    }

    @GET
    @Path("collection-details")
    @Produces(MediaType.APPLICATION_JSON)
    public String getCollectionDetails() {
        String p2PInvestmentCollectionDetailsUrl = p2PProperties.getP2PInvestmentCollectionDetailsUrl();
        remoteInterfaceCallUrl = String.format(p2PInvestmentCollectionDetailsUrl, investmentId);
        return getRemoteCallResult(remoteInterfaceCallUrl);
    }

    private String getRemoteCallResult(String remoteInterfaceCallUrl) {
        String remoteCallResult = null;
        remoteCallResult = p2pRemoteInterfaceCallService.getP2pRemoteInterfaceCallUrlByJerseyService(remoteInterfaceCallUrl, customerId, null);
        if (remoteCallResult == null) {
            DevLog.error(this, String.format("Remote call p2p service failed ,remoteInterfaceCallUrl is %s,customerId is %s, investmentId is %s", remoteInterfaceCallUrl, customerId, investmentId));
            throw new WebApplicationException(Response.Status.BAD_REQUEST);
        }
        return remoteCallResult;

    }
}
