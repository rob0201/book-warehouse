package com.lufax.customerService.resources;

import com.google.gson.Gson;
import com.lufax.common.domain.ASGuaranteedNote;
import com.lufax.common.domain.Loan;
import com.lufax.common.domain.TradingStatus;
import com.lufax.common.domain.User;
import com.lufax.common.domain.account.Money;
import com.lufax.common.domain.repository.ASGuaranteedNoteRepository;
import com.lufax.common.domain.repository.BizParametersRepository;
import com.lufax.common.domain.repository.LoanRepository;
import com.lufax.common.domain.repository.RepaymentPlanRepository;
import com.lufax.common.resources.ServiceProvider;
import com.lufax.common.utils.DevLog;
import com.lufax.customerService.resources.gsonTemplate.LoanGson;
import com.lufax.customerService.service.PrepaymentService;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class LoansResource {
    private User user;
    private LoanRepository loanRepository;
    private PrepaymentService prepaymentService;
    private RepaymentPlanRepository repaymentPlanRepository;
    private BizParametersRepository bizParametersRepository;
    private ASGuaranteedNoteRepository asGuaranteedNoteRepository;
    public LoansResource() {
    }

    public LoansResource(User user, ServiceProvider serviceProvider) {
        this.user = user;
        this.loanRepository = serviceProvider.getLoanRepository();
        this.prepaymentService = serviceProvider.getPrepaymentService();
        this.repaymentPlanRepository = serviceProvider.getRepaymentPlanRepository();
        this.bizParametersRepository=serviceProvider.getBizParametersRepository();
        this.asGuaranteedNoteRepository = serviceProvider.getAsGuaranteedNoteRepository();
    }


    @GET
    @Produces(value = MediaType.APPLICATION_JSON)
    public String getUserLoanHistory(@QueryParam("statusType") final TradingStatus.Type statusType) {
        List<Loan> loans = loanRepository.findOrderedLoansByStatusTypeFor(user, statusType);
        Map<Loan, Money> paidPrincipalsForLoans = loanRepository.getPaidPrincipalsForLoans(loans);
        List<LoanGson> loanGsons = new ArrayList<LoanGson>();
        for (Loan loan : loans) {
        	DevLog.debug(this, "The cde " + loan.getLoanRequestCode() + " source type is : [" + loan.getLoanSourceType() + "] " + ("9".equals(loan.getLoanSourceType())));
        	if(9 == loan.getLoanSourceType()) {
        		ASGuaranteedNote asGuaranteedNote = asGuaranteedNoteRepository.findByAsLoanRequestCode(loan.getLoanRequestCode());
        		DevLog.debug(this, "The code " + loan.getLoanRequestCode() + " as guarantee ndoe result is : [" + asGuaranteedNote + "]");
        		if(asGuaranteedNote != null) {
        			loanGsons.add(new LoanGson(loan, paidPrincipalsForLoans.get(loan), asGuaranteedNote.isBaiLinDai()));
        		} else {
        			loanGsons.add(new LoanGson(loan, paidPrincipalsForLoans.get(loan), false));
        		}
        	} else {
        		loanGsons.add(new LoanGson(loan, paidPrincipalsForLoans.get(loan), false));
        	}
            
        }
        return new Gson().toJson(loanGsons);
    }

    @Path("/{loanId}")
    public LoanResource getLoan(@PathParam("loanId") long loanId) {
        Loan loan = findLoan(loanId, user);
        return new LoanResource(loan, prepaymentService, repaymentPlanRepository,bizParametersRepository);
    }

    private Loan findLoan(long loanId, User user) {
        Loan loan = loanRepository.findForLoanee(user, loanId);
        if (loan == null) {
            throw new WebApplicationException(Response.Status.NOT_FOUND);
        }
        return loan;
    }
}
