package com.lufax.customerService.resources;

import com.lufax.common.domain.InvestmentRequest;
import com.lufax.common.domain.User;
import com.lufax.common.domain.repository.InvestmentRequestRepository;
import com.lufax.common.resources.ServiceProvider;
import com.lufax.common.resources.gsonTemplate.GsonExtractor;
import com.lufax.customerService.resources.gsonTemplate.InvestmentRequestGson;

import javax.ws.rs.GET;
import java.util.ArrayList;
import java.util.List;

public class InvestmentRequestsResource {
    private User loaner;
    private InvestmentRequestRepository investmentRequestRepository;

    public InvestmentRequestsResource(User loaner, ServiceProvider serviceProvider) {
        this.loaner = loaner;
        this.investmentRequestRepository = serviceProvider.getInvestmentRequestRepository();
    }

    @GET
    public String list() {
        List<InvestmentRequest> investmentRequests = investmentRequestRepository.findAllForLoaner(loaner);
        return GsonExtractor.extractGson(investmentRequests, new ArrayList<InvestmentRequestGson>(), InvestmentRequestGson.class);
    }
}
