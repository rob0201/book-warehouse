package com.lufax.customerService.resources;

import com.google.gson.Gson;
import com.lufax.common.domain.CollectionDetail;
import com.lufax.common.domain.CollectionPlan;
import com.lufax.common.domain.repository.CollectionPlanRepository;
import com.lufax.customerService.resources.gsonTemplate.CollectionDetailGson;

import javax.ws.rs.GET;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import java.util.ArrayList;
import java.util.List;

public class CollectionDetailsResource {
    private CollectionPlanRepository collectionPlanRepository;
    private long investmentId;

    public CollectionDetailsResource(CollectionPlanRepository collectionPlanRepository, long investmentId) {
        this.collectionPlanRepository = collectionPlanRepository;
        this.investmentId = investmentId;
    }

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public String getCollectionDetails() {
        List<CollectionDetailGson> collectionDetailGsons = new ArrayList<CollectionDetailGson>();

        List<CollectionPlan> collectionPlans = collectionPlanRepository.findAllByInvestmentId(investmentId);
        for (CollectionPlan collectionPlan : collectionPlans) {
            collectionDetailGsons.add(new CollectionDetailGson(new CollectionDetail(collectionPlan)));
        }
        return new Gson().toJson(collectionDetailGsons, collectionDetailGsons.getClass());
    }
}
