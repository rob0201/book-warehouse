package com.lufax.customerService.resources;

import com.google.gson.Gson;
import com.lufax.common.domain.Loan;
import com.lufax.common.domain.repository.BizParametersRepository;
import com.lufax.common.domain.repository.RepaymentPlanRepository;
import com.lufax.common.utils.DateUtils;
import com.lufax.customerService.service.PrepaymentService;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import java.util.Date;

public class LoanResource {
    private Loan loan;
    private PrepaymentService prepaymentService;
    private RepaymentPlanRepository repaymentPlanRepository;
    private BizParametersRepository bizParametersRepository;

    public LoanResource() {
    }

    public LoanResource(Loan loan, PrepaymentService prepaymentService, RepaymentPlanRepository repaymentPlanRepository, BizParametersRepository bizParametersRepository) {
        this.loan = loan;
        this.prepaymentService = prepaymentService;
        this.repaymentPlanRepository = repaymentPlanRepository;
        this.bizParametersRepository = bizParametersRepository;
    }

    @GET
    @Path("prepayment")
    @Produces(MediaType.APPLICATION_JSON)
    public String getPrepaymentInformation() {
        Date date = new Date();
        return new Gson().toJson(prepaymentService.getLoanPrepaymentGson(loan, date));
    }

    @GET
    @Path("prepayment/{date}")
    @Produces(MediaType.APPLICATION_JSON)
    public String getPrepaymentInformationByDate(@PathParam("date") String dateString) {
        Date date = DateUtils.parseDate(dateString);
        return new Gson().toJson(prepaymentService.getLoanPrepaymentGson(loan, date));
//        String remoteCallResult = null;
//        String p2pRemoteInterfaceCallUrl=null;
//        long loanId = loan.id();
//        try {
//            remoteCallResult = prepaymentService.getP2pRemoteInterfaceCallUrlByJerseyService(p2pRemoteInterfaceCallUrl, loanId, dateString);
//        } catch (Throwable e) {
//            return null;
//        }
//        return remoteCallResult;
    }

    @Path("repayment-history")
    public RepaymentHistoryResource getRepaymentRecords() {
        return new RepaymentHistoryResource(loan, bizParametersRepository);
    }

    @Path("repayment-details")
    public RepaymentDetailsResource getRepaymentDetails() {
        return new RepaymentDetailsResource(loan, repaymentPlanRepository);
    }

}
