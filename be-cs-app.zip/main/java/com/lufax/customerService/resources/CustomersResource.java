package com.lufax.customerService.resources;


import com.lufax.common.domain.User;
import com.lufax.common.domain.repository.UserRepository;
import com.lufax.common.resources.ServiceProvider;
import com.lufax.common.resources.gsonTemplate.GsonExtractor;
import com.lufax.customerService.resources.gsonTemplate.UserBasicInfoGson;
import com.lufax.customerService.domain.OperationsLog;
import com.lufax.customerService.service.CustomerOperationsLogService;

import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import java.util.ArrayList;
import java.util.List;

import static com.lufax.customerService.domain.OperationMenu.USER_LIST;

public class CustomersResource {
    private HttpServletResponse response;

    private UserRepository userRepository;
    private User customerRepresentative;
    private ServiceProvider serviceProvider;
    private CustomerOperationsLogService customerOperationsLogService;

    public CustomersResource(User customerRepresentative, ServiceProvider serviceProvider) {
        this.customerRepresentative = customerRepresentative;
        this.serviceProvider = serviceProvider;
        this.userRepository = serviceProvider.getUserRepository();
        this.customerOperationsLogService = serviceProvider.getCustomerOperationsLogService();
    }

    public CustomersResource(User customerRepresentative, ServiceProvider serviceProvider, HttpServletResponse response) {
        this.customerRepresentative = customerRepresentative;
        this.serviceProvider = serviceProvider;
        this.userRepository = serviceProvider.getUserRepository();
        this.customerOperationsLogService = serviceProvider.getCustomerOperationsLogService();
        this.response = response;
    }

    @GET
    @Path("mobileNo/{mobileNo}")
    @Produces(value = MediaType.APPLICATION_JSON)
    public String getUsersByMobileNo(@PathParam("mobileNo") String mobileNo) {
        List<User> userInfoList = userRepository.findAllByMobileNo(mobileNo);
        customerOperationsLogService.logCustomerOperations(new OperationsLog(USER_LIST, null, mobileNo, 0L, customerRepresentative.id()));
        String result = GsonExtractor.extractGson(userInfoList, new ArrayList<UserBasicInfoGson>(), UserBasicInfoGson.class);
        return result;
    }

    @Path("{customerId}")
    public CustomerResource getUser(@PathParam("customerId") long customerId) {
        User user = userRepository.load(customerId);
        return new CustomerResource(customerRepresentative, user, serviceProvider);
    }
}
