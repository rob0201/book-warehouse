package com.lufax.customerService.resources;

import com.google.gson.Gson;
import com.lufax.common.domain.Investment;
import com.lufax.common.domain.TradingStatus;
import com.lufax.common.domain.User;
import com.lufax.common.domain.account.Money;
import com.lufax.common.domain.repository.InvestmentRepository;
import com.lufax.common.resources.ServiceProvider;
import com.lufax.customerService.resources.gsonTemplate.InvestmentGson;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class InvestmentsResource extends AuthenticatedRequiredRootResource {
    private ServiceProvider serviceProvider;
    private InvestmentRepository investmentRepository;

    public InvestmentsResource() {
    }

    public InvestmentsResource(User user, ServiceProvider serviceProvider) {
        setCurrentUser(user);
        this.serviceProvider = serviceProvider;
        this.investmentRepository = serviceProvider.getInvestmentRepository();
    }

    @Path("/{investmentId}")
    public InvestmentResource getInvestment(@PathParam("investmentId") long investmentId) {
        Investment investment = getInvestment(investmentId, currentUser());
        return new InvestmentResource(investment, serviceProvider);
    }

    @GET
    @Produces(value = MediaType.APPLICATION_JSON)
    public String getInvestments(@QueryParam("statusType") TradingStatus.Type statusType) {
        List<Investment> investments = investmentRepository.findOrderedInvestmentsByStatusTypeFor(currentUser(), statusType);
        Map<Investment, Money> paidPrincipalsForInvestments = investmentRepository.getPaidPrincipalsForInvestments(investments);
        List<InvestmentGson> investmentGsons = new ArrayList<InvestmentGson>();
        for (Investment investment : investments) {
            investmentGsons.add(new InvestmentGson(investment, paidPrincipalsForInvestments.get(investment)));
        }
        return new Gson().toJson(investmentGsons);
    }

    private Investment getInvestment(long investmentId, User user) {
        Investment investment = investmentRepository.findForLoaner(investmentId, user);
        if (investment == null) {
            throw new WebApplicationException(Response.Status.NOT_FOUND);
        }
        return investment;
    }

}
