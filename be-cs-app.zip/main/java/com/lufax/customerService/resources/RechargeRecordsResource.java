package com.lufax.customerService.resources;

import java.util.ArrayList;

import javax.ws.rs.GET;
import javax.ws.rs.Produces;

import com.google.gson.Gson;
import com.lufax.common.domain.RechargeRecord;
import com.lufax.common.domain.User;
import com.lufax.common.domain.repository.RechargeRecordRepository;
import com.lufax.common.domain.repository.TBankCodeRepository;
import com.lufax.common.web.helper.ConstantsHelper;
import com.lufax.customerService.resources.gsonTemplate.RechargeRecordGson;

public class RechargeRecordsResource {

	private User user;
	private RechargeRecordRepository rechargeRecordRepository;
	public RechargeRecordsResource(User user, RechargeRecordRepository rechargeRecordRepository, TBankCodeRepository tBankCodeRepository) {
		this.user = user;
		this.rechargeRecordRepository = rechargeRecordRepository;
	}

	@GET
	@Produces(ConstantsHelper.APPLICATION_JSON_WITH_DEFAULT_CHARSET_HEADER)
	public String list() {
		ArrayList<RechargeRecordGson> rechargeRecordGsons = new ArrayList<RechargeRecordGson>();
		for (RechargeRecord rechargeRecord : rechargeRecordRepository.findAllByUser(user)) {
			if (rechargeRecord.isCmsOrAutoOrWithHolding() || !rechargeRecord.isNew()) {
				RechargeRecordGson rechargeRecordGson = new RechargeRecordGson(rechargeRecord);
				rechargeRecordGsons.add(rechargeRecordGson);
			}
		}
		return new Gson().toJson(rechargeRecordGsons);
	}

}
