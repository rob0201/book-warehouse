package com.lufax.customerService.resources;

import com.google.gson.Gson;
import com.lufax.common.domain.repository.UserRepository;
import com.lufax.common.metadata.User;
import com.lufax.common.utils.DevLog;
import com.lufax.common.web.filter.UsersContextFilter;
import com.lufax.customerService.domain.CsServiceRecord;
import com.lufax.jersey.usercontext.UserContextUtils;
import com.lufax.customerService.domain.CsServiceDetail;
import com.lufax.customerService.domain.CsUser;
import com.lufax.customerService.domain.VisitorContactType;
import com.lufax.customerService.service.CsCustomerService;
import com.sun.jersey.api.core.InjectParam;
import com.sun.jersey.api.representation.Form;
import org.apache.commons.lang.StringUtils;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Path("/service-records")
public class CsServiceRecordResource {

    @InjectParam
    private CsCustomerService customerService;

    @InjectParam
    private UserRepository userRepository;

    @POST
    @Path("/save")
    @Produces(value = MediaType.TEXT_PLAIN)
    public String serviceRecordsResource(@FormParam("visitor_name") String visitorName, @FormParam("visit_phone_no") String visitPhoneNo, @FormParam("register_phone_no") String registerPhoneNo, @FormParam("visitor_gender") String visitorGender, @FormParam("user_name") String userName,
                                         @FormParam("serviceType") List<String> serviceTypes, @FormParam("urgencyLevel") String urgencyLevel,@FormParam("visitorContactType")String visitorContactType,@FormParam("customerServiceRecordId") long customerServiceRecordId) {
        String flag = "";
        if(StringUtils.isEmpty(visitPhoneNo)) {
        	visitPhoneNo = "";
        }
        if(visitPhoneNo.length() > 11) {
        	visitPhoneNo = visitPhoneNo.substring(0, 11);
        }
        try {
        	
            Long visitorId = customerService.saveVisitorInfo(visitorName, userName, visitorGender, visitPhoneNo.replaceAll(" ", ""), registerPhoneNo.replaceAll(" ", ""),VisitorContactType.getVisitorContactTypeByName(visitorContactType));
            User currentLoginUser = (User) UserContextUtils.getUserParameter(UsersContextFilter.USER_KEY);
            Long recordId = customerService.saveServiceRecord(currentLoginUser.getId(), visitorId,customerServiceRecordId);
            customerService.saveServiceDetail(recordId, extractServiceDetails(serviceTypes, urgencyLevel));
            flag = "success";
        } catch (Exception ex) {
            flag = "failure";
            DevLog.error(this, "Failed to save ", ex);
        }
        return flag;
    }

    @GET
    @Path("/query")
    @Produces(value = MediaType.APPLICATION_JSON)
    public String visitorInfo(@QueryParam("currentUserId") String currentUserId) {
        long userId;
        if (currentUserId == null || currentUserId.trim().equals("")) {
            userId = -1;
        } else {
            userId = Long.parseLong(currentUserId);
        }
        // if userId is null ,don't select the userId
        if(userId <= 0) {
            DevLog.debug(this,"The userId is null, return empty JSON");
            return "{}";
        }
        com.lufax.common.domain.User p2pUser = userRepository.findById(userId);

        CsUser user = new CsUser();
        if (p2pUser != null) {
            if (p2pUser.getIdentity() != null) {
                user.setName(p2pUser.getIdentity().getName());
                user.setGender(p2pUser.getIdentity().getGender().getChineseDes());
            }
            user.setRegPhoneNo(p2pUser.getMobileNo());
            user.setUserName(p2pUser.getUsername());
        }
        return new Gson().toJson(user);
    }

    private List<CsServiceDetail> extractServiceDetails(List<String> serviceTypes, String urgencyLevel) {
        List<CsServiceDetail> serviceDetails = new ArrayList<CsServiceDetail>();
        for (String serviceType : serviceTypes) {
            if (serviceType != null && !serviceType.trim().equals("")) {
                CsServiceDetail serviceDetail = generateServiceDetail(serviceType);
                serviceDetails.add(serviceDetail);
            }
        }
        serviceDetails.add(generateServiceDetail(urgencyLevel));
        return serviceDetails;
    }

    private CsServiceDetail generateServiceDetail(String serviceType) {
        CsServiceDetail serviceDetail = new CsServiceDetail();
        if (serviceType != null && !serviceType.trim().equals("")) {
            String[] st = serviceType.split(":");
            serviceDetail.setServiceTypeId(Long.parseLong(st[0]));
            StringBuilder sb = new StringBuilder();
            for (int i = 1; i < st.length; i++) {
                sb.append(st[i] + ":");
            }
            String str = sb.deleteCharAt(sb.length() - 1).toString().replaceAll(" ", "");
            serviceDetail.setServiceDetail(str.equals("null") ? null : str);
        }
        return serviceDetail;
    }

    // userId=1748131
    // customerId=1748131
    // &realName=曹燕飞
    // &registerPhone=15801745346
    // &userName=oneforce
    // &phone=15801745346
    // &gender=男
    // &source=phone
    // &messagePoolId=11
    // &consultation=项目|合作方名称：安业贷&consultation=风险&consultation=陆金所公司介绍&consultation=收益&consultation=注册用户名&consultation=身份认证&consultation=绑卡&consultation=资料修改&consultation=借款&consultation=收款&consultation=还款&consultation=合同协议&consultation=担保&consultation=支付宝充值&consultation=银行卡代扣充值&consultation=取现&consultation=银行卡转账充值&consultation=投资项目少&consultation=邮箱认证操作&consultation=平安员工认证&consultation=等额本息计算&consultation=实际收益与逾期收益差&consultation=市场活动：双11营销&consultation=公告：双11营销公告
    // &query=用户名注册&query=资金记&query=身份证认证&query=投资请求&query=银行卡绑定&query=贷款请求&query=贷款不成功&query=正在还款&query=取现不成功&query=取现记录&query=提前还款&query=逾期还款&query=充值记录&query=正在收款&query=充值不成功：无法使用visa卡充值
    // &todoOption=提供用户账号&todoOption=借款需求_城市：上海&todoOption=借款需求_手机：15801745346
    // &sendOption=紧急程度：紧急&sendOption=联系方式_手机：15801745346&sendOption=联系方式_固话：021-38635907-635907
    // &other=抱怨&other=投诉&other=建议&other=其他
    // &remark=测试使用数据包含很多没用的信息
    @POST
    @Path("/saveNew")
    @Produces(value = MediaType.TEXT_PLAIN)
    public String serviceRecordsResourceNew(Form form) {
        String flag = "";
        DevLog.debug(this,"The source is [" + getValueFromForm(form, "source") + "]");
        try {
            Long visitorId = customerService.saveVisitorInfo(getValueFromForm(form,"realName"), getValueFromForm(form, "userName"), getValueFromForm(form, "gender"),
            		formotPhone(getValueFromForm(form, "phone")), formotPhone(getValueFromForm(form, "registerPhone")),VisitorContactType.getByName(getValueFromForm(form, "source")),getValueFromForm(form, "contractMobile"),getValueFromForm(form, "contractPhone"));
            DevLog.debug(this, "Success to save the visitor, the id is [" + visitorId + "]");
            Long recordId = customerService.saveServiceRecord(convert(form, visitorId));
            DevLog.debug(this, "Success to save the customer service record, the record id is [" + recordId + "]");
            flag = "success";
        } catch (Exception ex) {
            flag = "failure";
            DevLog.error(this, "Failed to save ", ex);
        }
        return flag;
    }
    private CsServiceRecord convert(Form form, Long visitId) {
        User currentLoginUser = (User) UserContextUtils.getUserParameter(UsersContextFilter.USER_KEY);
        CsServiceRecord csServiceRecord = new CsServiceRecord();
        csServiceRecord.setVisitorId(visitId);
        csServiceRecord.setCustomerId(currentLoginUser.getId());
        if(form.containsKey("messagePoolId") && StringUtils.isNotEmpty(form.getFirst("messagePoolId"))) {
            csServiceRecord.setMessagePoolId(new Long(getValueFromForm(form,"messagePoolId")));
        }
        csServiceRecord.setCreatedAt(new Date());
        csServiceRecord.setConsultation(convertList(form.get("consultation")));
        csServiceRecord.setQuery(convertList(form.get("query")));
        csServiceRecord.setTodoOption(convertList(form.get("todoOption")));
        csServiceRecord.setSendOption(convertList(form.get("sendOption")));
        csServiceRecord.setOther(convertList(form.get("other")));
        csServiceRecord.setRemark(convertList(form.get("remark")));
        csServiceRecord.setUrgent(isUrgent(form));
        DevLog.debug(this, "The csServiceRecord is [" + csServiceRecord + "]");
        return csServiceRecord;
    }
    private String getValueFromForm(Form form, String key) {
        if(form.containsKey(key)) {
            return form.getFirst(key);
        } else {
            DevLog.debug(this,"Don't have the key [" + key + "]");
            return "";
        }
    }
    private boolean isUrgent(Form form){
        List<String> sendOption = form.get("sendOption");
        for(String options : sendOption) {
            if("紧急程度：紧急".equals(options)) {
                return true;
            }
        }
        return false;
    }
    private String convertList(List<String> list) {
        if(list == null || list.isEmpty()) {
            return "";
        }
        String result = "";
        for(int i =0; i< list.size(); i++) {
            String temp = list.get(i);
            if(StringUtils.isNotEmpty(temp)) {
                result += list.get(i);
                if(i != list.size() -1) {
                    result += "`";
                }
            }
        }
        return result;
    }
    
    public String formotPhone(String phone) {
    	if(StringUtils.isNotEmpty(phone)) {
    		if(phone.length() > 11) {
    			return phone.substring(0,11);
    		}
    	}
    	return phone;
    }
    public static void main(String[] args) {
		System.out.println("123456789012345678".substring(0,11));
	}
}
