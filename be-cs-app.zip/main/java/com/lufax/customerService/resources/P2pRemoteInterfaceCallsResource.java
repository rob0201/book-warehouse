package com.lufax.customerService.resources;

import com.lufax.common.resources.ServiceProvider;
import com.sun.jersey.api.core.InjectParam;

import javax.ws.rs.Path;
import javax.ws.rs.PathParam;

@Path("p2pRemote-CustomerService")
public class P2pRemoteInterfaceCallsResource {
    @InjectParam
    private ServiceProvider serviceProvider;

    @Path("/users/{customerId}")
    public P2pRemoteInterfaceCallResource getP2pRepaymentDetails(@PathParam("customerId") String customerId) {
        return new P2pRemoteInterfaceCallResource(customerId, serviceProvider);
    }


}
