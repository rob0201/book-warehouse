package com.lufax.customerService.dao;

import javax.persistence.NoResultException;

import org.springframework.stereotype.Repository;

import com.lufax.common.domain.repository.BaseRepository;
import com.lufax.customerService.pojo.BuyRequestPool;
import com.lufax.customerService.pojo.InvestContract;
import com.lufax.customerService.pojo.TradeContractType;

@Repository
public class InvestContractDAO extends BaseRepository<InvestContract> {
	public InvestContract findByInvestAndType(BuyRequestPool buyRequestPool, TradeContractType contractType) {
		try {
			return entityManager.createQuery("select ic from InvestContract ic where ic.buyRequestPool=:buyRequestPool and ic.contractType=:contractType", InvestContract.class).setParameter("buyRequestPool", buyRequestPool).setParameter("contractType", contractType).getSingleResult();
		} catch (NoResultException e) {
			return null;
		}
	}
}
