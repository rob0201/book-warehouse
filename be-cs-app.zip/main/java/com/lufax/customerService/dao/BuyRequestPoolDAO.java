package com.lufax.customerService.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.lufax.common.dao.BaseDAO;
import com.lufax.customerService.pojo.BuyRequestPool;
import com.lufax.customerService.pojo.BuyRequestStatus;
import com.lufax.customerService.pojo.UserProductAccount;
import com.lufax.customerService.pojo.UserProductAccountStatus;

@Repository
public class BuyRequestPoolDAO extends BaseDAO<BuyRequestPool> {

    // 查询正在收款数目
    public long countInvestGathering(long userId) {
        String hql = "select count(upa) from UserProductAccount upa where upa.ownerId = :userId and upa.status = :status ";
        return entityManager.createQuery(hql, Long.class).setParameter("userId", userId).setParameter("status", UserProductAccountStatus.EFFECTIVE).getSingleResult();
    }

    // 查询正在收款列表
    public List<UserProductAccount> findInvestGathering(long userId, int firstResult, int maxResult) {
        String hql = "select upa from UserProductAccount upa where upa.ownerId = :userId and upa.status = :status order by upa.id desc ";
        return entityManager.createQuery(hql, UserProductAccount.class).setParameter("userId", userId).setParameter("status", UserProductAccountStatus.EFFECTIVE)
                .setFirstResult(firstResult).setMaxResults(maxResult).getResultList();
    }

    // 查询投资历史数目
    public long countInvestHistory(long userId) {
        String hql = "select count(upa) from UserProductAccount upa where upa.ownerId = :userId and upa.status = :status ";
        return entityManager.createQuery(hql, Long.class).setParameter("userId", userId).setParameter("status", UserProductAccountStatus.INVALID).getSingleResult();
    }

    // 产寻投资历史列表
    public List<UserProductAccount> findInvestHistory(long userId, int firstResult, int maxResult) {
        String hql = "select upa from UserProductAccount upa where upa.ownerId = :userId and upa.status = :status order by upa.id desc ";
        return entityManager.createQuery(hql, UserProductAccount.class).setParameter("userId", userId).setParameter("status", UserProductAccountStatus.INVALID).setFirstResult(firstResult).setMaxResults(maxResult).getResultList();
    }


    // 查询投资请求数目
    public long countInvestRequest(long userId) {

        List<BuyRequestStatus> status = new ArrayList<BuyRequestStatus>();
        status.add(BuyRequestStatus.WAIT_CONFIRM);
        status.add(BuyRequestStatus.FAIL);
        status.add(BuyRequestStatus.FREEZE_FAIL);
        status.add(BuyRequestStatus.REQUEST_FAIL);

        String hql = "select count(b) from BuyRequestPool b where b.buyer.id = :userId and b.status in :status";
        return entityManager.createQuery(hql, Long.class).setParameter("userId", userId).setParameter("status", status).getSingleResult();
    }

    // 查询投资请求列表
    public List<BuyRequestPool> findInvestRequest(long userId, int firstResult, int maxResult) {
        List<BuyRequestStatus> status = new ArrayList<BuyRequestStatus>();
        status.add(BuyRequestStatus.WAIT_CONFIRM);
        status.add(BuyRequestStatus.FAIL);
        status.add(BuyRequestStatus.FREEZE_FAIL);
        status.add(BuyRequestStatus.REQUEST_FAIL);

        String hql = "select b from BuyRequestPool b where b.buyer.id = :userId and b.status in :status order by b.createAt desc ";
        return entityManager.createQuery(hql, BuyRequestPool.class).setParameter("userId", userId).setParameter("status", status).setFirstResult(firstResult).setMaxResults(maxResult).getResultList();
    }

    public BuyRequestPool findBuyRequestPoolWithUserAndProduct(long userId, long productId, List<BuyRequestStatus> buyRequestStatuses) {
        String hql = "select b from BuyRequestPool b where b.buyer.id = :userId and b.productId=:productId and b.status in :statuses ";
        TypedQuery<BuyRequestPool> buyRequestPoolTypedQuery = entityManager.createQuery(hql, BuyRequestPool.class).setParameter("userId", userId).setParameter("productId", productId).setParameter("statuses", buyRequestStatuses);
        return getSingleResult(buyRequestPoolTypedQuery);
    }
}