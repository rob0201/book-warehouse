package com.lufax.customerService.dao;

import com.lufax.common.dao.BaseDAO;
import com.lufax.customerService.pojo.SMECollectionPlan;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class CollectionPlanDAO extends BaseDAO<SMECollectionPlan>{
    public List<SMECollectionPlan>  findCollectionPlan(long repaymentPlanId){
       String sql="select cp.* from sme_collection_plans cp,user_product_account a,sme_repayment_plans rp where cp.user_product_account_id = a.id and rp.product_id = a.product_id and cp.period = rp.period and rp.id = :repaymentPlanId";
       return entityManager.createNativeQuery(sql,SMECollectionPlan.class).setParameter("repaymentPlanId",repaymentPlanId).getResultList();
    }

	public List<SMECollectionPlan> findCollectionPlanByProductIdAndUserId(long productId, long userId) {
		String hql = "select p from SMECollectionPlan p where p.userProductAccount.productId = :productId and p.userProductAccount.ownerId = :userId order by p.planNumber asc ";
		return entityManager.createQuery(hql, SMECollectionPlan.class).setParameter("productId", productId).setParameter("userId", userId).getResultList();
	}
}
