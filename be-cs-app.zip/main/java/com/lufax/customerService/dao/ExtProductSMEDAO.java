package com.lufax.customerService.dao;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.lufax.common.dao.BaseDAO;
import com.lufax.customerService.pojo.Asset;
import com.lufax.customerService.pojo.AssetPool;
import com.lufax.customerService.pojo.ExtProductSME;
import com.lufax.customerService.pojo.FlowStatus;


@Repository
public class ExtProductSMEDAO extends BaseDAO<ExtProductSME> {
	
	 public long queryProductforLendingCount(String assetName, String productName) {
	        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
	        CriteriaQuery<Long> criteriaQuery = cb.createQuery(Long.class);
	        Root<ExtProductSME> eRoot = criteriaQuery.from(ExtProductSME.class);
	        Join<ExtProductSME, AssetPool> assetPool = eRoot.join("assetPool", JoinType.LEFT);
	        Join<AssetPool, Asset> asset = assetPool.join("asset", JoinType.LEFT);
	        criteriaQuery.select(cb.count(eRoot));
	        List<Predicate> predicateList = new ArrayList<Predicate>();
	        if (assetName != null && !"".equals(assetName)) {
	            Predicate predicate = cb.equal(asset.<String>get("name"), assetName);
	            predicateList.add(predicate);
	        }
	        if (productName != null && !"".equals(productName)) {
	            Predicate predicate1 = cb.like(eRoot.<String>get("name"), productName + "%");
	            predicateList.add(predicate1);
	        }

	        Predicate predicate1 = cb.equal(eRoot.<FlowStatus>get("flowStatus"), FlowStatus.COLLECT_SUCCESS);
	        predicateList.add(predicate1);

	        Predicate predicate = cb.equal(eRoot.<Boolean>get("isWithdraw"), false);
	        predicateList.add(predicate);

	        Predicate[] predicates = new Predicate[predicateList.size()];
	        predicateList.toArray(predicates);
	        criteriaQuery.where(predicates);
	        return entityManager.createQuery(criteriaQuery).getSingleResult();
	    }
	   

	    public List<ExtProductSME> queryProductforLending(String assetName, String productName, int firstResult, int maxResults) {
	        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
	        CriteriaQuery<ExtProductSME> criteriaQuery = cb.createQuery(ExtProductSME.class);
	        Root<ExtProductSME> eRoot = criteriaQuery.from(ExtProductSME.class);
	        Join<ExtProductSME,AssetPool> assetPool = eRoot.join("assetPool", JoinType.LEFT);
	        Join<AssetPool, Asset> asset = assetPool.join("asset", JoinType.LEFT);
	        criteriaQuery.select(eRoot);
	        List<Predicate> predicateList = new ArrayList<Predicate>();
	        if (assetName != null) {
	            Predicate predicate = cb.like(asset.<String>get("name"), assetName + "%");
	            predicateList.add(predicate);
	        }
	        if (productName != null) {
	            Predicate predicate1 = cb.like(eRoot.<String>get("name"), productName + "%");
	            predicateList.add(predicate1);
	        }
	        Predicate predicate1 = cb.equal(eRoot.<FlowStatus>get("flowStatus"), FlowStatus.COLLECT_SUCCESS);
	        predicateList.add(predicate1);

	        Predicate predicate = cb.equal(eRoot.<Boolean>get("isWithdraw"), false);
	        predicateList.add(predicate);

	        Predicate[] predicates = new Predicate[predicateList.size()];
	        predicateList.toArray(predicates);
	        criteriaQuery.where(predicates);
	        criteriaQuery.orderBy(cb.desc(asset.<Object>get("fcd")), cb.asc(asset.get("name")));
	        return entityManager.createQuery(criteriaQuery).setMaxResults(maxResults).setFirstResult(firstResult).getResultList();
	    }
	    
	    public long countProductForAssetPoolId(long assetPoolId){
	    	String hql="select count(ps) from ExtProductSME ps ,AssetPool ap where ps.assetPool.id=ap.id and ap.asset.id in ( select sa.id from AssetPool ap,Asset sa where ap.asset.id=sa.id and ap.id=:assetPoolId)";
	    	return entityManager.createQuery(hql, Long.class).setParameter("assetPoolId", assetPoolId).getSingleResult();
	    }
	    
	    public List queryRepayment(String productName,Long assetId,int firstResult,int maxResults){
	    	String sql="select p.id as PRODUCT_ID,p.contract_template_id,p.name,p.code,p.target_funds,p.actual_funds,p.unit_price,p.min_invest_shares,p.increase_investment_shares,p.product_category,p.interest_rate,p.status,p.version,p.fcd,p.fcu,p.lcd,p.lcu," +
	    			"ep.*,(select count(1) from sme_repayment_plans rp where rp.product_id(+) = p.id) as planNumbers "+
                "from sme_product p, ext_product_sme ep,sme_asset a,sme_asset_pool ap "+
                "where p.id = ep.id and a.id=ap.asset_id and ap.id=ep.asset_pool_id and a.id=:assetId and p.status='COLLECT_SUCCESS' and p.name like :productName ";
	    	TypedQuery query = (TypedQuery) entityManager.createNativeQuery(sql,"ExtProductSMEResults").setParameter("assetId", assetId).setParameter("productName", ("%"+productName+"%"));
	    	return query.setFirstResult(firstResult).setMaxResults(maxResults).getResultList();
	    }
	    
	    public BigDecimal queryRepaymentCount(String productName,Long assetId){
	    	String sql="select count(1) "+
                "from sme_product p, ext_product_sme ep,sme_asset a,sme_asset_pool ap "+
                "where p.id = ep.id and a.id=ap.asset_id and ap.id=ep.asset_pool_id and a.id=:assetId and p.status='COLLECT_SUCCESS' and p.name like :productName ";
	    	TypedQuery query = (TypedQuery) entityManager.createNativeQuery(sql).setParameter("assetId", assetId).setParameter("productName", ("%"+productName+"%"));
	    	return (BigDecimal) query.getSingleResult();
	    }
	    
	    public List queryRepaymentByProductName(String productName,int firstResult,int maxResults){
	    	String sql="select p.id as PRODUCT_ID,p.contract_template_id,p.name,p.code,p.target_funds,p.actual_funds,p.unit_price,p.min_invest_shares,p.increase_investment_shares,p.product_category,p.interest_rate,p.status,p.version,p.fcd,p.fcu,p.lcd,p.lcu," +
	    			"ep.*,(select count(1) from sme_repayment_plans rp where rp.product_id(+) = p.id) as planNumbers "+
                "from sme_product p, ext_product_sme ep "+
                "where p.id = ep.id and p.status='COLLECT_SUCCESS' and p.name like :productName ";
	    	TypedQuery query = (TypedQuery) entityManager.createNativeQuery(sql,"ExtProductSMEResults").setParameter("productName", ("%"+productName+"%"));
	    	return query.setFirstResult(firstResult).setMaxResults(maxResults).getResultList();
	    }
	    
	    public BigDecimal queryRepaymentCountByProductName(String productName){
	    	String sql="select count(1) "+
                "from sme_product p, ext_product_sme ep "+
                "where p.id = ep.id and p.status='COLLECT_SUCCESS' and p.name like :productName ";
	    	TypedQuery query = (TypedQuery) entityManager.createNativeQuery(sql).setParameter("productName", ("%"+productName+"%"));
	    	return (BigDecimal) query.getSingleResult();
	    }
}
