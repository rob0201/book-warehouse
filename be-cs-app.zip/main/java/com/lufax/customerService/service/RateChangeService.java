package com.lufax.customerService.service;

import com.lufax.common.domain.BizParameters;
import com.lufax.common.domain.repository.BizParametersRepository;
import com.lufax.common.utils.DevLog;
import com.lufax.common.utils.RateChangeUtils;
import com.lufax.customerService.domain.PointInterestRate;
import com.lufax.customerService.domain.RateChangePlan;
import com.lufax.customerService.domain.RateChangePlanStatus;
import com.lufax.customerService.domain.repository.RateChangePlanRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import static com.lufax.common.domain.BizParameters.INTEREST_FLOAT_RATE;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

@Service
public class RateChangeService {

    @Autowired
    private BizParametersRepository bizParametersRepository;
    @Autowired
    private RateChangePlanRepository rateChangePlanRepository;

    @Transactional
    public void updateRateToBizParameter(Date executeDate) {
        DevLog.info(this.getClass(), "start to update interest rate to biz parameter");
        List<RateChangePlan> rateChangePlans = rateChangePlanRepository.findRateChangeToExecute(executeDate);
        if (rateChangePlans == null || rateChangePlans.size() == 0) {
            DevLog.info(this.getClass(), "no interest rate need to update to biz parameter");
            return;
        }

        for (RateChangePlan rateChangePlan : rateChangePlans) {
            String parameterCode = rateChangePlan.getParameterCode();
            BizParameters bizParameters = bizParametersRepository.findByCode(parameterCode);
            bizParameters.setParameterValue(rateChangePlan.getParameterValue());
            bizParametersRepository.update(bizParameters);
            updateRateChangePlanStatus(rateChangePlan, RateChangePlanStatus.VALID);
            DevLog.info(this.getClass(), String.format("update interest rate(code=%s, value=%s) to biz parameter", rateChangePlan.getParameterCode(), rateChangePlan.getParameterValue()));
        }
////todo zhaoluxiao
//        P2PBizConfig.refreshCache();
    }

    private void updateRateChangePlanStatus(RateChangePlan rateChangePlan, RateChangePlanStatus rateChangePlanStatus) {
        rateChangePlan.setRateChangePlanStatus(rateChangePlanStatus);
        rateChangePlanRepository.persist(rateChangePlan);
    }
        @Transactional
    public List<PointInterestRate> getPointInterestRateToApply(Date today) {
        List<RateChangePlan> rateChangePlans = rateChangePlanRepository.findRateChangeToExecute(today);
        BigDecimal interestFloatRate = bizParametersRepository.findParameterValueByCode(INTEREST_FLOAT_RATE);
        return RateChangeUtils.convertToPointInterestRateList(interestFloatRate, rateChangePlans);
    }
        @Transactional
    public void updateRateToBizParameter(PointInterestRate pointInterestRate) {
        DevLog.info(this.getClass(), "start to update interest rate to biz parameter");
        for (RateChangePlan rateChangePlan : pointInterestRate.getRateChangePlans()) {
            String parameterCode = rateChangePlan.getParameterCode();
            BizParameters bizParameters = bizParametersRepository.findByCode(parameterCode);
            bizParameters.setParameterValue(rateChangePlan.getParameterValue());
            bizParametersRepository.update(bizParameters);
            updateRateChangePlanStatus(rateChangePlan, RateChangePlanStatus.VALID);
            DevLog.info(this.getClass(), String.format("update interest rate(code=%s, value=%s) to biz parameter", rateChangePlan.getParameterCode(), rateChangePlan.getParameterValue()));
        }
    }
}
