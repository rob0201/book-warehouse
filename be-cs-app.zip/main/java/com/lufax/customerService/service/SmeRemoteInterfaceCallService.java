package com.lufax.customerService.service;


import javax.ws.rs.core.Response;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.lufax.common.exception.RemoteInvokeException;
import com.lufax.common.utils.BEProperties;
import com.lufax.common.utils.DevLog;
import com.lufax.common.web.helper.ConstantsHelper;
import com.lufax.jersey.client.JerseyService;
import com.sun.jersey.api.client.ClientResponse;

@Service
public class SmeRemoteInterfaceCallService {

    @Autowired
    private BEProperties p2PProperties;

    @Autowired
    @Qualifier("smeJerseyService")
    private JerseyService smeJerseyService;


    public String getSmeRemoteInterfaceCallUrlByJerseyService(String smeRemoteInterfaceCallUrl) {
        ClientResponse clientResponse = null;

        try {
            clientResponse = smeJerseyService.getInstance(smeRemoteInterfaceCallUrl).getResource().queryParam("pageCount", String.valueOf(ConstantsHelper.CUSTOMER_SERVICE_PAGE_LIMIT)).get(ClientResponse.class);
        } catch (Throwable e) {
            DevLog.error(this, String.format("sme remote call failed"), e);
            throw new RemoteInvokeException("网络异常", e);
            
        }
        if (!(Response.Status.OK.getStatusCode() == clientResponse.getClientResponseStatus().getStatusCode())) {
            clientResponse.close();
            return null;
        }

        return clientResponse.getEntity(String.class);
    }
}
