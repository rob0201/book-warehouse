package com.lufax.customerService.service;


import com.lufax.common.exception.P2PErrorCode;
import com.lufax.common.exception.P2PException;
import com.lufax.common.utils.DevLog;
import com.lufax.jersey.client.JerseyService;
import com.sun.jersey.api.client.ClientResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;

@Service
public class XinbaoRemoteInterfaceCallService {
    @Autowired
    @Qualifier("xinbaoJerseyService")
    private JerseyService xinbaoJerseyService;

    public String getRemoteInterfaceCallUrlByJerseyService(String p2pRemoteInterfaceCallUrl, String customerId, String date) {
        DevLog.info(this, String.format("xinbaoRemoteInterfaceCallUrl is [%s] host is [%s]", p2pRemoteInterfaceCallUrl, xinbaoJerseyService.getHost().getHostURI()));
        DevLog.info(this, String.format("customerId is [%s]", customerId));
        ClientResponse clientResponse = null;
        try {
            if (date != null) {
                clientResponse = xinbaoJerseyService.getInstance(p2pRemoteInterfaceCallUrl).withUser(customerId).getResource().queryParam("date", date).get(ClientResponse.class);
            } else {
                clientResponse = xinbaoJerseyService.getInstance(p2pRemoteInterfaceCallUrl).withUser(customerId).getResource().get(ClientResponse.class);
            }
        } catch (Throwable e) {
            DevLog.error(this, String.format("p2p remote call failed clinet response is [" + clientResponse + "]"), e);
            throw new P2PException(P2PErrorCode.REMOTE_INVOKE_FAILED, "network connect exception");
        }
        DevLog.info(this, String.format("clientResponse.status is [%s]", clientResponse.getClientResponseStatus().getStatusCode()));
//        System.out.println(String.format("clientResponse.status is [%s]", clientResponse.getClientResponseStatus().getStatusCode()));
        if (200 == clientResponse.getClientResponseStatus().getStatusCode()) {
            return clientResponse.getEntity(String.class);
        }
        if (406 == clientResponse.getClientResponseStatus().getStatusCode()) {
            throw new WebApplicationException(Response.Status.NOT_ACCEPTABLE);
        }
        if(null != clientResponse) {
        	clientResponse.close();
        }
        return null;

    }


}
