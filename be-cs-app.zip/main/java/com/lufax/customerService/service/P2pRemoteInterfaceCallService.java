package com.lufax.customerService.service;


import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.lufax.common.exception.P2PErrorCode;
import com.lufax.common.exception.P2PException;
import com.lufax.common.utils.DevLog;
import com.lufax.jersey.client.JerseyService;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.representation.Form;

@Service
public class P2pRemoteInterfaceCallService {
    @Autowired
    @Qualifier("p2pJerseyService")
    private JerseyService p2pJerseyService;

    public String getP2pRemoteInterfaceCallUrlByJerseyService(String p2pRemoteInterfaceCallUrl, String customerId, String date) {
        DevLog.info(this, String.format("p2pRemoteInterfaceCallUrl is [%s]", p2pRemoteInterfaceCallUrl));
        DevLog.info(this, String.format("customerId is [%s]", customerId));
        ClientResponse clientResponse = null;
        try {
            if (date != null) {
                clientResponse = p2pJerseyService.getInstance(p2pRemoteInterfaceCallUrl).withUser(customerId).getResource().queryParam("date", date).get(ClientResponse.class);
            } else {
                clientResponse = p2pJerseyService.getInstance(p2pRemoteInterfaceCallUrl).withUser(customerId).getResource().get(ClientResponse.class);
            }
        } catch (Throwable e) {
            DevLog.error(this, String.format("p2p remote call failed"), e);
            throw new P2PException(P2PErrorCode.REMOTE_INVOKE_FAILED, "network connect exception");
        }
        DevLog.info(this, String.format("clientResponse.status is [%s]", clientResponse.getClientResponseStatus().getStatusCode()));
//        System.out.println(String.format("clientResponse.status is [%s]", clientResponse.getClientResponseStatus().getStatusCode()));
        if (200 == clientResponse.getClientResponseStatus().getStatusCode()) {
            return clientResponse.getEntity(String.class);
        }
        if (406 == clientResponse.getClientResponseStatus().getStatusCode()) {
            throw new WebApplicationException(Response.Status.NOT_ACCEPTABLE);
        }
        if(null != clientResponse) {
        	clientResponse.close();
        }
        return null;

    }
    public String getPrepaymentApply(String userId, String loanId) {
    	
    	String url =  String.format("/service/users/%s/loans/%s/prepayment/apply", userId, loanId);
    	ClientResponse  response = null;
    	try {
    		response  = p2pJerseyService.getInstance(url).withUser(userId).getResource().post(ClientResponse.class);
    		if (200 == response.getClientResponseStatus().getStatusCode()) {
                return response.getEntity(String.class);
            } else {
            	DevLog.error(this, String.format("p2p remote call failed response status is [" + response.getClientResponseStatus().getStatusCode() + "]"));
        		throw new P2PException(P2PErrorCode.REMOTE_INVOKE_FAILED, "network connect exception");
            }
    	} catch(Exception e) {
    		DevLog.error(this, String.format("p2p remote call failed response is [" + response + "]"), e);
    		throw new P2PException(P2PErrorCode.REMOTE_INVOKE_FAILED, "network connect exception");
    	}finally {
    		if(null != response) {
    			response.close();
    		}
    	}
    	
    }
    
    public String getPrepaymentGetInfo(String userId, String loanId, String prepayEstimateRequestId) {
    	String url =  String.format("/service/users/%s/loans/%s/prepayment/getInfo", userId, loanId);
    	ClientResponse  response = null;
    	Form form = new Form();
    	form.add("prepayEstimateRequestId", prepayEstimateRequestId);
    	try {
    		response  = p2pJerseyService.getInstance(url).withUser(userId).getResource().post(ClientResponse.class,form);
    		if (200 == response.getClientResponseStatus().getStatusCode()) {
                return response.getEntity(String.class);
            } else {
            	DevLog.error(this, String.format("p2p remote call failed response status is [" + response.getClientResponseStatus().getStatusCode() + "]"));
        		throw new P2PException(P2PErrorCode.REMOTE_INVOKE_FAILED, "network connect exception");
            }
    	} catch(Exception e) {
    		DevLog.error(this, String.format("p2p remote call failed response is [" + response + "]"), e);
    		throw new P2PException(P2PErrorCode.REMOTE_INVOKE_FAILED, "network connect exception");
    	}finally {
    		if(null != response) {
    			response.close();
    		}
    	}
    	
    }
    
    
    
}
