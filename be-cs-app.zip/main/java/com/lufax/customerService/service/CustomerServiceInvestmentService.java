package com.lufax.customerService.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lufax.common.domain.CollectionDetail;
import com.lufax.common.domain.CollectionPlan;
import com.lufax.common.domain.Investment;
import com.lufax.common.domain.InvestmentRequest;
import com.lufax.common.domain.TradingStatus;
import com.lufax.common.domain.User;
import com.lufax.common.domain.product.TransferRequest;
import com.lufax.common.domain.repository.BizParametersRepository;
import com.lufax.common.domain.repository.CollectionPlanRepository;
import com.lufax.common.domain.repository.InvestmentRepository;
import com.lufax.common.domain.repository.InvestmentRequestRepository;
import com.lufax.common.domain.transfer.TransferRequestRepository;
import com.lufax.customerService.resources.gsonTemplate.CollectionHistoryGson;
import com.lufax.customerService.resources.gsonTemplate.CustomerServiceInvestmentGson;
import com.lufax.customerService.resources.gsonTemplate.CustomerServiceInvestmentRequestGson;
import com.lufax.customerService.resources.gsonTemplate.CustomerServiceProductGson;

@Service
public class CustomerServiceInvestmentService {
	@Autowired
	private InvestmentRepository investmentRepository;
	@Autowired
    private InvestmentRequestRepository investmentRequestRepository;
	@Autowired
    private CollectionPlanRepository collectionPlanRepository;
	@Autowired
	private TransferRequestRepository transferRequestRepository;
	@Autowired
	private BizParametersRepository bizParametersRepository;
	public static final String PRODUCT_TRANSFER_FEE ="product.transfer.fee";
	
	

    /**
     * 投资请求查询
     * @param user
     * @param statuses
     * @param maxNum
     * @param offset
     * @return
     */
	public List<CustomerServiceInvestmentRequestGson> getInvestmentRequests(User user,List<String> statuses,int maxNum,int offset){
		List<CustomerServiceInvestmentRequestGson> investmentRequestGsons = new ArrayList<CustomerServiceInvestmentRequestGson>();
		List<InvestmentRequest> investmentRequests = investmentRequestRepository.findAllByLoanerAndStatus(user, statuses,maxNum,offset);
        for (InvestmentRequest investmentRequest : investmentRequests) {
        	investmentRequestGsons.add(new CustomerServiceInvestmentRequestGson(investmentRequest,new CustomerServiceProductGson(investmentRequest.getProduct())));
        }
        return investmentRequestGsons;
	}
	/**
	 * 正在收款及投资历史
	 * @param user
	 * @param type
	 * @param maxNum
	 * @param offset
	 * @return
	 */
	public List<CustomerServiceInvestmentGson> getInvestmentByStatusAndUser(User user,TradingStatus.Type type,int maxNum,int offset){
		List<CustomerServiceInvestmentGson> investmentGsons = new ArrayList<CustomerServiceInvestmentGson>();
        List<Investment> investments = investmentRepository.findInvestmentsByStatusAndUser(user, type, maxNum, offset);
        BigDecimal transferAmount = bizParametersRepository.findParameterValueByCode(PRODUCT_TRANSFER_FEE);
        for (Investment investment : investments) {
            List<CollectionPlan> collectionPlans = collectionPlanRepository.findByInvestmentIdWithAllRecords(investment.id());
            investment.setCollectionPlans(collectionPlans);
            ArrayList<CollectionDetail> collectionDetails = new ArrayList<CollectionDetail>();
	        for (CollectionPlan collectionPlan : collectionPlans) {
	        	collectionDetails.add(new CollectionDetail(collectionPlan));
	        }
            if (investment.isTransferred()) {
                List<TransferRequest> transferRequests = transferRequestRepository.findByInvestmentIdWithData(investment.id());
                investment.setTransferRequests(transferRequests);
            }
            if(investment.getStatus().equals(TradingStatus.TRANSFER)){
            	investmentGsons.add(new CustomerServiceInvestmentGson(investment,new CollectionHistoryGson(collectionDetails,investment,transferAmount)));
            }else{
            	investmentGsons.add(new CustomerServiceInvestmentGson(investment,new CollectionHistoryGson(collectionDetails,investment)));
            }
        }
        return investmentGsons;
	}
	
}
