package com.lufax.customerService.service;


import java.util.Date;
import java.util.List;

import com.lufax.common.utils.DevLog;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lufax.common.domain.User;
import com.lufax.common.domain.repository.UserRepository;
import com.lufax.customerService.domain.CsServiceDetail;
import com.lufax.customerService.domain.CsServiceRecord;
import com.lufax.customerService.domain.CsVisitor;
import com.lufax.customerService.domain.VisitorContactType;
import com.lufax.customerService.domain.repository.CsServiceDetailRepository;
import com.lufax.customerService.domain.repository.CsServiceRecordRepository;
import com.lufax.customerService.domain.repository.CsVisitorRepository;

@Service
public class CsCustomerService {

    @Autowired
    private CsVisitorRepository visitorRepository;

    @Autowired
    private CsServiceRecordRepository serviceRecordRepository;

    @Autowired
    private CsServiceDetailRepository serviceDetailRepository;

    @Autowired
    private UserRepository userRepository;

    public CsCustomerService() {

    }

    @Transactional
    public Long saveVisitorInfo(String visitorName, String userName, String gender, String visitPhoneNo, String regPhoneNo,VisitorContactType type,String contractMobile,String contractPhone) {
        CsVisitor visitor = new CsVisitor();
        visitor.setName(visitorName);
        visitor.setUserName(userName);
        visitor.setGender(gender);
        visitor.setVisitPhoneNo(visitPhoneNo);
        visitor.setRegisterPhoneNo(regPhoneNo);
        visitor.setVisitCount(1);
        visitor.setLastVisitTime(new Date());
        visitor.setContactSourceType(type);
        visitor.setRemark("暂不区分访客");
        visitor.setContractMobile(contractMobile);
        visitor.setContractPhone(contractPhone);

        Long userId = extractUserId(userName, visitPhoneNo, regPhoneNo);
        visitor.setUserId(userId);
        visitorRepository.persist(visitor);
        return visitor.getId();
    }

    @Transactional
    public Long saveVisitorInfo(String visitorName, String userName, String gender, String visitPhoneNo, String regPhoneNo,VisitorContactType type) {
        CsVisitor visitor = new CsVisitor();
        visitor.setName(visitorName);
        visitor.setUserName(userName);
        visitor.setGender(gender);
        visitor.setVisitPhoneNo(visitPhoneNo);
        visitor.setRegisterPhoneNo(regPhoneNo);
        visitor.setVisitCount(1);
        visitor.setLastVisitTime(new Date());
        visitor.setContactSourceType(type);
        visitor.setRemark("暂不区分访客");

        Long userId = extractUserId(userName, visitPhoneNo, regPhoneNo);
        visitor.setUserId(userId);
        visitorRepository.persist(visitor);
        return visitor.getId();
    }

    private Long extractUserId(String username, String visitPhoneNo, String regPhoneNo) {
        User user = null;
        if (username != null && !username.trim().equals("") && !username.equals("匿名")) {
            user = userRepository.findByUserName(username);
        } else if (regPhoneNo != null && !regPhoneNo.trim().equals("")) {
            List<User> userInfoList = userRepository.findAllByMobileNo(regPhoneNo);
            user = (userInfoList.isEmpty() ? null : userInfoList.get(0));
        } else if (visitPhoneNo != null && !visitPhoneNo.trim().equals("")) {
            List<User> userInfoList = userRepository.findAllByMobileNo(visitPhoneNo);
            user = (userInfoList.isEmpty() ? null : userInfoList.get(0));
        }
        return (user != null ? user.id() : null);
    }

    @Transactional
    public Long saveServiceRecord(long customerId, long visitorId,long messagePoolId) {
        CsServiceRecord record = new CsServiceRecord();
        record.setVisitorId(visitorId);
        record.setCustomerId(customerId);
        record.setMessagePoolId(messagePoolId);
        record.setCreatedAt(new Date());
        serviceRecordRepository.persist(record);
        return record.getId();
    }

    @Transactional
    public Long saveServiceRecord(CsServiceRecord record) {
        serviceRecordRepository.persist(record);
        return record.getId();
    }

    @Transactional
    public void saveServiceDetail(Long recordId, List<CsServiceDetail> csServiceDetails) {
        for (CsServiceDetail detail : csServiceDetails) {
            detail.setServiceRecordId(recordId);
            serviceDetailRepository.persist(detail);
        }
    }
}
