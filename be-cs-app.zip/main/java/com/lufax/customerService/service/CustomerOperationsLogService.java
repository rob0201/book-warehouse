package com.lufax.customerService.service;

import com.lufax.common.domain.repository.CustomerOperationsLogRepository;
import com.lufax.customerService.domain.OperationsLog;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class CustomerOperationsLogService {

    @Autowired
    private CustomerOperationsLogRepository customerOperationsLogRepository;

    public CustomerOperationsLogService() {
    }

    public CustomerOperationsLogService(CustomerOperationsLogRepository customerOperationsLogRepository) {
       this.customerOperationsLogRepository = customerOperationsLogRepository;
    }

    @Transactional
    public void logCustomerOperations(OperationsLog operationsLog) {
        customerOperationsLogRepository.persist(operationsLog);
    }


}
