package com.lufax.customerService.service;

import com.lufax.customerService.service.impl.AbstractRemoteServiceFascade;
import com.lufax.jersey.client.JerseyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

@Service
public class RemoteServiceFascade extends AbstractRemoteServiceFascade {

    @Qualifier(value = "commonJerseyService")
    @Autowired
    private JerseyService commonJerseyService;

    protected JerseyService getRemoteService() {
        return commonJerseyService;
    }
}
