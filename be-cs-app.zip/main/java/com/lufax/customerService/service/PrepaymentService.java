package com.lufax.customerService.service;

import java.util.Date;

import javax.ws.rs.core.Response;

import org.joda.time.DateTime;
import org.joda.time.Days;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.lufax.common.domain.Loan;
import com.lufax.common.domain.PlanStatus;
import com.lufax.common.domain.RepaymentPlan;
import com.lufax.common.domain.account.service.AccountService;
import com.lufax.common.domain.repository.BizParametersRepository;
import com.lufax.common.domain.repository.CollectionPlanRepository;
import com.lufax.common.domain.repository.CollectionRecordRepository;
import com.lufax.common.domain.repository.InvestmentRepository;
import com.lufax.common.domain.repository.RepaymentOperationRepository;
import com.lufax.common.domain.repository.RepaymentPlanRepository;
import com.lufax.common.domain.repository.RepaymentRecordRepository;
import com.lufax.common.domain.repository.TransactionRepository;
import com.lufax.common.domain.repository.UserRepository;
import com.lufax.common.exception.P2PErrorCode;
import com.lufax.common.exception.P2PException;
import com.lufax.common.exception.PrepaymentException;
import com.lufax.common.utils.BEProperties;
import com.lufax.common.utils.DateUtils;
import com.lufax.common.utils.DevLog;
import com.lufax.customerService.resources.gsonTemplate.LoanPrepaymentInfoGson;
import com.lufax.jersey.client.JerseyService;
import com.lufax.sms.service.SmsService;
import com.sun.jersey.api.client.ClientResponse;

@Service
public class PrepaymentService {
    @Autowired
    private BEProperties p2PProperties;
    
    @Autowired
    @Qualifier("p2pJerseyService")
    private JerseyService p2pJerseyService;
    
//    private static Client client = Client.create();
//    private AccountService accountService;
//    private RepaymentPlanRepository repaymentPlanRepository;
//    private CollectionPlanRepository collectionPlanRepository;
//    private RepaymentRecordRepository repaymentRecordRepository;
//    private RepaymentOperationRepository repaymentOperationRepository;
//    private CollectionRecordRepository collectionRecordRepository;
//    private UserRepository userRepository;
    private BizParametersRepository bizParametersRepository;
//    private SmsService smsService;
//    private RepaymentService repaymentService;
//    private TransactionRepository transactionRepository;
//    private InvestmentRepository investmentRepository;

    public PrepaymentService() {
    }

    @Autowired
    public PrepaymentService(AccountService accountService,
                             InvestmentRepository investmentRepository,
                             BizParametersRepository bizParametersRepository, RepaymentPlanRepository repaymentPlanRepository,
                             CollectionPlanRepository collectionPlanRepository, RepaymentRecordRepository repaymentRecordRepository,
                             RepaymentOperationRepository repaymentOperationRepository, CollectionRecordRepository collectionRecordRepository,
                             UserRepository userRepository,
                             SmsService smsService, RepaymentService repaymentService, TransactionRepository transactionRepository) {
//        this.accountService = accountService;
//        this.investmentRepository = investmentRepository;
        this.bizParametersRepository = bizParametersRepository;
//        this.repaymentPlanRepository = repaymentPlanRepository;
//        this.collectionPlanRepository = collectionPlanRepository;
//        this.repaymentRecordRepository = repaymentRecordRepository;
//        this.repaymentOperationRepository = repaymentOperationRepository;
//        this.collectionRecordRepository = collectionRecordRepository;
//        this.userRepository = userRepository;
//        this.smsService = smsService;
//        this.repaymentService = repaymentService;
//        this.transactionRepository = transactionRepository;
    }

    public LoanPrepaymentInfoGson getLoanPrepaymentGson(Loan loan) {
        validate(loan);
        return new LoanPrepaymentInfoGson(loan);
    }

    public LoanPrepaymentInfoGson getLoanPrepaymentGson(Loan loan, Date date) {
        date = validateDate(loan, date);
        validate(loan, date);
        return new LoanPrepaymentInfoGson(loan, date,bizParametersRepository.getPrepayParameters());
    }

    private void validate(Loan loan) {
        if (loan.isSettled()) {
            DevLog.warn(this, String.format("Repeated prepayment request for loan %d", loan.id()));
            throw new PrepaymentException(P2PErrorCode.REPEATED_REPAYMENT);
        }
        RepaymentPlan currentRepaymentPlan = loan.getCurrentRepaymentPlan();
        if (currentRepaymentPlan == null || loan.isLastRepayment(currentRepaymentPlan)) {
            DevLog.warn(this, String.format("Invalid prepayment request for loan (id: %d, currentPlanNumber: %d)", loan.id(), loan.getCurrentInstalment()));
            throw new PrepaymentException(P2PErrorCode.PREPAYMENT_FAILED);
        }
    }

    private void validate(Loan loan, Date date) {
        if (loan.isSettled()) {
            DevLog.warn(this, String.format("Repeated prepayment request for loan %d", loan.id()));
            throw new PrepaymentException(P2PErrorCode.REPEATED_REPAYMENT);
        }
        RepaymentPlan currentRepaymentPlan = loan.getCurrentRepaymentPlan(date);
        if (currentRepaymentPlan == null || loan.isLastRepayment(currentRepaymentPlan)) {
            DevLog.warn(this, String.format("Invalid prepayment request for loan (id: %d, currentPlanNumber: %d)", loan.id(), loan.getCurrentInstalment()));
            throw new PrepaymentException(P2PErrorCode.PREPAYMENT_FAILED);
        }
    }

    private Date validateDate(Loan loan, Date date) {
        //todo: loans  whose only have one instalment cannot prepayment
        RepaymentPlan lastMinusOnePlan = loan.getRepaymentPlan(loan.getNumberOfInstalments() - 1);
        Date lastMinusOnePlanEndAT = DateUtils.endOfDay(lastMinusOnePlan.getEndAt());
        date = (date == null) || DateUtils.beforeToday(date) ? new Date() : date;
        date = date.after(lastMinusOnePlanEndAT) ? lastMinusOnePlanEndAT : date;
        Date firstOverDueDate = null;
        for (RepaymentPlan plan : loan.getRepaymentPlans()) {
            if (plan.getStatus().equals(PlanStatus.OVERDUE)) {
                firstOverDueDate = plan.getEndAt();
                break;
            }
        }
        //todo    currentRepaymentPlan maybe null
        RepaymentPlan currentRepaymentPlan = loan.getCurrentRepaymentPlan();
        Date currentRepaymentPlanEndAt = currentRepaymentPlan.getEndAt();
        firstOverDueDate = firstOverDueDate == null ? currentRepaymentPlanEndAt : firstOverDueDate;
        int calculateOverdueDays = Days.daysBetween(new DateTime(DateUtils.endOfDay(firstOverDueDate)), new DateTime(DateUtils.endOfDay(date))).getDays();
        Date latestDayToPay = new DateTime(firstOverDueDate).plusDays(80).toDate();
        latestDayToPay = latestDayToPay.after(lastMinusOnePlanEndAT) ? lastMinusOnePlanEndAT : latestDayToPay;
        latestDayToPay = DateUtils.endOfDay(latestDayToPay);
        date = calculateOverdueDays > 80 ? latestDayToPay : date;
        date = DateUtils.startOfDay(date);
        return date;
    }

    public String getP2pRemoteInterfaceCallUrlByJerseyService(String p2pRemoteInterfaceCallUrl, long loanId, String date) {
        ClientResponse clientResponse = null;
        try {
            clientResponse = p2pJerseyService.getInstance(p2pRemoteInterfaceCallUrl).getResource().queryParam("date", date).get(ClientResponse.class);
        } catch (Throwable e) {
            DevLog.error(this, String.format("p2p remote call failed"), e);
            throw new P2PException(P2PErrorCode.REMOTE_INVOKE_FAILED, "network connect exception");
        }
        DevLog.debug(this, "invoke p2p url[" + p2pRemoteInterfaceCallUrl + "] result is [" + clientResponse + "]" );
        if (!(Response.Status.OK.getStatusCode() == clientResponse.getClientResponseStatus().getStatusCode())) {
        	clientResponse.close();//Cango add : close the response
            return null;
        }
        return clientResponse.getEntity(String.class);
    }
}
