package com.lufax.customerService.service;

import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lufax.common.domain.User;
import com.lufax.common.domain.repository.UserRepository;
import com.lufax.common.utils.DevLog;
import com.lufax.customerService.domain.RareWords;
import com.lufax.customerService.domain.repository.RareWordsRespository;

@Service
public class RareWordsService{
    @Autowired
    private RareWordsRespository rareWordsRespository;
    @Autowired
    private UserRepository userRepository;

    public RareWordsService() {

    }

    @Transactional
    public String generateRareWords(String operator, String words) {
        if (StringUtils.isEmpty(words)) {
        	return null;
        }
        if(!rareWordsRespository.findAllRareWordCount(words)){
    		return "repeat";
    	}
        RareWords rareWords = new RareWords(operator, words);
        rareWordsRespository.persist(rareWords);
        processUpdateRareWords(rareWords);
        return "success";
    }

    @Transactional
    public List<RareWords> findAllRareWords(int maxNum, int offset) {
        return rareWordsRespository.findAllRareWords(maxNum, offset);
    }

    @Transactional
    public Long countOfRareWords() {
        return rareWordsRespository.countOfRareWords();
    }

    @Transactional
    public List<RareWords> findAllRareWords() {
        return rareWordsRespository.findAllRareWords();
    }

    public RareWords load(long id) {
        return rareWordsRespository.load(id);
    }

    public RareWords update(RareWords rareWords) {
        processUpdateRareWords(rareWords);
        return rareWordsRespository.update(rareWords);
    }

    public void remove(RareWords rareWords) {
        rareWordsRespository.remove(rareWords);
    }

    public void processUpdateRareWords(RareWords newRareWords) {
        DevLog.info(this, "start to process rare words:"+newRareWords);
//        System.out.println("start to process rare words:"+newRareWords);
        List<User> users = userRepository.findAllUsersByRareWords(newRareWords.getWord());
        for (User user : users){
            user.setRareWord(true);
            userRepository.update(user);
            DevLog.debug(this,"update user [" + user.getId() + "] rare world status to true");
        }
        DevLog.info(this, "end to process rare words:"+newRareWords);
    }

}
