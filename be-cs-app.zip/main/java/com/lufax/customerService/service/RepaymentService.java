package com.lufax.customerService.service;

import com.lufax.common.domain.account.service.AccountService;
import com.lufax.common.domain.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class RepaymentService {
    @Autowired
    private RepaymentOperationRepository repaymentOperationRepository;
    @Autowired
    private RepaymentPlanRepository repaymentPlanRepository;
    @Autowired
    private RepaymentRecordRepository repaymentRecordRepository;
    @Autowired
    private CollectionPlanRepository collectionPlanRepository;
    @Autowired
    private CollectionRecordRepository collectionRecordRepository;
    @Autowired
    private InvestmentRepository investmentRepository;
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private TransactionRepository transactionRepository;
    @Autowired
    private AccountService accountService;

    public RepaymentService() {
    }
}
