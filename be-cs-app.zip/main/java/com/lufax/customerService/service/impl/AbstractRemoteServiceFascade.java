package com.lufax.customerService.service.impl;

import java.util.Date;
import java.util.Map;

import com.google.gson.Gson;
import com.lufax.common.exception.CapitalErrorCode;
import com.lufax.common.exception.CapitalException;
import com.lufax.common.exception.CapitalRemoteErrorCode;
import com.lufax.common.exception.CapitalRemoteException;
import com.lufax.common.utils.DevLog;
import com.lufax.jersey.client.JerseyRequestParam;
import com.lufax.jersey.client.JerseyService;
import com.lufax.jersey.exception.InvokeRemoteServiceException;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.representation.Form;

public abstract class AbstractRemoteServiceFascade {
	
	public final static String METHOD_GET = "GET";
	public final static String METHOD_POST = "POST";
	
	protected abstract JerseyService getRemoteService();

	public <T> T get(String remoteURI, Class<T> returnType) throws CapitalException{
		long invokeId = System.currentTimeMillis();
		DevLog.info(this, String.format("Invoke id is [%s], the remoteHost is [%s], Remote Invoke [%s] occurred at [%s]", invokeId,getRemoteService().getHost().getHostURI(), remoteURI, new Date()));
		try {
			ClientResponse clientResponse = getRemoteService().getInstance(remoteURI).invokeJersey();
			if (ClientResponse.Status.OK.getStatusCode() == clientResponse.getStatus()) {
				String returnJson = clientResponse.getEntity(String.class);
                DevLog.debug(this,"The result string is [" + returnJson + "]");
				return new Gson().fromJson(returnJson, returnType);
			} else {
				DevLog.info(this, String.format("Invoke id is [%s], Remote Application Error occurred [%s]", invokeId, clientResponse));
                clientResponse.close();
				throw new CapitalException(CapitalErrorCode.REMOTE_INVOKE_FAILED);
			}
		} catch (InvokeRemoteServiceException e) {
			DevLog.error(this, String.format("Invoke id is [%s], InvokeRemoteServiceException occurred", invokeId), e);
			throw new CapitalRemoteException(CapitalRemoteErrorCode.REMOTE_INVOKE_FAILED,e);
		}
	}
	
	public <T> T invoke(String remoteURI, Class<T> returnType, Map<String, String> arg) throws CapitalException{
		return invoke(remoteURI, returnType, arg, METHOD_GET, null);
	}

	
	public <T> T invoke(String remoteURI, Class<T> returnType, Map<String, String> arg, String methodName, String operaterId) throws CapitalException{

		if (!METHOD_GET.equalsIgnoreCase(methodName) && !METHOD_POST.equalsIgnoreCase(methodName) ) {
			throw new IllegalArgumentException(String.format("http method is not support [%s]", methodName));
		}

		long invokeId = System.currentTimeMillis();

		DevLog.info(this, String.format("Invoke id is [%s], the romoteHost is [%s], Remote Invoke [%s] occurred at [%s], and operaterId is [%s], param is [%s]", invokeId,getRemoteService().getHost().getHostURI(), remoteURI, new Date(), operaterId, arg.toString()));

		try {
			JerseyRequestParam param = new JerseyRequestParam();
			param.setParameters(arg);
			param.setMethodName(methodName);
			ClientResponse clientResponse = null;
			if (operaterId == null) {
				clientResponse = getRemoteService().getInstance(remoteURI).invokeJersey(param);
			} else {
				clientResponse = getRemoteService().getInstance(remoteURI).withUser(operaterId).invokeJersey(param);
			}
            DevLog.debug(this,"the client response is [" + clientResponse + "]");
			if (ClientResponse.Status.OK.getStatusCode() == clientResponse.getStatus()) {
				String returnJson = clientResponse.getEntity(String.class);
				return new Gson().fromJson(returnJson, returnType);
			} else {
				DevLog.error(this, String.format("Invoke id is [%s], Application Error occurred", invokeId));
                clientResponse.close();
				throw new CapitalException(CapitalErrorCode.REMOTE_INVOKE_FAILED);
			}
		} catch (InvokeRemoteServiceException e) {
			DevLog.error(this, String.format("Invoke id is [%s], InvokeRemoteServiceException occurred", invokeId), e);
			throw new CapitalRemoteException(CapitalRemoteErrorCode.REMOTE_INVOKE_FAILED,e);
		}
	}
	
    public <T> T post(String remoteURI, Class<T> returnType, Form form) throws CapitalException{
    	return invoke(remoteURI,returnType,form,METHOD_POST, null);
    }

    public <T> T invoke(String remoteURI, Class<T> returnType, Form form, String methodName, String operaterId) throws CapitalException{
	
	if (!METHOD_GET.equalsIgnoreCase(methodName) && !METHOD_POST.equalsIgnoreCase(methodName) ) {
		throw new IllegalArgumentException(String.format("http method is not support [%s]", methodName));
	}

	long invokeId = System.currentTimeMillis();

	DevLog.info(this, String.format("Invoke id is [%s],the remote host is [%s], Remote Invoke [%s] occurred at [%s]", invokeId,getRemoteService().getHost().getHostURI(), remoteURI, new Date()));

	try {
		ClientResponse clientResponse;
		if (operaterId == null) {
			clientResponse = getRemoteService().getInstance(remoteURI).getResource().method(methodName, ClientResponse.class, form);
		} else {
			clientResponse = getRemoteService().getInstance(remoteURI).withUser(operaterId).getResource().method(methodName, ClientResponse.class, form);
		}
        DevLog.debug(this,"the client response is [" + clientResponse + "]");
		if (ClientResponse.Status.OK.getStatusCode() == clientResponse.getStatus()) {
			String returnJson = clientResponse.getEntity(String.class);
			return new Gson().fromJson(returnJson, returnType);
		} else {
			DevLog.error(this, String.format("Invoke id is [%s], Application Error occurred", invokeId));
            clientResponse.close();
			throw new CapitalException(CapitalErrorCode.REMOTE_INVOKE_FAILED);
		}
	} catch (Exception e) {
		DevLog.error(this, String.format("Invoke id is [%s], InvokeRemoteServiceException occurred", invokeId), e);
		throw new CapitalRemoteException(CapitalRemoteErrorCode.REMOTE_INVOKE_FAILED,e);
	}
}
}
