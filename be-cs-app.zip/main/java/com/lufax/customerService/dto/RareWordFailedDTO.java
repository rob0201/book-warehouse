package com.lufax.customerService.dto;

import java.math.BigDecimal;
import java.util.Date;

import org.apache.commons.lang.StringUtils;

import com.lufax.common.domain.WithdrawType;
import com.lufax.common.utils.DateUtils;

public class RareWordFailedDTO {
	private String username;
	private long withdrawId;
	private String withdrawType;
	private BigDecimal amount;
	private String sendTime;
	private String bankName;
	private String tbName;
	private String bankAccount;
	private String remark;
	
	public RareWordFailedDTO(){}
	public RareWordFailedDTO(String username,long withdrawId, String withdrawType,
			BigDecimal amount, String sendTime, String bankName, String tbName,
			String bankAccount, String remark) {
		this.username = username;
		this.withdrawId = withdrawId;
		this.withdrawType = withdrawType;
		this.amount = amount;
		this.sendTime = sendTime;
		this.bankName = bankName;
		this.tbName = tbName;
		this.bankAccount = bankAccount;
		this.remark = remark;
	}
	
	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public long getWithdrawId() {
		return withdrawId;
	}
	public void setWithdrawId(long withdrawId) {
		this.withdrawId = withdrawId;
	}
	public String getWithdrawType() {
		return withdrawType;
	}
	public void setWithdrawType(String withdrawType) {
		if(!StringUtils.isEmpty(withdrawType)){
			this.withdrawType = WithdrawType.getWithdrawTypeByName(withdrawType.trim()).getValue();
		}
	}
	public BigDecimal getAmount() {
		return amount;
	}
	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}
	public String getSendTime() {
		return sendTime;
	}
	public void setSendTime(Date sendTime) {
		if(null!=sendTime){
			this.sendTime = DateUtils.formatDate(sendTime, DateUtils.DATE_TIME_FORMAT_DEFAULT);
		}
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public String getTbName() {
		return tbName;
	}
	public void setTbName(String tbName) {
		this.tbName = tbName;
	}
	public String getBankAccount() {
		return bankAccount;
	}
	public void setBankAccount(String bankAccount) {
		this.bankAccount = bankAccount;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	@Override
	public String toString() {
		return "RareWordFailedDTO [username=" + username + ", withdrawId="
				+ withdrawId + ", withdrawType=" + withdrawType + ", amount="
				+ amount + ", sendTime=" + sendTime + ", bankName=" + bankName
				+ ", tbName=" + tbName + ", bankAccount=" + bankAccount
				+ ", remark=" + remark + "]";
	}
	
	
}
