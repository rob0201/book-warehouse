package com.lufax.customerService.dto;

import java.util.Date;


public class BaseResponseDTO {
    /**
     * 应答号(请求记录表主键)
     */
    private Long responseNo;
    /**
     * 返回码
     */
    private String retCode;
    /**
     * 返回信息
     */
    private String retMessage;
    /**
     * 数据库执行时间
     */
    private Date executedTime;
    
    private long rechargeRecordId;

    /**
     * 应答号(请求记录表主键)
     */
    public Long getResponseNo() {
        return responseNo;
    }

    /**
     * 应答号(请求记录表主键)
     */
    public void setResponseNo(Long responseNo) {
        this.responseNo = responseNo;
    }

    /**
     * 返回码
     */
    public String getRetCode() {
        return retCode;
    }

    /**
     * 返回码
     */
    public void setRetCode(String retCode) {
        this.retCode = retCode;
    }

    /**
     * 返回信息
     */
    public String getRetMessage() {
        return retMessage;
    }

    /**
     * 返回信息
     */
    public void setRetMessage(String retMessage) {
        this.retMessage = retMessage;
    }

    /**
     * 数据库执行时间
     */
    public Date getExecutedTime() {
        return executedTime;
    }

    /**
     * 数据库执行时间
     */
    public void setExecutedTime(Date dbCreatedTime) {
        this.executedTime = dbCreatedTime;
    }

    public long getRechargeRecordId() {
		return rechargeRecordId;
	}

	public void setRechargeRecordId(long rechargeRecordId) {
		this.rechargeRecordId = rechargeRecordId;
	}

	@Override
    public String toString() {
        return "BaseResponseDTO{" +
                "responseNo=" + responseNo +
                ", retCode='" + retCode + '\'' +
                ", retMessage='" + retMessage + '\'' +
                ", executedTime=" + executedTime +
                '}';
    }
}
