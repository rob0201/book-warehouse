package com.lufax.customerService.dto;

import java.math.BigDecimal;
import java.util.Date;

import org.apache.commons.lang.StringUtils;

import com.lufax.common.domain.WithdrawStatus;
import com.lufax.common.utils.DateUtils;


public class RareManualCapitalDTO {
	private String username;
	private long withdrawId;
	private String operationType;
	private BigDecimal amount;
	private String sendTime;
	private String realName;
	private String bankName;
	private String bankAccount;
	private String remark;
	private String auditor;
	private String reason;
	private long manualCapitalId;
	private String manualCapitalStatementStatus;
	
	private String applier;
	private String lufaxAccount;
	private String transactionNo;
	private String manualDesc;
	private String eoaNo;
	private String withdrawStatus;
	private String withdrawStatusValue;
	
	private boolean isApply;
	private boolean isNeedClosed;
	
	public RareManualCapitalDTO() {
	}
	public RareManualCapitalDTO(String username,long withdrawId, String operationType, BigDecimal amount, String sendTime, String realName, String bankName, String bankAccount, String remark, 
			String auditor, String reason, long manualCapitalId, String manualCapitalStatementStatus) {
		this.username = username;
		this.withdrawId = withdrawId;
		this.operationType = operationType;
		this.amount = amount;
		this.sendTime = sendTime;
		this.realName = realName;
		this.bankName = bankName;
		this.bankAccount = bankAccount;
		this.remark = remark;
		this.auditor = auditor;
		this.reason = reason;
		this.manualCapitalId = manualCapitalId;
		this.manualCapitalStatementStatus = manualCapitalStatementStatus;
	}
	
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getOperationType() {
		return operationType;
	}
	public void setOperationType(String operationType) {
		if(!StringUtils.isEmpty(operationType)){
			if("CUSTOMER_WITHDRAWAL".equalsIgnoreCase(operationType)){
				this.operationType = "取现";
			}else if("LOAN_GRANTING".equalsIgnoreCase(operationType)){
				this.operationType = "贷款放款";
			}else{
				this.operationType = "unknown";
			}
		}
	}
	public BigDecimal getAmount() {
		return amount;
	}
	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}
	public String getSendTime() {
		return sendTime;
	}
	public void setSendTime(Date sendTime) {
		this.sendTime = DateUtils.format(DateUtils.DATE_FORMAT_DEFAULT, sendTime);
	}
	public String getRealName() {
		return realName;
	}
	public void setRealName(String realName) {
		this.realName = realName;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public String getBankAccount() {
		return bankAccount;
	}
	public void setBankAccount(String bankAccount) {
		this.bankAccount = bankAccount;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getAuditor() {
		return auditor;
	}
	public void setAuditor(String auditor) {
		this.auditor = auditor;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	public long getManualCapitalId() {
		return manualCapitalId;
	}
	public void setManualCapitalId(long manualCapitalId) {
		this.manualCapitalId = manualCapitalId;
	}
	public String getManualCapitalStatementStatus() {
		return manualCapitalStatementStatus;
	}
	public void setManualCapitalStatementStatus(String manualCapitalStatementStatus) {
		if(StringUtils.isEmpty(manualCapitalStatementStatus)){
			this.manualCapitalStatementStatus = "未回销";
			this.isApply = false;
		}else if("AUTDING".equalsIgnoreCase(manualCapitalStatementStatus.trim())){
			this.manualCapitalStatementStatus = "待审核";
			this.isApply = true;
		}else if("PROCESSING".equalsIgnoreCase(manualCapitalStatementStatus.trim())){
			this.manualCapitalStatementStatus ="打回";
			this.isApply = true;
		}else if("FAILED".equalsIgnoreCase(manualCapitalStatementStatus.trim())){
			this.manualCapitalStatementStatus = "取现失败";
			this.isApply = true;
		}else if ("SUCCESS".equalsIgnoreCase(manualCapitalStatementStatus.trim())){
			this.manualCapitalStatementStatus = "已回销";
			this.isApply = true;
		}
	}
	public long getWithdrawId() {
		return withdrawId;
	}
	public void setWithdrawId(long withdrawId) {
		this.withdrawId = withdrawId;
	}
	public boolean isApply() {
		return isApply;
	}
	public void setApply(boolean isApply) {
		this.isApply = isApply;
	}
	public String getApplier() {
		return applier;
	}
	public void setApplier(String applier) {
		this.applier = applier;
	}
	public String getLufaxAccount() {
		return lufaxAccount;
	}
	public void setLufaxAccount(String lufaxAccount) {
		this.lufaxAccount = lufaxAccount;
	}
	public String getTransactionNo() {
		return transactionNo;
	}
	public void setTransactionNo(String transactionNo) {
		this.transactionNo = transactionNo;
	}
	public String getManualDesc() {
		return manualDesc;
	}
	public void setManualDesc(String manualDesc) {
		this.manualDesc = manualDesc;
	}
	public String getEoaNo() {
		return eoaNo;
	}
	public void setEoaNo(String eoaNo) {
		this.eoaNo = eoaNo;
	}
	
	public String getWithdrawStatus() {
		return withdrawStatus;
	}
	public void setWithdrawStatus(String withdrawStatus) {
		if(WithdrawStatus.SUCCESS.name().equals(withdrawStatus.trim())){
			this.manualCapitalStatementStatus = "已回销";	
			this.isApply = true;
		}else if(WithdrawStatus.FAILURE.name().equals(withdrawStatus.trim())){
			if("待审核".equals(this.manualCapitalStatementStatus)){
				this.manualCapitalStatementStatus = "取现失败";
				this.isNeedClosed= true;
				this.isApply = true;
			}else if("打回".equals(this.manualCapitalStatementStatus)){
				this.manualCapitalStatementStatus = "取现失败";
				this.isNeedClosed= true;
				this.isApply = true;
			}else {
				this.manualCapitalStatementStatus = "取现失败";
				this.isApply = true;
			}
			
		}
		this.withdrawStatus = withdrawStatus;
		
	}
	public void setSendTime(String sendTime) {
		this.sendTime = sendTime;
	}
	
	
	public String getWithdrawStatusValue() {
		return withdrawStatusValue;
	}
	public void setWithdrawStatusValue(String withdrawStatusValue) {
		this.withdrawStatusValue = withdrawStatusValue;
	}
	
	public boolean isNeedClosed() {
		return isNeedClosed;
	}
	public void setNeedClosed(boolean isNeedClosed) {
		this.isNeedClosed = isNeedClosed;
	}
	@Override
	public String toString() {
		return "RareManualCapitalDTO [username=" + username + ", withdrawId="
				+ withdrawId + ", operationType=" + operationType + ", amount="
				+ amount + ", sendTime=" + sendTime + ", realName=" + realName
				+ ", bankName=" + bankName + ", bankAccount=" + bankAccount
				+ ", remark=" + remark + ", auditor=" + auditor + ", reason="
				+ reason + ", manualCapitalId=" + manualCapitalId
				+ ", manualCapitalStatementStatus="
				+ manualCapitalStatementStatus + ", applier=" + applier
				+ ", lufaxAccount=" + lufaxAccount + ", transactionNo="
				+ transactionNo + ", manualDesc=" + manualDesc + ", eoaNo="
				+ eoaNo + ", withdrawStatus=" + withdrawStatus
				+ ", withdrawStatusValue=" + withdrawStatusValue + ", isApply="
				+ isApply + ", isNeedClosed=" + isNeedClosed + "]";
	}
	
	
}
