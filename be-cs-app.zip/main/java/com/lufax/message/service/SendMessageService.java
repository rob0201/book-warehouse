package com.lufax.message.service;

import com.lufax.message.domain.Message;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: caoyanfei079
 * Date: 12-9-27
 * Time: 上午10:19
 * To change this template use File | Settings | File Templates.
 */
public interface SendMessageService {
    public void sendMessage(String operationId, List<String> userList, Message message, String batchNo);
    public void sendMessage(String operationId, List<String> userList, Message message, String batchNo, Boolean isFormat);
}
