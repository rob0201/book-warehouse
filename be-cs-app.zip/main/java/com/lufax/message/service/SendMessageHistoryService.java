package com.lufax.message.service;

import com.lufax.message.domain.SendMessageHistory;

/**
 * Created by IntelliJ IDEA.
 * User: caoyanfei079
 * Date: 12-9-27
 * Time: 上午11:20
 * To change this template use File | Settings | File Templates.
 */
public interface SendMessageHistoryService {
    public Long createSendMessageHistory(SendMessageHistory sendMessageHistory);
}
