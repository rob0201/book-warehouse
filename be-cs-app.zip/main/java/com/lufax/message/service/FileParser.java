package com.lufax.message.service;

/**
 * Created by IntelliJ IDEA.
 * User: caoyanfei079
 * Date: 12-9-27
 * Time: 上午9:58
 * To change this template use File | Settings | File Templates.
 */
public interface FileParser<T> {
    public T parse(String fileName);
    public boolean delete(String fileName);
}
