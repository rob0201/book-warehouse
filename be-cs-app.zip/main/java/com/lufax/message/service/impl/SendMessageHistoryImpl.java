package com.lufax.message.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lufax.common.utils.DevLog;
import com.lufax.message.domain.SendMessageHistory;
import com.lufax.message.domain.repository.SendMessageHistoryRepository;
import com.lufax.message.service.SendMessageHistoryService;

/**
 * Created by IntelliJ IDEA. User: caoyanfei079 Date: 12-9-27 Time: 上午11:24 To
 * change this template use File | Settings | File Templates.
 */
@Service
public class SendMessageHistoryImpl implements SendMessageHistoryService {
	@Autowired
	private SendMessageHistoryRepository sendMessageHistoryRepository;

	public Long createSendMessageHistory(SendMessageHistory sendMessageHistory) {

		sendMessageHistoryRepository.persist(sendMessageHistory);
		DevLog.info(this, "save the send message history, the id is ["
				+ sendMessageHistory.getId() + "], the batchNo is ["
				+ sendMessageHistory.getBatchNo() + ']');
		return sendMessageHistory.getId();
	}
}
