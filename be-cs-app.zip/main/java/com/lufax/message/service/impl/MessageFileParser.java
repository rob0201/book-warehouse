package com.lufax.message.service.impl;

import com.lufax.common.utils.DevLog;
import com.lufax.message.service.FileParser;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: caoyanfei079
 * Date: 12-9-27
 * Time: 上午9:59
 * To change this template use File | Settings | File Templates.
 */
@Service
public class MessageFileParser implements FileParser<List<String>> {

    @Value("${be.temporary.path}")
    private String nasdir;
    public List<String> parse(String fileName) {
        DevLog.debug(this,"The nas directory is [" + nasdir + "]");
        DevLog.debug(this,"The filename is [" + fileName + "]");
        BufferedReader reader =null;
        try {
            List<String> result = new ArrayList<String>();
            reader = new BufferedReader(new FileReader(new File(new File(nasdir), fileName)));
            String userId = null;
            while((userId = reader.readLine()) != null) {
                result.add(userId);
            }
            DevLog.debug(this,"The file [" + fileName + "] has user [" + result.size() + "]");
            return result;
        } catch (IOException e) {
            DevLog.error(this,"Failed to parse the file [" + fileName + "]", e);
            throw new RuntimeException("Failed to load the file [" + fileName + "]",e);
        } finally {
        	if(reader != null) {
        		try {
					reader.close();
				} catch (IOException e) {
					DevLog.error(this, "Failed to close the stream",e);
				}
        	}
        }
    }

    public boolean delete(String fileName) {
        if(new File(new File(nasdir), fileName).exists()) {

            boolean  result =  new File(new File(nasdir), fileName).delete();
            DevLog.debug(this, "The file [" + new File(new File(nasdir), fileName) + "] delete result is [" + result + "]");
            return result;
        } else {
            DevLog.debug(this, "The file [" + new File(new File(nasdir), fileName) + "] is not exists. ");
            return false;
        }


    }
}
