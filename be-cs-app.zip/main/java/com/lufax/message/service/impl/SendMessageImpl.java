package com.lufax.message.service.impl;

import com.lufax.customerService.service.RemoteServiceFascade;
import com.lufax.common.domain.CommonInvokeResponseStatus;
import com.lufax.common.utils.DevLog;


import com.lufax.customerService.dto.BaseResponseDTO;
import com.lufax.message.domain.Message;
import com.lufax.message.service.SendMessageService;
import com.sun.jersey.api.representation.Form;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: caoyanfei079
 * Date: 12-9-27
 * Time: 上午10:25
 * To change this template use File | Settings | File Templates.
 */
@Service
public class SendMessageImpl implements SendMessageService {
    @Value("${send.message.uri}")
    private String sendMessageUrl;
    @Autowired
    private RemoteServiceFascade remoteServiceFascade;
    public void sendMessage(String operationId, List<String> userList, Message message, String batchNo) {
        sendMessage(operationId,userList,message,batchNo,false);
    }

    public void sendMessage(String operationId, List<String> userList, Message message, String batchNo, Boolean isFormat) {
        //        operationId = "16" ;
        String tempResource = String.format(sendMessageUrl, operationId);
        DevLog.debug(this,"The send message url is [" + tempResource + "]");
        Form form = new Form();
        for(String userId : userList) {
            form.add("userId", userId);
        }
        form.add("title", message.getTitle());
        DevLog.debug(this,"The content " + message.getContent() + "] format to [" + message.getFormatContent() + "]");
        if(isFormat) {
            form.add("content",message.getFormatContent());
        } else {
            form.add("content",message.getContent());
        }
        form.add("batchNo", batchNo);
        form.add("sendFrom", message.getOperator()); // -1 -2 -3  kefu 管理 系统
        form.add("createdBy", operationId);
        DevLog.debug(this,"The form is [" + form + "]");
        BaseResponseDTO result = remoteServiceFascade.invoke(tempResource, BaseResponseDTO.class,form, com.lufax.customerService.service.impl.AbstractRemoteServiceFascade.METHOD_POST, operationId);
        DevLog.debug(this, "The send message invoke common result is [" + result + "]");
        if(!CommonInvokeResponseStatus.convert(result.getRetCode()).isSuccess()) {
            DevLog.info(this,"Failed to invoke remote interface.the result is [" + batchNo + "]");
            throw new RuntimeException("Failed to invoke remote interface.the result is [" + batchNo + "]");
        } else {
            DevLog.debug(this,"Success send the message");

        }
    }
}

