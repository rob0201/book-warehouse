package com.lufax.message.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * Created by IntelliJ IDEA.
 * User: caoyanfei079
 * Date: 12-9-27
 * Time: 上午10:08
 * To change this template use File | Settings | File Templates.
 */

//create table send_message_history (
//        id number(19,0),
//        fcd date,
//        fcu varchar2(20),
//        user_file_name varchar2(200),
//        content varchar2(2000),
//        title varchar2(200),
//        user_count number(10,0),
//        result varchar2(1000),
//        batch_no varchar2(100)
//)
//    comment on table send_message_history is '发送站内信历史';
//        comment on column send_message_history.id is '主键';
//        comment on column send_message_history.fcd is '创建时间';
//        comment on column send_message_history.fcu is '创建人';
//        comment on column send_message_history.user_file_name is '文件名';
//        comment on column send_message_history.content is '内容';
//        comment on column send_message_history.title is '标题';
//        comment on column send_message_history.user_count is '发送的用户数量';
//        comment on column send_message_history.result is 'common返回结果';
//        comment on column send_message_history.batch_no is '批次号';
//
//create sequence seq_message_history;
@Entity
@Table(name="SEND_MESSAGE_HISTORY")
public class SendMessageHistory {
	@Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_MESSAGE_HISTORY")
    @SequenceGenerator(name = "SEQ_MESSAGE_HISTORY", sequenceName = "SEQ_MESSAGE_HISTORY", allocationSize = 1)
    private Long id;
	
	@Column(name = "fcd") 
    private Date fcd = new Date();
	
	@Column(name = "fcu")
    private String fcu;
	
	@Column(name = "CONTENT")
    private String contentInfo;
	
	@Column(name = "TITLE")
    private String titleName;
	
	@Column(name = "USER_COUNT")
    private Integer userCount;
	
	@Column(name = "RESULT")
    private String result;
	
	@Column(name = "BATCH_NO")
    private String batchNo ;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Date getFcd() {
		return fcd;
	}

	public void setFcd(Date fcd) {
		this.fcd = fcd;
	}

	public String getFcu() {
		return fcu;
	}

	public void setFcu(String fcu) {
		this.fcu = fcu;
	}

	public String getContentInfo() {
		return contentInfo;
	}

	public void setContentInfo(String contentInfo) {
		this.contentInfo = contentInfo;
	}

	public String getTitleName() {
		return titleName;
	}

	public void setTitleName(String titleName) {
		this.titleName = titleName;
	}

	public Integer getUserCount() {
		return userCount;
	}

	public void setUserCount(Integer userCount) {
		this.userCount = userCount;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public String getBatchNo() {
		return batchNo;
	}

	public void setBatchNo(String batchNo) {
		this.batchNo = batchNo;
	}

}
