package com.lufax.message.domain;


/**
 * Created by IntelliJ IDEA.
 * User: caoyanfei079
 * Date: 12-9-27
 * Time: 上午10:21
 * To change this template use File | Settings | File Templates.
 */
public class Message {
    private String content;
    private String title;
    private String operator; // -1 -2 -3  kefu 管理 系统

    public String getOperator() {
        return operator;
    }

    public void setOperator(String operator) {
        this.operator = operator;
    }

//    public Message(String title,String content) {
//        this.content = content;
//        this.title = title;
//    }


    public Message(String title, String content,  String operator) {
        this.content = content;
        this.title = title;
        this.operator = operator;
    }

    public String getContent() {
        return content;
    }

    public String getTitle() {
        return title;
    }
    public String getFormatContent() {
         if(content == null) {
             return null;
         } else {
             return content.replace("\r\n","<br/>").replace("\n", "<br>").replaceAll("\\s", "&nbsp;");
         }
    }
    public static void main(String[] args) {
        String content = "\r\n  asdfasdf  asdfasdf\r\n";
        System.out.println(content.replace("\r\n","<br/>").replace("\n","<br>").replaceAll("\\s", "&nbsp;"));
    }
}
