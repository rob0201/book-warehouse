package com.lufax.message.domain.repository;

import org.springframework.stereotype.Repository;

import com.lufax.common.domain.repository.BaseRepository;
import com.lufax.message.domain.SendMessageHistory;

@Repository
public class SendMessageHistoryRepository extends BaseRepository<SendMessageHistory>{

}
