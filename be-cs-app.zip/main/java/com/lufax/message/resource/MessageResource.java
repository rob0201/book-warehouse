package com.lufax.message.resource;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.lufax.common.utils.DevLog;
import com.lufax.jersey.usercontext.UserContext;
import com.lufax.jersey.usercontext.UserContextUtils;
import com.lufax.jersey.utils.Logger;
import com.lufax.message.domain.Message;
import com.lufax.message.domain.SendMessageHistory;
import com.lufax.message.service.SendMessageHistoryService;
import com.lufax.message.service.SendMessageService;
import com.lufax.message.service.impl.MessageFileParser;
import com.sun.jersey.api.core.InjectParam;

/**
 * Created by IntelliJ IDEA.
 * User: caoyanfei079
 * Date: 12-9-27
 * Time: 上午9:51
 * To change this template use File | Settings | File Templates.
 */
@Path("/SendMessage")
public class MessageResource {
    @InjectParam
    private MessageFileParser messageFileParser;
    @InjectParam
    private SendMessageService sendMessageService;
    @InjectParam
    private SendMessageHistoryService sendMessageHistoryService;
    private static final Integer SEND_MESSAGE_SIZE = 1000;
    
    private ExecutorService executorService  = Executors.newFixedThreadPool(10);

    @POST
	@Path("/create")
	@Produces(value = MediaType.APPLICATION_JSON)
	public Response sendMessageByAdmin(@FormParam("fileName") String fileName,@FormParam("messageTitle") String title,@FormParam("messagecontent") String content, @FormParam("operator") String operator) {
		DevLog.debug(this,"send message to user list");
		// TODO should be update : use the thread pool
		executorService.submit(new SendMessageTask(getCurrentUserId(), fileName, title, content, operator));
		DevLog.debug(this,"send message to user end");
        return Response.ok().entity("success").build();
	}
    private String getCurrentUserId() {
        UserContext uc = UserContextUtils.getCurrentUserContext();
        if(uc != null ) {
            return    uc.getUserId();
        } else {
            return "";
        }
    }
    private class SendMessageTask implements Runnable {
    	private String fileName;
    	private String title;
    	private String content;
    	private String operator;
    	private String userId;
    	
		public SendMessageTask(String userId, String fileName, String title, String content, String operator) {
			this.fileName = fileName;
			this.title = title;
			this.content = content;
			this.operator = operator;
			this.userId = userId;
		}

		public void run() {
			Long startTime = System.currentTimeMillis();
			DevLog.debug(this,"send message to user list");
	        String batchNo = new Date().getTime() + "";
	        List<String> userIds = messageFileParser.parse(fileName);
	        DevLog.debug(this, "Delete the temporary file [" + fileName + "]");
//	        messageFileParser.delete(fileName);
	        Integer userIdsSize =userIds.size();
	        for(int i =0 ; i < userIdsSize/SEND_MESSAGE_SIZE + 1; i++ ) {
	        	List<String> sendUserIds = gitUserId(userIds, i);
		        SendMessageHistory history = new SendMessageHistory();
		        history.setUserCount(sendUserIds.size());
		        history.setContentInfo(content);
		        history.setFcd(new Date());
		        history.setFcu(userId);
		        history.setBatchNo(batchNo);
		        history.setTitleName(title);
		        Long startSendMessageTime = System.currentTimeMillis();
		        sendMessageService.sendMessage(userId, sendUserIds, new Message(title, content, operator), batchNo);
		        Long endSendMessageTime = System.currentTimeMillis();
		        Logger.info(this, "Send  [" + sendUserIds.size() + "] records to common use [" + (startSendMessageTime - endSendMessageTime ) + "]");
		        DevLog.debug(this,"Success send the send message");
		        sendMessageHistoryService.createSendMessageHistory(history);
		        DevLog.debug(this,"Success create the history");
	        }
	        Long endTime = System.currentTimeMillis();
	        Logger.info(this, "Send file [" + fileName + "] user [" + userIdsSize + "] records use [" + (endTime - startTime ) + "]");
		}
		
		
    	
    }
    private static List<String> gitUserId(List<String> userIds, Integer index) {
		List<String> result = new ArrayList<String>();
		for(int i = index * SEND_MESSAGE_SIZE; (i < ((index  + 1) * SEND_MESSAGE_SIZE)) && i < userIds.size() ; i++) {// 最后一次需要特殊处理 i < userIds.size()
			result.add(userIds.get(i));
		}
		return result;
	}
    
    public static void main(String[] args) {
    	String[] result = {"1","2","3","4","5","6","7","8","9","0","10","1","2","3","4","5","6","7","8","9","0","10","1","2","3","4","5","6","7","8","9","0","10","1","2","3","4","5","6","7","8","9","0","10"};
    	List<String> list = Arrays.asList(result);
    	for(int i =0 ; i < list.size()/SEND_MESSAGE_SIZE + 1; i ++ ) {
    		System.out.println(gitUserId(list, i));
    	}
	}
}
