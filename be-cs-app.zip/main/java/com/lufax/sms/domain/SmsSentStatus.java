package com.lufax.sms.domain;


public enum SmsSentStatus {
    UNSENT,
    AUTH_UNSENT,
    SUCC_SENT ,
    UNKNOWN;
    public static SmsSentStatus getSmsSentStatusByName(String status){
        SmsSentStatus[] smsSentStatuses=SmsSentStatus.values();
        for(SmsSentStatus smsSentStatus:smsSentStatuses)
            if(smsSentStatus.name().equalsIgnoreCase(status))
                return smsSentStatus;
        return UNKNOWN;

    }

}
