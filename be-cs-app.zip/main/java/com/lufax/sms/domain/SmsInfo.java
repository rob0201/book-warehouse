package com.lufax.sms.domain;

import javax.persistence.*;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@Entity
    @Table(name = "SMS_INFO")
public class SmsInfo {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_SMS_INFO")
    @SequenceGenerator(name = "SEQ_SMS_INFO", sequenceName = "SEQ_SMS_INFO", allocationSize = 1)
    @Column(name = "SMS_ID")
    private long smsId;

    @Column(name = "EXPECT_SEND_TIME")
    private Date expectSendTime;

    @Column(name = "EXPIRE_TIME")
    private Date expireTime;

    @Column(name = "MOBILE_NO")
    private String mobileNo;

    @Column(name = "TEMPLET_ID")
    private String templateId;

    @Column(name = "SMS_CONTENT")
    private String smsContent;

    @Column(name = "FETCH_DATE")
    private Date fetchDate;

    @Column(name = "SENDER_ID")
    private String senderId;

    @Column(name = "SEND_USER")
    private String sendUser;

    @Column(name = "SEND_DATE")
    private Date sendDate;

    //    @Enumerated(EnumType.STRING)
    @Column(name = "SEND_STATUS")
    private String sendStatus;

    @Column(name = "CREATED_DATE")
    private Date createdDate;

    @Column(name = "CREATED_BY")
    private String createdBy;

    @Column(name = "SEND_SERIES_ID")
    private String sendSeriesId;

    @Version
    private long version;

    public SmsInfo() {
    }

    public SmsInfo(Date expectSendTime, Date expireTime, String mobileNo, String templateId, String smsContent, String senderId, String sendUser, String sendSeriesId) {
        this.expectSendTime = expectSendTime;
        this.expireTime = expireTime;
        this.mobileNo = mobileNo;
        this.templateId = templateId;
        this.smsContent = smsContent;
        this.senderId = senderId;
        this.sendUser = sendUser;
        this.sendSeriesId = sendSeriesId;
        this.sendStatus = SmsStatus.NEW.name();
        this.createdDate = new Date();
        this.createdBy = "BE";
    }

    public long getSmsId() {
        return smsId;
    }

    public Date getExpectSendTime() {
        return expectSendTime;
    }

    public Date getExpireTime() {
        return expireTime;
    }

    public String getMobileNo() {
        return mobileNo;
    }

    public String getTemplateId() {
        return templateId;
    }

    public String getSmsContent() {
        return smsContent;
    }

    public Date getFetchDate() {
        return fetchDate;
    }

    public String getSenderId() {
        return senderId;
    }

    public String getSendUser() {
        return sendUser;
    }

    public Date getSendDate() {
        return sendDate;
    }

    public SmsStatus getSendStatus() {
        return SmsStatus.getSmsStatusByName(sendStatus);
    }

    public String getSendSeriesId() {
        return sendSeriesId;
    }

    public void setFetchDate(Date fetchDate) {
        this.fetchDate = fetchDate;
    }

    public void setSendStatus(SmsStatus sendStatus) {
        this.sendStatus = (sendStatus != null) ? sendStatus.name() : null;
    }

    public Map<String, String> contentAsMap() {
        Map<String, String> map = new HashMap<String, String>();
        String smsContent = getSmsContent();
        if (hasContent(smsContent)) {
            String[] str = smsContent.split("\\|");
            for (int i = 0; i < str.length - 1; i++) {
                map.put(str[i], str[++i]);
            }
        }
        return map;
    }

    private boolean hasContent(String smsContent) {
        if (smsContent.contains("|"))
            return true;
        return false;
    }

    @Override
    public String toString() {
        return "SmsInfo{" +
                "smsId=" + smsId +
                ", expectSendTime=" + expectSendTime +
                ", expireTime=" + expireTime +
                ", mobileNo='" + mobileNo + '\'' +
                ", templateId='" + templateId + '\'' +
                ", smsContent='" + smsContent + '\'' +
                ", fetchDate=" + fetchDate +
                ", senderId='" + senderId + '\'' +
                ", sendUser='" + sendUser + '\'' +
                ", sendDate=" + sendDate +
                ", sendStatus='" + sendStatus + '\'' +
                ", createdDate=" + createdDate +
                ", createdBy='" + createdBy + '\'' +
                ", sendSeriesId='" + sendSeriesId + '\'' +
                ", version=" + version +
                '}';
    }
}

