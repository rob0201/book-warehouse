package com.lufax.sms.domain;

import org.apache.commons.lang.StringUtils;

import java.util.Date;

public class SmsMessage {

    public static final String DEFAULT_CONTENT = " ";

    private SmsTemplate smsTemplate;
    private String content;
    private Date expectSendTime;

    public SmsMessage(SmsTemplate smsTemplate) {
        this(smsTemplate, null);
    }

    public SmsMessage(SmsTemplate smsTemplate, String content) {
        this.smsTemplate = smsTemplate;

        if (StringUtils.isEmpty(content)) {
            this.content = DEFAULT_CONTENT;
        } else {
            this.content = content;
        }
    }

    public SmsMessage(SmsTemplate smsTemplate, String content, Date expectSendTime) {
        this(smsTemplate, content);
        this.expectSendTime = expectSendTime;
    }

    public SmsTemplate getSmsTemplate() {
        return smsTemplate;
    }

    public String getContent() {
        return content;
    }

    public Date getExpectSendTime() {
        return expectSendTime;
    }
}
