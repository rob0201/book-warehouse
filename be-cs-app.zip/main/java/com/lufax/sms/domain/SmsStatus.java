package com.lufax.sms.domain;

public enum SmsStatus {
    NEW,
    SUCCESS,
    FAILED,
    UNKNOWN;

    public static SmsStatus fromResult(String result) {
        return "0".equals(result) ? SUCCESS : FAILED;
    }
    public static SmsStatus getSmsStatusByName(String name){
        SmsStatus[] smsStatuses=SmsStatus.values();
        for(SmsStatus smsStatus:smsStatuses)
            if(smsStatus.name().equalsIgnoreCase(name))
                return smsStatus;
        return UNKNOWN;
    }
}
