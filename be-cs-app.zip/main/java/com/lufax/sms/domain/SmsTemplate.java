package com.lufax.sms.domain;

public enum SmsTemplate {
    RECHARGE_SUCCESS("JY_XJ2011110305", "充值成功"),
    RECHARGE_FAILURE("JY_XJ2011110306", "充值失败"),
    LOAN_REQUEST_LOANER_SUCCESS("JY_XJ2011110303", "确认合同成功"),
    LOAN_REQUEST_LOANEE_SUCCESS("JY_XJ2011110302", "确认合同成功"),
    LOAN_REQUEST_FAILED("JY_XJ2011110301", "贷款合同交易失败"),
    LOAN_CONFIRM_NOTICE_LOANEE("JY_XJ2011110314", "通知借款方"),
    LOAN_REQUEST_PUBLISH("JY_XJ2011110304", "贷款请求发布"),
    NOTICE_LOAN_LOANEE_COMFIRM_LOAN_REQUEST("JY_XJ2011110315", "通知确认贷款请求"),
    LOAN_GRANTING_FAILED("JY_XJ2011110312", "自动取现失败"),
    MANUAL_WITHDRAW_FAILED("JY_XJ2011110313", "手动取现失败"),
    REPAYMENT_LOANER_CONFIRM("JY_XJ2011110307", "提前还款确认"),
    VERIFICATION_SUCCESS_NO_AUTH("JY_XJ2011112102", "交易_创新交易所会员银行卡确认提示通知短信"),
    VERIFICATION_FAILURE("JY_XJ2011112101", "交易_创新交易所向用户认证银行卡账户打款失败通知短信"),
    CUSTOMER_SEND_USER_NAME("JY_XJ2011111601", "客服短信发送用户账号"),
    WITH_HOLDING_FAILURE("JY_XJ2011110311", "通知借款人代扣失败"),
    WITH_HOLDING_SUCCESS("JY_XJ2011110310", "通知借款人代扣成功"),
    NOTICE_LOANEE_OVERDUE("JY_XJ2011110308", "通知借款人逾期"),
    NOTICE_LOANER_OVERDUE("JY_XJ2011110309", "通知投资人逾期"),
    // TODO
    NOTICE_MATCH_FAILED("JY_LJS121118001", "提醒用户充值失败重新提交表单");


    private String value;
    private String description;

    SmsTemplate(String value, String description) {
        this.value = value;
        this.description = description;
    }

    public String getValue() {
        return value;
    }

    public String getDescription() {
        return description;
    }

    @Override
    public String toString() {
        return value;
    }
}
