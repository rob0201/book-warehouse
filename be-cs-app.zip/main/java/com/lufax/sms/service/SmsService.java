package com.lufax.sms.service;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lufax.common.domain.User;
import com.lufax.common.domain.repository.SmsInfoRepository;
import com.lufax.common.utils.BEProperties;
import com.lufax.common.utils.DevLog;
import com.lufax.sms.domain.SmsInfo;
import com.lufax.sms.domain.SmsMessage;
import com.lufax.sms.domain.SmsTemplate;

@Service
public class SmsService {
//    private static final String SEND_USER = "SendUser";
//    private static final String SEND_SERIES_ID = "SendSeriesID";
//    private static final String REQUEST_ID = "RequestID";
//    private static final String TEMPLATE_ID = "TemplateID";
//    private static final String MOBILE_NO = "MobileNo";
//    private static final String RESULT_ID = "ResultID";
//    private static final String SMS_HANDLER_ID = "ServiceStrongAdapter";
//    private static final String SENDER_ID = "senderID";
//    private static final String MESSAGES = "messages";
//    private static final String RESULT = "result";
//    private static final String SUCCESS_LIST = "SuccessList";
//    private static final String ERROR_LIST = "ErrorList";
    public static final String SMS_ALREADY_SENT = "smsAlreadySent";

    @Autowired
    private BEProperties p2pProperties;

    @Autowired
    private SmsInfoRepository smsInfoRepository;

//    @Autowired
//    private AMESBMessageSender amesbMessageSender;

    public SmsService() {
    }

    public void saveMessageWithTemplateId(User user, SmsTemplate smsTemplate) {
        this.saveMessage(user, new SmsMessage(smsTemplate));
    }

    @Transactional
    public void saveMessage(User user, SmsMessage message) {
        DevLog.info(this, String.format("Send a SMS message to user:%s, message is {templateId:%s,content:%s}",
                user.getUsername(), message.getSmsTemplate(), message.getContent()));

        if (message.getSmsTemplate() == null) {
            DevLog.error(this, "The template can not be null.");
            return;
        }

        if (StringUtils.isEmpty(user.getMobileNo())) {
            DevLog.error(this, "The user mobile is not exist.");
            return;
        }

        SmsInfo sms = new SmsInfo(message.getExpectSendTime(), null, user.getMobileNo(),
                message.getSmsTemplate().getValue(), message.getContent(),
                p2pProperties.getSmsSenderId(), p2pProperties.getSmsSenderName(), p2pProperties.getSmsSendSeriesId());

        smsInfoRepository.persist(sms);
    }

//    @Transactional
//    public void sendMessages(List<SmsInfo> smsInfos) {
//        List<Map<String, String>> messageList = new ArrayList<Map<String, String>>();
//        for (SmsInfo smsInfo : smsInfos) {
//            smsInfo.setFetchDate(new Date());
//            smsInfoRepository.update(smsInfo);
//            messageList.add(composeSmsMessageForSend(smsInfo));
//        }
//
//        doSendMessages(messageList);
//    }

//    private void doSendMessages(List<Map<String, String>> messageList) {
//        Otc otc = amesbMessageSender.send(prepareMessage(messageList));
//        if (otc.getReturnFlag() < 0) {
//            throw new SmsException(P2PErrorCode.SMS_RETURN_FLAG_NOT_SUCCESS);
//        }
//        Map<String, List> resultMap = otc.getValueAsMap(RESULT);
//        List<Map<String, String>> result = new ArrayList<Map<String, String>>();
//        result.addAll(resultMap.get(SUCCESS_LIST));
//        result.addAll(resultMap.get(ERROR_LIST));
//
//        for (Map<String, String> map : result) {
//            SmsInfo smsInfo = smsInfoRepository.load(Long.valueOf(map.get(REQUEST_ID)));
//            smsInfo.setSendStatus(SmsStatus.fromResult(map.get(RESULT_ID)));
//        }
//    }

//    private Msg prepareMessage(List<Map<String, String>> messageList) {
//        Msg msg = new Msg();
//        msg.setHandlerId(SMS_HANDLER_ID);
//        msg.setServiceURL(p2pProperties.getSmsServiceId());
//        msg.setValueWithString(SENDER_ID, p2pProperties.getSmsSenderId());
//        msg.setValueWithList(MESSAGES, messageList);
//        return msg;
//    }

//    private Map<String, String> composeSmsMessageForSend(SmsInfo smsToSend) {
//        Map<String, String> map = new HashMap<String, String>();
//        map.put(SEND_USER, smsToSend.getSendUser());
//        map.put(SEND_SERIES_ID, smsToSend.getSendSeriesId());
//        map.put(REQUEST_ID, String.valueOf(smsToSend.getSmsId()));
//        map.put(TEMPLATE_ID, smsToSend.getTemplateId());
//        map.put(MOBILE_NO, smsToSend.getMobileNo());
//        map.putAll(smsToSend.contentAsMap());
//        return map;
//    }
//
//    public void setAmesbMessageSender(AMESBMessageSender amesbMessageSender) {
//        this.amesbMessageSender = amesbMessageSender;
//    }
}
