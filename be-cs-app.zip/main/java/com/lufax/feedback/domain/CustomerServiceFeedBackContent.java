package com.lufax.feedback.domain;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

public class CustomerServiceFeedBackContent {
	private String userId;
	private long sendDate;
	private String page;
	private String content;
	private String name;
	private String gender;
	private List<Map<String,String>> contact = new ArrayList<Map<String, String>>();
	private String content_type;
	
	public CustomerServiceFeedBackContent(){}

	public String getUserId() {
		return userId;
	}

	public Date getSendDate() {
		return new Date(sendDate);
	}

	public String getPage() {
		return page;
	}

	public String getContent() {
		return content;
	}

	public String getName() {
		return name;
	}

	public String getGender() {
		return gender;
	}

	public List<Map<String, String>> getContact() {
		return contact;
	}

	public void setContact(List<Map<String, String>> contact) {
		this.contact = contact;
	}

	public String getContent_type() {
		return content_type;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public void setSendDate(long sendDate) {
		this.sendDate = sendDate;
	}

	public void setPage(String page) {
		this.page = page;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public void setContent_type(String content_type) {
		this.content_type = content_type;
	}

	@Override
	public String toString() {
		return "CustomerServiceFeedBackContent [userId=" + userId
				+ ", sendDate=" + sendDate + ", page=" + page + ", content="
				+ content + ", name=" + name + ", gender=" + gender
				+ ", contact=" + contact + ", content_type=" + content_type
				+ "]";
	}
	
	
}
