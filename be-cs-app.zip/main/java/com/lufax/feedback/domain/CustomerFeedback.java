package com.lufax.feedback.domain;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "MKT_MESSAGE_POOL")
public class CustomerFeedback {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_MKT_MESSAGE_POOL")
    @SequenceGenerator(name = "SEQ_MKT_MESSAGE_POOL", sequenceName = "SEQ_MKT_MESSAGE_POOL", allocationSize = 1)
    private long id;
    @Column(name = "CATEGORY")
    private String category;

    @Enumerated(EnumType.STRING)
    @Column(name="STATUS")
    private FeedbackProcessStatus status;

    @Column(name = "CONTENT")
    private String content;

    @Column(name="IP_ADDRESS")
    private String ipAddress;

    @Column(name="EXT_REF")
    private String extRef;

    @Column(name="USERID")
     private String userId;

    @Column(name="GUID")
     private String guid;
      //    '创建时间'
    @Column(name = "FCD")
    private Date fcd;

    //    '创建人'
    @Column(name = "FCU")
    private String fcu;

    //    '修改时间'
    @Column(name = "LCD")
    private Date lcd;

    //    '修改人'
    @Column(name = "LCU")
    private String lcu;

    public CustomerFeedback(){

    }

    public CustomerFeedback(long id, String category, FeedbackProcessStatus status, String content, String ipAddress, String extRef, String userId, String guid, Date fcd, String fcu, Date lcd, String lcu) {
        this.id = id;
        this.category = category;
        this.status = status;
        this.content = content;
        this.ipAddress = ipAddress;
        this.extRef = extRef;
        this.userId = userId;
        this.guid = guid;
        this.fcd = fcd;
        this.fcu = fcu;
        this.lcd = lcd;
        this.lcu = lcu;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public FeedbackProcessStatus getStatus() {
        return status;
    }


    public void setStatus(String status) {
        this.status = FeedbackProcessStatus.getStatus(status);

    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getIpAddress() {
        return ipAddress;
    }

    public void setIpAddress(String ipAddress) {
        this.ipAddress = ipAddress;
    }

    public String getExtRef() {
        return extRef;
    }

    public void setExtRef(String extRef) {
        this.extRef = extRef;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getGuid() {
        return guid;
    }

    public void setGuid(String guid) {
        this.guid = guid;
    }

    public Date getFcd() {
        return fcd;
    }

    public void setFcd(Date fcd) {
        this.fcd = fcd;
    }

    public String getFcu() {
        return fcu;
    }

    public void setFcu(String fcu) {
        this.fcu = fcu;
    }

    public Date getLcd() {
        return lcd;
    }

    public void setLcd(Date lcd) {
        this.lcd = lcd;
    }

    public String getLcu() {
        return lcu;
    }

    public void setLcu(String lcu) {
        this.lcu = lcu;
    }
}
