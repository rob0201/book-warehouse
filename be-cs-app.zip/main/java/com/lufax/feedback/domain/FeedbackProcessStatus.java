package com.lufax.feedback.domain;


import java.util.ArrayList;
import java.util.List;

public enum FeedbackProcessStatus {
	PENDING("PENDING","待处理"),
    PROCESSED("PROCESSED","已处理");

    private String name;
    private String value;

    public String getValue() {
        return value;
    }
    public String getName(){
        return name;
    }

    private FeedbackProcessStatus(String name,String value) {
        this.value = value;
        this.name=name;
    }


    public static FeedbackProcessStatus getStatus(String name){
    	FeedbackProcessStatus[] statuses = FeedbackProcessStatus.values();
    	for(FeedbackProcessStatus status:statuses){
    		if(status.name.equals(name)){
    			return status;
    		}
    	}
        return null;
    }
    
    public static List<FeedbackProcessStatus> getStatusesByName(String name){
    	List<FeedbackProcessStatus> statuses = new ArrayList<FeedbackProcessStatus>();
    	if(name.equals("ALL")){
    		for(FeedbackProcessStatus status : FeedbackProcessStatus.values()){
    			statuses.add(status);
    		}
    	}else{
    		statuses.add(getStatus(name));
    	}
    	return statuses;
    }

}
