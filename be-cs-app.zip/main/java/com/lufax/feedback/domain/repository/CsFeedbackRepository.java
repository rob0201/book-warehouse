package com.lufax.feedback.domain.repository;

import java.util.Date;
import java.util.List;

import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.google.gson.Gson;
import com.lufax.common.domain.repository.BaseRepository;
import com.lufax.common.utils.DevLog;
import com.lufax.feedback.domain.CustomerFeedback;
import com.lufax.feedback.domain.FeedbackProcessStatus;

@Repository
public class CsFeedbackRepository extends BaseRepository<CustomerFeedback> {
	public Long CountFeedback(Date fromTime, Date toTime,List<FeedbackProcessStatus> statuses) {
		DevLog.info(this, String.format("The statuses is [%s]", new Gson().toJson(statuses)));
		String sql = "select count(p.id) from CustomerFeedback p where p.status in (:statuses) and p.category in ('sme_invest_success_feedback','p2p_invest_success_feedback','help_service_feedback','common_my_account_feedback') ";
		if (null != fromTime) {
			sql = sql + " and p.fcd >=:fromTime ";
		}
		if (null != toTime) {
			sql = sql + " and p.fcd <=:toTime ";
		}
		TypedQuery<Long> query = (TypedQuery<Long>) entityManager.createQuery(sql,Long.class).setParameter("statuses", statuses);
		if (null != fromTime) {
			query.setParameter("fromTime", fromTime);
		}
		if (null != toTime) {
			query.setParameter("toTime", toTime);
		}
		
		return query.getSingleResult();
	}

	public List<CustomerFeedback> findCustomerFeedbackByStatus(long index,long maxNum, Date fromTime, Date toTime,List<FeedbackProcessStatus> statuses) {
		DevLog.info(this, String.format("The statuses is [%s]", new Gson().toJson(statuses)));
		String sql = "select fb from CustomerFeedback fb where fb.status in (:statuses) and fb.category in ('sme_invest_success_feedback','p2p_invest_success_feedback','help_service_feedback','common_my_account_feedback') ";
		if (null != fromTime) {
			sql = sql + " and fb.fcd >=:fromTime ";
		}
		if (null != toTime) {
			sql = sql + " and fb.fcd <=:toTime ";
		}

		sql = sql + " order by fb.status asc,fb.id desc ";
		DevLog.debug(this, "The entityManager is [" + entityManager + "]");
		TypedQuery<CustomerFeedback> query = (TypedQuery<CustomerFeedback>) entityManager.createQuery(sql, CustomerFeedback.class);//.setParameter("statuses", statuses);
		query.setParameter("statuses", statuses);
		if (null != fromTime) {
			query.setParameter("fromTime", fromTime);
		}
		if (null != toTime) {
			query.setParameter("toTime", toTime);
		}
		return (List<CustomerFeedback>) query.setFirstResult((int) index).setMaxResults((int) maxNum).getResultList();
	}

}
