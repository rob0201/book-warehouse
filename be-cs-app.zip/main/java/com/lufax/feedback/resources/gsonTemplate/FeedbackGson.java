package com.lufax.feedback.resources.gsonTemplate;

import java.util.Map;

import com.lufax.common.utils.DevLog;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.lang.StringUtils;

import com.google.gson.Gson;
import com.lufax.common.domain.Gender;
import com.lufax.common.domain.User;
import com.lufax.common.utils.DateUtils;
import com.lufax.feedback.domain.CustomerFeedback;
import com.lufax.feedback.domain.CustomerServiceFeedBackContent;

public class FeedbackGson {
    private String submitTime;
    private CustomerServiceFeedBackContent content;
    private String category;
    private String statusName;
    private String status;
    private long id;
    
    private String userId;
    private String name;
    private String gender;
    private String mobileNo;
    private String email;
    private String userName;
    private String messageContent;
    private String content_type;
    private String genderChinese;
    private String messageLocation;
    private String contactType;
    private String zipCode;

    public FeedbackGson(CustomerFeedback customerFeedback) {

        this.submitTime= DateUtils.formatDateToSeconds(customerFeedback.getFcd());
        this.category=customerFeedback.getCategory();
        this.statusName=customerFeedback.getStatus().getName();
        this.status=customerFeedback.getStatus().getValue();
        this.id=customerFeedback.getId();
        try {
            this.content=new Gson().fromJson(customerFeedback.getContent(),CustomerServiceFeedBackContent.class);
            this.userId = content.getUserId();
            this.name = StringEscapeUtils.escapeHtml(content.getName());
            this.gender = content.getGender();
            if(null!=content.getContact()){
                for(Map<String,String> map :content.getContact()){
                    if("email".equals(map.get("type"))){
                        this.contactType = "email";
                        this.email = StringEscapeUtils.escapeHtml(map.get("detail"));
                    }else if("phone".equals(map.get("type"))){
                        this.contactType = "phone";
                        this.mobileNo = StringEscapeUtils.escapeHtml(map.get("detail"));
                    }else if("zipCode".equals(map.get("type"))){
                        this.contactType = "zipCode";
                        this.zipCode = StringEscapeUtils.escapeHtml(map.get("detail"));
                    }
                }
            }
            this.messageContent = StringEscapeUtils.escapeHtml(content.getContent());
            this.content_type = StringEscapeUtils.escapeHtml(content.getContent_type());
            if(!StringUtils.isEmpty(content.getGender())){
                setGenderChinese(content.getGender());
            }
            this.messageLocation = StringEscapeUtils.escapeHtml(content.getPage());
        } catch (Exception e) {
//            DevLog.error(this, "Failed to convert the content [" + customerFeedback.getContent() + "], please check it", e);
        	DevLog.warn(this, "Failed to convert the content [" + customerFeedback.getContent() + "], please check it");
        }
    }

    public void setUserInfo(User user){
    	this.name = user.getName();
    	this.userName = user.getUsername();
    	this.mobileNo = user.getMobileNo();
    	this.email = user.getEmail();
    	this.gender = user.getIdentity()==null?null:user.getIdentity().getGender().name();
    	setGenderChinese(this.gender);
    }
    
    public CustomerServiceFeedBackContent getContent() {
        return content;
    }

    public void setContent(CustomerServiceFeedBackContent content) {
        this.content = content;
    }

    public String getSubmitTime() {
        return submitTime;
    }

    public void setSubmitTime(String submitTime) {
        this.submitTime = submitTime;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getStatusName() {
        return statusName;
    }

    public void setStatusName(String statusName) {
        this.statusName = statusName;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getMessageContent() {
		return messageContent;
	}

	public void setMessageContent(String messageContent) {
		this.messageContent = messageContent;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getContent_type() {
		return content_type;
	}

	public void setContent_type(String content_type) {
		this.content_type = content_type;
	}

	public String getGenderChinese() {
		return genderChinese;
	}

	public void setGenderChinese(String genderChinese) {
		if(Gender.MALE.name().equalsIgnoreCase(genderChinese)){
    		this.genderChinese = "先生";
    	}else if(Gender.FEMALE.name().equalsIgnoreCase(genderChinese)){
    		this.genderChinese = "女士";
    	}else{
    		this.genderChinese="未知";
    	}
	}
	
	public String getContactType() {
		return contactType;
	}

	public String getZipCode() {
		return zipCode;
	}
	
	@Override
	public String toString() {
		return "FeedbackGson [submitTime=" + submitTime + ", content="
				+ content + ", category=" + category + ", statusName="
				+ statusName + ", status=" + status + ", id=" + id
				+ ", userId=" + userId + ", name=" + name + ", gender="
				+ gender + ", mobileNo=" + mobileNo + ", email=" + email
				+ ", userName=" + userName + ", messageContent="
				+ messageContent + ", content_type=" + content_type
				+ ", genderChinese=" + genderChinese + ", messageLocation="
				+ messageLocation + ", contactType=" + contactType
				+ ", zipCode=" + zipCode + "]";
	}
}
