package com.lufax.feedback.resources;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.lang.StringUtils;

import com.google.gson.Gson;
import com.lufax.common.domain.User;
import com.lufax.common.domain.repository.UserRepository;
import com.lufax.common.resources.gsonTemplate.PaginationGson;
import com.lufax.common.utils.DateUtils;
import com.lufax.common.web.filter.UsersContextFilter;
import com.lufax.feedback.domain.CustomerFeedback;
import com.lufax.feedback.domain.FeedbackProcessStatus;
import com.lufax.feedback.domain.repository.CsFeedbackRepository;
import com.lufax.feedback.resources.gsonTemplate.FeedbackGson;
import com.lufax.feedback.service.CustomerFeedbackService;
import com.lufax.jersey.usercontext.UserContextUtils;
import com.sun.jersey.api.core.InjectParam;

@Path("/feedback")
public class customerFeedbackResource {
	private final static int PAGE_SIZE = 10;
	@InjectParam
	private CustomerFeedbackService customerFeedbackService;

	@InjectParam
	private CsFeedbackRepository csFeedbackRepository;
	
	@InjectParam
	private UserRepository userRepository;

	private static final String TIME_START_HEAD = " 00:00:00";
	private static final String TIME_END_TAIL = " 23:59:59";
	@GET
	@Path("/query/{pageno}")
	@Produces(value = MediaType.APPLICATION_JSON)
	public String customerFeedback(@PathParam("pageno") String pageno,
			@QueryParam("fromTime") String fromTime,
			@QueryParam("toTime") String toTime,
			@QueryParam("feedBackStatus") String feedBachStatus) {
		com.lufax.common.utils.DevLog.debug(this,String.format("the pageNo is [%s], the fromTime is [%s], the toTime is [%s], the feedBackStatus is [%s]",pageno, fromTime, toTime, feedBachStatus));
		long total = csFeedbackRepository.CountFeedback(parseStrToDate(fromTime,TIME_START_HEAD), parseStrToDate(toTime,TIME_END_TAIL),FeedbackProcessStatus.getStatusesByName(feedBachStatus));
		int targetPage = 0;
		if (null != pageno && !"".equals(pageno)) {
			targetPage = Integer.parseInt(pageno);
		}
		PaginationGson paginationGson = new PaginationGson(PAGE_SIZE, total, targetPage);
		
		List<CustomerFeedback> customerFeedbackList = customerFeedbackService.findCustomerFeedbacks((targetPage - 1) * PAGE_SIZE, PAGE_SIZE,parseStrToDate(fromTime,TIME_START_HEAD), parseStrToDate(toTime,TIME_END_TAIL),FeedbackProcessStatus.getStatusesByName(feedBachStatus));
		List<FeedbackGson> feedbackGsonList = new ArrayList<FeedbackGson>();
		for (CustomerFeedback customerFeedback : customerFeedbackList) {
			FeedbackGson feedbackGson = new FeedbackGson(customerFeedback);
			if(!StringUtils.isEmpty(feedbackGson.getUserId())){
				User user = userRepository.findById(Long.parseLong(feedbackGson.getUserId()));
				feedbackGson.setUserInfo(user);
			}
			feedbackGsonList.add(feedbackGson);
		}
		paginationGson.setData(feedbackGsonList);
		String result =  new Gson().toJson(paginationGson);
//		return StringEscapeUtils.escapeHtml(result);
		return result;
	}

	@GET
	@Path("/changeStatus")
	@Produces(value = MediaType.TEXT_PLAIN)
	public String changeFeedbackStatus(@QueryParam("id") String id) {
		com.lufax.common.metadata.User currentLoginUser = (com.lufax.common.metadata.User) UserContextUtils.getUserParameter(UsersContextFilter.USER_KEY);
		customerFeedbackService.changeStatusToProcessed(Long.parseLong(id),currentLoginUser.getP2pUserId());
		return "success";
	}

	private Date parseStrToDate(String dateString,String tail){
		if(!StringUtils.isEmpty(dateString) && null!=dateString){
			Date date = DateUtils.parse(DateUtils.DATE_TIME_FORMAT_DEFAULT, dateString+tail);
			com.lufax.common.utils.DevLog.info(this, String.format("The dateString is [%s], the date is [%s]", dateString,date));
			return date;
		}
		return null;
	}
	
}
