package com.lufax.feedback.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lufax.feedback.domain.CustomerFeedback;
import com.lufax.feedback.domain.FeedbackProcessStatus;
import com.lufax.feedback.domain.repository.CsFeedbackRepository;

/**
 * 查询客户反馈信息 、将客户反馈信息置为解决
 */
@Service
public class CustomerFeedbackService {
    @Autowired
    private CsFeedbackRepository csFeedbackRepository;

    public List<CustomerFeedback> findCustomerFeedbacks(long index,long maxNum,Date fromTime ,Date toTime,List<FeedbackProcessStatus> statuses){
        return csFeedbackRepository.findCustomerFeedbackByStatus(index,maxNum,fromTime,toTime,statuses);
    }
    @Transactional
    public void changeStatusToProcessed(long id,long p2pUserId){
        CustomerFeedback customerFeedback = csFeedbackRepository.load(id);
        customerFeedback.setStatus(FeedbackProcessStatus.PROCESSED.getName());
        customerFeedback.setLcu(String.valueOf(p2pUserId));
        customerFeedback.setLcd(new Date());
    }
}
