package com.lufax.common.exception;

public class CapitalRemoteException extends RuntimeException {

    protected TagErrorCode errorCode;
    protected String errorMsg;

    public CapitalRemoteException(TagErrorCode errorCode, Object args) {
        super();
        this.errorCode = errorCode;
        this.errorMsg = String.format(errorCode.getLocaleMsg());
    }

}
