package com.lufax.common.exception;

import java.util.Locale;

public enum CapitalRemoteErrorCode implements TagErrorCode {
    REMOTE_INVOKE_FAILED("远程调用失败","network connect failed");
	private String cn;
	private String en;
	private CapitalRemoteErrorCode(String cn,String en){
		this.cn = cn;
		this.en = en;
	}

    public String getLocaleMsg() {
		return getLocaleMsg(Locale.getDefault());
	}
	public String getLocaleMsg(Locale locale) {
		if ("CN".equalsIgnoreCase(locale.getCountry())) { 
			return this.cn; 
		}else { 
			return this.en; 
		}
	}
}
