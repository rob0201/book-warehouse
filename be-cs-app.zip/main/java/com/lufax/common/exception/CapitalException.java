package com.lufax.common.exception;


public class CapitalException extends RuntimeException {
    protected TagErrorCode errorCode;
    protected String errorMsg;

    public CapitalException(TagErrorCode errorCode) {
        super();
        this.errorCode = errorCode;
        this.errorMsg = String.format(errorCode.getLocaleMsg());
    }

    public String getErrorMsg() {
        return errorMsg;
    }

}
