package com.lufax.common.exception;

public class RepaymentException extends P2PException {
    public RepaymentException(P2PErrorCode errorCode) {
        super(errorCode);
    }
}
