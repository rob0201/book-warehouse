package com.lufax.common.exception;

import java.util.Locale;


public interface TagErrorCode {

    public String getLocaleMsg();

	public String getLocaleMsg(Locale Locale);
}
