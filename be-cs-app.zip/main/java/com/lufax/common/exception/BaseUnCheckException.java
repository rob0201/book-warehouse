package com.lufax.common.exception;

public class BaseUnCheckException extends RuntimeException{
    public BaseUnCheckException(String message, Exception e){
        super(message, e);
    }
}
