package com.lufax.common.exception;

import static javax.ws.rs.core.MediaType.TEXT_PLAIN;
import static javax.ws.rs.core.Response.Status.CONFLICT;
import static javax.ws.rs.core.Response.Status.INTERNAL_SERVER_ERROR;

import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

import com.lufax.jersey.utils.Logger;

@Provider
public class CSExceptionHandler implements ExceptionMapper<Exception> {
    public Response toResponse(Exception e) {
        if (e instanceof CapitalException) {
            Logger.warn(this, e.getMessage(), e);// 记录出错信息日志
            return Response.status(CONFLICT).entity(((CapitalException) e).getErrorMsg()).type(TEXT_PLAIN).build();
        }
//        if (e instanceof MKTException) {
//            Logger.error(this, e.getMessage(), e);// 记录出错信息日志
//            return Response.status(CONFLICT).entity(((MKTException) e).getErrorMsg()).type(TEXT_PLAIN).build();
//        }
        Logger.warn(this, e.getMessage(), e);
        return Response.status(INTERNAL_SERVER_ERROR).entity(e.getMessage()).build();
    }
}
