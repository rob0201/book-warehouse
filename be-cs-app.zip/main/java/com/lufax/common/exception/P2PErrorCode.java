package com.lufax.common.exception;

public enum P2PErrorCode {
    REMOTE_INVOKE_FAILED("network connect failed"),
    AVAILABLE_FUND_NOT_ENOUGH("available.fund.not.enough"),
    FROZEN_FUND_NOT_ENOUGHT_TO_UNFREEZE("fronzen.fund.not.enough.to.unfreeze"),
    PREPAYMENT_FAILED("prepayment.failed"),
    FROZEN_CODE_NOT_EXISTS("frozen.code.not.exists"),
    FROZEN_CODE_ALREADY_UNFROZEN("frozen.code.already.unfrozen"),
    DATE_RANGE_INVALID("date.range.invalid"),
    START_DATE_AFTER_END_DATE("start.date.after.end.date"),
    END_DATE_AFTER_YESTERDAY("end.date.after.yesterday"),
    TRANSFER_AMOUNT_LESS_THAN_ZERO("transfer.amount.lessthan.zero"),
    SMS_RETURN_FLAG_NOT_SUCCESS("Failed to send sms to AmESB."),
    REPEATED_REPAYMENT("repayment.repeated");

    private String value;

    P2PErrorCode(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
