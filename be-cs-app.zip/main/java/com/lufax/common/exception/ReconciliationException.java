package com.lufax.common.exception;

public class ReconciliationException extends P2PException {
    public ReconciliationException(P2PErrorCode errorCode, String... args) {
        super(errorCode, args);
    }
}
