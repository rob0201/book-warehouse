package com.lufax.common.exception;

public class BaseCheckException extends Exception{
    private  ErrorCode errorCode;

    public ErrorCode getErrorCode() {
        return errorCode;
    }

    public BaseCheckException(ErrorCode errorCode, String message, Exception e){
        super(message, e);
        this.errorCode = errorCode;
    }
}
