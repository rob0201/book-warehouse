package com.lufax.common.exception;

public enum ErrorCode {
    DATABASE_ERROR
}
