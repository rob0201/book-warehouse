package com.lufax.common.exception;

public class CSException extends RuntimeException {

	public CSException() {
	}

	public CSException(String message) {
		super(message);
	}

	public CSException(Throwable cause) {
		super(cause);
	}

	public CSException(String message, Throwable cause) {
		super(message, cause);
	}

}
