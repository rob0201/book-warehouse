package com.lufax.common.exception;

import com.lufax.common.web.helper.ConstantsHelper;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;

import static com.lufax.common.web.helper.ConstantsHelper.DEFAULT_LOCALE;

public class P2PException extends RuntimeException {

    public static ReloadableResourceBundleMessageSource ERROR_MESSAGE_RESOURCE = new ReloadableResourceBundleMessageSource();
    static {
        ERROR_MESSAGE_RESOURCE.setBasename("errors");
        ERROR_MESSAGE_RESOURCE.setDefaultEncoding(ConstantsHelper.DEFAULT_CHARSET);
    }

    public P2PException() {
    }

    public P2PException(P2PErrorCode errorCode, String... args) {
        super(ERROR_MESSAGE_RESOURCE.getMessage(errorCode.getValue(), args, "", DEFAULT_LOCALE));
    }

    public P2PException(String msg) {
        super(msg);
    }
}
