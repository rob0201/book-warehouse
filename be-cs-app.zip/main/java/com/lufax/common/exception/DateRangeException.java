package com.lufax.common.exception;

public class DateRangeException extends P2PException {
    public DateRangeException(P2PErrorCode errorCode, String... args) {
        super(errorCode, args);
    }
}
