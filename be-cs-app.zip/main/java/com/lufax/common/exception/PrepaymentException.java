package com.lufax.common.exception;

public class PrepaymentException extends P2PException {
    public PrepaymentException(P2PErrorCode errorCode, String... args) {
        super(errorCode, args);
    }

}
