package com.lufax.common.exception;

public class RemoteInvokeException extends RuntimeException {

	public RemoteInvokeException() {
	}

	public RemoteInvokeException(String message) {
		super(message);
	}

	public RemoteInvokeException(Throwable cause) {
		super(cause);
	}

	public RemoteInvokeException(String message, Throwable cause) {
		super(message, cause);
	}

}
