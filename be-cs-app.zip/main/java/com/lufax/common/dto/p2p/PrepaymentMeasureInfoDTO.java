package com.lufax.common.dto.p2p;

import java.math.BigDecimal;

import com.lufax.common.dto.NotBaseDTO;


public class PrepaymentMeasureInfoDTO extends NotBaseDTO{
    private boolean prepayWithCurrent;
    private boolean prepayWithPrevious;
    private BigDecimal normalAmount = new BigDecimal("0");
    private BigDecimal realPreviousOverduePenalty = new BigDecimal("0");
    private String startAt;
    private String endAt;
    private String startAtOfFinalPlan;
    private String InExtensionLimit;
    private String prepaymentDate;
    //useful
    private BigDecimal totalAmount;
    private BigDecimal previousPrincipal = new BigDecimal("0");
    private BigDecimal previousInterest = new BigDecimal("0");
    private BigDecimal previousInsuranceFee = new BigDecimal("0");
    private BigDecimal previousOverduePenaltyToPay = new BigDecimal("0");
    private BigDecimal remainingPrincipal;
    private BigDecimal currentInterest = new BigDecimal("0");
    private BigDecimal currentInsuranceFee = new BigDecimal("0");
    private BigDecimal currentOverduePenaltyToPay = new BigDecimal("0");
    private BigDecimal insuranceManagementFee;
    private BigDecimal penalValue;
    private BigDecimal previousTotalAmount = new BigDecimal("0");
    private BigDecimal prepayTotalAmount = new BigDecimal("0");
    
	public boolean isPrepayWithCurrent() {
		return prepayWithCurrent;
	}
	public void setPrepayWithCurrent(boolean prepayWithCurrent) {
		this.prepayWithCurrent = prepayWithCurrent;
	}
	public boolean isPrepayWithPrevious() {
		return prepayWithPrevious;
	}
	public void setPrepayWithPrevious(boolean prepayWithPrevious) {
		this.prepayWithPrevious = prepayWithPrevious;
	}
	public BigDecimal getNormalAmount() {
		return normalAmount;
	}
	public void setNormalAmount(BigDecimal normalAmount) {
		this.normalAmount = normalAmount;
	}
	public BigDecimal getRealPreviousOverduePenalty() {
		return realPreviousOverduePenalty;
	}
	public void setRealPreviousOverduePenalty(BigDecimal realPreviousOverduePenalty) {
		this.realPreviousOverduePenalty = realPreviousOverduePenalty;
	}
	public String getStartAt() {
		return startAt;
	}
	public void setStartAt(String startAt) {
		this.startAt = startAt;
	}
	public String getEndAt() {
		return endAt;
	}
	public void setEndAt(String endAt) {
		this.endAt = endAt;
	}
	public String getStartAtOfFinalPlan() {
		return startAtOfFinalPlan;
	}
	public void setStartAtOfFinalPlan(String startAtOfFinalPlan) {
		this.startAtOfFinalPlan = startAtOfFinalPlan;
	}
	public String getInExtensionLimit() {
		return InExtensionLimit;
	}
	public void setInExtensionLimit(String inExtensionLimit) {
		InExtensionLimit = inExtensionLimit;
	}
	public String getPrepaymentDate() {
		return prepaymentDate;
	}
	public void setPrepaymentDate(String prepaymentDate) {
		this.prepaymentDate = prepaymentDate;
	}
	public BigDecimal getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(BigDecimal totalAmount) {
		this.totalAmount = totalAmount;
	}
	public BigDecimal getPreviousPrincipal() {
		return previousPrincipal;
	}
	public void setPreviousPrincipal(BigDecimal previousPrincipal) {
		this.previousPrincipal = previousPrincipal;
	}
	public BigDecimal getPreviousInterest() {
		return previousInterest;
	}
	public void setPreviousInterest(BigDecimal previousInterest) {
		this.previousInterest = previousInterest;
	}
	public BigDecimal getPreviousInsuranceFee() {
		return previousInsuranceFee;
	}
	public void setPreviousInsuranceFee(BigDecimal previousInsuranceFee) {
		this.previousInsuranceFee = previousInsuranceFee;
	}
	public BigDecimal getPreviousOverduePenaltyToPay() {
		return previousOverduePenaltyToPay;
	}
	public void setPreviousOverduePenaltyToPay(BigDecimal previousOverduePenaltyToPay) {
		this.previousOverduePenaltyToPay = previousOverduePenaltyToPay;
	}
	public BigDecimal getRemainingPrincipal() {
		return remainingPrincipal;
	}
	public void setRemainingPrincipal(BigDecimal remainingPrincipal) {
		this.remainingPrincipal = remainingPrincipal;
	}
	public BigDecimal getCurrentInterest() {
		return currentInterest;
	}
	public void setCurrentInterest(BigDecimal currentInterest) {
		this.currentInterest = currentInterest;
	}
	public BigDecimal getCurrentInsuranceFee() {
		return currentInsuranceFee;
	}
	public void setCurrentInsuranceFee(BigDecimal currentInsuranceFee) {
		this.currentInsuranceFee = currentInsuranceFee;
	}
	public BigDecimal getCurrentOverduePenaltyToPay() {
		return currentOverduePenaltyToPay;
	}
	public void setCurrentOverduePenaltyToPay(BigDecimal currentOverduePenaltyToPay) {
		this.currentOverduePenaltyToPay = currentOverduePenaltyToPay;
	}
	public BigDecimal getInsuranceManagementFee() {
		return insuranceManagementFee;
	}
	public void setInsuranceManagementFee(BigDecimal insuranceManagementFee) {
		this.insuranceManagementFee = insuranceManagementFee;
	}
	public BigDecimal getPenalValue() {
		return penalValue;
	}
	public void setPenalValue(BigDecimal penalValue) {
		this.penalValue = penalValue;
	}
	public BigDecimal getPreviousTotalAmount() {
		return previousTotalAmount;
	}
	public void setPreviousTotalAmount(BigDecimal previousTotalAmount) {
		this.previousTotalAmount = previousTotalAmount;
	}
	public BigDecimal getPrepayTotalAmount() {
		return prepayTotalAmount;
	}
	public void setPrepayTotalAmount(BigDecimal prepayTotalAmount) {
		this.prepayTotalAmount = prepayTotalAmount;
	}
    
}
