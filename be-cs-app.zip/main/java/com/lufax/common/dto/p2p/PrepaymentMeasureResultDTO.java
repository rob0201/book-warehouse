package com.lufax.common.dto.p2p;

import com.lufax.common.dto.BaseDTO;

public class PrepaymentMeasureResultDTO extends BaseDTO {
	
	private String result;
	private long loanId;
	private String message;
	private String loanSourceType;
	private PrepaymentMeasureInfoDTO prepaymentMeasureInfoGson;

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public long getLoanId() {
		return loanId;
	}

	public void setLoanId(long loanId) {
		this.loanId = loanId;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getLoanSourceType() {
		return loanSourceType;
	}

	public void setLoanSourceType(String loanSourceType) {
		this.loanSourceType = loanSourceType;
	}

	public PrepaymentMeasureInfoDTO getPrepaymentMeasureInfoGson() {
		return prepaymentMeasureInfoGson;
	}

	public void setPrepaymentMeasureInfoGson(PrepaymentMeasureInfoDTO prepaymentMeasureInfoGson) {
		this.prepaymentMeasureInfoGson = prepaymentMeasureInfoGson;
	}
	
}
