package com.lufax.common.metadata;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Menu implements Cloneable {

    private Long id;
    private String name;
    private String displayName;
    private Long sequence;
    private Long parentID;
    private String url;

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    private List<Menu> children = new ArrayList<Menu>();

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public Long getSequence() {
        return sequence;
    }

    public void setSequence(Long sequence) {
        this.sequence = sequence;
    }

    public Long getParentID() {
        return parentID;
    }

    public void setParentID(Long parentID) {
        this.parentID = parentID;
    }

    public List<Menu> getChildren() {
        return children;
    }

    public void setChildren(List<Menu> children) {
        this.children = children;
        sort();
    }

    public void addChild(Menu child) {
        this.children.add(child);
        sort();
    }

    public void removeChild(Menu child) {
        this.children.remove(child);
        sort();
    }

    private void sort() {
        if (this.children.size() <= 1) return;
        Collections.sort(this.children, new Comparator<Menu>() {
            public int compare(Menu o1, Menu o2) {
                return o1.getSequence() < o2.getSequence() ? 0 : 1;
            }
        });
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("[id=");
        sb.append(this.id);
        sb.append(",name=");
        sb.append(this.name);
        sb.append(",displayname=");
        sb.append(this.displayName);
        sb.append(",seq=");
        sb.append(this.sequence);
        sb.append(",url=");
        sb.append(this.url);
        sb.append(",childen=\n");
        if (this.children.size() == 0)
            sb.append("null]");
        else {
            for (Menu subMenu : this.children) {
                sb.append(subMenu.toString());
            }
            sb.append("]");
        }
        return sb.toString();
    }

    public Object clone() throws CloneNotSupportedException {
        Menu cloneObject = new Menu();
        cloneObject.setId(this.id);
        cloneObject.setName(this.name);
        cloneObject.setDisplayName(this.displayName);
        cloneObject.setSequence(this.sequence);
        cloneObject.setUrl(this.url);

        for (Menu m : this.children) {
            Menu cloneChild = (Menu) m.clone();
            cloneObject.addChild(cloneChild);
        }

        return cloneObject;
    }
}
