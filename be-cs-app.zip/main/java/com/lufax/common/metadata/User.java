package com.lufax.common.metadata;

public class User {

	private Long id;
	private String name;
	private Long p2pUserId;
	private String password;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Long getP2pUserId() {
		return p2pUserId;
	}

	public void setP2pUserId(Long p2pUserId) {
		this.p2pUserId = p2pUserId;
	}

	public String toString() {
		return "[id=" + id + ",name=" + name + ",p2pUserId=" + p2pUserId + "]";
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

}
