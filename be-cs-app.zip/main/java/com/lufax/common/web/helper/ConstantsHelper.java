package com.lufax.common.web.helper;

import javax.ws.rs.core.MediaType;
import java.math.BigDecimal;
import java.text.DecimalFormatSymbols;
import java.util.Locale;

public class ConstantsHelper {
    //Cookie
    public static final String TOKEN = "_token";
    public static final String USER_ID = "userId";
    public static final String USER_CONTEXT = "userContext";
    public static final String USER_UM = "um";

    //DateFormat
    public static final String DATE_FORMAT = "yyyy-MM-dd";
    public static final String DATE_FORMAT_CHINESE = "yyyy年MM月dd日";
    public static final String DATE_TIME_FORMAT = "yyyy-MM-dd HH:mm:ss";
    public static final String CMS_DRAW_SEQUENCE_FORMAT = "yyyyMMddhhmmss";
    public static final String XINBAO_DATE_FORMAT = "yyyy/MM/dd";
    public static final String MEMBER_SYSTEM_DATE_FORMAT = "yyyy-MM-dd";
    public static final String MATCH_TIME_FORMAT = "yyyy/MM/dd HH:mm:ss";


    public static final String P2P_USER_ID = "userId";
    public static final String USER = "user";
    public static final String CMS_USER_NAME = "P2P_USER";

    public static final String FAIL_RESULT = "fail";
    public static final String SUCCESS_RESULT = "success";

    public static final String SUCCESS_MESSAGE = "成功";
    public static final Locale DEFAULT_LOCALE = Locale.SIMPLIFIED_CHINESE;
    public static final String CURRENCY_FORMAT = new DecimalFormatSymbols(DEFAULT_LOCALE).getCurrencySymbol() + "#,##0.00";
    public static final String PERCENTAGE_FORMAT = "#,##0.00%";


    public static final String DATE_STRING_FORMAT = "yyyyMMdd";

    public static final int PERCENTAGE_SCALE = 4;
    public static final int CURRENCY_SCALE = 2;

    public static final String REDIRECT_ADMIN_LOGIN_PATH = "redirect:/operation/p2p/login";
    public static final String REDIRECT_CUSTOM_SERVICE_LOGIN_PATH = "redirect:/customerService/login";

    public static final String PDF_SUFFIX = "pdf";
    public static final String DEFAULT_CHARSET = "UTF-8";
    public static final String DEFAULT_CHARSET_HEADER = "charset=utf-8";
    public static final String APPLICATION_JSON_WITH_DEFAULT_CHARSET_HEADER = MediaType.APPLICATION_JSON + ";" + DEFAULT_CHARSET_HEADER;

    public static final String PENAL_TRANSACTION_TYPE_VALUE = "提前还款违约金";
    public static final String ALL_TRANSACTION_TYPE_VALUE = "所有";
    public static final String MANAGEMENT_FEE_TRANSACTION_TYPE_VALUE = "账户管理费";
    public static final String INSURANCE_FEE_TRANSACTION_TYPE_VALUE = "担保费";
    public static final String INVESTMENT_TRANSACTION_FEE_VALUE= "投资交易费";
    public static final String TRANSFER_FEE_TRANSACTION_TYPE_VALUE = "转让手续费";

    public static final String HANDLED_CMS_WITHDRAW_CODE = "PBB00";
    public static final String SUCCESSED_CMS_WITHDRAW_STATUS = "bat-0007";

    public static final String MONEY_PATTERN = "^\\d+(\\.\\d{1,2})?$";
    public static final String FAKE_CONTRACT_STORE_ID = "contractStoreId";

    public static final String CMS_WITHDRAW_FEE_REMARK = "银行转账手续费";
    public static final String CMS_WITHDRAW_FEE_TYPE = "取现手续费";

    public static final String TRANSACTION_FEE_TRANSACTION_TYPE_VALUE = "服务费";
    public static final String RECHARGE_FEE_TRANSACTION_TYPE_VALUE = "充值手续费";

    public static final String MEMBER_SYSTEM_KEEP_SESSION_URL = "memberSystemKeepSessionUrl";
    public static final String MEMBER_LOGOUT_URL = "MEMBER_LOGOUT_URL";

    public static final int PAGE_LIMIT = 15;
    public static final int RECENT_LIMIT = 5;
    public static final int ADMIN_CANCEL_PAGE_LIMIT = 20;
    public static final int CUSTOMER_SERVICE_PAGE_LIMIT = 10;
    public static final int ADMIN_COMPENSATION_PAGE_LIMIT = 10;
    public static final int RARE_PAGE_LIMIT = 50;

    public static final int START_INTEREST_DELAY = 3;

    public static final String OCS_DOMAIN = "ocsDomain";
    public static final String OCS_CUSTOMER_SERVICE_SWITCH = "ocsCustomerServiceSwitch";
    public static final String OCS_TYPE_ID = "ocsTypeId";
    public static final String OCS_STRATEGY_ID = "ocsStrategyId";

    public static final String MAIN_CONFIGRATION = "mainConfigration";
    public static final String STATIC_VERSION = "staticVersion";

    public static final String OTP_SEND_SUCCESSFUL = "SendOk";
    public static final String OTP_VERIFY_SUCCESSFUL = "VerifyOk";
    public static final String OTP_SMS_CONTEXT = "context";
    public static final String OTP_SMS_TEMPLATE = "template";
    public static final String OTP_SMS_MOBILENO = "mobileNo";

    public static final String OTP_SEPARATOR = "|||";
    public static final String OTP_KEY_VALUE_SEPARATOR = "||||";

    public static final String OTP_CONTENT_NUMBER = "NUMBER";
    public static final String OTP_CONTENT_NOTIC = "NOTIC";

    public static final String CCF_MATCH_SUCCESS = "一致";
    public static final String CCF_MATCH_FAILED = "不一致";

    public static final String BANK_CODE_PINGAN = "A00";
    public static final String BANK_CODE_SHENFAZHAN = "307";
    public static final BigDecimal MAX_RECHARGE_AMOUNT_OF_PINGAN = new BigDecimal(50000);
    public static final String ALL_COMPENSATION_TYPE_VALUE = "所有";
    public static final String ALL_WITHDRAW_RECORDS_REASON_FOR_RARE_WORDS = "所有";

    public static final String RARE_WORDS_EXCEL_NAME = "rare-words";
    public static final String RARE_WORDS_EXCEL_ID = "编号";
    public static final String RARE_WORDS_EXCEL_WORDS = "生僻字";
    public static final String RARE_WORDS_EXCEL_CREATED_AT = "生成时间";
    public static final String RARE_WORDS_EXCEL_CREATED_BY = "添加人";
    public static final String RARE_WORDS_EXCEL_UPDATED_BY = "修改人";
    public static final String RARE_WORDS_EXCEL_UPDATED_AT = "修改时间";
    public static final String RARE_WORDS_EXCEL_IS_AVAILABLE = "有效性";
    public static final String REMOTE_INTERFACE_CALL_GET_METHOD_NAME = "GET";
    public static final String REMOTE_INTERFACE_CALL_POST_METHOD_NAME = "POST";
    public static final String REMOTE_INTERFACE_CALL_RARE_WORDS_SUCCESS = "success";
    public static final String REMOTE_INTERFACE_CALL_RARE_WORDS_PARAMETER_OF_RESULT = "result";
    public static final String REMOTE_INTERFACE_CALL_RARE_WORDS_PARAMETER_OF_RECORD_ID = "recordId";
    public static final String REMOTE_INTERFACE_CALL_RARE_WORDS_FAIL = "fail";
    public static final String REMOTE_INTERFACE_CALL_RARE_WORDS_SUCCESS_RESULT_CODE = "000";
    public static final String REMOTE_INTERFACE_CALL_COMPENSATION_SUCCESS_RESULT_CODE = "success";
    public static final String REMOTE_INTERFACE_CALL_COMPENSATION_FAIL_RESULT_CODE = "failure";
    public static final String REMOTE_INTERFACE_CALL_COMPENSATION_PARAMETER_OF_COMPENSATION_ID = "";
    public static final String RETCODE_SUCCESS= "000";


    public static final String LAUNCH_CHANNEL_P2P = "P2P";

    public static final String LAUNCH_CHANNEL_SME = "SME";

    // ECR343 REQUEST_COMPENSATE_DAYS
    public static final int REQUEST_COMPENSATE_DAYS = 80;
}
