package com.lufax.common.web.filter;

import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import org.springframework.beans.factory.annotation.Autowired;

import com.lufax.common.metadata.User;
import com.lufax.common.utils.BEProperties;
import com.lufax.common.utils.DevLog;
import com.lufax.common.utils.UserHelper;
import com.lufax.jersey.usercontext.UserContext;
import com.lufax.jersey.usercontext.UserContextUtils;
import com.lufax.jersey.usercontext.filter.UserContextFilter;

public class UsersContextFilter extends UserContextFilter {
    @Autowired
    private BEProperties beProperties;
    @Autowired
    private UserHelper userHelper;
    
    public static String USER_KEY = "CUREENT_UM_USER";

    protected void setConfig(ServletRequest request, ServletResponse response, UserContext userContext) {
        try {
            User user = userHelper.getUser(new Long(userContext.getUserId()));
            UserContextUtils.setUserParameter(USER_KEY, user);
        } catch (Exception e) {
            //得到当前用户信息
            DevLog.error(this, String.format("Current user is [%s]", userContext.getUserId()), e);
        }
    }
}
