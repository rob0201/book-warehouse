package com.lufax.common.web.filter;

import org.springframework.web.filter.GenericFilterBean;

import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.List;
import java.util.regex.Pattern;

public abstract class IgnorableFilter extends GenericFilterBean {
    private String[] ignore = new String[0];

    public void setIgnore(String[] ignore) {
        this.ignore = ignore.clone();
    }

    protected boolean isIgnored(ServletRequest request) throws IOException, ServletException {
        HttpServletRequest httpServletRequest = (HttpServletRequest) request;
        String requestURI = httpServletRequest.getRequestURI();
        for (String pattern : ignore) {
            if (Pattern.compile(pattern).matcher(requestURI).matches()) {
                return true;
            }
        }
        return false;
    }

    protected boolean isGrantedAuthority(ServletRequest request, List<String> permissionURLs) throws IOException, ServletException {
        if (permissionURLs == null) return false;
        HttpServletRequest httpServletRequest = (HttpServletRequest) request;
        String requestURI = httpServletRequest.getRequestURI();
        for (String pattern : permissionURLs) {
            if (Pattern.compile(pattern).matcher(requestURI).find()) {
                return true;
            }
        }
        return false;
    }
}
