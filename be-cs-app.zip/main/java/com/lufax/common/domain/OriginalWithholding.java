package com.lufax.common.domain;

import com.lufax.common.domain.account.Money;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "ORIGINAL_WITHHOLDING")
public class OriginalWithholding {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_ORIGINAL_WITHHOLDING")
    @SequenceGenerator(name = "SEQ_ORIGINAL_WITHHOLDING", sequenceName = "SEQ_ORIGINAL_WITHHOLDING", allocationSize = 1)
    private long id;

    @Column(name = "POLICY_NO")
    private String policyNo;

    @Embedded
    @AttributeOverrides({@AttributeOverride(name = "amount", column = @Column(name = "AMOUNT"))})
    private Money amount;

    //    @Enumerated(EnumType.STRING)
    @Column(name = "STATUS")
    private String status;


    @Column(name = "REF_NO")
    private String refNo;

    @Column(name = "CREATED_AT")
    private Date createdAt;

    @Column(name = "UPDATED_AT")
    private Date updatedAt;

    public OriginalWithholding() {
    }

    public OriginalWithholding(String policyNo, Money amount, WithHoldingStatus status) {
        this(policyNo, amount, status, "");
    }

    public OriginalWithholding(String policyNo, Money amount, WithHoldingStatus status, String refNo) {
        this.policyNo = policyNo;
        this.amount = amount;
        this.status = (status != null) ? status.name() : null;
        this.refNo = refNo;
        this.createdAt = new Date();
    }

    public String getPolicyNo() {
        return policyNo;
    }

    public Money getAmount() {
        return amount;
    }

    public void setStatus(WithHoldingStatus status) {
        this.status = (status != null) ? status.name() : null;
        this.updatedAt = new Date();
    }

    public long id() {
        return id;
    }

    public WithHoldingStatus getStatus() {
        return WithHoldingStatus.getWithHoldingStatusByName(status);
    }
}
