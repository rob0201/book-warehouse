package com.lufax.common.domain;

public enum RiskVerifyStatus {
    NO_VERIFIED("0", "未评估"),
    CONSERVATIVE("1", "保守型"),
    ROBUST_TYPE("2", "稳健型"),
    BALANCE_TYPE("3", "平衡型"),
    UP_TYPE("4","成长型"),
    ENTERPRISING_TYPE("5","进取型"),
    UNKNOWN("unkonwn", "unkonwn");

    private String value;
    private String riskVerifyStatusDesc;

    RiskVerifyStatus(String value, String riskVerifyStatusDesc) {
        this.value = value;
        this.riskVerifyStatusDesc = riskVerifyStatusDesc;
    }

    public static RiskVerifyStatus getRiskVerifyStatus(String value){
        if("0".equals(value)){
            return RiskVerifyStatus.NO_VERIFIED;
        }
        else if("1".equals(value)){
            return RiskVerifyStatus.CONSERVATIVE;
        }
        else if("2".equals(value)){
            return RiskVerifyStatus.ROBUST_TYPE;
        }
        else if("3".equals(value)){
            return RiskVerifyStatus.BALANCE_TYPE;
        }
        else if("4".equals(value)){
            return RiskVerifyStatus.UP_TYPE;
        }
        else if("5".equals(value)){
            return RiskVerifyStatus.ENTERPRISING_TYPE;
        }
        else{
            return RiskVerifyStatus.UNKNOWN;
        }
    }

    public String getValue() {
        return value;
    }

    public String getRiskVerifyStatusDesc() {
        return riskVerifyStatusDesc;
    }
}
