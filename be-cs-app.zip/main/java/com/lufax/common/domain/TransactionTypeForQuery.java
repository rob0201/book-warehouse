package com.lufax.common.domain;

import com.lufax.common.web.helper.ConstantsHelper;

import java.util.List;

import static java.util.Arrays.asList;

public enum TransactionTypeForQuery {
	ALL(ConstantsHelper.ALL_TRANSACTION_TYPE_VALUE, null),
    RECHARGE(TransactionType.RECHARGE.getValue(), asList(TransactionType.RECHARGE)),
    WITHDRAWALS(TransactionType.WITHDRAWALS.getValue(), asList(TransactionType.WITHDRAWALS)),
    RECHARGE_FEE(TransactionType.EXPENSE_RECHARGE_FEE.getValue(), asList(TransactionType.EXPENSE_RECHARGE_FEE, TransactionType.INCOME_RECHARGE_FEE)),
    WITHDRAWALS_FEE(TransactionType.EXPENSE_WITHDRAWALS_FEE.getValue(), asList(TransactionType.INCOME_WITHDRAWALS_FEE, TransactionType.EXPENSE_WITHDRAWALS_FEE)),
    FROZEN_FUND(TransactionType.FROZEN_FUND.getValue(), asList(TransactionType.FROZEN_FUND, TransactionType.FROZEN_FUND_LOANREQUEST, TransactionType.FROZEN_FUND_WITHDRAW)),
    UNFROZEN_FUND(TransactionType.UNFROZEN_FUND.getValue(), asList(TransactionType.UNFROZEN_FUND, TransactionType.UNFROZEN_FUND_CMSWITHDRAW, TransactionType.UNFROZEN_FUND_INVESTMENT)),
    INVESTMENT(TransactionType.INVESTMENT.getValue(), asList(TransactionType.INVESTMENT)),
    LOAN(TransactionType.LOAN.getValue(), asList(TransactionType.LOAN)),
    PRINCIPAL_REPAYMENT(TransactionType.PRINCIPAL_REPAYMENT.getValue(), asList(TransactionType.PRINCIPAL_REPAYMENT)),
    INTEREST_REPAYMENT(TransactionType.INTEREST_REPAYMENT.getValue(), asList(TransactionType.INTEREST_REPAYMENT)),
    PRINCIPAL_COLLECTION(TransactionType.PRINCIPAL_COLLECTION.getValue(), asList(TransactionType.PRINCIPAL_COLLECTION)),
    INTEREST_COLLECTION(TransactionType.INTEREST_COLLECTION.getValue(), asList(TransactionType.INTEREST_COLLECTION)),
    INSURANCE_FEE(TransactionType.INSURANCE_FEE_COLLECTION.getValue(), asList(TransactionType.INSURANCE_FEE_COLLECTION, TransactionType.INSURANCE_FEE_REPAYMENT)),
    MANAGEMENT_FEE(TransactionType.MANAGEMENT_FEE_COLLECTION.getValue(), asList(TransactionType.MANAGEMENT_FEE_COLLECTION, TransactionType.MANAGEMENT_FEE_REPAYMENT, TransactionType.MANAGEMENT_FEE_COLLECTION_LOANEE, TransactionType.MANAGEMENT_FEE_COLLECTION_LOANER)),
    INVESTMENT_TRANSACTION_FEE(TransactionType.INVESTMENT_TRANSACTION_FEE_COLLECTION.getValue(), asList(TransactionType.INVESTMENT_TRANSACTION_FEE_COLLECTION, TransactionType.INVESTMENT_TRANSACTION_FEE_REPAYMENT)),
    PENAL(TransactionType.PENAL_COLLECTION.getValue(), asList(TransactionType.PENAL_COLLECTION, TransactionType.PENAL_REPAYMENT, TransactionType.PENAL_COLLECTION_LOANER, TransactionType.PENAL_COLLECTION_P2P, TransactionType.PENAL_COLLECTION_XINBAO, TransactionType.PENAL_REPAYMENT_LOANER, TransactionType.PENAL_REPAYMENT_P2P, TransactionType.PENAL_REPAYMENT_XINBAO)),
    RE_OVERDUE_PENAL(TransactionType.RE_OVERDUE_PENALTY.getValue(), asList(TransactionType.RE_OVERDUE_PENALTY)),
    CO_OVERDUE_PENAL(TransactionType.CO_OVERDUE_PENALTY.getValue(), asList(TransactionType.CO_OVERDUE_PENALTY)),
    TRANSACTION_FEE(ConstantsHelper.TRANSACTION_FEE_TRANSACTION_TYPE_VALUE, asList(TransactionType.INCOME_TRANSACTION_FEE, TransactionType.EXPENSE_TRANSACTION_FEE)),
    WITHDRAW_RETURN_TICKET(TransactionType.WITHDRAW_RETURN_TICKET.getValue(), asList(TransactionType.WITHDRAW_RETURN_TICKET)),

    //RECHARGE_FOR_COMPENSATE(TransactionType.RECHARGE_FOR_COMPENSATE.getValue(), asList(TransactionType.RECHARGE_FOR_COMPENSATE)),
    PRINCIPAL_COLLECTION_COMPENSATE(TransactionType.PRINCIPAL_COLLECTION_COMPENSATE.getValue(), asList(TransactionType.PRINCIPAL_COLLECTION_COMPENSATE)),
    INTEREST_COLLECTION_COMPENSATE(TransactionType.INTEREST_COLLECTION_COMPENSATE.getValue(), asList(TransactionType.INTEREST_COLLECTION_COMPENSATE)),
    OVERDUE_PENALTY_COLLECTION_COMPENSATE(TransactionType.OVERDUE_PENALTY_COLLECTION_COMPENSATE.getValue(), asList(TransactionType.OVERDUE_PENALTY_COLLECTION_COMPENSATE)),
    //PRINCIPAL_REPAYMENT_COMPENSATE(TransactionType.PRINCIPAL_REPAYMENT_COMPENSATE.getValue(), asList(TransactionType.PRINCIPAL_REPAYMENT_COMPENSATE)),
    //INTEREST_REPAYMENT_COMPENSATE(TransactionType.INTEREST_REPAYMENT_COMPENSATE.getValue(), asList(TransactionType.INTEREST_REPAYMENT_COMPENSATE)),
    //OVERDUE_PENALTY_REPAYMENT_COMPENSATE(TransactionType.OVERDUE_PENALTY_REPAYMENT_COMPENSATE.getValue(), asList(TransactionType.OVERDUE_PENALTY_REPAYMENT_COMPENSATE)),

    SUBROGATION_REPAYMENT(TransactionType.SUBROGATION_REPAYMENT.getValue(), asList(TransactionType.SUBROGATION_REPAYMENT)),
    SUBROGATION_COLLECTION(TransactionType.SUBROGATION_COLLECTION.getValue(), asList(TransactionType.SUBROGATION_COLLECTION)),

    PROFIT_TRANSFERED_IN(TransactionType.PROFIT_TRANSFERED_IN.getValue(), asList(TransactionType.PROFIT_TRANSFERED_IN)),
    PROFIT_TRANSFERED_OUT(TransactionType.PROFIT_TRANSFERED_OUT.getValue(), asList(TransactionType.PROFIT_TRANSFERED_OUT)),
    MARGINS_IN(TransactionType.MARGINS_IN.getValue(), asList(TransactionType.MARGINS_IN)),
    MARGINS_OUT(TransactionType.MARGINS_OUT.getValue(), asList(TransactionType.MARGINS_OUT)),
    MARGINS_MAG_PENAL_BOND_IN(TransactionType.MARGINS_MAG_PENAL_BOND_IN.getValue(), asList(TransactionType.MARGINS_MAG_PENAL_BOND_IN)),
    MARGINS_MAG_PENAL_BOND_OUT(TransactionType.MARGINS_MAG_PENAL_BOND_OUT.getValue(), asList(TransactionType.MARGINS_MAG_PENAL_BOND_OUT)),
    MARGINS_MAG_PENAL_BOND_PENALTY_IN(TransactionType.MARGINS_MAG_PENAL_BOND_PENALTY_IN.getValue(), asList(TransactionType.MARGINS_MAG_PENAL_BOND_PENALTY_IN)),
    MARGINS_MAG_PENAL_BOND_PENALTY_OUT(TransactionType.MARGINS_MAG_PENAL_BOND_PENALTY_OUT.getValue(), asList(TransactionType.MARGINS_MAG_PENAL_BOND_PENALTY_OUT)),
    SHOT_OVER_IN(TransactionType.SHOT_OVER_IN.getValue(), asList(TransactionType.SHOT_OVER_IN)),
    SHOT_OVER_OUT(TransactionType.SHOT_OVER_OUT.getValue(), asList(TransactionType.SHOT_OVER_OUT)),
    SHOT_OVER_REPAY_OUT(TransactionType.SHOT_OVER_REPAY_OUT.getValue(), asList(TransactionType.SHOT_OVER_REPAY_OUT)),

    TRANSFER_FEE(TransactionType.EXPENSE_TRANSFER_FEE.getValue(), asList(TransactionType.EXPENSE_TRANSFER_FEE,TransactionType.INCOME_TRANSFER_FEE)),
    INVESTMENT_TRANSFER(TransactionType.INVESTMENT_TRANSFER.getValue(),asList(TransactionType.INVESTMENT_TRANSFER)),
    EXCEPTION_RETURN(TransactionType.EXPENSE_EXCEPTION_RETURN.getValue(),asList(TransactionType.EXPENSE_EXCEPTION_RETURN,TransactionType.INCOME_EXCEPTION_RETURN));

    private String value;

    private List<TransactionType> transactionTypes;

    TransactionTypeForQuery(String value, List<TransactionType> transactionTypes) {
        this.value = value;
        this.transactionTypes = transactionTypes;
    }

    public String getValue() {
        return value;
    }

    public List<TransactionType> getTransactionTypes() {
        return transactionTypes;
    }
}
