package com.lufax.common.domain;

import com.lufax.common.domain.account.Money;

import java.math.BigDecimal;
import java.util.Date;

public interface InsurancePolicyDescription {
    String getPolicyNo();

    Money getAppliedAmount();

    int getNumberOfInstalments();

    UserIdentity getApplicant();

    String getFullDescription();

    Money getInsuranceTotalAmount();

    Date getInsuranceStartDate();

    Date getInsuranceEndDate();

    BigDecimal getInsuranceRate();

    Date getPayStartDate();

    Money getInsuranceValuePerMonth();

    String getLoanPurpose();

    String getMobileNo();

    String getBankAccount();

    String getSubBankCode();

    String getBankCode();
}
