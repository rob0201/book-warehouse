package com.lufax.common.domain;

import javax.persistence.*;
import java.util.Date;

import static com.lufax.common.web.helper.ConstantsHelper.CMS_USER_NAME;

@Entity
@Table(name = "TBANK")
public class TBank {
    @Id
    @Column(name = "BANKID")
    private String subBankCode;

    @Column(name = "NAME")
    private String subBankCodeName;

    @Column(name = "BANKCODE")
    private String bankCode;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "STATE")
    private Province province;

    @Column(name = "CREATED_BY")
    private String createdBy;

    @Column(name = "CREATED_DATE")
    private Date createdDate;

    @Column(name = "UPDATED_BY")
    private String updatedBy;

    @Column(name = "UPDATED_DATE")
    private Date updatedDate;

    @Column(name = "IS_AVAILABLE")
    private String isAvailable;

    public TBank() {
    }

    public TBank(String subBankCode, String subBankCodeName, String bankCode, Province province, String isAvailable) {
        this.subBankCode = subBankCode;
        this.subBankCodeName = subBankCodeName;
        this.bankCode = bankCode;
        this.province = province;
        this.isAvailable = isAvailable;
        this.createdBy = CMS_USER_NAME;
        this.createdDate = new Date();
        this.updatedBy = CMS_USER_NAME;
        this.updatedDate = new Date();
    }

    public String getSubBankCode() {
        return subBankCode;
    }

    public String getSubBankCodeName() {
        return subBankCodeName;
    }

    public String getBankCode() {
        return bankCode;
    }
}
