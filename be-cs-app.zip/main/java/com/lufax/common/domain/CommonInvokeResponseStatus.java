package com.lufax.common.domain;

public enum CommonInvokeResponseStatus {
	
	RETCODE_SUCCESS("000","成功"),
	RETCODE_WRONG_PARAM("001","参数有误或缺失"),
	RETCODE_LESS_AVAIL_BAL("002","账户可用余额不足"),
	RETCODE_WRONG_PWD("003","密码错误"),
	RETCODE_FROZEN_ACCT("004","账户被冻结"),
	RETCODE_REPEATED_CMD("005","重复指令操作"),
	RETCODE_INVALID_USER("006","无效用户"),
	RETCODE_ACCOUNT_EXCEPTION("007","帐户异常"),
	RETCODE_EXCESSIVE_TRANS("008","批量交易笔数超过最大允许值"),
	RETCODE_EXCEPTION("009","程序异常"),
	RETCODE_INVALID_OPERATION("0010","程序异常"),
	RETCODE_BTRANS_PARTLY_SUCCESS("101","批量操作部分成功部分失败"),
	RETCODE_BTRANS_ALL_FAIL("102","批量操作全部失败");
	
	private String retCode;
	private String value;
	
	private CommonInvokeResponseStatus(String retCode,String value){
		this.retCode = retCode;
		this.value = value;
	}
	
	public String getRetCode() {
		return retCode;
	}
	
	public String getValue() {
		return value;
	}
	
	public static String getValue(String retCode){
		CommonInvokeResponseStatus[] responseStatus = CommonInvokeResponseStatus.values();
		for(int i=0;i<responseStatus.length;i++){
			if(responseStatus[i].getRetCode().equals(retCode)){
				return responseStatus[i].getValue();
			}
		}
		return null;
	}	
	
	public static CommonInvokeResponseStatus convert(String retCode){
		CommonInvokeResponseStatus[] responseStatus = CommonInvokeResponseStatus.values();
		for(int i=0;i<responseStatus.length;i++){
			if(responseStatus[i].getRetCode().equals(retCode)){
				return responseStatus[i];
			}
		}
		return null;
	}
    public boolean isSuccess() {
        return this.equals(RETCODE_SUCCESS);
    }
}
