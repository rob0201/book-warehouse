package com.lufax.common.domain;

import static com.lufax.common.utils.DateUtils.startOfDay;
import static java.util.Arrays.asList;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.OrderBy;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.persistence.Version;

import org.joda.time.DateTime;

import com.lufax.common.domain.account.Money;
import com.lufax.common.domain.product.Product;
import com.lufax.common.domain.product.TransferRequest;
import com.lufax.common.domain.product.TransferRequestData;
import com.lufax.common.domain.product.TransferRequestStatus;
import com.lufax.common.utils.DateUtils;
import com.lufax.common.utils.StringUtils;

@Entity
@Table(name = "INVESTMENTS")
public class Investment {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_INVESTMENTS")
    @SequenceGenerator(name = "SEQ_INVESTMENTS", sequenceName = "SEQ_INVESTMENTS", allocationSize = 1)
    private long id;

    
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "INVESTMENT_REQUEST_ID")
    private InvestmentRequest investmentRequest;
    
//    @Enumerated(EnumType.STRING)
    @Column(name = "TRANSFER_REQUEST_STATUS")
    private String transferRequestStatus;

    @Column(name = "INVEST_MGMT_FEE_RATE")
    protected BigDecimal investMgmtFeeRate;

    @Column(name = "INVEST_TRANS_FEE_RATE")
    protected BigDecimal investTransFeeRate;

    @Embedded
    @AttributeOverrides({@AttributeOverride(name = "amount", column = @Column(name = "PRINCIPAL"))})
    private Money principal;

    //    @Enumerated(EnumType.STRING)
    @Column(name = "STATUS")
    private String status;
    
    @Column(name = "LENGTH_OF_PERIODS")
    private int lengthOfPeriods;

    @Column(name = "LOANEE_USERNAME")
    private String loaneeUsername;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "LOAN_ID")
    private Loan loan;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "LOANER_ID")
    private User loaner;

    @Transient
    private BigDecimal manageFeeRate;

    @OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    @JoinColumn(name = "INVESTMENT_ID")
    private List<CollectionPlan> collectionPlans;

    @Version
    private long version;

    @Column(name = "created_at")
    private Date createdAt;

    @Column(name = "updated_at")
    private Date updatedAt;
    
    /////////////////////
    @OneToMany(fetch = FetchType.LAZY, mappedBy = "investment")
    @OrderBy("id ASC")
    private List<TransferRequest> transferRequests;
    
    public Investment() {
    }

    public Investment(User loaner, Loan loan, InvestmentRequest investmentRequest, Money principal, TradingStatus status, BigDecimal managementFeeRate) {
        this.loan = loan;
        this.investmentRequest = investmentRequest;
        this.principal = principal;
        this.status = (status != null) ? status.name() : null;
        this.loaner = loaner;
        this.manageFeeRate = managementFeeRate;
        this.collectionPlans = createCollectionPlans();
        this.loaneeUsername = loan.getLoanee().getUsername();
    }


    private Date collectionPlanEndAt(int planNumber) {
        return loan.getRepaymentPlan(planNumber).getEndAt();
    }

    private CollectionPlan lastInstalmentCollectionPlan(int countOfInstalments, BigDecimal annualInterestRate, Money monthlyManagementFee) {
        PaymentMethodFactory paymentMethod = loan.getPaymentMethodFactory();
        Money lastMonthIncome = paymentMethod.getLastMonthIncomeToLoaner(principal, countOfInstalments);
        Money lastMonthPrincipal = paymentMethod.getLastMonthPrincipalToLoaner(principal, countOfInstalments);
        Money lastMonthInterest = paymentMethod.getLastMonthInterestToLoaner(principal, countOfInstalments);
        Date lastMonthEndAt = collectionPlanEndAt(countOfInstalments);

        return new CollectionPlan(countOfInstalments, lastMonthIncome, lastMonthPrincipal, lastMonthInterest, PlanStatus.UNPAID, lastMonthEndAt, this, monthlyManagementFee);
    }

    public long id() {
        return id;
    }

    public List<CollectionPlan> getCollectionPlans() {
        return collectionPlans;
    }

    public Date getStartAt() {
        return loan.getStartAt();
    }

    public User getLoanee() {
        return loan.getLoanee();
    }

    public Loan getLoan() {
        return loan;
    }

    public String getLoanCode() {
        return loan.getCode();
    }

    public Money getPrincipal() {
        return principal;
    }

    public int getNumberOfInstalments() {
        return this.lengthOfPeriods;
    }

    public CollectionPlan getCollectionPlan(int planNumber) {
        for (CollectionPlan collectionPlan : collectionPlans) {
            if (collectionPlan.getPlanNumber() == planNumber) {
                return collectionPlan;
            }
        }
        return null;
    }

    public CollectionPlan getLastCollectionPlan() {
        return getCollectionPlan(getNumberOfInstalments());
    }

    public int getRemainingInstalments() {
        return getRealNumberOfInstalments() - getSettledInstalments();
    }


    private boolean isSettled() {
        return TradingStatus.getTradingStatusByName(status).isSettled();
    }

    public boolean isOverdue() {
        return TradingStatus.OVERDUE.equals(TradingStatus.getTradingStatusByName(status));
    }

    public boolean isCompensate() {
        return TradingStatus.COMPENSATE.equals(TradingStatus.getTradingStatusByName(status));
    }

    private CollectionPlan getCurrentCollectionPlan() {
        DateTime now = new DateTime(new Date());
        for (CollectionPlan collectionPlan : collectionPlans) {
            if (collectionPlan.isInCollectionPlan(now)) {
                return collectionPlan;
            }
        }
        return null;
    }

    public void sortCollectionPlans() {
        Collections.sort(this.collectionPlans, new Comparator<CollectionPlan>() {
            public int compare(CollectionPlan collectionPlan1, CollectionPlan collectionPlan2) {
                return collectionPlan1.getPlanNumber() - collectionPlan2.getPlanNumber();
            }
        });
    }
    
    public void setCollectionPlans(List<CollectionPlan> collectionPlans) {
		this.collectionPlans = collectionPlans;
	}

	public BigDecimal getAnnualInterestRate() {
        return loan.getAnnualInterestRate();
    }

    public int getOverdueBufferDays() {
        return loan.getOverdueBufferDays();
    }

    public TradingStatus getStatus() {
        return TradingStatus.getTradingStatusByName(status);
    }

    public void setStatus(TradingStatus status) {
        this.status = (status != null) ? status.name() : null;
    }
    
    public CollectionPlan getNextUnsettledCollectionPlan() {
        return getCollectionPlan(getSettledInstalments() + 1);
    }

    public Product getProduct() {
        return getInvestmentRequest().getProduct();
    }
    
    public List<CollectionRecord> getCollectionRecords() {
        List<CollectionRecord> collectionRecords = new ArrayList<CollectionRecord>();
        for (CollectionPlan collectionPlan : collectionPlans) {
            if (collectionPlan.isSettled()) {
                collectionRecords.addAll(collectionPlan.getRecords());
            }
        }

        return collectionRecords;
    }

    public int getCurrentPlanNumber() {
        if (isSettled()) {
            return 0;
        }

        CollectionPlan currentCollectionPlan = getCurrentCollectionPlan();
        if (currentCollectionPlan == null) {
            if (new DateTime(startOfDay(loan.getLastRepayDate())).isBeforeNow()) {
                return loan.getNumberOfInstalments();
            }

            return 0;
        }
        return currentCollectionPlan.getPlanNumber();
    }
    

    public List<CollectionRecord> getSettledCollectionRecords() {
        List<CollectionRecord> collectionRecords = new ArrayList<CollectionRecord>();
        for (CollectionPlan collectionPlan : collectionPlans) {
            collectionRecords.addAll(collectionPlan.getSettledRecords());
        }
        return collectionRecords;
    }
    
	public Money getIncomeBeforeTransferred() {
        Money collectedAmount = Money.ZERO_YUAN;
        for (CollectionRecord collectionRecord : getSettledCollectionRecords()) {
            collectedAmount = collectedAmount.add(collectionRecord.getAmount());
        }
        return collectedAmount.subtract(getPaidInvestmentManagementFee()).subtract(getPaidInvestmentTransactionFee());
    }
	
	public Money getPaidInvestmentManagementFee() {
        Money paidInvestmentManagementFee = Money.ZERO_YUAN;
        List<CollectionRecord> collectionRecords = getSettledCollectionRecords();
        for (CollectionRecord collectionRecord : collectionRecords) {
            paidInvestmentManagementFee = paidInvestmentManagementFee.add(collectionRecord.getInvestmentManagementFee());
        }
        return paidInvestmentManagementFee;
    }

    public Money getPaidInvestmentTransactionFee() {
        Money paidInvestmentTransactionFee = Money.ZERO_YUAN;
        List<CollectionRecord> collectionRecords = getSettledCollectionRecords();
        for (CollectionRecord collectionRecord : collectionRecords) {
            paidInvestmentTransactionFee = paidInvestmentTransactionFee.add(collectionRecord.getInvestmentTransactionFee());
        }
        return paidInvestmentTransactionFee;
    }


	public Date getUpdatedAt() {
		return updatedAt;
	}
	
	public TransferRequestStatus getTransferRequestStatus() {
        return null == transferRequestStatus ? TransferRequestStatus.NON_TRANSFERABLE : TransferRequestStatus.getTransferRequestStatusByName(transferRequestStatus);
    }
	public boolean isCompensateDone() {
        return TradingStatus.COMP_DONE.name().equals(status);
    }
	
	public boolean isTransferred() {
        return TradingStatus.TRANSFER.equals(status);
    }
	
	public Money getAllCollectedTotalNetAmount() {
        Money allTotalNetAmount = Money.ZERO_YUAN;
        for (CollectionRecord collectionRecord : getSettledCollectionRecords()) {
            allTotalNetAmount = allTotalNetAmount.add(collectionRecord.getNetAmount());
        }
        return allTotalNetAmount;
    }
	
	public Money getTransferPriceDeductTransferFee() {
        if (!isTransferred()) {
            return Money.ZERO_YUAN;
        }
        TransferRequest latestTransferRequest = getLatestTransferRequest();
        if (null != latestTransferRequest && latestTransferRequest.isTransferSuccess()) {
            TransferRequestData transferRequestOfApplied = getTransferRequestOfApplied(latestTransferRequest.getCode());
            if (null != transferRequestOfApplied) {
                return transferRequestOfApplied.getTransferPrice().subtract(transferRequestOfApplied.getTransferFee());
            }
        }
        return Money.ZERO_YUAN;
    }
	
	public TransferRequestData getTransferRequestOfApplied(String transferRequestCode) {
        if (StringUtils.isBlank(transferRequestCode)) return null;
        for (TransferRequest transferRequest : transferRequests) {
            if (transferRequestCode.equals(transferRequest.getCode()) && transferRequest.isTransferApplied()) {
                return transferRequest.getTransferRequestData();
            }
        }
        return null;
    }
	
	public void setTransferRequests(List<TransferRequest> transferRequests) {
        this.transferRequests = transferRequests;
    }

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public BigDecimal getInvestMgmtFeeRate() {
		return investMgmtFeeRate;
	}

	public void setInvestMgmtFeeRate(BigDecimal investMgmtFeeRate) {
		this.investMgmtFeeRate = investMgmtFeeRate;
	}

	public BigDecimal getInvestTransFeeRate() {
		return investTransFeeRate;
	}

	public void setInvestTransFeeRate(BigDecimal investTransFeeRate) {
		this.investTransFeeRate = investTransFeeRate;
	}

	public BigDecimal getManageFeeRate() {
		return manageFeeRate;
	}

	public void setManageFeeRate(BigDecimal manageFeeRate) {
		this.manageFeeRate = manageFeeRate;
	}

	public long getVersion() {
		return version;
	}

	public void setVersion(long version) {
		this.version = version;
	}

	public void setInvestmentRequest(InvestmentRequest investmentRequest) {
		this.investmentRequest = investmentRequest;
	}

	public void setTransferRequestStatus(String transferRequestStatus) {
		this.transferRequestStatus = transferRequestStatus;
	}

	public void setPrincipal(Money principal) {
		this.principal = principal;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public void setLoaneeUsername(String loaneeUsername) {
		this.loaneeUsername = loaneeUsername;
	}

	public void setLoan(Loan loan) {
		this.loan = loan;
	}

	public void setLoaner(User loaner) {
		this.loaner = loaner;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}
	
	private List<CollectionPlan> createCollectionPlans() {
        PaymentMethodFactory paymentMethod = loan.getPaymentMethodFactory();
        List<CollectionPlan> collectionPlans = new ArrayList<CollectionPlan>();

        int countOfInstalments = getNumberOfInstalments();
        BigDecimal annualInterestRate = loan.getAnnualInterestRate();
        Money monthlyIncome = paymentMethod.getMonthlyIncomeToLoaner(principal);
        Money monthlyManagementFee = Money.ZERO_YUAN;//paymentMethod.getMonthlyManagementFee(manageFeeRate, principal);

        for (int planNumber = 1; planNumber < countOfInstalments; planNumber++) {
            Date endAt = collectionPlanEndAt(planNumber);
            Money instalmentPrincipal = paymentMethod.getMonthlyPrincipalForGivenInstalment(planNumber, principal);
            Money instalmentInterest = paymentMethod.getMonthlyInterestForGivenInstalment(planNumber, principal);

            collectionPlans.add(new CollectionPlan(planNumber, monthlyIncome, instalmentPrincipal, instalmentInterest, PlanStatus.UNPAID, endAt, this, monthlyManagementFee));
        }

        collectionPlans.add(lastInstalmentCollectionPlan(countOfInstalments, annualInterestRate, monthlyManagementFee));

        return collectionPlans;
    }

	private List<CollectionPlan> copyCollectionPlans(List<CollectionPlan> originalCollectionPlans) {
        List<CollectionPlan> copiedCollectionPlanList = new ArrayList<CollectionPlan>();
        for (CollectionPlan collectionPlan : originalCollectionPlans) {
            copiedCollectionPlanList.add(new CollectionPlan(
                    collectionPlan.planNumber,
                    collectionPlan.amount,
                    collectionPlan.principal,
                    collectionPlan.interest,
                    PlanStatus.getPlanStatusByName(collectionPlan.status),
                    collectionPlan.endAt,
                    this,
                    collectionPlan.managementFee,
                    collectionPlan.overduePenalty,
                    collectionPlan.overduePenaltyToProceed,
                    collectionPlan.interestRate));
        }
        return copiedCollectionPlanList;
    }


    public User getLoaner() {
        return loaner;
    }

    public int getRealNumberOfInstalments() {
    	return getNumberOfInstalments();
    }

    public int getPlanNumberOffset() {
        return collectionPlans.get(0).getPlanNumber() - 1;
    }

    protected int getRealPlanNumber(int planNumberForDisplay) {
        return planNumberForDisplay + getPlanNumberOffset();
    }


    public CollectionPlan getCollectionPlanByDisplayPlanNumber(int planNumberForDisplay) {
        int realPlanNumber = getRealPlanNumber(planNumberForDisplay);
        for (CollectionPlan collectionPlan : collectionPlans) {
            if (collectionPlan.getPlanNumber() == realPlanNumber) {
                return collectionPlan;
            }
        }
        return null;
    }

    public Date getCurrentCollectionPlanStartAt() {
        return loan.getCurrentRepaymentPlan().getStartAt();
    }

    public Money getAllCollectedTotalAmount() {
        Money allTotalAmount = Money.ZERO_YUAN;
        for (CollectionRecord collectionRecord : getSettledCollectionRecords()) {
            allTotalAmount = allTotalAmount.add(collectionRecord.getAmount());
        }
        return allTotalAmount;
    }

    public Money getAllCollectedInterest() {
        Money allCollectedInterest = Money.ZERO_YUAN;
        for (CollectionRecord collectionRecord : getSettledCollectionRecords()) {
            allCollectedInterest = allCollectedInterest.add(collectionRecord.getInterest());
        }
        return allCollectedInterest;
    }

    public Money getAllCollectedOverduePenalValue() {
        Money allCollectedOverduePenalValue = Money.ZERO_YUAN;
        for (CollectionRecord collectionRecord : getSettledCollectionRecords()) {
            allCollectedOverduePenalValue = allCollectedOverduePenalValue.add(collectionRecord.getOverduePenalValue());
        }
        return allCollectedOverduePenalValue;
    }

    public Money getAllCollectedPrincipal() {
        Money allCollectedPrincipal = Money.ZERO_YUAN;
        for (CollectionRecord collectionRecord : getSettledCollectionRecords()) {
            allCollectedPrincipal = allCollectedPrincipal.add(collectionRecord.getPrincipal());
        }
        return allCollectedPrincipal;
    }

    public Money getPrepaidPenalValue() {
        Money collectedPenalValue = Money.ZERO_YUAN;
        if (!isPrepaid()) return collectedPenalValue;
        for (CollectionRecord collectionRecord : getSettledCollectionRecords()) {
            collectedPenalValue = collectedPenalValue.add(collectionRecord.getPenalValue());
        }
        return collectedPenalValue;
    }

//    public Money getCurrentCollectionPlanInterestTillNow() {
//        BigDecimal daysBetween = new BigDecimal(Days.daysBetween(
//                new DateTime(startOfDay(loan.getRepaymentPlan(getCurrentPlanNumber()).getStartAt())),
//                new DateTime(startOfTomorrow())).getDays());
//        BigDecimal ratio = divide(daysBetween, THIRTY);
//        return getCurrentCollectionPlan().getInterest().multiply(ratio).roundUp();
//    }


    public TransferRequest getLatestTransferRequest() {
        if (null != transferRequests && transferRequests.size() > 0) {
            return transferRequests.get(transferRequests.size() - 1);
        }
        return null;
    }

    private int getSettledInstalments() {
        int numberOfPaidInstalments = 0;
        for (CollectionPlan plan : collectionPlans) {
            if (plan.isSettled()) {
                numberOfPaidInstalments++;
            }
        }
        // check the split 
        if(numberOfPaidInstalments > lengthOfPeriods) {
        	return lengthOfPeriods;
        } else {
        	return numberOfPaidInstalments;
        }
    }

    public boolean isPaid() {
        return TradingStatus.PAID.equals(status);
    }

    public boolean isPrepaid() {
        return TradingStatus.PREPAID.equals(status);
    }


    public BigDecimal getOverdueFloatRate() {
        return loan.getOverdueFloatRate();
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public CollectionPlan getFirstUnsettledCollectionPlan() {
        return getCollectionPlanByDisplayPlanNumber(getSettledInstalments() + 1);
    }


    public InvestmentRequest getInvestmentRequest() {
        return investmentRequest;
    }

    public List<TransferRequest> getTransferRequests() {
        if (transferRequests == null) {
            transferRequests = new ArrayList<TransferRequest>();
        }
        return transferRequests;
    }

    public void addTransferRequest(TransferRequest... transferRequests) {
        getTransferRequests().addAll(asList(transferRequests));
    }

    public String getLoaneeUsername() {
//    	return loaneeUsername;
        return loan.getLoanee().getUsername();
    }

    public Money getRemainingPrincipal() {
        if (isSettled()) {
            return Money.ZERO_YUAN;
        }
        return principal.subtract(getAllCollectedPrincipal());
    }

    public List<CollectionPlan> getUnpaidCollections() {
        List<CollectionPlan> unpaidCollectionPlans = new ArrayList<CollectionPlan>();
        for (CollectionPlan collectionPlan : collectionPlans) {
            if (collectionPlan.isUnpaid()) {
                unpaidCollectionPlans.add(collectionPlan);
            }
        }
        return unpaidCollectionPlans;
    }

    public void setUnpaidCollectionPlanToTransferred() {
        for (CollectionPlan collectionPlan : collectionPlans) {
            if (collectionPlan.isUnpaid()) {
                collectionPlan.setStatus(PlanStatus.TRANSFER);
            }
        }
    }

    public Date getFirstCollectionPlanStartAt() {
        return loan.getRepaymentPlan(getRealPlanNumber(1)).getStartAt();
    }

    public void setTransferRequestStatus(TransferRequestStatus transferRequestStatus) {
        this.updatedAt = new Date();
        this.transferRequestStatus = transferRequestStatus.name();
    }

    public boolean hasProcessingPlan() {
        for (CollectionPlan plan : collectionPlans) {
            if (plan.isProcessing()) {
                return true;
            }
        }
        return false;
    }

    public boolean isTransferApplied() {
        return TransferRequestStatus.TRANSFER_APPLIED.equals(transferRequestStatus);
    }

    public boolean isTransferable() {
        return TransferRequestStatus.TRANSFERABLE.equals(transferRequestStatus);
    }

    public Money getTotalInterest() {
        Money totalInterest = Money.ZERO_YUAN;
        for (CollectionPlan collectionPlan : collectionPlans) {
            totalInterest = totalInterest.add(collectionPlan.getInterest());
        }
        return totalInterest;
    }

    public Money getTotalAmount() {
        Money totalAmount = Money.ZERO_YUAN;
        for (CollectionPlan collectionPlan : collectionPlans) {
            totalAmount = totalAmount.add(collectionPlan.getAmount());
        }
        return totalAmount;
    }

    public Money getRemainingPrincipal(int planNumber) {
        Money remainingPrincipal = Money.ZERO_YUAN;
        if (planNumber == getNumberOfInstalments()) {
            return remainingPrincipal;
        } else {
            for (int i = planNumber + 1; i <= getNumberOfInstalments(); i++) {
                remainingPrincipal = remainingPrincipal.add(getCollectionPlan(i).getPrincipal());
            }
            return remainingPrincipal;
        }
    }

    public Money getRemainingAmount() {
        if (isSettled()) {
            return Money.ZERO_YUAN;
        }

        Money totalRemainingAmount = Money.ZERO_YUAN;
        for (CollectionPlan collectionPlan : collectionPlans) {
            totalRemainingAmount = totalRemainingAmount.add(collectionPlan.getRemainingAmount());
        }
        return totalRemainingAmount;
    }

    public Money getRemainingInterest() {
        if (isSettled()) {
            return Money.ZERO_YUAN;
        }
        Money totalRemainingInterest = Money.ZERO_YUAN;
        for (CollectionPlan collectionPlan : collectionPlans) {
            totalRemainingInterest = totalRemainingInterest.add(collectionPlan.getRemainingInterest());
        }
        return totalRemainingInterest;
    }

    public Money getEstimatedUnchargedInvestMgmtFee() {
        if (isSettled()) {
            return Money.ZERO_YUAN;
        }

        Money unchargedInvestMgmtFee = Money.ZERO_YUAN;
        for (CollectionPlan collectionPlan : collectionPlans) {
            unchargedInvestMgmtFee = unchargedInvestMgmtFee.add(collectionPlan.getEstimatedUnchargedInvestMgmtFee());
        }
        return unchargedInvestMgmtFee;
    }

    public Money getTransferPrice() {
        if (!isTransferred()) {
            return Money.ZERO_YUAN;
        }
        TransferRequest latestTransferRequest = getLatestTransferRequest();
        if (null != latestTransferRequest && latestTransferRequest.isTransferSuccess()) {
            TransferRequestData transferRequestOfApplied = getTransferRequestOfApplied(latestTransferRequest.getCode());
            if (null != transferRequestOfApplied) {
                return transferRequestOfApplied.getTransferPrice();
            }
        }
        return Money.ZERO_YUAN;
    }
    public CollectionPlan getLastHoldingCollectionPlan() {
        return collectionPlans.get(getLengthOfPeriods() - 1);
    }
    public int getLengthOfPeriods() {
        return lengthOfPeriods;
    }
    public String getStartAtForDisplay() {
        if (null == getProduct()) return "";
        if (getProduct().isPrimary()) {
            return DateUtils.formatDate(getLoan().getStartAt());
        } else if (getProduct().isSecondary()) {
            return DateUtils.formatDate(getCreatedAt());
        } else if (getProduct().isSplited()) {
            return DateUtils.formatDate(getFirstCollectionPlanStartAt());
        } else {
            return "";
        }
    }

    public String getEndAtForDisplay() {
        if (isSettled()) {
            if (isPrepaid()) {
                return DateUtils.formatDate(getLoan().getEndedAt());
            } else if (isTransferred()) {
                return DateUtils.formatDate((null == getLatestTransferRequest()) ? new Date() : getLatestTransferRequest().getCreatedAt());
            } else if (isCompensateDone()) {
                return DateUtils.formatDate(getUpdatedAt()); //TODO: temporary use update time as compensate time
            } else {
                if (getProduct().isSplited()) {
                    return DateUtils.formatDate(getLastHoldingCollectionPlan().getEndAt());
                } else {
                    return DateUtils.formatDate(getLoan().getEndedAt());
                }
            }
        } else {
            //actually, in the following situations the date should be the same day
            //to separate into two branch just for readability
            if (getProduct().isSplited()) {
                return DateUtils.formatDate(getLastHoldingCollectionPlan().getEndAt());
            } else {
                return DateUtils.formatDate(getLoan().getScheduledEndAt());
            }
        }
    }
}
