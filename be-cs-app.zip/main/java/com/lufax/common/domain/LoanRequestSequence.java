package com.lufax.common.domain;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "LOAN_REQUEST_SEQUENCE")
public class LoanRequestSequence {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_LOAN_REQUEST_SEQUENCE")
    @SequenceGenerator(name = "SEQ_LOAN_REQUEST_SEQUENCE", sequenceName = "SEQ_LOAN_REQUEST_SEQUENCE", allocationSize = 1)
    private long id;

    @Column(name = "CREATED_AT")
    private Date createdAt;

    public LoanRequestSequence() {
    }

    public LoanRequestSequence(Date createdAt) {
        this.createdAt = createdAt;
    }

    public long id() {
        return this.id;
    }

    public Date getCreatedAt() {
        return createdAt;
    }
}
