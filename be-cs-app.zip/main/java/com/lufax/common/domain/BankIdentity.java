package com.lufax.common.domain;

import com.lufax.common.web.helper.ConstantsHelper;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class BankIdentity {
    @Column(name = "BANK_CODE")
    private String bankCode;

    @Column(name = "BANK_ID")
    private String subBankCode;

    @Column(name = "BRANCH_ID")
    private String branchId;

    // card number
    @Column(name = "BANK_ACCOUNT")
    private String bankAccount;

    @Column(name = "BANK_ACCOUNT_IS_XINBAO")
    private Boolean isXinbao;

    public BankIdentity() {
    }

    public String getBankCode() {
        return bankCode;
    }

    public String getSubBankCode() {
        return subBankCode;
    }

    public String getBranchId() {
        return branchId;
    }

    public String getBankAccount() {
        return bankAccount;
    }

    public boolean isXinbao() {
        return isXinbao.booleanValue();
    }

    public void setBankAccount(String bankAccount) {
        this.bankAccount = bankAccount;
    }

    public Boolean getXinbao() {

        return isXinbao;
    }

    public boolean isPingAnCard() {
        return bankCode.equals(ConstantsHelper.BANK_CODE_PINGAN) || bankCode.equals(ConstantsHelper.BANK_CODE_SHENFAZHAN);
    }

    public BankIdentity(InsurancePolicyDescription policyDescription) {
        this(policyDescription.getBankCode(), policyDescription.getSubBankCode(), policyDescription.getBankAccount(), new Boolean(true));
    }

    public BankIdentity(String bankCode, String subBankCode, String bankAccount, Boolean isXinbao) {
        this.bankCode = bankCode;
        this.subBankCode = subBankCode;
        this.bankAccount = bankAccount;
        this.isXinbao = isXinbao;
    }

    public BankIdentity(String bankCode, String subBankCode, String branchId, String bankAccount, Boolean isXinbao) {
        this.bankCode = bankCode;
        this.subBankCode = subBankCode;
        this.branchId = branchId;
        this.bankAccount = bankAccount;
        this.isXinbao = isXinbao;
    }
}

