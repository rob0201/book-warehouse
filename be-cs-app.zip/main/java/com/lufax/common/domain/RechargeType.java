package com.lufax.common.domain;


import static com.lufax.common.domain.account.Money.rmb;

import java.math.BigDecimal;

import com.lufax.common.domain.account.Money;
import com.lufax.common.utils.TransactionHistoryRemarkHelper;

public enum RechargeType {
    ALIPAY("支付宝") {
        @Override
        public String getRemark(TransactionType transactionType, User user, RepaymentPlan repaymentPlan) {
            if (TransactionType.RECHARGE.equals(transactionType)) {
                return TransactionHistoryRemarkHelper.getRechargeAlipyRemark();
            } else if (TransactionType.INCOME_RECHARGE_FEE.equals(transactionType) || TransactionType.EXPENSE_RECHARGE_FEE.equals(transactionType)) {
                return TransactionHistoryRemarkHelper.getRechargeFeeAlipyRemark();
            }
            return "";
        }

        @Override
        public Money fee(Money amount, Money rechargeFeeThreshold) {
            if (amount.lessThan(rmb("2"))) {
                return rmb("0.01");
            }
            return amount.multiply(new BigDecimal("0.005"));
        }
    },

    CMS("银行卡") {
        @Override
        public Money fee(Money amount, Money rechargeFeeThreshold) {
            if (amount.lessThan(rmb(rechargeFeeThreshold.getAmount()))) {
                return rmb("1");
            }
            return rmb("0");
        }

        @Override
        public String getRemark(TransactionType transactionType, User user, RepaymentPlan repaymentPlan) {
            if (TransactionType.RECHARGE.equals(transactionType)) {
                return user.getBankIdentity().getBankCode();
            } else if (TransactionType.INCOME_RECHARGE_FEE.equals(transactionType) || TransactionType.EXPENSE_RECHARGE_FEE.equals(transactionType)) {
                return user.getBankIdentity().getBankCode();
            }
            return "";
        }
    },

    OFFFLINE("银行转帐") {
        @Override
        public Money fee(Money amount, Money rechargeFeeThreshold) {
            return rmb("0");
        }

        @Override
        public String getRemark(TransactionType transactionType, User user, RepaymentPlan repaymentPlan) {
            return "银行转帐";
        }
    },
    
    /**
     * 人工充值（BE用）
     */
    MANAUL("人工充值") {
        @Override
        public Money fee(Money amount, Money rechargeFeeThreshold) {
            return rmb("0");
        }

        @Override
        public String getRemark(TransactionType transactionType, User user, RepaymentPlan repaymentPlan) {
            return "";
        }
    },
    
    AUTO("银行卡") {
        @Override
        public Money fee(Money amount, Money rechargeFeeThreshold) {
            return rmb("0");
        }

        @Override
        public String getRemark(TransactionType transactionType, User user, RepaymentPlan plan) {
            if (plan != null && plan.getLoan() != null) {
                return TransactionHistoryRemarkHelper.getRechargeAutoRemark(plan.getLoan().getLoanRequestCode());
            }
            return "";
        }
    },

    WITHHOLD("银行卡") {
        @Override
        public Money fee(Money amount, Money rechargeFeeThreshold) {
            return rmb("0");
        }

        @Override
        public String getRemark(TransactionType transactionType, User user, RepaymentPlan plan) {
            if (plan != null && plan.getLoan() != null) {
                return TransactionHistoryRemarkHelper.getRechargeWithHoldRemark(plan.getLoan().getLoanRequestCode());
            }
            return "";
        }
    },



    COMPENSATE("银行卡") {
        @Override
        public Money fee(Money amount, Money rechargeFeeThreshold) {
            return rmb("0");
        }

        @Override
        public String getRemark(TransactionType transactionType, User user, RepaymentPlan repaymentPlan) {
            return TransactionHistoryRemarkHelper.getRechargeCompensateRemark();
        }
    },

    SUBROGATE("银行卡") {
        @Override
        public Money fee(Money amount, Money rechargeFeeThreshold) {
            return rmb("0");
        }

        @Override
        public String getRemark(TransactionType transactionType, User user, RepaymentPlan repaymentPlan) {
            return TransactionHistoryRemarkHelper.getRechargeSubrogationRemark();
        }
    },
    UNKNOWN("unknow"){
        @Override
        public Money fee(Money amount, Money rechargeFeeThreshold) {
            return null;  //To change body of implemented methods use File | Settings | File Templates.
        }

        @Override
        public String getRemark(TransactionType transactionType, User user, RepaymentPlan repaymentPlan) {
            return null;  //To change body of implemented methods use File | Settings | File Templates.
        }
    } ;

    private String value;

    RechargeType(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    public abstract Money fee(Money amount, Money rechargeFeeThreshold);

    public abstract String getRemark(TransactionType transactionType, User user, RepaymentPlan repaymentPlan);

    public boolean isCms() {
        return CMS.equals(this);
    }

    public boolean isAlipay() {
        return ALIPAY.equals(this);
    }

    public static RechargeType getRechargeTypeByType(String type) {
        RechargeType[] rechargeTypes = RechargeType.values();
        for (RechargeType rechargeType : rechargeTypes)
            if (rechargeType.name().equalsIgnoreCase(type))
                return rechargeType;
        return UNKNOWN;
    }
}
