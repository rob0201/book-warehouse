package com.lufax.common.domain;

import com.lufax.common.domain.account.Money;
import org.apache.commons.lang.time.DateUtils;
import org.joda.time.DateTime;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static com.lufax.common.utils.DateUtils.endOfDay;

@Entity
@Table(name = "REPAYMENT_PLANS")
public class RepaymentPlan extends Plan<RepaymentRecord> {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_REPAYMENT_PLANS")
    @SequenceGenerator(name = "SEQ_REPAYMENT_PLANS", sequenceName = "SEQ_REPAYMENT_PLANS", allocationSize = 1)
    private long id;

    @Embedded
    @AttributeOverrides({@AttributeOverride(name = "amount", column = @Column(name = "INSURANCE_FEE"))})
    private Money insuranceFee;

    @OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL, mappedBy = "repaymentPlan")
    @OrderBy("penalDate DESC")
    private List<OverdueRecord> overdueRecords;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "LOAN_ID")
    private Loan loan;

    @Column(name = "STATUS_TO_XINBAO")
    private Boolean statusToXinbao;

    @Version
    private long version;

    public RepaymentPlan() {

    }

    public RepaymentPlan(int planNumber, Money amount, Money principal, Money interest, Money managementFee, Money insuranceFee, Date endAt, Loan loan) {
        super(planNumber, amount, principal, interest, managementFee, endAt);
        this.insuranceFee = insuranceFee;
        this.loan = loan;
    }

    public long id() {
        return id;
    }

    public Money getInsuranceFee() {
        return insuranceFee;
    }

    public Loan getLoan() {
        return loan;
    }

    public Boolean getStatusToXinbao() {
        return statusToXinbao;
    }

    public void setStatusToXinbao(Boolean statusToXinbao) {
        this.statusToXinbao = statusToXinbao;
    }

    public void setStatus(PlanStatus status) {
        this.status = (status != null) ? status.name() : null;
        this.statusToXinbao = null;
    }

    public String toString() {
        return new StringBuilder("Repayment plan: ")
                .append("plan number: ").append(this.planNumber)
                .append("amount: ").append(this.amount)
                .append("principal: ").append(this.principal)
                .append("interest: ").append(this.interest)
                .append("insurance fee: ").append(this.insuranceFee)
                .append("mangement fee: ").append(this.managementFee).toString();
    }

    public Money getContractTotalAmount() {
        return principal.add(interest).add(insuranceFee);
    }

    @Override
    public Money getTotalExcludingOverduePenaltyToProceed() {
        return principal.add(interest).add(insuranceFee).add(managementFee);
    }

    public boolean isInProgress() {
        Date date = new Date();
        return date.after(endDateOfPreviousPlan()) && (date.before(endAt));
    }

    public boolean isInProgress(Date date) {
        return date.after(endDateOfPreviousPlan()) && (date.before(endAt));
    }

    public boolean isNotStarted() {
        return isOngoing() && new DateTime().isBefore(endDateOfPreviousPlan().getTime());
    }

    public Date endDateOfPreviousPlan() {
        if (planNumber > 1) {
            return loan.getRepaymentPlan(planNumber - 1).getEndAt();
        }
        return endOfDay(new DateTime(loan.getStartAt()).minusDays(1).toDate());
    }

    @Override
    public BigDecimal getAnnualInterestRate() {
        return loan.getAnnualInterestRate();
    }

    @Override
    public BigDecimal getOverdueFloatRate() {
        return loan.getOverdueFloatRate();
    }

    @Override
    public int getOverdueBufferDays() {
        return loan.getOverdueBufferDays();
    }

    @Override
    public int getNumberOfInstalments() {
        return loan.getNumberOfInstalments();
    }

    public Money getOverduePenaltyToPay() {
        return getOverduePenaltyToProceed();
    }

    public Money getOverduePenaltyToPay(Date date) {
        return getOverduePenaltyToProceed(date);
    }

    public Money overduePenaltyOfPreviousPlan() {
        return loan.getRepaymentPlan(planNumber - 1).getOverduePenalty();
    }

    public Money overduePenaltyOfPreviousPlan(Date date) {
        return loan.getRepaymentPlan(planNumber - 1).getOverduePenalty(date);
    }

    public Date getStartRecordOverdueDate() {
        if (overdueUpdateDate == null || overdueUpdateDate.before(endAt)) {
            return endAt;
        }

        return overdueUpdateDate;
    }

    public List<RepaymentRecord> getRecordsBelongingTo(RepaymentOperation repaymentOperation) {
        List<RepaymentRecord> result = new ArrayList<RepaymentRecord>();
        for (RepaymentRecord repaymentRecord : repaymentOperation.getRepaymentRecords()) {
            if (containsRecord(repaymentRecord)) {
                result.add(repaymentRecord);
            }
        }
        return result;
    }

    @Override
    protected boolean isTradeOverdue() {
        return loan.isOverdue();
    }

    public boolean isDueToPay() {
        return isUnpaid() && DateUtils.isSameDay(new Date(), endAt);
    }

    public boolean isDueToPay(Date date) {
        return isUnpaid() && DateUtils.isSameDay(date, endAt);
    }

    public boolean shouldUpdateOverdueInfo() {
        if (isOverdue()) {
            return true;
        }

        if (isProcessing() || isSettled()) {
            return false;
        }

        return loan.isOverdue() && (isInProgress() || passEndDate());
    }
    public Date getStartAt() {
        return loan.calculateStartDateForRepaymentPlan(planNumber);
    }
}
