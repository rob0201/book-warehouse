package com.lufax.common.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Version;

import com.lufax.common.domain.product.Product;

@Entity
@Table(name = "INVESTMENT_REQUESTS")
public class InvestmentRequest {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_INVESTMENT_REQUESTS")
    @SequenceGenerator(name = "SEQ_INVESTMENT_REQUESTS", sequenceName = "SEQ_INVESTMENT_REQUESTS", allocationSize = 1)
    private long id;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "PRODUCT_ID")
    private Product product;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "LOANER_USER_ID")
    private User loaner;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "LOAN_REQUEST_ID")
    private LoanRequest loanRequest;

    //    @Enumerated(EnumType.STRING)
    @Column(name = "STATUS")
    private String status;

    @Column(name = "CREATED_AT")
    private Date createdAt;
    
    @Column(name = "UPDATED_AT")
    private Date updatedAt;
    
    @Column(name = "LOAN_CODE")
    private String loanCode;

    @Column(name = "STATUS_TO_XINBAO")
    private String statusToXinbao;

    @Column(name = "FROZEN_CODE")
    private Long frozenCode;

    @Version
    private long version;

    public InvestmentRequest() {

    }

    public InvestmentRequest(User loaner, LoanRequest loanRequest, InvestmentRequestStatus status) {
        this(loaner, loanRequest, status, new Date(), null);
    }

    public InvestmentRequest(User loaner, LoanRequest loanRequest, InvestmentRequestStatus status, Date createdAt, String loanCode) {
        this.loaner = loaner;
        this.loanRequest = loanRequest;
        this.status = (status != null) ? status.name() : null;
        this.createdAt = createdAt;
        this.loanCode = loanCode;
    }

    public InvestmentRequest(User loaner, LoanRequest loanRequest, InvestmentRequestStatus status, Date createdAt, String loanCode, long frozenCode) {
        this(loaner, loanRequest, status, createdAt, loanCode);
        this.frozenCode = frozenCode;
    }

    public long id() {
        return id;
    }

    public User getLoaner() {
        return loaner;
    }

    public LoanRequest getLoanRequest() {
        return loanRequest;
    }

    public InvestmentRequestStatus getStatus() {
        return InvestmentRequestStatus.getInvestmentRequestStatusByName(status);
    }

    public void setStatus(InvestmentRequestStatus status) {
        this.status = (status!=null)?status.name():null;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public String getLoanCode() {
        return loanCode;
    }

    public void setLoanCode(String loanCode) {
        this.loanCode = loanCode;
    }

    public String getStatusToXinbao() {
        return statusToXinbao;
    }

    public Long getFrozenCode() {
        return frozenCode;
    }

    public void setFrozenCode(Long frozenCode) {
        this.frozenCode = frozenCode;
    }

    public void setStatusToXinbao(String statusToXinbao) {
        this.statusToXinbao = statusToXinbao;
    }

	public Product getProduct() {
		return product;
	}
    
}
