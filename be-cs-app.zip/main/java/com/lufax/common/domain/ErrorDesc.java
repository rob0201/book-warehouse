package com.lufax.common.domain;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "ERROR_DESC")
public class ErrorDesc {

    public static final String RETURN_TICKET_ERROR_CODE = "RETURN_TICKET";

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_ERROR_DESC")
    @SequenceGenerator(name = "SEQ_ERROR_DESC", sequenceName = "SEQ_ERROR_DESC", allocationSize = 1)
    @Column(name = "ID")
    private long id;

    @Column(name = "CODE")
    private String code;

    //    @Enumerated(EnumType.STRING)
    @Column(name = "ORIGIN_SYSTEM")
    private String originSystem;

    //    @Enumerated(EnumType.STRING)
    @Column(name = "ERROR_TYPE")
    private String errorType;

    @Column(name = "DESCRIPTION")
    private String description;

    @Column(name = "SHORT_DESC")
    private String shortDesc;

    @Column(name = "CREATED_BY")
    private String createdBy;

    @Column(name = "CREATED_DATE")
    private Date createdDate;


    public ErrorDesc() {
    }

    public ErrorDesc(String code, OriginSystem originSystem, ErrorType errorType, String description, String shortDesc, String createdBy) {
        this.code = code;
        this.originSystem = (originSystem != null) ? originSystem.name() : null;
        this.errorType = (errorType != null) ? errorType.name() : null;
        this.description = description;
        this.shortDesc = shortDesc;
        this.createdBy = createdBy;
        this.createdDate = new Date();
    }

    public long getId() {
        return id;
    }

    public String getCode() {
        return code;
    }

    public OriginSystem getOriginSystem() {
        return OriginSystem.getOriginSystemByName(originSystem);
    }

    public String getDescription() {
        return description;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public String getShortDesc() {
        return shortDesc;
    }
}
