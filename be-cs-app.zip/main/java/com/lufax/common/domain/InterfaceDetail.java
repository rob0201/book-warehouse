package com.lufax.common.domain;


public enum InterfaceDetail {

    CONFIRM_GUARANTEE_COMPENSATION("确认担保代偿", "CONFIRM_GUARANTEE_COMPENSATION");
    private String desc;
    private String interfaceType;

    InterfaceDetail(String desc, String interfaceType) {
        this.desc = desc;
        this.interfaceType = interfaceType;
    }
}
