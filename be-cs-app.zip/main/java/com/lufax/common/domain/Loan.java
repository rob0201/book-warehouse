package com.lufax.common.domain;

import com.lufax.common.domain.account.Money;
import com.lufax.common.exception.P2PException;
import com.lufax.common.utils.DateUtils;
import com.lufax.common.web.helper.ConstantsHelper;
import static com.lufax.common.web.helper.ConstantsHelper.REQUEST_COMPENSATE_DAYS;
import org.joda.time.DateTime;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static com.lufax.common.utils.DateUtils.*;

@Entity
@Table(name = "LOANS")
public class Loan {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_LOANS")
    @SequenceGenerator(name = "SEQ_LOANS", sequenceName = "SEQ_LOANS", allocationSize = 1)
    private long id;

    @Column(name = "CODE")
    private String code;

    @Column(name = "LOAN_REQUEST_CODE")
    private String loanRequestCode;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "LOANEE_USER_ID")
    private User loanee;

    @OneToMany(mappedBy = "loan")
    @OrderBy("createdAt DESC")
    private List<WithdrawRecord> withdrawRecords;

    // Note: a loan only has one investment. Current OneToMany association is just for solving N+1 performance issue.
    @OneToMany(fetch = FetchType.LAZY, mappedBy = "loan")
    private List<Investment> investments;

    @Embedded
    @AttributeOverrides({@AttributeOverride(name = "amount", column = @Column(name = "APPLIED_AMOUNT"))})
    private Money appliedAmount;

    @Column(name = "NUM_OF_INSTALMENTS")
    private int numberOfInstalments;

    @Column(name = "LOAN_PURPOSE")
    private String loanPurpose;

    @Column(name = "INTEREST_RATE")
    private BigDecimal interestRate;

    @Column(name = "MANAGEMENT_FEE_RATE")
    private BigDecimal managementFeeRate;

    @Embedded
    @AttributeOverrides({@AttributeOverride(name = "amount", column = @Column(name = "MONTHLY_INSURANCE_FEE"))})
    private Money monthlyInsuranceFee;

    //    @Enumerated(EnumType.STRING)
    @Column(name = "PAYMENT_METHOD")
    private String paymentMethod;

    //    @Enumerated(EnumType.STRING)
    @Column(name = "status")
    private String status;

    @OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL, mappedBy = "loan")
    @OrderBy("planNumber ASC")
    private List<RepaymentPlan> repaymentPlans;

    @Column(name = "START_AT")
    private Date startAt;

    @Column(name = "CREATED_AT")
    private Date createdAt;

    @Column(name = "ENDED_AT")
    private Date endedAt;

    //    @Enumerated(EnumType.STRING)
    @Column(name = "STATUS_TO_XINBAO")
    private String statusToXinbao;

    @Column(name = "CONTRACT_STATUS_TO_XINBAO")
    private Boolean contractStatusToXinBao;

    @Column(name = "OVERDUE_UPDATE_DATE")
    private Date overdueUpdateDate;

    @Column(name = "OVERDUE_EXTENSION_DAYS")
    private int overdueBufferDays;

    @Column(name = "OVERDUE_FLOAT_RATE")
    private BigDecimal overdueFloatRate;
    @Column(name = "SCHEDULED_END_AT")
    private Date scheduledEndAt;
    @Version
    private long version;
    
    @Column(name = "LOAN_SOURCE_TYPE")
    private int loanSourceType;

    public int getLoanSourceType() {
		return loanSourceType;
	}

	public Loan() {
    }

    public Loan(LoanRequest loanRequest, String code, TradingStatus status, int overdueBufferDays, BigDecimal overdueFloatRate) {
        this(loanRequest, code, status, overdueBufferDays, overdueFloatRate, new Date(), new DateTime().plusDays(ConstantsHelper.START_INTEREST_DELAY).toDate());
    }

    //could not be used for init Loan in production code
    public Loan(LoanRequest loanRequest, String code, TradingStatus status, int overdueBufferDays, BigDecimal overdueFloatRate, Date createdAt, Date startAt) {
        this.code = code;
        this.status = (status != null) ? status.name() : null;
        this.startAt = DateUtils.startOfDay(startAt);
        this.overdueBufferDays = overdueBufferDays;
        this.overdueFloatRate = overdueFloatRate;

        this.loanee = loanRequest.getLoanee();
        this.loanRequestCode = loanRequest.getCode();
        this.appliedAmount = loanRequest.getAppliedAmount();
        this.numberOfInstalments = loanRequest.getNumberOfInstalments();
        this.loanPurpose = loanRequest.getLoanPurpose();
        this.interestRate = loanRequest.getInterestRate();
        this.managementFeeRate = loanRequest.getManagementFeeRate();
        this.monthlyInsuranceFee = loanRequest.getMonthlyInsuranceFee();
        this.paymentMethod = (loanRequest.getPaymentMethod()!=null)?loanRequest.getPaymentMethod().name():null;
        this.createdAt = createdAt;

        repaymentPlans = createRepaymentPlans();
        this.scheduledEndAt = getLastRepaymentPlan().getEndAt();
    }

    private List<RepaymentPlan> createRepaymentPlans() {
        PaymentMethodFactory paymentMethodFactory = getPaymentMethodFactory();
        List<RepaymentPlan> repaymentPlans = new ArrayList<RepaymentPlan>();

        Money monthlyManagementFee = paymentMethodFactory.getMonthlyManagementFee(managementFeeRate, appliedAmount).roundUp();

        for (int index = 1; index < numberOfInstalments; index++) {
            Date endAt = calculateEndDateForRepaymentPlan(index);

            Money instalmentPrincipal = paymentMethodFactory.getMonthlyPrincipalForGivenInstalment(index, appliedAmount).roundUp();
            Money instalmentInterest = paymentMethodFactory.getMonthlyInterestForGivenInstalment(index, appliedAmount).roundUp();
            Money monthlyAmount = instalmentPrincipal.add(instalmentInterest).add(monthlyManagementFee).add(monthlyInsuranceFee);
            repaymentPlans.add(new RepaymentPlan(index, monthlyAmount, instalmentPrincipal, instalmentInterest, monthlyManagementFee, monthlyInsuranceFee, endAt, this));
        }

        Date lastEndAt = calculateEndDateForRepaymentPlan(numberOfInstalments);
        repaymentPlans.add(createLastMonthRepaymentPlan(monthlyManagementFee, numberOfInstalments, lastEndAt, paymentMethodFactory));

        return repaymentPlans;
    }

    public long id() {
        return id;
    }

    public String getCode() {
        return code;
    }

    public TradingStatus getStatus() {
        return TradingStatus.getTradingStatusByName(status);
    }

    public void setStatus(TradingStatus status) {
        this.status = (status!=null)?status.name():null;
    }

    public Date getStartAt() {
        return startAt;
    }

    public Money getMonthlyInsuranceFee() {
        return monthlyInsuranceFee;
    }

    public BigDecimal getManagementFeeRate() {
        return managementFeeRate;
    }

    public List<RepaymentPlan> getRepaymentPlans() {
        return repaymentPlans;
    }

    public PaymentMethodFactory getPaymentMethodFactory() {
        return new PaymentMethodFactory(interestRate, numberOfInstalments);
    }

    public String getLoanRequestCode() {
        return loanRequestCode;
    }

    public User getLoanee() {
        return loanee;
    }

    public RepaymentPlan getRepaymentPlan(int planNumber) {
        if (planNumber < 1 || planNumber > numberOfInstalments) return null;
        for (RepaymentPlan repaymentPlan : repaymentPlans) {
            if (repaymentPlan.getPlanNumber() == planNumber) {
                return repaymentPlan;
            }
        }
        return null;
    }

    public Date calculateStartDateForRepaymentPlan(int planNumber) {
        if (planNumber > 1) {
            return startOfDay(new DateTime(calculateEndDateForRepaymentPlan(planNumber - 1)).plusDays(1).toDate());
        }
        return startAt;
    }

    public RepaymentPlan getLastRepaymentPlan() {
        return getRepaymentPlan(getNumberOfInstalments());
    }

    public Money getPrincipal() {
        return appliedAmount;
    }

    public int getNumberOfInstalments() {
        return numberOfInstalments;
    }

    public BigDecimal getAnnualInterestRate() {
        return interestRate;
    }

    public Date getScheduledEndAt() {
        return scheduledEndAt;
    }

    public Investment getInvestment() {
        if (investments == null) {
            return null;
        }
        return investments.get(0);
    }


    public void setInvestment(Investment investment) {
        if (investments != null) {
            throw new P2PException(String.format("Only one investment allowed for a loan, the loan id is %d", id));
        }
        investments = new ArrayList<Investment>();
        investments.add(investment);
    }

    public int getSettledInstalments() {
        int numberOfPaidInstalments = 0;

        for (RepaymentPlan plan : repaymentPlans) {
            if (plan.isSettled()) {
                numberOfPaidInstalments++;
            }
        }

        return numberOfPaidInstalments;
    }

    public int getRemainingInstalments() {
        return getNumberOfInstalments() - getSettledInstalments();
    }

    private RepaymentPlan createLastMonthRepaymentPlan(Money monthlyManagementFee, int index, Date endAt, PaymentMethodFactory paymentMethodFactory) {
        Money lastMonthAmount = paymentMethodFactory.getLastMonthIncomeToLoaner(appliedAmount, numberOfInstalments).add(monthlyInsuranceFee).add(monthlyManagementFee);
        Money lastMonthPrincipal = paymentMethodFactory.getLastMonthPrincipalToLoaner(appliedAmount, numberOfInstalments);
        Money lastMonthInterest = paymentMethodFactory.getLastMonthInterestToLoaner(appliedAmount, numberOfInstalments);
        Money lastMonthManagementFee = paymentMethodFactory.getMonthlyManagementFee(managementFeeRate, this.appliedAmount);
        return new RepaymentPlan(index, lastMonthAmount, lastMonthPrincipal, lastMonthInterest, lastMonthManagementFee, monthlyInsuranceFee, endAt, this);
    }

    public Date calculateEndDateForRepaymentPlan(int planNumber) {
        DateTime timeOfStartAt = new DateTime(startAt);
        DateTime monthsAfter = timeOfStartAt.plusMonths(planNumber);

        if (isOnSameDayOfMonth(timeOfStartAt, monthsAfter)) {
            return endOfDay(monthsAfter.minusDays(1).toDate());
        }

        return endOfDay(monthsAfter.toDate());
    }

    public RepaymentPlan getCurrentRepaymentPlan() {
        for (RepaymentPlan repaymentPlan : repaymentPlans) {
            if (repaymentPlan.isInProgress()) {
                return repaymentPlan;
            }
        }
        return null;
    }

    public RepaymentPlan getCurrentRepaymentPlan(Date date) {
        for (RepaymentPlan repaymentPlan : repaymentPlans) {
            if (repaymentPlan.isInProgress(date)) {
                return repaymentPlan;
            }
        }
        return null;
    }

    public int getCurrentInstalment() {
        RepaymentPlan currentRepaymentPlan = getCurrentRepaymentPlan();
        return (isSettled() || currentRepaymentPlan == null) ? 0 : currentRepaymentPlan.getPlanNumber();
    }

    public Boolean isAbleToBePrepaid() {
        return getCurrentInstalment() != 0 && getCurrentInstalment() != numberOfInstalments;
    }

    public boolean isSettled() {
        return TradingStatus.getTradingStatusByName(status).isSettled();
    }

    public boolean isOverdue() {
        return TradingStatus.OVERDUE.equals(TradingStatus.getTradingStatusByName(status));
    }

    public boolean isCompensate() {
        return TradingStatus.COMPENSATE.equals(TradingStatus.getTradingStatusByName(status));
    }


    public Money getRemainingAmountByStatus(PlanStatus status) {
        Money money = Money.ZERO_YUAN;
        for (RepaymentPlan plan : repaymentPlans) {
            if (status.equals(plan.getStatus())) {
                money = money.add(new RepaymentDetail(plan).getRemainingAmount());
            }
        }
        return money;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public Date getEndedAt() {
        return endedAt;
    }

    public void setEndedAt(Date endedAt) {
        this.endedAt = endedAt;
    }

    public boolean isLastRepayment(RepaymentPlan repaymentPlan) {
        return repaymentPlan.getPlanNumber() == getNumberOfInstalments();
    }

    public RepaymentPlan getNextUnsettledRepaymentPlan() {
        return getRepaymentPlan(getSettledInstalments() + 1);
    }

    public String getContractCode() {
        return TradeContractType.codeOf(code);
    }

    public LoanToXinbaoStatus getStatusToXinbao() {
        return LoanToXinbaoStatus.getLoanToXinbaoStatusByName(statusToXinbao);
    }

    public void setStatusToXinbao(LoanToXinbaoStatus statusToXinbao) {
        this.statusToXinbao = (statusToXinbao != null) ? statusToXinbao.name() : null;
    }

    public Boolean getContractStatusToXinBao() {
        return contractStatusToXinBao;
    }

    public void setContractStatusToXinBao(Boolean contractStatusToXinBao) {
        this.contractStatusToXinBao = contractStatusToXinBao;
    }

    public List<RepaymentRecord> getRepaymentRecords() {
        List<RepaymentRecord> repaymentRecords = new ArrayList<RepaymentRecord>();
        for (RepaymentPlan repaymentPlan : repaymentPlans) {
            if (!repaymentPlan.isOngoing()) {
                repaymentRecords.addAll(repaymentPlan.getRecords());
            }
        }
        return repaymentRecords;
    }

    public List<RepaymentPlan> getAllOverdueRepaymentPlans() {
        List<RepaymentPlan> overduePlans = new ArrayList<RepaymentPlan>();
        for (RepaymentPlan plan : repaymentPlans) {
            if (plan.isOverdue()) {
                overduePlans.add(plan);
            }
        }
        return overduePlans;
    }

    public List<RepaymentPlan> getAllProcessingRepaymentPlans() {
        List<RepaymentPlan> processingPlans = new ArrayList<RepaymentPlan>();
        for (RepaymentPlan plan : repaymentPlans) {
            if (plan.isProcessing()) {
                processingPlans.add(plan);
            }
        }
        return processingPlans;
    }

    public int getOverdueAndProcessingPlansNum() {
        int num = 0;
        for (RepaymentPlan plan : repaymentPlans) {
            if (plan.isOverdue() || plan.isProcessing()) {
                num++;
            }
        }
        return num;
    }

    public boolean hasProcessingPlan() {
        for (RepaymentPlan plan : repaymentPlans) {
            if (plan.isProcessing()) {
                return true;
            }
        }
        return false;
    }

    public Date getFirstRepayDate() {
        return calculateEndDateForRepaymentPlan(1);
    }

    public Date getLastRepayDate() {
        return calculateEndDateForRepaymentPlan(numberOfInstalments);
    }

    public String getPDFContractName(TradeContractType tradeContractType) {
        return tradeContractType.contractNameOf(this);
    }

    public List<WithdrawRecord> getWithdrawRecords() {
        return withdrawRecords;
    }

    public int getOverdueBufferDays() {
        return overdueBufferDays;
    }

    public Date getOverdueUpdateDate() {
        return overdueUpdateDate;
    }

    public void setOverdueUpdateDate(Date overdueUpdateDate) {
        this.overdueUpdateDate = overdueUpdateDate;
    }

    public BigDecimal getOverdueFloatRate() {
        return overdueFloatRate;
    }

    public List<RepaymentPlan> getPayableRepaymentPlans() {
        List<RepaymentPlan> payablePlans = new ArrayList<RepaymentPlan>();
        payablePlans.addAll(getAllOverdueRepaymentPlans());
        payablePlans.addAll(getAllProcessingRepaymentPlans());

        RepaymentPlan currentRepaymentPlan = getCurrentRepaymentPlan();
        if (currentRepaymentPlan != null && currentRepaymentPlan.isDueToPay()) {
            payablePlans.add(currentRepaymentPlan);
        }
        return payablePlans;
    }

    public List<RepaymentPlan> getPayableRepaymentPlans(Date date) {
        List<RepaymentPlan> payablePlans = new ArrayList<RepaymentPlan>();
        payablePlans.addAll(getAllOverdueRepaymentPlans());
        payablePlans.addAll(getAllProcessingRepaymentPlans());

        RepaymentPlan currentRepaymentPlan = getCurrentRepaymentPlan(date);
        if (currentRepaymentPlan != null && currentRepaymentPlan.isDueToPay(date)) {
            payablePlans.add(currentRepaymentPlan);
        }
        return payablePlans;
    }
    //ECR343
    public boolean passedCompensateDay(Date date) {
        Date compensateDate = getCompensateDateForWillCompensate(REQUEST_COMPENSATE_DAYS);
        return compensateDate == null ? false : date.after(compensateDate);
    }
        public Date getCompensateDateForWillCompensate(int compensateDays) {
        int firstOngoingPlanNumber = getFirstOngoingPlanNumber();
        if (firstOngoingPlanNumber == 0) return null;
        Date endAt = getRepaymentPlan(firstOngoingPlanNumber).getEndAt();
        return new DateTime(endAt).plusDays(compensateDays).toDate();
    }
        public int getFirstOngoingPlanNumber() {
        for (RepaymentPlan repaymentPlan : getRepaymentPlans()) {
            if (repaymentPlan.isOngoing()) {
                return repaymentPlan.getPlanNumber();
            }
        }
        return 0;
    }

    //ECR343 end
}
