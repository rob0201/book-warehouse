package com.lufax.common.domain;

import com.lufax.common.domain.account.Money;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static java.util.Arrays.asList;

@Entity
@Table(name = "REPAYMENT_OPERATIONS")
public class RepaymentOperation {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_REPAYMENTS")
    @SequenceGenerator(name = "SEQ_REPAYMENTS", sequenceName = "SEQ_REPAYMENTS", allocationSize = 1)
    private long id;

    //    @Enumerated(EnumType.STRING)
    @Column(name = "REPAYMENT_TYPE")
    private String repaymentType;

    @JoinColumn(name = "RECHARGE_RECORD_ID")
    @OneToOne(fetch = FetchType.LAZY)
    private RechargeRecord rechargeRecord;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "LOAN_ID")
    private Loan loan;

    @Column(name = "CREATED_AT")
    private Date createdAt;

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "repaymentOperation")
    private List<RepaymentRecord> repaymentRecords;

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "repaymentOperation")
    private List<CollectionRecord> collectionRecords;

    //    @Enumerated(EnumType.STRING)
    @Column(name = "STATUS")
    private String status;

    public RepaymentOperation() {

    }

    public RepaymentOperation(RepaymentType repaymentType, OperationStatus status, RechargeRecord rechargeRecord, Loan loan, Date createdAt) {
        this.repaymentType = (repaymentType != null) ? repaymentType.name() : null;
        this.status = (status != null) ? status.name() : null;
        this.rechargeRecord = rechargeRecord;
        this.loan = loan;
        this.createdAt = createdAt;
    }

    public long id() {
        return this.id;
    }

    public RechargeRecord getRechargeRecord() {
        return rechargeRecord;
    }

    public void addRepaymentRecords(RepaymentRecord... repaymentRecords) {
        getRepaymentRecords().addAll(asList(repaymentRecords));
    }

    public List<RepaymentRecord> getRepaymentRecords() {
        if (repaymentRecords == null) {
            repaymentRecords = new ArrayList<RepaymentRecord>();
        }
        return repaymentRecords;
    }

    public void addCollectionRecords(CollectionRecord... collectionRecords) {
        getCollectionRecords().addAll(asList(collectionRecords));
    }

    public List<CollectionRecord> getCollectionRecords() {
        if (collectionRecords == null) {
            collectionRecords = new ArrayList<CollectionRecord>();
        }
        return collectionRecords;
    }

    public Money getTotalPayAmount() {
        Money total = Money.ZERO_YUAN;
        if (null == repaymentRecords || repaymentRecords.size() == 0) {
            return total;
        }

        for (RepaymentRecord repaymentRecord : repaymentRecords) {
            if (repaymentRecord.isDone() || repaymentRecord.isOngoing()) {
                total = total.add(repaymentRecord.getAmount());
            }
        }
        return total;
    }

    public Money getPaidAmount() {
        Money total = Money.ZERO_YUAN;
        if (null == repaymentRecords || repaymentRecords.size() == 0) {
            return total;
        }
        for (RepaymentRecord repaymentRecord : repaymentRecords) {
            if (repaymentRecord.isDone()) {
                total = total.add(repaymentRecord.getAmount());
            }
        }
        return total;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public Loan getLoan() {
        return loan;
    }

    public OperationStatus getStatus() {
        return OperationStatus.getOperationStatusByName(status);
    }

    public void setRepaymentRecords(List<RepaymentRecord> repaymentRecords) {
        this.repaymentRecords = repaymentRecords;
    }

    public void setStatus(OperationStatus status) {
        this.status = (status != null) ? status.name() : null;
    }

    public RepaymentType getRepaymentType() {
        return RepaymentType.getRepaymentTypeByName(repaymentType);
    }

    public void setRechargeRecord(RechargeRecord rechargeRecord) {
        this.rechargeRecord = rechargeRecord;
    }

    public CollectionRecord getOngoingCollectionRecordFor(RepaymentRecord repaymentRecord) {
        for (CollectionRecord collectionRecord : collectionRecords) {
            if (collectionRecord.isOngoing() && collectionRecord.getRecordNumber() == repaymentRecord.getRecordNumber()) {
                return collectionRecord;
            }
        }
        return null;
    }
}
