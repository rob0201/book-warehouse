package com.lufax.common.domain;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

import javax.persistence.Embeddable;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import java.util.Date;

@Embeddable
public class UserIdentity {
    private String name;

    @Enumerated(EnumType.STRING)
    private Gender gender;

    private Date birthDay;

    private Identity identity;
    
    private UserIdentity() {

    }

    public String getName() {
        return name;
    }

    public Gender getGender() {
        return gender;
    }

    public Date getBirthDay() {
        return birthDay;
    }

    public Identity getIdentity() {
        return identity;
    }

    public UserIdentity(String name, Gender gender, Identity identity, Date birthDay) {
        this.name = name;
        this.gender = gender;
        this.identity = identity;
        this.birthDay = birthDay;
    }

    public UserIdentity(String name){
        this.name = name;
    }

    @Override
    public boolean equals(Object o) {
        return EqualsBuilder.reflectionEquals(this, o);
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(name).append(gender).append(birthDay).append(identity).hashCode();
    }
}

