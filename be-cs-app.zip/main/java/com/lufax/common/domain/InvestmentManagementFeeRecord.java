package com.lufax.common.domain;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.lufax.common.domain.account.Money;

@Entity
@Table(name = "INVEST_MGMT_FEE_RECORDS")
public class InvestmentManagementFeeRecord extends InvestmentFeeRecord {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_INVEST_MGMT_FEE_RECORDS")
    @SequenceGenerator(name = "SEQ_INVEST_MGMT_FEE_RECORDS", sequenceName = "SEQ_INVEST_MGMT_FEE_RECORDS", allocationSize = 1)
    private long id;

    @AttributeOverrides({@AttributeOverride(name = "amount", column = @Column(name = "INVESTMENT_MANAGEMENT_FEE"))})
    private Money investmentManagementFee;


    public InvestmentManagementFeeRecord() {
    }

    public long getId() {
        return id;
    }

    public InvestmentManagementFeeRecord(CollectionRecord collectionRecord, Money investmentManagementFee) {
        super(collectionRecord);
        this.investmentManagementFee = investmentManagementFee;
    }

    public Money getInvestmentManagementFee() {
        return investmentManagementFee;
    }
}

