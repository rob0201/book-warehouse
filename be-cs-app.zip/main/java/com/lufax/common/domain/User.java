package com.lufax.common.domain;

import com.lufax.common.domain.account.Account;
import com.lufax.common.utils.EncryptUtils;
import org.apache.commons.lang.StringUtils;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static com.lufax.common.domain.UserRole.COMMON;


@Entity
@Table(name = "P2PUSERS")
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_USERS")
    @SequenceGenerator(name = "SEQ_USERS", sequenceName = "SEQ_USERS", allocationSize = 1)
    private long id;

    @Column(name = "PARTY_NO")
    private String partyNo;
    private Credential credential;
    private String email;

    @Column(name = "MOBILE_NO")
    private String mobileNo;
    
    private UserIdentity identity;
    private BankIdentity bankIdentity;

    //    @Enumerated(EnumType.STRING)
    @Column(name = "USER_ROLE")
    private String userRole;

    // Currently one user only has one account, to make OneToMany relation is just to avoid n+1 problem of JPA.
    @OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.PERSIST, mappedBy = "user")
    private List<Account> accounts;

    //    @Enumerated(EnumType.STRING)
    @Column(name = "AUTHENTICATION_STATUS")
    private String status;

    @Column(name = "CREATED_AT")
    private Date createdAt;

    @Column(name = "UPDATED_AT")
    private Date updatedAt;

    @OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    @JoinColumn(name = "LOANEE_USER_ID")
    @OrderBy("createdAt DESC")
    private List<LoanRequest> loanRequests;

    @OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    @JoinColumn(name = "LOANER_USER_ID")
    @OrderBy("createdAt DESC")
    private List<InvestmentRequest> investmentRequests;

    @Version
    private Long version;

    @Enumerated(EnumType.STRING)
    @Column(name = "TO_XINBAO_STATUS")
    private XinbaoStatus xinbaoStatus;

    @Column(name = "EMPLOYEE_EMAIL")
    private String employeeEmail;

    @Enumerated(EnumType.STRING)
    @Column(name = "USER_TYPE")
    private UserTypes userType;

    @Column(name = "IS_RARE_WORD")
    private Boolean isRareWord;

    @Column(name = "RECHARGE_NOTICE")
    private Boolean isShowRechargeNotice;

    @Column(name="CARD_BIND_STATUS")
    private String cardBindStatus;

    public User() {
        this(null, null, null, null, COMMON);
    }

    public User(Credential credential, String email, UserIdentity userIdentity) {
        this(credential, null, email, userIdentity, COMMON);
    }

    public User(Credential credential, String moblieNo, String email, UserIdentity identity, UserRole userRole) {
        this(credential, moblieNo, email, identity, userRole, UserStatus.NOT_AUTHENTICATED, null, new Date());
    }

    public User(Credential credential, String moblieNo, String email, UserIdentity identity, UserRole userRole, UserStatus userStatus, BankIdentity bankIdentity, Date createdAt) {
        this.credential = credential;
        this.mobileNo = moblieNo;
        this.email = email;
        this.identity = identity;
        this.userRole = (userRole != null) ? userRole.name() : null;
        this.status = (userStatus != null) ? userStatus.name() : null;
        this.bankIdentity = bankIdentity;
        this.createdAt = createdAt;
        this.updatedAt = createdAt;
        accounts = new ArrayList<Account>();
        accounts.add(new Account(this));
    }

    public String getPartyNo() {
        return partyNo;
    }

    public void setPartyNo(String partyNo) {
        this.partyNo = partyNo;
    }

    public String getMobileNo() {
        return mobileNo;
    }

    public String getEncryptedMobileNo() {
        return EncryptUtils.encryptMobileNumber(mobileNo);
    }

    public void setMobileNo(String mobileNo) {
        this.mobileNo = mobileNo;
    }

    public BankIdentity getBankIdentity() {
        return bankIdentity;
    }

    public void setBankIdentity(BankIdentity bankIdentity) {
        this.bankIdentity = bankIdentity;
    }

    public long id() {
        return id;
    }

    public String getUsername() {
        return ((credential == null || partyNo == null) && COMMON.equals(UserRole.getUserRoleByName(userRole))) ? "匿名" : credential.getUsername();
    }

    public String getUsernameByMarket() {
        return credential.getUsername();
    }

    public String getName() {
        return identity == null ? null : identity.getName();
    }

    public UserIdentity getIdentity() {
        return identity;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setIdentity(UserIdentity identity) {
        this.identity = identity;
    }

    public UserRole getUserRole() {
        return UserRole.getUserRoleByName(userRole);
    }

    public Account getAccount() {
        if (accounts == null || accounts.size() == 0) {
            return null;
        }
        return accounts.get(0);
    }

    public boolean isAdmin() {
        return UserRole.ADMIN.equals(UserRole.getUserRoleByName(userRole));
    }

    public boolean isGuarantor() {
        return UserRole.GUARANTOR.equals(UserRole.getUserRoleByName(userRole));
    }

    public boolean isCustomerService() {
        return UserRole.CUSTOM.equals(UserRole.getUserRoleByName(userRole));
    }

    public UserStatus getStatus() {
        return UserStatus.getUserStatusByName(status);
    }

    public void setStatus(UserStatus status) {
        this.status = (status != null) ? status.name() : null;
    }

    public List<Account> getAccounts() {
        return accounts;
    }

    public void setAccounts(List<Account> accounts) {
        this.accounts = accounts;
    }

    public List<LoanRequest> getLoanRequests() {
        return loanRequests;
    }

    public void setLoanRequests(List<LoanRequest> loanRequests) {
        this.loanRequests = loanRequests;
    }

    public List<InvestmentRequest> getInvestmentRequests() {
        return investmentRequests;
    }

    public void setInvestmentRequests(List<InvestmentRequest> investmentRequests) {
        this.investmentRequests = investmentRequests;
    }

    public long getVersion() {
        return version;
    }

    public void setVersion(long version) {
        this.version = version;
    }

    public void setUsername(String userName) {
        if (credential == null) {
            this.credential = new Credential(userName, "");
        }
        this.credential.setUsername(userName);
    }

    public Credential getCredential() {
        return credential;
    }

    public boolean isAuthenticated() {
        return UserStatus.AUTHENTICATED.equals(status);
    }

    public boolean hasBindBankAccount() {
        return bankIdentity != null && StringUtils.isNotBlank(bankIdentity.getBankAccount());
    }

    public void setUpdatedAt(Date updatedAt) {
        this.updatedAt = updatedAt;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public Date getUpdatedAt() {
        return updatedAt;
    }

    public XinbaoStatus getXinbaoStatus() {
        return xinbaoStatus;
    }

    public void setXinbaoStatus(XinbaoStatus xinbaoStatus) {
        this.xinbaoStatus = xinbaoStatus;
    }

    public boolean isInnerEmployee() {
        return UserTypes.INNER_EMPLOYEE.equals(this.userType);
    }

    public UserTypes getUserType() {
        return userType;
    }

    public void setUserType(UserTypes userType) {
        this.userType = userType;
    }

    public String getEmployeeEmail() {
        return employeeEmail;
    }

    public void setEmployeeEmail(String employeeEmail) {
        this.employeeEmail = employeeEmail;
    }

    public boolean isRareWord() {
        return isRareWord.booleanValue();
    }

    public void setRareWord(Boolean rareWord) {
        isRareWord = rareWord;
    }

    public Boolean isShowRechargeNotice() {
        return isShowRechargeNotice;
    }

    public void setShowRechargeNotice(Boolean showRechargeNotice) {
        isShowRechargeNotice = showRechargeNotice;
    }

    public void setId(long id) {
        this.id = id;
    }

    public void setCredential(Credential credential) {
        this.credential = credential;
    }

    public long getId() {
        return id;
    }

    public Boolean getRareWord() {
        return isRareWord;
    }

    public Boolean getShowRechargeNotice() {
        return isShowRechargeNotice;
    }

    public void setUserRole(String userRole) {
        this.userRole = userRole;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public String getCardBindStatus() {
        return cardBindStatus;
    }

    public void setCardBindStatus(String cardBindStatus) {
        this.cardBindStatus = cardBindStatus;
    }

    @Override
    public String toString() {
        return "User{" +
                "id=" + id +
                ", email='" + email + '\'' +
                ", mobileNo='" + mobileNo + '\'' +
                "}\n";

    }
}
