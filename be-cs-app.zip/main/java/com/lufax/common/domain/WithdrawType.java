package com.lufax.common.domain;


public enum WithdrawType {
    CUSTOMER_WITHDRAWAL("取现"),
    GUARANTOR_WITHDRAWAL("取现"),
    LOAN_GRANTING("贷款放款"),
    MANUAL_WITHDRAWAL("人工取现"),
    MANUAL_GRANTING("手动放款代付"),
    UNKNOWN("unknown");

    private String value;

    WithdrawType(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
    public static WithdrawType getWithdrawTypeByName(String name){
        WithdrawType[] withdrawTypes=WithdrawType.values();
        for(WithdrawType withdrawType:withdrawTypes)
            if(withdrawType.name().equalsIgnoreCase(name))
                return withdrawType;
        return UNKNOWN;
    }

}
