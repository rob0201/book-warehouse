package com.lufax.common.domain;

public enum OperationStatus {
    ONGOING, DONE ,UNKNOWN;
    public  static   OperationStatus getOperationStatusByName(String status){
        OperationStatus[] operationStatuses=OperationStatus.values();
        for(OperationStatus operationStatus:operationStatuses)
            if(operationStatus.name().equalsIgnoreCase(status))
                return operationStatus;
        return UNKNOWN;
    }

}
