package com.lufax.common.domain;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.util.Date;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Version;

import com.lufax.common.domain.account.Money;
import com.lufax.common.domain.product.Product;
import com.lufax.common.utils.NumberUtils;

@Entity
@Table(name = "LOAN_REQUESTS")
public class LoanRequest {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_LOAN_REQUESTS")
    @SequenceGenerator(name = "SEQ_LOAN_REQUESTS", sequenceName = "SEQ_LOAN_REQUESTS", allocationSize = 1)
    private long id;

    private String code;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "LOANEE_USER_ID")
    private User loanee;

    @OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    @JoinColumn(name = "INSURANCE_POLICY_ID")
    private InsurancePolicy policy;

    @Embedded
    @AttributeOverrides({@AttributeOverride(name = "amount", column = @Column(name = "APPLIED_AMOUNT"))})
    private Money appliedAmount;

    @Column(name = "NUM_OF_INSTALMENTS")
    private int numberOfInstalments;

    @Column(name = "LOAN_PURPOSE")
    private String loanPurpose;

    @Column(name = "INTEREST_RATE")
    private BigDecimal interestRate;

    @Column(name = "MANAGEMENT_FEE_RATE")
    private BigDecimal managementFeeRate;

    //    @Enumerated(EnumType.STRING)
    @Column(name = "PAYMENT_METHOD")
    private String paymentMethod;

    //    @Enumerated(EnumType.STRING)
    @Column(name = "STATUS")
    private String status;

    @Column(name = "CREATED_AT")
    private Date createdAt;

    @Column(name = "UPDATED_AT")
    private Date updatedAt;

    //    @Enumerated(EnumType.STRING)
    @Column(name = "STATUS_TO_XINBAO")
    private String statusToXinBao;

    @Column(name = "FLAG")
    private String flag;

    @Version
    private long version;
    
    @OneToOne(fetch = FetchType.LAZY, mappedBy = "loanRequest")
    private Product product;

    public LoanRequest() {
    }

    public LoanRequest(InsurancePolicyDescription policyDescription, String code, User loanee, BigDecimal interestRate,
                       BigDecimal managementFeeRate, PaymentMethod paymentMethod, LoanRequestStatus status, Date createdAt) {
        InsurancePolicy policy = new InsurancePolicy(policyDescription.getPolicyNo(),
                policyDescription.getInsuranceTotalAmount(),
                policyDescription.getInsuranceValuePerMonth(),
                policyDescription.getInsuranceRate(),
                policyDescription.getInsuranceStartDate(),
                policyDescription.getInsuranceEndDate(),
                policyDescription.getPayStartDate());

        this.code = code;

        this.loanee = loanee;
        this.policy = policy;

        this.appliedAmount = policyDescription.getAppliedAmount();
        this.numberOfInstalments = policyDescription.getNumberOfInstalments();
        this.loanPurpose = policyDescription.getLoanPurpose();
        this.interestRate = NumberUtils.withPercentageScale(interestRate);
        this.managementFeeRate = NumberUtils.withPercentageScale(managementFeeRate);
        this.paymentMethod = (paymentMethod != null) ? paymentMethod.name() : null;

        this.status = (status != null) ? status.name() : null;
        this.createdAt = createdAt;
        this.updatedAt = createdAt;
    }

    public LoanRequest(InsurancePolicyDescription policyDescription, String code, User loanee, BigDecimal interestRate,
                       BigDecimal managementFeeRate, PaymentMethod paymentMethod, LoanRequestStatus status) {
        this(policyDescription, code, loanee, interestRate, managementFeeRate, paymentMethod, status, new Date());
    }

    public long id() {
        return id;
    }

    public String getCode() {
        return code;
    }

    public BigDecimal getInterestRate() {
        return NumberUtils.withPercentageScale(this.interestRate);
    }

    public BigDecimal getMonthlyInterestRate() {
        return NumberUtils.withPercentageScale(this.interestRate.divide(new BigDecimal(12), new MathContext(100, RoundingMode.HALF_UP)));
    }

    public int getNumberOfInstalments() {
        return numberOfInstalments;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public User getLoanee() {
        return loanee;
    }

    public Money getAppliedAmount() {
        return appliedAmount;
    }

    public BigDecimal getManagementFeeRate() {
        return managementFeeRate;
    }

    public LoanRequestStatus getStatus() {
        return LoanRequestStatus.getLoanRequestStatusByName(status);
    }

    public InsurancePolicy getPolicy() {
        return policy;
    }

    public Money getMonthlyInsuranceFee() {
        return policy.getInsuranceValuePerMonth();
    }

    public PaymentMethod getPaymentMethod() {
        return PaymentMethod.getPaymentMethodByName(this.paymentMethod);
    }

    public String getLoanPurpose() {
        return loanPurpose;
    }

    public void setStatus(LoanRequestStatus status) {
        this.status = (status != null) ? status.name() : null;
        this.updatedAt = new Date();
    }

    public void setFlag(String flag) {
        this.flag = flag;
    }

    public boolean isWaitingInvest() {
        return LoanRequestStatus.WAITING_INVEST == LoanRequestStatus.getLoanRequestStatusByName(status);
    }

    public boolean isWaitingConfirm() {
        return LoanRequestStatus.WAITING_CONFIRM.equals(LoanRequestStatus.getLoanRequestStatusByName(status));
    }

    public boolean isBelongTo(User loanee) {
        return getLoanee().getIdentity().equals(loanee.getIdentity());
    }

    @Override
    public String toString() {
        return String.format("code: %s, status: %s", code, status);
    }

    public Money getAmountWithoutTransactionFee(BigDecimal transactionFeeRate) {
        return appliedAmount.subtract(getTransactionFee(transactionFeeRate));
    }

    public Money getTransactionFee(BigDecimal transactionFeeRate) {
        return Money.rmb(appliedAmount.multiply(transactionFeeRate).getAmount());
    }

    public LoanRequestToXinbaoStatus getStatusToXinBao() {
        return LoanRequestToXinbaoStatus.getLoanRequestToXinbaoStatusByName(statusToXinBao);
    }

    public void setStatusToXinBao(LoanRequestToXinbaoStatus statusToXinBao) {
        this.statusToXinBao = (statusToXinBao != null) ? statusToXinBao.name() : null;
    }

    public void setUpdatedAt(Date updatedAt) {
        this.updatedAt = updatedAt;
    }

    public String getFlag() {
        return flag;
    }

    public Date getUpdatedAt() {
        return updatedAt;

    }

    public boolean isSuccess() {
        return LoanRequestStatus.SUCCESS.equals(LoanRequestStatus.getLoanRequestStatusByName(status));
    }

	public Product getProduct() {
		return product;
	}
    
    
}
