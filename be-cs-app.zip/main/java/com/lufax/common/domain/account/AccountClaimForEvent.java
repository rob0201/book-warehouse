package com.lufax.common.domain.account;

import com.lufax.common.domain.TransactionType;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "ACCOUNT_CLAIM_FOR_EVENTS")
public class AccountClaimForEvent {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_ACC_CLAIM_FOR_EVENTS")
    @SequenceGenerator(name = "SEQ_ACC_CLAIM_FOR_EVENTS", sequenceName = "SEQ_ACC_CLAIM_FOR_EVENTS", allocationSize = 1)
    private long id;

    @OneToOne
    @JoinColumn(name = "FROM_ACCOUNT", unique = false, nullable = false)
    private Account fromAccount;

    @OneToOne
    @JoinColumn(name = "TO_ACCOUNT", unique = false, nullable = false)
    private Account toAccount;

    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "amount", column = @Column(name = "AMOUNT"))
    })
    private Money amount;

    @Column(name = "TRANSACTION_ID")
    private long transactionId;

    //    @Enumerated(value = EnumType.ORDINAL)
    @Column(name = "STATUS")
    private int status;

    @Column(name = "CREATED_AT")
    private Date createdAt;

    @Column(name = "UPDATED_AT")
    private Date updatedAt;

    @Version
    private int version;
    //    @Enumerated(value = EnumType.STRING)
    @Column(name = "TRANSACTION_TYPE")
    private String transactionType;

    public void setTransactionType(TransactionType transactionType) {
        this.transactionType = (transactionType != null) ? transactionType.name() : null;
    }

    public void setAmount(Money amount) {
        this.amount = amount;
    }

    public void setTransactionId(long transactionId) {
        this.transactionId = transactionId;
    }

    public void setFromAccount(Account fromAccount) {
        this.fromAccount = fromAccount;
    }

    public void setToAccount(Account toAccount) {
        this.toAccount = toAccount;
    }

    public void setStatus(EventStatus status) {
        this.status = status.ordinal();
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public void setUpdatedat(Date updatedat) {
        this.updatedAt = updatedat;
    }

    public Money getAmount() {
        return amount;
    }

    public static class Builder {
        private long transactionId;
        private Account fromAccount;
        private Account toAccount;
        private Money amount;
        private TransactionType type = TransactionType.RECHARGE;
        private EventStatus status = EventStatus.NEW;

        public Builder(long transactionId) {
            this.transactionId = transactionId;
        }

        public Builder withFromAccount(Account fromAccount) {
            this.fromAccount = fromAccount;
            return this;
        }

        public Builder withToAccount(Account toAccount) {
            this.toAccount = toAccount;
            return this;
        }

        public Builder withAmount(Money amount) {
            this.amount = amount;
            return this;
        }

        public Builder withTransactionType(TransactionType type) {
            this.type = type;
            return this;
        }

        public Builder withStatus(EventStatus status) {
            this.status = status;
            return this;
        }

        public AccountClaimForEvent build() {
            AccountClaimForEvent event = new AccountClaimForEvent();
            event.setTransactionId(transactionId);
            event.setFromAccount(fromAccount);
            event.setToAccount(toAccount);
            event.setAmount(amount);
            event.setTransactionType(type);
            event.setStatus(status);
            Date now = new Date();
            event.setCreatedAt(now);
            event.setUpdatedat(now);
            return event;
        }
    }
}
