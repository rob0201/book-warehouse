package com.lufax.common.domain.account;

import com.lufax.common.domain.TransactionType;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "TRANSACTION_HISTORY")
public class TransactionHistory {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_TRANSACTION_HISTORY")
    @SequenceGenerator(name = "SEQ_TRANSACTION_HISTORY", sequenceName = "SEQ_TRANSACTION_HISTORY", allocationSize = 1)
    private long id;

    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "amount", column = @Column(name = "BALANCE_AMOUNT"))
    })
    private Money balance;

    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "amount", column = @Column(name = "FROZEN_AMOUNT"))
    })
    private Money frozenFund;

    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "amount", column = @Column(name = "TRANSACTION_AMOUNT"))
    })
    private Money transactionAmount;

    @Column(name = "CREATED_AT")
    private Date createdAt;

    @Column(name = "TRANSACTION_ID")
    private long transactionId;

    @Column(name = "REMARK")
    private String remark;

    @Enumerated(EnumType.STRING)
    @Column(name = "TRANSACTION_TYPE")
    private TransactionType type;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ACCOUNT_ID")
    private Account account;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "COUNTER_PARTY_ID")
    private Account counterParty;

    @Column(name = "BUSINESS_ID")
    private long businessId;

    public TransactionHistory() {
    }

    public TransactionHistory(Money balance, Money frozenFund, Money transactionAmount,
                              TransactionType type, Account account, Account counterParty, String remark, Date createdAt) {
        this.balance = balance;
        this.frozenFund = frozenFund;
        this.transactionAmount = transactionAmount;
        this.createdAt = createdAt;
        this.remark = remark;
        this.type = type;
        this.account = account;
        this.counterParty = counterParty;
    }

    public TransactionHistory(Money balance, Money frozenFund, Money transactionAmount,
                              TransactionType type, Account account, Account counterParty, String remark) {
        this(balance, frozenFund, transactionAmount, type, account, counterParty, remark, new Date());
    }

    public long id() {
        return id;
    }

    public Money getBalance() {
        return balance;
    }

    public Money getTransactionAmount() {
        return transactionAmount;
    }

    public Money getAvailableFund() {
        return balance.subtract(frozenFund);
    }

    public Money getFrozenFund() {
        return frozenFund;
    }

    public TransactionType getType() {
        return type;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public Account getCounterParty() {
        return counterParty;
    }

    public Account getAccount() {
        return account;
    }

    public void setTransactionId(long transactionId) {
        this.transactionId = transactionId;
    }

    public long getTransactionId() {
        return transactionId;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getRemark() {
        return remark;
    }

    public long getBusinessId() {
        return businessId;
    }

    public void setBusinessId(long businessId) {
        this.businessId = businessId;
    }
}
