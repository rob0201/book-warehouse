package com.lufax.common.domain.account.repository;

import com.lufax.common.domain.User;
import com.lufax.common.domain.account.Account;
import com.lufax.common.domain.account.Money;
import com.lufax.common.domain.repository.BaseRepository;
import org.springframework.stereotype.Repository;

import javax.persistence.LockModeType;
import java.util.List;

@Repository
public class AccountRepository extends BaseRepository<Account> {
    public Account findByUserId(long userId) {
        return entityManager.createQuery("select acc from Account acc where acc.user.id=:userId", Account.class).setParameter("userId", userId).getSingleResult();
    }

    public List<Account> findAllAccountReasonForRareWords(List<User> users) {
        return entityManager.createQuery("select  acc from Account acc where acc.user in (:users)", Account.class).setParameter("users", users).getResultList();
    }

    public Money getTotalBalance() {
        return entityManager.createQuery("select sum(a.balance) from Account a", Money.class).getSingleResult();
    }

    public void lock(Account account) {
        entityManager.lock(account, LockModeType.PESSIMISTIC_READ);
    }
}

