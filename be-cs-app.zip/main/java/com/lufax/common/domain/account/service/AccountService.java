package com.lufax.common.domain.account.service;

import com.lufax.common.domain.TransactionType;
import com.lufax.common.domain.User;
import com.lufax.common.domain.account.*;
import com.lufax.common.domain.account.exception.AccountException;
import com.lufax.common.domain.account.repository.AccountRepository;
import com.lufax.common.domain.account.repository.FrozenFundRepository;
import com.lufax.common.domain.account.repository.TransactionHistoryRepository;
import com.lufax.common.domain.repository.FrozenStatus;
import com.lufax.common.exception.P2PErrorCode;
import com.lufax.common.utils.DevLog;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

import static com.lufax.common.domain.repository.FrozenStatus.UNFREEZE;
import static com.lufax.common.exception.P2PErrorCode.*;
import static com.lufax.common.utils.NumberUtils.*;

@Service
public class AccountService {
    private TransactionHistoryRepository transactionHistoryRepository;
    private AccountRepository accountRepository;
    private FrozenFundRepository frozenFundRepository;

    public AccountService() {
    }

    @Autowired
    public AccountService(TransactionHistoryRepository transactionHistoryRepository, AccountRepository accountRepository, FrozenFundRepository frozenFundRepository) {
        this.transactionHistoryRepository = transactionHistoryRepository;
        this.accountRepository = accountRepository;
        this.frozenFundRepository = frozenFundRepository;
    }

    @Transactional
    public long freezeFund(TransactionType transactionType, long transactionId, long businessId, Account fromAccount, Money amount, Account accountCounterParty, String remark, FrozenType frozenType) {
        DevLog.info(this, String.format("Freeze fund %s on account %s", amount, fromAccount.id()));

        long frozenCode = checkAndFreeze(fromAccount, amount, frozenType);

        generateTransactionHistory(fromAccount, accountCounterParty, transactionType, amount, transactionId, businessId, remark, new Date());

        return frozenCode;
    }

    @Transactional
    public void unfreezeFund(Long frozenCode, long transactionId, long businessId, Account fromAccount, Money amount, TransactionType type, String remark) {
        DevLog.info(this, String.format("Unfreeze fund %s on account %s", amount, fromAccount.id()));

        checkAndUnfreeze(frozenCode, fromAccount, amount);

        generateTransactionHistory(fromAccount, fromAccount, type, amount, transactionId, businessId, remark, new Date());
    }

    @Transactional
    public void plusAmount(TransactionType type, long transactionId, long businessId, Account account, Money amount, String remark) {
        plusMoney(account, amount, null, type, remark, transactionId, businessId, new Date());
    }

    @Transactional
    public void subtractAmount(TransactionType type, long transactionId, long businessId, Account account, Money amount, String remark) {
        checkAndDeductMoney(account, amount, null, type, remark, transactionId, businessId, new Date());
    }

    @Transactional
    public void transfer(long transactionId, long fromBusinessId, long toBusinessId, Money amount, AccountTransferObject from, AccountTransferObject to, Date createdAt) {
        AccountTransferValueObject valueObject = build(transactionId, amount, from, to);

        if (isLessThanZero(valueObject.getAmount().getAmount())) {
            throw new AccountException(P2PErrorCode.TRANSFER_AMOUNT_LESS_THAN_ZERO, formatCurrency(valueObject.getAmount()));
        }

        if (isEqualsToZero(valueObject.getAmount().getAmount())) {
            return;
        }

        plusMoney(valueObject.getToAccount(), valueObject.getAmount(), valueObject.getFromAccount(), valueObject.getToTransactionType(), valueObject.getToRemark(), valueObject.getTransactionId(), toBusinessId, createdAt);
        checkAndDeductMoney(valueObject.getFromAccount(), valueObject.getAmount(), valueObject.getToAccount(), valueObject.getFromTransactionType(), valueObject.getFromRemark(), valueObject.getTransactionId(), fromBusinessId, createdAt);
    }

    @Transactional
    public void unfreezeAndTransfer(Long frozenCode, long transactionId, long fromBusinessId, long toBusinessId, Money appliedAmount, AccountTransferObject from, AccountTransferObject to) {
        AccountTransferValueObject valueObject = build(transactionId, appliedAmount, from, to);
        if (isLessThanZero(valueObject.getAmount().getAmount())) {
            throw new AccountException(P2PErrorCode.TRANSFER_AMOUNT_LESS_THAN_ZERO, formatCurrency(valueObject.getAmount()));
        }
        if (isLessOrEqualThanZero(valueObject.getAmount().getAmount())) {
            return;
        }

        checkAndUnfreeze(frozenCode, valueObject.getFromAccount(), valueObject.getAmount());

        plusMoney(valueObject.getToAccount(), valueObject.getAmount(), valueObject.getFromAccount(), valueObject.getToTransactionType(), valueObject.getToRemark(), valueObject.getTransactionId(), toBusinessId, new Date());
        checkAndDeductMoney(valueObject.getFromAccount(), valueObject.getAmount(), valueObject.getToAccount(), valueObject.getFromTransactionType(), valueObject.getFromRemark(), valueObject.getTransactionId(), fromBusinessId, new Date());
    }

  
    public List<Account> getAllAccountReasonForRareWords(List<User> users){
        return accountRepository.findAllAccountReasonForRareWords(users);
    }

    private void plusMoney(Account account, Money amount, Account counterParty, TransactionType type, String remark, long transactionId, long businessId, Date createdAt) {
        accountRepository.lock(account);
        account.plusBalance(amount);
        accountRepository.update(account);
        generateTransactionHistory(account, counterParty, type, amount, transactionId, businessId, remark, createdAt);
    }

    private void checkAndDeductMoney(Account account, Money amount, Account counterParty, TransactionType type, String remark, long transactionId, long businessId, Date createdAt) {
        if (!account.isEnoughToPay(amount)) {
            DevLog.warn(this, String.format("Failed to subtract money from account %s, want to subtract %s, but currently available fund is only %s", account.id(), amount, account.getAvailableFund()));
            throw new AccountException(AVAILABLE_FUND_NOT_ENOUGH, formatCurrency(account.getAvailableFund()));
        }

        accountRepository.lock(account);

        account.minusBalance(amount);
        accountRepository.update(account);
        generateTransactionHistory(account, counterParty, type, amount, transactionId, businessId, remark, createdAt);
    }

    private long checkAndFreeze(Account account, Money amount, FrozenType frozenType) {
        if (!account.isEnoughToPay(amount)) {
            DevLog.warn(this, String.format("Failed to freeze acount %s, want to free %s, but currently available fund is only %s", account.id(), amount, account.getAvailableFund()));
            throw new AccountException(AVAILABLE_FUND_NOT_ENOUGH, formatCurrency(account.getAvailableFund()));
        }

        long frozenCode = frozenFundRepository.getNextFrozenCode();
        FrozenFund frozenFund = new FrozenFund(account, frozenCode, FrozenStatus.FREEZING, amount, frozenType);

        accountRepository.lock(account);
        account.freezeFund(amount);
        account.addFrozenFund(frozenFund);
        accountRepository.persist(account);
        return frozenCode;
    }

    private void checkAndUnfreeze(Long frozenCode, Account account, Money amount) {
        if (!account.isEnoughToUnFreeze(amount)) {
            DevLog.warn(this, String.format("Failed to unfreeze fund from account %s, want to unfree %s, but currently frozen fund is only %s", account.id(), amount, account.getFrozenFund()));
            throw new AccountException(FROZEN_FUND_NOT_ENOUGHT_TO_UNFREEZE, formatCurrency(amount), formatCurrency(account.getFrozenFund()));
        }

        accountRepository.lock(account);
        account.minusFrozenFund(amount);

        if (null != frozenCode) {
            setFrozenStatusToUnfreeze(frozenCode, account);
        }

        accountRepository.update(account);
    }

    private void setFrozenStatusToUnfreeze(Long frozenCode, Account account) {
        boolean isFrozenCodeExist = false;
        List<FrozenFund> frozenFundList = account.getFrozenFundList();
        for (FrozenFund frozenFund : frozenFundList) {
            if (frozenFund.getFrozenCode() == frozenCode) {

                if (frozenFund.isUnFrozen()) {
                    DevLog.warn(this, String.format("frozenCode(code=%s) is already unfrozen", frozenCode));
                    throw new AccountException(FROZEN_CODE_ALREADY_UNFROZEN, String.valueOf(frozenCode));
                }

                frozenFund.setFrozenStatus(UNFREEZE);
                isFrozenCodeExist = true;
            }
        }

        if (false == isFrozenCodeExist) {
            DevLog.warn(this, String.format("Failed to find frozenCode(code=%s) from account(id=%s)", frozenCode, account.id()));
            throw new AccountException(FROZEN_CODE_NOT_EXISTS, String.valueOf(frozenCode));
        }
    }

    private void generateTransactionHistory(Account account, Account counterParty, TransactionType transactionType, Money amount, long transactionId, long businessId, String remark, Date createdAt) {
        TransactionHistory transactionHistory = new TransactionHistory(account.getBalance(), account.getFrozenFund(), amount, transactionType, account, counterParty, remark, createdAt);
        transactionHistory.setTransactionId(transactionId);
        transactionHistory.setBusinessId(businessId);
        transactionHistoryRepository.persist(transactionHistory);
    }

    private AccountTransferValueObject build(long transactionId, Money amount, AccountTransferObject from, AccountTransferObject to) {
        return new AccountTransferValueObject.Builder().
                withTransactionId(transactionId).
                withAmount(amount).
                from(from).
                to(to).
                build();
    }
}
