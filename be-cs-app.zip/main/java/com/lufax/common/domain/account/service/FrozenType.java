package com.lufax.common.domain.account.service;

public enum FrozenType {
    WITHDRAW,
    INVESTMENT,
    UNKNOWN;

    public static FrozenType getFrozenTypeByName(String name) {
        FrozenType[] frozenTypes = FrozenType.values();
        for (FrozenType frozenType : frozenTypes)
            if (frozenType.name().equalsIgnoreCase(name))
                return frozenType;
        return UNKNOWN;
    }

}
