package com.lufax.common.domain.account.exception;

import com.lufax.common.domain.account.Money;
import com.lufax.common.exception.P2PErrorCode;
import com.lufax.common.exception.P2PException;

public class AccountException extends P2PException {

    private Funds funds;

    public AccountException(P2PErrorCode errorCode, String... args) {
        super(errorCode, args);
    }

    public AccountException(P2PErrorCode errorCode, Funds funds, String... args) {
        super(errorCode, args);
        this.funds = funds;
    }

    public Funds getFunds() {
        return funds;
    }

    public static class Funds{
        private Money availableFund;
        private Money requiredFund;

        public Funds(Money availableFund, Money requiredFund) {
            this.availableFund = availableFund;
            this.requiredFund = requiredFund;
        }

        public Money getAvailableFund() {
            return availableFund;
        }

        public Money getRequiredFund() {
            return requiredFund;
        }

        public Money getRechargeFund() {
            return requiredFund.subtract(availableFund);
        }
    }
}
