package com.lufax.common.domain.account;

import com.lufax.common.domain.User;
import com.lufax.common.domain.UserRole;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "ACCOUNTS")
public class Account {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_ACCOUNTS")
    @SequenceGenerator(name = "SEQ_ACCOUNTS", sequenceName = "SEQ_ACCOUNTS", allocationSize = 1)
    private long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "USER_ID", unique = true, nullable = false)
    private User user;

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "account", cascade = CascadeType.ALL)
    private List<FrozenFund> frozenFundList = new ArrayList<FrozenFund>();

    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "amount", column = @Column(name = "BALANCE_AMOUNT"))
    })
    private Money balance;

    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "amount", column = @Column(name = "FROZEN_AMOUNT"))
    })
    private Money frozenFund;

    public Account() {
    }

    public Account(User user) {
        this(user, Money.rmb("0.0"), Money.rmb("0.0"));
    }

    public Account(User user, Money balance, Money frozenFund) {
        this.user = user;
        this.balance = balance;
        this.frozenFund = frozenFund;
    }

    public long id() {
        return id;
    }

    public Money getBalance() {
        return balance;
    }

    public User getUser() {
        return user;
    }

    public void setFrozenFund(Money frozenFund) {
        this.frozenFund = frozenFund;
    }

    public Money getFrozenFund() {
        return frozenFund;
    }

    public Money getAvailableFund() {
        return balance.subtract(frozenFund);
    }

    public List<FrozenFund> getFrozenFundList() {
        return frozenFundList;
    }

    public void setBalance(Money balance) {
        this.balance = balance;
    }

    public void plusBalance(Money balance) {
        this.balance = this.balance.add(balance);
    }

    public void minusBalance(Money amount) {
        this.balance = this.balance.subtract(amount);
    }

    public void minusFrozenFund(Money amount) {
        this.frozenFund = this.frozenFund.subtract(amount);
    }

    public void freezeFund(Money amount) {
        this.frozenFund = this.frozenFund.add(amount);
    }

    public boolean isEnoughToPay(Money amount) {
        return getAvailableFund().greaterThanOrEqualsTo(amount);
    }

    public boolean isEnoughToUnFreeze(Money amount) {
        return getFrozenFund().greaterThanOrEqualsTo(amount);
    }

    public boolean isGuarantorAccount() {
        return user.isGuarantor();
    }

    public boolean useAsyncClaimForEvents() {
        return isP2PAccount() || isGuarantorAccount();
    }

    private boolean isP2PAccount() {
        return this.user.getUserRole() == UserRole.P2P;
    }

    public void addFrozenFund(FrozenFund freezeRecord) {
        this.frozenFundList.add(freezeRecord);
    }

    public void setFrozenFundList(List<FrozenFund> frozenFundList) {
        this.frozenFundList = frozenFundList;
    }
}
