package com.lufax.common.domain.account.resources.gsonTemplate;

import com.lufax.common.domain.account.Account;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

import java.math.BigDecimal;

public class AccountGson {
    private BigDecimal availableFund;
    private BigDecimal frozenFund;
    private BigDecimal balance;

    public AccountGson() {
    }

    public AccountGson(Account account) {
        availableFund = account.getAvailableFund().getAmount();
        frozenFund = account.getFrozenFund().getAmount();
        balance = account.getBalance().getAmount();
    }

    public BigDecimal getAvailableFund() {
        return availableFund;
    }

    public BigDecimal getFrozenFund() {
        return frozenFund;
    }

    public BigDecimal getBalance() {
        return balance;
    }

    @Override
    public boolean equals(Object o) {
        return EqualsBuilder.reflectionEquals(this, o);
    }

    @Override
    public int hashCode() {
        return HashCodeBuilder.reflectionHashCode(this);
    }
}
