package com.lufax.common.domain.account;

import com.lufax.common.domain.TransactionType;

public class AccountTransferValueObject {
    private Account fromAccount;
    private Account toAccount;
    private Money amount;
    private TransactionType toTransactionType;
    private TransactionType fromTransactionType;
    private long transactionId;
    private String fromRemark;
    private String toRemark;

    private AccountTransferValueObject() {
    }

    public Account getFromAccount() {
        return fromAccount;
    }

    public long getFromAccountId() {
        return fromAccount.id();
    }

    public Account getToAccount() {
        return toAccount;
    }

    public Money getAmount() {
        return amount;
    }

    public long getTransactionId() {
        return transactionId;
    }

    public TransactionType getToTransactionType() {
        return toTransactionType;
    }

    public TransactionType getFromTransactionType() {
        return fromTransactionType;
    }

    public String getFromRemark() {
        return fromRemark;
    }

    public String getToRemark() {
        return toRemark;
    }

    public long getToAccountId() {
        return toAccount.id();
    }

    public static class Builder{

        private AccountTransferValueObject object;

        public Builder() {
            object = new AccountTransferValueObject();
        }

        public Builder withAmount(Money amount) {
            object.amount = amount;
            return this;
        }

        public Builder withTransactionId(long transactionId){
            object.transactionId = transactionId;
            return this;
        }

        public Builder from(AccountTransferObject accountTransaferObject) {
            object.fromAccount = accountTransaferObject.getAccount();
            object.fromTransactionType = accountTransaferObject.getTransactionType();
            object.fromRemark = accountTransaferObject.getRemark();
            return this;
        }
        public Builder to(AccountTransferObject accountTransaferObject) {
            object.toAccount = accountTransaferObject.getAccount();
            object.toTransactionType = accountTransaferObject.getTransactionType();
            object.toRemark = accountTransaferObject.getRemark();
            return this;
        }

        public AccountTransferValueObject build(){
            return object;
        }
    }
}