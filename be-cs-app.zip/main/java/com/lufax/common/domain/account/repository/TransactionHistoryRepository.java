package com.lufax.common.domain.account.repository;

import java.util.Date;
import java.util.List;

import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.lufax.common.domain.TransactionTypeForQuery;
import com.lufax.common.domain.User;
import com.lufax.common.domain.account.TransactionHistory;
import com.lufax.common.domain.repository.BaseRepository;

@Repository
public class TransactionHistoryRepository extends BaseRepository<TransactionHistory> {
    
    public long findCountByAccountAndTypeWithRangeTime(User user, TransactionTypeForQuery type,Date beginTime,Date endTime) {
        String hql = " select count(t) from TransactionHistory t where t.account.user=:user ";
        if(null!=beginTime){
        	hql = hql + " and t.createdAt>= :beginTime ";
        }
        if(null!=endTime){
        	hql = hql + " and t.createdAt<= :endTime ";
        }
        
        if(null!=type.getTransactionTypes()){
        	hql = hql + " and t.type in (:types) ";
        }
        
        TypedQuery query = (TypedQuery)entityManager.createQuery(hql);
        query.setParameter("user", user);
        if(null!=beginTime){
        	query.setParameter("beginTime", beginTime);
        }
        if(null!=endTime){
        	query.setParameter("endTime", endTime);
        }
        
        if(null!=type.getTransactionTypes()){
        	query.setParameter("types", type.getTransactionTypes());
        }
    	return (Long)query.getSingleResult();
    }
    
    public List<TransactionHistory> findByAccountAndTypeWithRangeTime(User user, TransactionTypeForQuery type,Date beginTime,Date endTime, int pageLimit, int offset) {
        String hql = " select t from TransactionHistory t  where t.account.user=:user ";
        if(null!=beginTime){
        	hql = hql + " and t.createdAt>= :beginTime ";
        }
        if(null!=endTime){
        	hql = hql + " and t.createdAt<= :endTime ";
        }
        
        if(null!=type.getTransactionTypes()){
        	hql = hql + " and t.type in (:types) ";
        }
        hql = hql + " order by t.createdAt desc ";
        TypedQuery query = (TypedQuery)entityManager.createQuery(hql);
        query.setParameter("user", user);
        if(null!=beginTime){
        	query.setParameter("beginTime", beginTime);
        }
        if(null!=endTime){
        	query.setParameter("endTime", endTime);
        }
        
        if(null!=type.getTransactionTypes()){
        	query.setParameter("types", type.getTransactionTypes());
        }
    	return (List<TransactionHistory>)query.setFirstResult(offset).setMaxResults(pageLimit).getResultList();
    }

}
