package com.lufax.common.domain.account;

import com.lufax.common.domain.TransactionType;

public class AccountTransferObject {
    private final Account account;
    private final TransactionType transactionType;
    private final String remark;

    public AccountTransferObject(Account account, TransactionType transactionType, String remark) {
        this.account = account;
        this.transactionType = transactionType;
        this.remark = remark;
    }

    public Account getAccount() {
        return account;
    }

    public TransactionType getTransactionType() {
        return transactionType;
    }

    public String getRemark() {
        return remark;
    }
}
