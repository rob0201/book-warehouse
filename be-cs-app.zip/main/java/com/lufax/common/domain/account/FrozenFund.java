package com.lufax.common.domain.account;

import com.lufax.common.domain.account.service.FrozenType;
import com.lufax.common.domain.repository.FrozenStatus;

import javax.persistence.*;
import java.util.Date;

import static com.lufax.common.domain.repository.FrozenStatus.UNFREEZE;

@Entity
@Table(name = "FROZEN_FUNDS")
public class FrozenFund {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_FROZEN_FUNDS")
    @SequenceGenerator(name = "SEQ_FROZEN_FUNDS", sequenceName = "SEQ_FROZEN_FUNDS", allocationSize = 1)
    private long id;

    @ManyToOne
    @JoinColumn(name = "ACCOUNT_ID")
    private Account account;

    @Column(name = "FROZEN_CODE")
    private long frozenCode;

    //    @Enumerated(value = EnumType.STRING)
    @Column(name = "FROZEN_STATUS")
    private String frozenStatus;

    @AttributeOverrides({@AttributeOverride(name = "amount", column = @Column(name = "FROZEN_AMOUNT"))})
    private Money frozenAmount;

    //    @Enumerated(value = EnumType.STRING)
    @Column(name = "FROZEN_TYPE")
    private String frozenType;

    @Column(name = "CREATED_AT")
    private Date createdAt;

    @Column(name = "UPDATED_AT")
    private Date updatedAt;

    public FrozenFund() {

    }

    public FrozenFund(Account account, long frozenCode, FrozenStatus frozenStatus, Money frozenAmount, FrozenType frozenType, Date createdAt, Date updatedAt) {
        this.account = account;
        this.frozenCode = frozenCode;
        this.frozenStatus = (frozenStatus != null) ? frozenStatus.name() : null;
        this.frozenAmount = frozenAmount;
        this.frozenType = (frozenType != null) ? frozenType.name() : null;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }

    public FrozenFund(Account account, long frozenCode, FrozenStatus frozenStatus, Money frozenAmount, FrozenType frozenType) {
        this(account, frozenCode, frozenStatus, frozenAmount, frozenType, new Date(), new Date());
    }


    public Money getFrozenAmount() {
        return frozenAmount;
    }

    public FrozenType getFrozenType() {
        return FrozenType.getFrozenTypeByName(frozenType);
    }

    public FrozenStatus getFrozenStatus() {
        return FrozenStatus.getFrozenStatusByName(frozenStatus);
    }

    public long getFrozenCode() {
        return frozenCode;
    }

    public Account getAccount() {
        return account;
    }

    public long id() {
        return id;
    }

    public void setFrozenStatus(FrozenStatus frozenStatus) {
        this.frozenStatus = (frozenStatus != null) ? frozenStatus.name() : null;
    }

    public boolean isUnFrozen() {
        return UNFREEZE.equals(getFrozenStatus());
    }
}
