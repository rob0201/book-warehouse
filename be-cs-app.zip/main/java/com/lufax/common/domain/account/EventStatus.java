package com.lufax.common.domain.account;

public enum EventStatus {
    NEW, DONE, UNKONWN;

    public static EventStatus getEventStatusByName(String status) {
        EventStatus[] eventStatuses = EventStatus.values();
        for (EventStatus eventStatus : eventStatuses)
            if (eventStatus.name().equalsIgnoreCase(status))
                return eventStatus;
        return UNKONWN;
    }

    public static EventStatus getEventStatusByOrdinal(int ordinal){
        EventStatus[] eventStatuses=EventStatus.values();
        for(EventStatus eventStatus:eventStatuses)
            if(eventStatus.ordinal()==ordinal)
                return eventStatus;
        return UNKONWN;
    }
}
