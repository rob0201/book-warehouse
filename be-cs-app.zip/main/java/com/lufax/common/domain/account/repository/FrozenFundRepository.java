package com.lufax.common.domain.account.repository;

import com.lufax.common.domain.account.FrozenFund;
import com.lufax.common.domain.repository.BaseRepository;
import org.springframework.stereotype.Repository;

@Repository
public class FrozenFundRepository extends BaseRepository<FrozenFund> {
    public long getNextFrozenCode() {
        Object result = entityManager.createNativeQuery("SELECT seq_frozen_code.nextval from Dual").getSingleResult();
        return Long.valueOf(result.toString());
    }
}
