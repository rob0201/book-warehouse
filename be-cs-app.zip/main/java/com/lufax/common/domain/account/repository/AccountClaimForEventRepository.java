package com.lufax.common.domain.account.repository;

import com.lufax.common.domain.account.Account;
import com.lufax.common.domain.account.AccountClaimForEvent;
import com.lufax.common.domain.account.EventStatus;
import com.lufax.common.domain.account.Money;
import com.lufax.common.domain.repository.BaseRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class AccountClaimForEventRepository extends BaseRepository<AccountClaimForEvent> {
    public List<AccountClaimForEvent> findClaimForEvents(Account account) {
        return entityManager.createQuery("select e from AccountClaimForEvent e where e.toAccount=:toAccount and e.status=:status")
                .setParameter("toAccount", account)
                .setParameter("status", EventStatus.NEW.name())
                .getResultList();
    }

    public Money findClaimForAmount(Account account) {
        Money result = entityManager.createQuery("select sum(e.amount) from AccountClaimForEvent e where e.toAccount=:toAccount and e.status=:status", Money.class)
                .setParameter("toAccount", account)
                .setParameter("status", EventStatus.NEW.name())
                .getSingleResult();
        return result == null ? Money.ZERO_YUAN : result;
    }
}
