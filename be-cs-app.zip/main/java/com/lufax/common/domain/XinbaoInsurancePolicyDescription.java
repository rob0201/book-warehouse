package com.lufax.common.domain;

import com.lufax.common.domain.account.Money;
import com.lufax.common.utils.XinbaoXMLFieldHelper;
import com.lufax.common.utils.DateUtils;
import com.lufax.common.utils.DevLog;

import java.math.BigDecimal;
import java.text.ParseException;
import java.util.Date;
import java.util.Map;

public class XinbaoInsurancePolicyDescription implements InsurancePolicyDescription {

    public static final String KEY_INSURED_TOTAL_AMT = "insuredTotalAmt";
    public static final String KEY_INSURED_RATE = "insureRate";
    public static final String KEY_APPLY_TERM_MONTH = "applNosInst";
    public static final String KEY_CUSTOMER_NAME = "custName";
    public static final String KEY_VOUCH_VALUE = "vouchValue";
    public static final String KEY_CONFIRM_VALUE = "confirmValue";
    public static final String KEY_BANK_LOAN_PURPOSE = "loanPurpose";
    public static final String KEY_MOBILE_NO = "mobileTel";
    public static final String BANK_CODE = "cmsBank";
    public static final String SUB_BANK_CODE = "subBank";
    public static final String BANK_ACCOUNT = "bankAccount";

    private Map<String, String> loanInfo;

    public XinbaoInsurancePolicyDescription(Map<String, String> loanInfo) {
        this.loanInfo = loanInfo;
    }

    public String getPolicyNo() {
        return getFromMap(XinbaoXMLFieldHelper.POLICY_NO);
    }

    public Money getAppliedAmount() {
        return Money.rmb(getFromMap(KEY_VOUCH_VALUE));
    }

    public int getNumberOfInstalments() {
        return Integer.parseInt(getFromMap(KEY_APPLY_TERM_MONTH));
    }

    public UserIdentity getApplicant() {
        Gender gender = Gender.getGenderBy(getFromMap(XinbaoXMLFieldHelper.SEX));
        Identity identity = new Identity(Identity.Type.IDENTITY_CARD, getFromMap(XinbaoXMLFieldHelper.ID));

        Date birthday = null;
        try {
            birthday = DateUtils.parseXinbaoDateFormat(getFromMap(XinbaoXMLFieldHelper.BIRTHDAY));
        } catch (ParseException e) {
            DevLog.warn(getClass(), String.format("invalid birthday for original insurance info (%s).", birthday));
        }

        return new UserIdentity(getFromMap(KEY_CUSTOMER_NAME), gender, identity, birthday);
    }

    public String getFullDescription() {
        return loanInfo.toString();
    }

    public Money getInsuranceTotalAmount() {
        return Money.rmb(getFromMap(KEY_INSURED_TOTAL_AMT));
    }

    public Date getInsuranceStartDate() {
        return null;
    }

    public Date getInsuranceEndDate() {
        return null;
    }

    public Date getPayStartDate() {
        return null;
    }

    public Money getInsuranceValuePerMonth() {
        return Money.rmb(getFromMap(KEY_CONFIRM_VALUE));
    }

    public String getLoanPurpose() {
        return getFromMap(KEY_BANK_LOAN_PURPOSE);
    }

    public String getMobileNo() {
        return getFromMap(KEY_MOBILE_NO);
    }

    public String getBankAccount() {
        return getFromMap(BANK_ACCOUNT);
    }

    public String getSubBankCode() {
        return getFromMap(SUB_BANK_CODE);
    }

    public String getBankCode() {
        return getFromMap(BANK_CODE);
    }

    public BigDecimal getInsuranceRate() {
        return new BigDecimal(getFromMap(KEY_INSURED_RATE));
    }

    private String getFromMap(String key) {
        return loanInfo.containsKey(key) ? loanInfo.get(key) : "";
    }
}
