package com.lufax.common.domain;

import java.math.BigDecimal;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "AS_GUARANTEED_NOTE")
public class ASGuaranteedNote {
//	ID                   NOT NUL NUMBER(19)     
	@Id
    @Column(name = "ID")
    private Long id;
//	AS_REQUEST_NO        NOT NULL VARCHAR2(32)
	@Column(name = "AS_REQUEST_NO")
    private String asRequestNo;
//	LOAN_ACCEPT_ID       NOT NULL VARCHAR2(32)
	@Column(name = "LOAN_ACCEPT_ID")
    private String loanAcceptId;
//	AS_PRODUCT_TYPE      NOT NULL VARCHAR2(32)
//	 DIRECT_P2P("1000200010", "无抵押贷款"),
//	 WHITECOLLAR("1000200020", "白领贷款"), //todo: the code need to be clearify
//	 HOUSE_LOAN("1000100010", "抵押贷款");
	@Column(name = "AS_PRODUCT_TYPE")
    private String asProductType;
//	LOANEE_USERNAME               VARCHAR2(32)
	@Column(name = "LOANEE_USERNAME")
    private String loaneeUserName;
//	LOANEE_NAME                   VARCHAR2(32)
	@Column(name = "LOANEE_NAME")
    private String loaneeName;
//	SEX                           VARCHAR2(32)
	@Column(name = "SEX")
    private String sex;
//	IDENTITY_TYPE                 VARCHAR2(32)
	@Column(name = "IDENTITY_TYPE")
    private String identityType;
//	IDENTITY_NUMBER               VARCHAR2(32)
	@Column(name = "IDENTITY_NUMBER")
    private String identityNumber;
//	MOBILE_NO                     VARCHAR2(32)
	@Column(name = "MOBILE_NO")
    private String mobileNo;
//	EMAIL                         VARCHAR2(128)
	@Column(name = "EMAIL")
    private String email;
//	GRANTING_ACCNO       NOT NULL VARCHAR2(32)
	@Column(name = "GRANTING_ACCNO")
    private String grantingAccNo;
//	BANK_CODE                     VARCHAR2(32)
	@Column(name = "BANK_CODE")
    private String bankCode;
//	CURRENCY                      VARCHAR2(32)
	@Column(name = "CURRENCY")
    private String currency;
//	INTEREST_RATE        NOT NULL NUMBER(20,15)
	@Column(name = "INTEREST_RATE")
    private BigDecimal interestRate;
//	APPLIED_AMOUNT       NOT NULL NUMBER(19,2)
	@Column(name = "APPLIED_AMOUNT")
    private BigDecimal appliedAmount;
//	INSTALMENTS          NOT NULL NUMBER(19)
	@Column(name = "INSTALMENTS")
    private Long instalments;
//	INSTALMENTS_UNIT              VARCHAR2(32)
	@Column(name = "INSTALMENTS_UNIT")
    private String  instalmentsUnit;
//	LOAN_STATUS                   VARCHAR2(32)
	@Column(name = "LOAN_STATUS")
    private String  loanStatus;
//	PURPOSE                       VARCHAR2(512)
	@Column(name = "PURPOSE")
    private String  purpose;
//	VALUE_DATE                    DATE
	@Column(name = "VALUE_DATE")
    private Date  valueDate;
//	DUE_DATE                      DATE
	@Column(name = "DUE_DATE")
    private Date  dueDate;
//	MONTHLY_REPAY_DAY             VARCHAR2(32)
	@Column(name = "MONTHLY_REPAY_DAY")
    private String  monthlyRepayDay;
//	TOTAL_INSURANCE_FEE           NUMBER(19,2)
	@Column(name = "TOTAL_INSURANCE_FEE")
    private BigDecimal  totalInsuranceFee;
//	TOTAL_INTEREST                NUMBER(19,2)
	@Column(name = "TOTAL_INTEREST")
    private BigDecimal  totalInterest;
//	TOTAL_REPAY_AMOUNT            NUMBER(19,2)
	@Column(name = "TOTAL_REPAY_AMOUNT")
    private BigDecimal  totalRepayAmount;
//	GUARANTEE_COMPANY             VARCHAR2(1024)
	@Column(name = "GUARANTEE_COMPANY")
    private String  guaranteeCompany;
//	GUARANTEE_RATE                NUMBER(20,15)
	@Column(name = "GUARANTEE_RATE")
    private BigDecimal  guaranteeRate;
//	GUARANTEE_AMOUNT              NUMBER(19,2)
	@Column(name = "GUARANTEE_AMOUNT")
    private BigDecimal  guaranteeAmount;
//	STATUS                        VARCHAR2(32)
	@Column(name = "STATUS")
    private String  status;
//	CREATED_AT                    DATE
	@Column(name = "CREATED_AT")
    private Date  createdAt;
//	UPDATED_AT                    DATE
	@Column(name = "UPDATED_AT")
    private Date  updatedAt;
//	AS_LOAN_REQUEST_CODE NOT NULL VARCHAR2(32)
	@Column(name = "AS_LOAN_REQUEST_CODE")
    private String  asLoanRequestCode;
//	AS_LOAN_REQUEST_ID            NUMBER(19)
	@Column(name = "AS_LOAN_REQUEST_ID")
    private Long  asLoanRequestId;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getAsRequestNo() {
		return asRequestNo;
	}
	public void setAsRequestNo(String asRequestNo) {
		this.asRequestNo = asRequestNo;
	}
	public String getLoanAcceptId() {
		return loanAcceptId;
	}
	public void setLoanAcceptId(String loanAcceptId) {
		this.loanAcceptId = loanAcceptId;
	}
	public String getAsProductType() {
		return asProductType;
	}
	public void setAsProductType(String asProductType) {
		this.asProductType = asProductType;
	}
	public String getLoaneeUserName() {
		return loaneeUserName;
	}
	public void setLoaneeUserName(String loaneeUserName) {
		this.loaneeUserName = loaneeUserName;
	}
	public String getLoaneeName() {
		return loaneeName;
	}
	public void setLoaneeName(String loaneeName) {
		this.loaneeName = loaneeName;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getIdentityType() {
		return identityType;
	}
	public void setIdentityType(String identityType) {
		this.identityType = identityType;
	}
	public String getIdentityNumber() {
		return identityNumber;
	}
	public void setIdentityNumber(String identityNumber) {
		this.identityNumber = identityNumber;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getGrantingAccNo() {
		return grantingAccNo;
	}
	public void setGrantingAccNo(String grantingAccNo) {
		this.grantingAccNo = grantingAccNo;
	}
	public String getBankCode() {
		return bankCode;
	}
	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public BigDecimal getInterestRate() {
		return interestRate;
	}
	public void setInterestRate(BigDecimal interestRate) {
		this.interestRate = interestRate;
	}
	public BigDecimal getAppliedAmount() {
		return appliedAmount;
	}
	public void setAppliedAmount(BigDecimal appliedAmount) {
		this.appliedAmount = appliedAmount;
	}
	public Long getInstalments() {
		return instalments;
	}
	public void setInstalments(Long instalments) {
		this.instalments = instalments;
	}
	public String getInstalmentsUnit() {
		return instalmentsUnit;
	}
	public void setInstalmentsUnit(String instalmentsUnit) {
		this.instalmentsUnit = instalmentsUnit;
	}
	public String getLoanStatus() {
		return loanStatus;
	}
	public void setLoanStatus(String loanStatus) {
		this.loanStatus = loanStatus;
	}
	public String getPurpose() {
		return purpose;
	}
	public void setPurpose(String purpose) {
		this.purpose = purpose;
	}
	public Date getValueDate() {
		return valueDate;
	}
	public void setValueDate(Date valueDate) {
		this.valueDate = valueDate;
	}
	public Date getDueDate() {
		return dueDate;
	}
	public void setDueDate(Date dueDate) {
		this.dueDate = dueDate;
	}
	public String getMonthlyRepayDay() {
		return monthlyRepayDay;
	}
	public void setMonthlyRepayDay(String monthlyRepayDay) {
		this.monthlyRepayDay = monthlyRepayDay;
	}
	public BigDecimal getTotalInsuranceFee() {
		return totalInsuranceFee;
	}
	public void setTotalInsuranceFee(BigDecimal totalInsuranceFee) {
		this.totalInsuranceFee = totalInsuranceFee;
	}
	public BigDecimal getTotalInterest() {
		return totalInterest;
	}
	public void setTotalInterest(BigDecimal totalInterest) {
		this.totalInterest = totalInterest;
	}
	public BigDecimal getTotalRepayAmount() {
		return totalRepayAmount;
	}
	public void setTotalRepayAmount(BigDecimal totalRepayAmount) {
		this.totalRepayAmount = totalRepayAmount;
	}
	public String getGuaranteeCompany() {
		return guaranteeCompany;
	}
	public void setGuaranteeCompany(String guaranteeCompany) {
		this.guaranteeCompany = guaranteeCompany;
	}
	public BigDecimal getGuaranteeRate() {
		return guaranteeRate;
	}
	public void setGuaranteeRate(BigDecimal guaranteeRate) {
		this.guaranteeRate = guaranteeRate;
	}
	public BigDecimal getGuaranteeAmount() {
		return guaranteeAmount;
	}
	public void setGuaranteeAmount(BigDecimal guaranteeAmount) {
		this.guaranteeAmount = guaranteeAmount;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Date getCreatedAt() {
		return createdAt;
	}
	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}
	public Date getUpdatedAt() {
		return updatedAt;
	}
	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}
	public String getAsLoanRequestCode() {
		return asLoanRequestCode;
	}
	public void setAsLoanRequestCode(String asLoanRequestCode) {
		this.asLoanRequestCode = asLoanRequestCode;
	}
	public Long getAsLoanRequestId() {
		return asLoanRequestId;
	}
	public void setAsLoanRequestId(Long asLoanRequestId) {
		this.asLoanRequestId = asLoanRequestId;
	}
	
	public Boolean isBaiLinDai() {
		return "1000200020".equals(asProductType);
	}

}
