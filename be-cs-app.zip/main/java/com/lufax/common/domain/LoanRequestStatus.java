package com.lufax.common.domain;

public enum LoanRequestStatus {
    WAITING_CHECK("等待审核", "待审核"), // 0
    CHECK_SUCCESS("审核成功", "审核成功"), //
    WAITING_INVEST("等待投资", "待投资"),  // 1

    CHECK_FAILED("审核失败", "失败(审核失败)"), // 2
    LOANEE_TELEPHONE_DENIED("申请失败", "申请失败(借款人电话签约失败)"),

    UN_CHECK_EXPIRED("失败(审核超时)", "失败(申请审核超时)"), //5 
    UN_INVESTED_EXPIRED("失败(投资超时)", "失败(超时)"),

    CANCELED("失败", "取消"),
    SUCCESS("成功", "成功"), //4 

    //  todo should be deleted since the way of invest modified
    UN_APPLY_EXPIRED("失败", "失败(申请失败)"),     //可删除
    WAITING_CONFIRM("确认合同", "待确认合同"),   //可删除
    LOANEE_WEBSITE_DENIED("失败", "失败(借款人网上拒绝)"),      // 可删除
    UN_CONFIRMED_EXPIRED("失败", "失败(超时)"),   // 可删除
    UNKNOWN_STATUS("未知状态","未知状态"),
    INVESTED("已放款", "投资完成"); // 3


    private String desc;
    private String customerServiceDesc;

    LoanRequestStatus(String desc, String customerServiceDesc) {
        this.desc = desc;
        this.customerServiceDesc = customerServiceDesc;
    }

    public String getDesc() {
        return desc;
    }

    public String getCustomerServiceDesc() {
        return customerServiceDesc;
    }

    public static String getFailureCodeForUnconfirmedLoanRequest(LoanRequestStatus status) {
        switch (status) {
            case UN_CONFIRMED_EXPIRED:
                return "01";
            case LOANEE_WEBSITE_DENIED:
                return "02";
            case LOANEE_TELEPHONE_DENIED:
                return "03";
            default:
                return "04";
        }
    }

    public static String getFailureCodeForMatchResult(LoanRequestStatus status) {
        switch (status) {
            case UN_INVESTED_EXPIRED:
                return "01";
            case CANCELED:
                return "02";
            case LOANEE_TELEPHONE_DENIED:
                return "03";
            default:
                return "";
        }
    }

    public static LoanRequestStatus getLoanRequestStatusByName(String status){
        LoanRequestStatus[] loanRequestStatuses=LoanRequestStatus.values();
        for(LoanRequestStatus loanRequestStatus:loanRequestStatuses)
            if(loanRequestStatus.name().equalsIgnoreCase(status))
                return loanRequestStatus;
        return LoanRequestStatus.UNKNOWN_STATUS;

    }
}