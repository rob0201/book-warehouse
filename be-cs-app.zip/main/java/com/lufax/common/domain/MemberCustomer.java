package com.lufax.common.domain;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "MEMBER_CUSTOMER")
public class MemberCustomer {
    @Id
    @Column(name = "PARTY_NO")
    private String partyNo;

    @Column(name = "NAME")
    private String name;

    @Column(name = "SEX")
    private String sex;

    @Column(name = "ID_TYPE")
    private String idType;
    @Column(name = "ID_NO")
    private String idNo;

    @Column(name = "BIRTH_DATE")
    private Date birthDate;

    @Column(name = "AREA_CODE")
    private String areaCode;
    @Column(name = "PHONE_CODE")
    private String phoneCode;
    @Column(name = "EMAIL_VERIFY_STATUS")
    private String emailVerifyStatus;

    @Column(name = "RISK_VERIFY_STATUS")
    private String riskVerifyStatus;

    public MemberCustomer() {
    }

    public String getPartyNo() {
        return partyNo;
    }

    public void setPartyNo(String partyNo) {
        this.partyNo = partyNo;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getIdType() {
        return idType;
    }

    public void setIdType(String idType) {
        this.idType = idType;
    }

    public String getIdNo() {
        return idNo;
    }

    public void setIdNo(String idNo) {
        this.idNo = idNo;
    }

    public Date getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(Date birthDate) {
        this.birthDate = birthDate;
    }

    public String getAreaCode() {
        return areaCode;
    }

    public void setAreaCode(String areaCode) {
        this.areaCode = areaCode;
    }

    public String getPhoneCode() {
        return phoneCode;
    }

    public void setPhoneCode(String phoneCode) {
        this.phoneCode = phoneCode;
    }

    public String getEmailVerifyStatus() {
        return emailVerifyStatus;
    }

    public void setEmailVerifyStatus(EmailVerifyStatus emailVerifyStatus) {
        this.emailVerifyStatus = emailVerifyStatus.getValue();
    }

    public String getRiskVerifyStatus() {
        return riskVerifyStatus;
    }

    public void setRiskVerifyStatus(RiskVerifyStatus riskVerifyStatus) {
        this.riskVerifyStatus = riskVerifyStatus.getValue();
    }
}
