package com.lufax.common.domain.product;


import java.util.ArrayList;
import java.util.List;

public enum AdminOperationType {
    UNPLANED_TO_ONLINE(Type.ONLINE_OR_OFFLINE,"从未计划到上架"),
    ONLINE_TO_OFFLINE(Type.ONLINE_OR_OFFLINE,"从上架到下架"),
    OFFLINE_TO_ONLINE(Type.ONLINE_OR_OFFLINE,"从下架到上架"),
    CONFIRM_GUARANTEE_COMPENSATION(Type.CONFIRM_GUARANTEE_COMPENSATION,"确认担保代偿"),
    ADMIN_CHECK_SYSTEM_FUND_RECORDS(Type.ADMIN_CHECK_SYSTEM_FUND_RECORDS,"查看系统资金记录"),
    ADMIN_CHECK_RECONCILIATION_FILE(Type.ADMIN_CHECK_RECONCILIATION_FILE,"查看对账文件");

    private String value;
    private  Type type;
    AdminOperationType(Type type,String value) {
        this.type=type;
        this.value = value;
    }
    public String getValue() {
        return value;
    }

    public Type getType() {
        return type;
    }

    public void setType(Type type) {
        this.type = type;
    }

    public static enum Type {
        ONLINE_OR_OFFLINE,
        CONFIRM_GUARANTEE_COMPENSATION,
        ADMIN_CHECK_SYSTEM_FUND_RECORDS,
        ADMIN_CHECK_RECONCILIATION_FILE;


        public List<AdminOperationType> getTypes() {
            List<AdminOperationType> result = new ArrayList<AdminOperationType>();
            for (AdminOperationType status : AdminOperationType.values()) {
                if (this.equals(status.type)) {
                    result.add(status);
                }
            }
            return result;
        }
    }
}
