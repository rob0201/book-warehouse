package com.lufax.common.domain.product;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "PRODUCT_HISTORY")
public class ProductHistory {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_PRODUCT_SCH")
    @SequenceGenerator(name = "SEQ_PRODUCT_SCH", sequenceName = "SEQ_PRODUCT_SCH", allocationSize = 1)
    private long id;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "PRODUCT_ID", nullable = false)
    private Product product;

//    @Enumerated(EnumType.STRING)
    @Column(name = "NEW_STATUS")
    private String newStatus;

    @Column(name = "CREATED_AT")
    private Date createdAt;

    public ProductHistory() {
    }

    public ProductHistory(Product product) {
        this.product = product;
        this.newStatus = (product.getProductStatus()!=null)?product.getProductStatus():null;
        this.createdAt = new Date();
    }

    public long id(){
        return id;
    }

    public ProductStatus getNewStatus() {
        return ProductStatus.getProductStatusByName(newStatus);
    }

    public Product getProduct() {
        return product;
    }
}
