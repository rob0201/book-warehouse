package com.lufax.common.domain.product.repository;

import com.lufax.customerService.domain.AdminOperationLog;
import com.lufax.common.domain.repository.BaseRepository;
import org.springframework.stereotype.Repository;

@Repository
public class AdminOperationLogRepository extends BaseRepository<AdminOperationLog>{


}
