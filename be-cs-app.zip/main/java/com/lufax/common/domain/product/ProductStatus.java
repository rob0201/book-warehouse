package com.lufax.common.domain.product;

public enum ProductStatus {
    UNPLANNED("未计划"),
    PREVIEW("预览"),
    PLANNED("已计划"),
    ONLINE("已上架"),
    OFFLINE("强制下架"),
    EXPIRED("过期下架"),
    DONE("完成"),
    CANCELED("取消"),
    REJECTED("电话拒绝"),
    UNKNOWN("unknown");

    private String value;

    ProductStatus(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
    public static ProductStatus getProductStatusByName(String status){
        ProductStatus[] productStatuses=ProductStatus.values();
        for(ProductStatus productStatus:productStatuses)
            if(productStatus.name().equalsIgnoreCase(status))
                return productStatus;
        return UNKNOWN;
    }

    public static ProductStatus getProductStatusByOrdinal(int ordinal){
        ProductStatus[] productStatuses=ProductStatus.values();
        for(ProductStatus productStatus:productStatuses)
            if(productStatus.ordinal()==ordinal)
                return productStatus;
        return UNKNOWN;
    }

}
