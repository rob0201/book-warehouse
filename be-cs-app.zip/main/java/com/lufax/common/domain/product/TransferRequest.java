package com.lufax.common.domain.product;

import static com.lufax.common.domain.account.Money.ZERO_YUAN;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Version;

import com.lufax.common.domain.Investment;
import com.lufax.common.domain.User;
import com.lufax.common.domain.account.Money;
import static com.lufax.common.domain.product.TransferCancelType.*;

@Entity
@Table(name = "TRANSFER_REQUESTS")
public class TransferRequest {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_TRANSFER_REQUESTS")
    @SequenceGenerator(name = "SEQ_TRANSFER_REQUESTS", sequenceName = "SEQ_TRANSFER_REQUESTS", allocationSize = 1)
    private long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "INVESTMENT_ID")
    private Investment investment;

    @Column(name = "TRANSFER_USER_ID")
    private long transferUserId;

    @Enumerated(EnumType.STRING)
    @Column(name = "STATUS")
    private TransferRequestStatus status;

    @Column(name = "SCAN_FLAG")
    private Boolean scanFlag;

    @Column(name = "REMARK")
    private String remark;

    @Column(name = "CREATED_AT")
    private Date createdAt;

    @Column(name="CODE")
    private String code;
    
    @Column(name = "UPDATED_AT")
    private Date updatedAt;

    @Version
    private long version;

    @OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL, mappedBy = "transferRequest")
    private TransferRequestData transferRequestData;

    public TransferRequest() {

    }

    public TransferRequest(Investment investment, TransferRequestStatus status) {
        this(investment, status, "");
    }

    public TransferRequest(Investment investment, TransferRequestStatus status, String remark) {
        this.investment = investment;
        this.status = status;
        this.transferUserId = investment.getLoaner().id();
        this.scanFlag = false;
        this.remark = remark;
        this.createdAt = new Date();
        this.updatedAt = createdAt;
    }

    public Money getPrincipal() {
        return transferRequestData == null ? ZERO_YUAN : transferRequestData.getTransferPrincipal();
    }

    public int getNumberOfInstalments() {
        return transferRequestData == null ? null : transferRequestData.getTransferInstalments();
    }

    public Money getTransferFee() {
        return transferRequestData == null ? ZERO_YUAN : transferRequestData.getTransferFee();
    }

    public BigDecimal getInterestRate() {
        return transferRequestData == null ? null : transferRequestData.getInterestRate();
    }

    public User getSubmitUser() {
        return transferRequestData == null ? null : transferRequestData.getSubmitUser();
    }

    public TransferRequestData getTransferRequestData() {
        return transferRequestData;
    }

    public TransferRequestStatus getStatus() {
        return status;
    }

    public Boolean isTransferApplied() {
        return TransferRequestStatus.TRANSFER_APPLIED.equals(status);
    }

    public Boolean isTransferSuccess() {
        return TransferRequestStatus.TRANSFER_SUCCESS.equals(status);
    }

    public Boolean isTransferable() {
        return TransferRequestStatus.TRANSFERABLE.equals(status);
    }

    public Boolean isNotTransferable() {
        return TransferRequestStatus.NON_TRANSFERABLE.equals(status);
    }

    public Boolean isCancelled() {
        return TransferRequestStatus.TRANSFER_CANCELLED.equals(status);
    }

    public Boolean isSystemExpireCancelled() {
        return isCancelled() && remark.equals(SYSTEM_EXPIRE.getValue());
    }

    public Boolean isSystemPrepayCancelled() {
        return isCancelled() && remark.equals(SYSTEM_PREPAY.getValue());
    }

    public Boolean isManualCancelled() {
        return isCancelled() && remark.equals(USER.getValue());
    }

    public Investment getInvestment() {
        return investment;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public long getTransferUserId() {
        return transferUserId;
    }

    public Boolean getScanFlag() {
        return scanFlag;
    }

    public void setTransferRequestData(TransferRequestData transferRequestData) {
        this.transferRequestData = transferRequestData;
    }

    public Long id() {
        return id;
    }

    public void setScanFlag(Boolean scanFlag) {
        this.scanFlag = scanFlag;
    }

	public String getCode() {
		return code;
	}

	public String getRemark() {
		return remark;
	}

	public Date getUpdatedAt() {
		return updatedAt;
	}
    
}
