package com.lufax.common.domain.product;

public enum ProductType {
    LOAN_REQUEST,
    TRANSFER_REQUEST,
    TIME_SPLIT,
    UNKNOWN;
    public static ProductType getProductTypeBYOrdinal(int ordinal){
        ProductType[] productTypes=ProductType.values();
        for(ProductType productType:productTypes)
            if(productType.ordinal()==ordinal)
                return productType;
        return UNKNOWN;
    }
    
    public static ProductType getProductTypeByName(String name){
        ProductType[] productTypes=ProductType.values();
        for(ProductType productType:productTypes)
            if(productType.name().equals(name))
                return productType;
        return UNKNOWN;
    }
}
