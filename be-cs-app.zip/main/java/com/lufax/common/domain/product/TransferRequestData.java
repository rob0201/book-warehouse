package com.lufax.common.domain.product;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Version;

import com.lufax.common.domain.Investment;
import com.lufax.common.domain.User;
import com.lufax.common.domain.account.Money;

@Entity
@Table(name = "TRANSFER_REQUEST_DATA")
public class TransferRequestData {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_TRANSFER_REQUEST_DATA")
    @SequenceGenerator(name = "SEQ_TRANSFER_REQUEST_DATA", sequenceName = "SEQ_TRANSFER_REQUEST_DATA", allocationSize = 1)
    private long id;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "TRANSFER_REQUEST_ID")
    private TransferRequest transferRequest;

    @Column(name = "INVESTMENT_ID")
    private long investmentId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "TRANSFER_USER_ID")
    private User submitUser;

    @Column(name = "TRANSFER_INSTALMENTS")
    private int transferInstalments;

    @Embedded
    @AttributeOverrides({@AttributeOverride(name = "amount", column = @Column(name = "TRANSFER_PRINCIPAL"))})
    private Money transferPrincipal;

    @Embedded
    @AttributeOverrides({@AttributeOverride(name = "amount", column = @Column(name = "UN_COLLECT_INTEREST"))})
    private Money unCollectInterest;

    @Embedded
    @AttributeOverrides({@AttributeOverride(name = "amount", column = @Column(name = "UN_COLLECT_PENALTY"))})
    private Money unCollectPenalty;

    @Column(name = "INTEREST_START_AT")
    private Date interestStartAt;

    @Column(name = "INTEREST_RATE")
    protected BigDecimal interestRate;

    @Embedded
    @AttributeOverrides({@AttributeOverride(name = "amount", column = @Column(name = "TRANSFER_PRICE"))})
    private Money transferPrice;

    @Embedded
    @AttributeOverrides({@AttributeOverride(name = "amount", column = @Column(name = "TRANSFER_FEE"))})
    private Money transferFee;

    @Column(name = "CREATED_AT")
    private Date createdAt;

    @Column(name = "UPDATED_AT")
    private Date updatedAt;

    @Version
    private long version;

    public TransferRequestData(String code, TransferRequest transferRequest, Money transferFee) {
        Investment investment = transferRequest.getInvestment();
        this.transferRequest = transferRequest;
        this.investmentId = investment.id();
        this.submitUser = investment.getLoaner();
        this.transferInstalments = investment.getRemainingInstalments();
//        this.transferPrincipal = investment.getTotalPrincipalOfUnpaidPlan();
//        this.unCollectInterest = investment.getCurrentCollectionPlanInterestTillNow();
//        this.unCollectPenalty = investment.getCurrentCollectionPlan().getOverduePenaltyToCollect();
//        this.interestRate = investment.getCurrentCollectionPlan().getInterestRate();
//        this.interestStartAt = investment.getCurrentCollectionPlanStartAt();
        this.transferPrice = this.transferPrincipal;
        this.transferFee = transferFee;
        this.createdAt = new Date();
        this.updatedAt = this.createdAt;
    }

    public TransferRequestData() {

    }

    public TransferRequestData(String code, TransferRequest transferRequest, Investment investment, User submitUser, int transferInstalments, Money transferPrincipal, Money unCollectInterest, Money unCollectPenalty, BigDecimal interestRate, Date interestStartAt, Money transferPrice, Money transferFee, Date createdAt) {
        this.transferRequest = transferRequest;
        this.investmentId = investment.id();
        this.submitUser = submitUser;
        this.transferInstalments = transferInstalments;
        this.transferPrincipal = transferPrincipal;
        this.unCollectInterest = unCollectInterest;
        this.unCollectPenalty = unCollectPenalty;
        this.interestRate = interestRate;
        this.interestStartAt = interestStartAt;
        this.transferPrice = transferPrice;
        this.transferFee = transferFee;
        this.updatedAt = this.createdAt = createdAt;
    }

    public Money getTransferFee() {
        return transferFee;
    }

    public User getSubmitUser() {
        return submitUser;
    }

    public Money getTransferPrincipal() {
        return transferPrincipal;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public int getTransferInstalments() {
        return transferInstalments;
    }

    public BigDecimal getInterestRate() {
        return interestRate;
    }

    public Money getTransferPrice() {
        return transferPrice;
    }

    public Money getUnCollectInterest() {
        return unCollectInterest;
    }

    public Money getUnCollectPenalty() {
        return unCollectPenalty;
    }

    public Date getInterestStartAt() {
        return interestStartAt;
    }
}
