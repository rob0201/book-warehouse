package com.lufax.common.domain.product;

public enum ProductTradingFeeType {
    TRANSFER_FEE
}
