package com.lufax.common.domain.product.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.lufax.common.domain.product.Product;
import com.lufax.common.domain.product.ProductHistory;
import com.lufax.common.domain.product.ProductStatus;
import com.lufax.common.domain.repository.BaseRepository;
import com.lufax.common.web.helper.ConstantsHelper;

@Repository
public class ProductHistoryRepository extends BaseRepository<ProductHistory> {

    public List<ProductHistory> findByProductAndType(Product product, ProductStatus productStatus) {
        return entityManager.createQuery("select ph from ProductHistory ph where ph.product=:product and ph.newStatus=:type")
                .setParameter("product", product).setParameter("type", productStatus.name()).getResultList();
    }

    public List<ProductHistory> findByProduct(Product product) {
        return entityManager.createQuery("select ph from ProductHistory ph where ph.product=:product")
                .setParameter("product", product).getResultList();
    }
    
    public List<ProductHistory> findRecentSoldProducts() {
        return entityManager.createQuery("select ph from ProductHistory ph left join fetch ph.product where ph.productStatus=:productStatus order by ph.createdAt desc", ProductHistory.class)
                .setParameter("productStatus", ProductStatus.DONE.name()).setMaxResults(ConstantsHelper.PAGE_LIMIT).getResultList();
    }
}

