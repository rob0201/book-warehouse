package com.lufax.common.domain.product;


public enum TransferRequestStatus {
    TRANSFERABLE,
    NON_TRANSFERABLE,
    TRANSFER_APPLIED,
    TRANSFER_SUCCESS,
    TRANSFER_CANCELLED,
    UNKOWN;
    
    public static TransferRequestStatus getTransferRequestStatusByName(String name){
    	TransferRequestStatus[] statuses = TransferRequestStatus.values();
    	for(TransferRequestStatus status:statuses){
    		if(status.name().equals(name)){
    			return status;
    		}
    	}
    	return UNKOWN;
    }
}
