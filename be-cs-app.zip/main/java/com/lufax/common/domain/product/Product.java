package com.lufax.common.domain.product;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.OrderBy;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Version;

import com.lufax.customerService.domain.ProductGroupRelation;
import org.joda.time.DateTime;

import com.lufax.common.domain.LoanRequest;
import com.lufax.common.domain.User;
import com.lufax.common.domain.account.Money;

@Entity
@Table(name = "PRODUCTS")
public class Product {
	@Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_PRODUCTS")
    @SequenceGenerator(name = "SEQ_PRODUCTS", sequenceName = "SEQ_PRODUCTS", allocationSize = 1)
    private long id;

    @Embedded
    @AttributeOverrides({@AttributeOverride(name = "amount", column = @Column(name = "PRICE"))})
    private Money price;

    @Embedded
    @AttributeOverrides({@AttributeOverride(name = "amount", column = @Column(name = "PRINCIPAL"))})
    private Money principal;

    @Column(name = "INTEREST_RATE")
    private BigDecimal interestRate;

    @Column(name = "NUM_OF_INSTALMENTS")
    private int numberOfInstalments;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "LOAN_REQUEST_ID")
    private LoanRequest loanRequest;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "SOURCE_ID")
    private TransferRequest transferRequest;

//    @Enumerated(EnumType.STRING)
    @Column(name = "PRODUCT_TYPE")
    private String productType;

//    @Enumerated(EnumType.STRING)
    @Column(name = "PRODUCT_STATUS")
    private String productStatus;

    @Column(name = "PUBLISHED_AT")
    private Date publishedAt;

    @Column(name = "EXPIRED_AT")
    private Date expiredAt;

    @Column(name = "PREVIOUS_PRODUCT_ID")
    private Long previousProductId;

    @Column(name = "ROOT_PRODUCT_ID")
    private Long rootProductId;

    @Column(name = "CREATED_AT")
    private Date createdAt;

    @Column(name = "UPDATED_AT")
    private Date updatedAt;

    @Column(name = "CODE")
    private String code;

    @Version
    private long version;
    
    @Column(name = "COLLECTION_MODE")
    private String productCollectionMode;

    @Column(name = "PRODUCT_NAME")
    private String productName;

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "product")
    @OrderBy("id ASC")
    private List<TradingHistory> tradingHistories;
    
    @OneToMany(fetch = FetchType.LAZY, mappedBy = "productRelation")
    @OrderBy(" createDate DESC")
    private List<ProductGroupRelation> productGroupRelations;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "BUYER_USER_ID")
    private User buyer;
    
    @Column(name="preview_at")
    private Date previewStartTime;
    
    @Column(name="SOURCE_TYPE")
    private String sourceType;
    
    @Column(name="PRODUCT_CATEGORY")
    private String productCategory;
    
    

    public String getProductCategory() {
		return productCategory;
	}

	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}

	public String getSourceType() {
		return sourceType;
	}

    @Column(name="BUYER_TRANSACTION_FEE")
    private BigDecimal buyerTransactionFee;

    
	public Product() {
    }

    public Product(LoanRequest loanRequest, int expiredDays) {
        this.productType = ProductType.LOAN_REQUEST.name();
        this.loanRequest = loanRequest;
        this.productStatus = ProductStatus.UNPLANNED.name();
        Date date = new Date();
        this.createdAt = date;
        this.updatedAt = date;
        this.expiredAt = new DateTime().plusDays(expiredDays).toDate();
    }
    
    public Product(LoanRequest loanRequest, Date expiredAt) {
        this(expiredAt);
        this.loanRequest = loanRequest;
        this.productType = ProductType.LOAN_REQUEST.name();
        this.price = loanRequest.getAppliedAmount();
        this.principal = loanRequest.getAppliedAmount();
        this.numberOfInstalments = loanRequest.getNumberOfInstalments();
        this.interestRate = loanRequest.getInterestRate();
        this.code = loanRequest.getCode();
    }

    public Product(TransferRequest transferRequest, Date expiredAt) {
        this(expiredAt);
        this.transferRequest = transferRequest;
        this.productType = ProductType.TRANSFER_REQUEST.name();
        this.price = transferRequest.getPrincipal();
        this.principal = transferRequest.getPrincipal();
        this.numberOfInstalments = transferRequest.getNumberOfInstalments();
        this.interestRate = transferRequest.getInterestRate();
        this.code = transferRequest.getCode();
    }

    public Product(TransferRequest transferRequest, Date expiredAt, long previousProductId, long rootProductId) {
        this(transferRequest, expiredAt);
        this.productStatus= ProductStatus.ONLINE.name();
        this.previousProductId = previousProductId;
        this.rootProductId = rootProductId;
    }

    public Product(Date expiredAt) {
        this.productStatus = ProductStatus.UNPLANNED.name();
        this.expiredAt = expiredAt;
        this.createdAt = new Date();
        this.updatedAt = new Date();
    }

    public boolean isPrimary() {
        return ProductType.LOAN_REQUEST.name().equals(productType);
    }

    public boolean isSecondary() {
        return ProductType.TRANSFER_REQUEST.name().equals(productType);
    }
    public boolean isSplited() {
        return ProductType.TIME_SPLIT.name().equals(productType);
    }

    public long id() {
        return id;
    }

    public LoanRequest getLoanRequest() {
        return loanRequest;
    }

    public String getProductType() {
        return productType;
    }

    public String getProductStatus() {
        return productStatus;
    }

    public String getProductCode() {
        return code;
    }

    public Date getUpdatedAt() {
        return updatedAt;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public Date getExpiredAt() {
        return expiredAt;
    }

    public boolean isDone() {
        return ProductStatus.DONE.name().equals(getProductStatus());
    }

    public boolean isOnline() {
        return ProductStatus.ONLINE.name().equals(getProductStatus());
    }

    public boolean canExpire() {
        return productStatus != ProductStatus.EXPIRED.name() && productStatus != ProductStatus.DONE.name() && productStatus != ProductStatus.CANCELED.name();
    }

    public boolean canCancel() {
        return productStatus != ProductStatus.EXPIRED.name() && productStatus != ProductStatus.DONE.name() && productStatus != ProductStatus.CANCELED.name();
    }

    public Money getPrice() {
        return price;
    }

    public Money getPrincipal() {
        return principal;
    }

    public BigDecimal getInterestRate() {
        return interestRate;
    }

    public int getNumberOfInstalments() {
        return numberOfInstalments;
    }

    public long getRootProductId() {
        if (null == rootProductId || 0 == rootProductId) {
            return previousProductId;
        }
        return rootProductId;
    }

    public Date getPublishedAt() {
        return publishedAt;
    }
    
    public String getLoanRequestCode() {
        return loanRequest.getCode();
    }


    public void setProductStatus(String productStatus) {
        this.productStatus = productStatus;
    }

    public void setExpiredAt(Date expiredAt) {
        this.expiredAt = expiredAt;
    }

    public void setUpdatedAt(Date updatedAt) {
        this.updatedAt = updatedAt;
    }

    public void setBuyer(User buyer) {
        this.buyer = buyer;
    }

    public User getBuyer() {
        return buyer;
    }

    
   
	public TransferRequest getTransferRequest() {
		return transferRequest;
	}

	@Deprecated
    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

	public List<TradingHistory> getTradingHistories() {
		return tradingHistories;
	}

	
	public List<ProductGroupRelation> getProductGroupRelations() {
		return productGroupRelations;
	}

	public void setPublishedAt(Date publishedAt) {
		this.publishedAt = publishedAt;
	}

	public String getProductCollectionMode() {
		return productCollectionMode;
	}

	public String getProductName() {
		return productName;
	}

	public Date getPreviewStartTime() {
		return previewStartTime;
	}

    public BigDecimal getBuyerTransactionFee() {
        return buyerTransactionFee;
    }

    public void setBuyerTransactionFee(BigDecimal buyerTransactionFee) {
        this.buyerTransactionFee = buyerTransactionFee;
    }
}
