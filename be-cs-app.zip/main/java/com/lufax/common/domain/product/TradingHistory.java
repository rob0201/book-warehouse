package com.lufax.common.domain.product;

import java.util.Date;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.lufax.common.domain.User;
import com.lufax.common.domain.account.Money;

@Entity
@Table(name = "TRADING_HISTORY")
public class TradingHistory {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_TRADING_HISTORY")
    @SequenceGenerator(name = "SEQ_TRADING_HISTORY", sequenceName = "SEQ_TRADING_HISTORY", allocationSize = 1)
    private long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "PRODUCT_ID")
    private Product product;

    @Embedded
    @AttributeOverrides({@AttributeOverride(name = "amount", column = @Column(name = "FEE"))})
    private Money fee;

//    @Enumerated(EnumType.STRING)
    @Column(name = "FEE_TYPE")
    private String productTradingFeeType;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "BUYER_USER_ID")
    private User buyerUserId;

    @Column(name = "CREATED_AT")
    private Date createdAt;


    public TradingHistory() {
    }
}
