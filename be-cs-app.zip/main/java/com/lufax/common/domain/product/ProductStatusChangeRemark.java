package com.lufax.common.domain.product;

public enum ProductStatusChangeRemark {
    NONE("无"),
    MANUAL_CANCEL("手动撤销"),
    PREPAY_CANCEL("提前还款撤销");

    private String value;

    ProductStatusChangeRemark(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    public boolean isManualCancel() {
        return this.equals(MANUAL_CANCEL);
    }

    public boolean isPrepayCancel() {
        return this.equals(PREPAY_CANCEL);
    }
}
