package com.lufax.common.domain.product;

public enum TransferCancelType {
    SYSTEM_EXPIRE("system_expire"),
    SYSTEM_PREPAY("system_prepay"),
    USER("user");

    private String value;

    TransferCancelType(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
