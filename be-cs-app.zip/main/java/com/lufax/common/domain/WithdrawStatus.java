package com.lufax.common.domain;

public enum WithdrawStatus {
    NEW("新建"),
    PROCESSING("处理中"),
    SUCCESS("成功"),
    FAILURE("失败"),
    UNKNOWN("unknown");

    private String value;

    WithdrawStatus(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
    public static WithdrawStatus getWithdrawStatusByName(String name){
        WithdrawStatus[]  withdrawStatuses=WithdrawStatus.values();
        for(WithdrawStatus withdrawStatus:withdrawStatuses)
            if(withdrawStatus.name().equalsIgnoreCase(name))
                return withdrawStatus;
        return UNKNOWN;
    }
}
