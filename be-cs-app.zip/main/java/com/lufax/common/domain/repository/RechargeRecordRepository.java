package com.lufax.common.domain.repository;

import com.lufax.common.domain.RechargeRecord;
import com.lufax.common.domain.RechargeStatus;
import com.lufax.common.domain.RechargeType;
import com.lufax.common.domain.User;
import com.lufax.common.domain.account.Money;
import com.lufax.common.utils.DateRange;
import com.lufax.common.utils.DevLog;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

@Repository
public class RechargeRecordRepository extends BaseRepository<RechargeRecord> {
    public List<RechargeRecord> findAllByUser(User user) {
        return entityManager.createQuery("select rr from RechargeRecord rr where rr.user.id=:userId order by rr.rechargeAt desc, rr.tradeNo desc", RechargeRecord.class).setParameter("userId", user.id()).getResultList();
    }

    public RechargeRecord findByTradeNo(String tradeNo) {
        return entityManager.createQuery("select rr from RechargeRecord rr where rr.tradeNo=:tradeNo", RechargeRecord.class).setParameter("tradeNo", tradeNo).getSingleResult();
    }

    public List<RechargeRecord> findAllByTypeAndTradeTime(RechargeType rechargeType, DateRange dateRange, int offset, int limit) {
        DevLog.info(this,String.format("The startDate is [%s], the endDate is [%s]", dateRange.getStartDate(),dateRange.getEndDate()));
    	return entityManager.createQuery("select rr from RechargeRecord rr left join fetch rr.user where rr.tradeTime>=:startDate and rr.tradeTime<:endDate and rr.rechargeType=:rechargeType order by rr.tradeTime", RechargeRecord.class)
                .setParameter("startDate", dateRange.getStartDate())
                .setParameter("endDate", dateRange.getEndDate())
                .setParameter("rechargeType", rechargeType.name())
                .setFirstResult(offset)
                .setMaxResults(limit)
                .getResultList();
    }

    @Override
    @Transactional
    public RechargeRecord update(RechargeRecord record) {
        record.setUpdatedAt(new Date());
        return super.update(record);
    }

    @Override
    @Transactional
    public void persist(RechargeRecord record) {
        record.setUpdatedAt(new Date());
        super.persist(record);
    }

    public Money getSuccessfulRechargeAmount(DateRange dateRange) {
        Money result = entityManager.createQuery("select sum(rr.amount) from RechargeRecord rr where rr.updatedAt >= :startDate and rr.updatedAt < :endDate and rr.rechargeStatus=:rechargeStatus", Money.class)
                .setParameter("startDate", dateRange.getStartDate())
                .setParameter("endDate", dateRange.getEndDate())
                .setParameter("rechargeStatus", RechargeStatus.SUCCESS.name())
                .getSingleResult();
        if (result == null) {
            return Money.ZERO_YUAN;
        }
        return result;
    }

    public List<RechargeRecord> findContractUnUploadedRecords(int batchAmount) {
        return entityManager.createQuery("select rr from RechargeRecord rr left join fetch rr.user where not exists (select 1 from RechargeContract rc where rc.rechargeRecord = rr)", RechargeRecord.class).
                setMaxResults(batchAmount).getResultList();
    }
}
