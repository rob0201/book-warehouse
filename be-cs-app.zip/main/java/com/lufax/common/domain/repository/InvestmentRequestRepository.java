package com.lufax.common.domain.repository;

import java.util.List;

import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.lufax.common.domain.InvestmentRequest;
import com.lufax.common.domain.InvestmentRequestStatus;
import com.lufax.common.domain.LoanRequest;
import com.lufax.common.domain.User;

@Repository
public class InvestmentRequestRepository extends BaseRepository<InvestmentRequest> {
    public InvestmentRequest findByLoanRequest(LoanRequest loanRequest) {
        return findFirst("select r from InvestmentRequest as r left join fetch r.loaner where r.loanRequest=?1", loanRequest);
    }

    public InvestmentRequest findByLoanRequestCode(String loanRequestCode) {
        String query = "select ir from InvestmentRequest as ir left join fetch ir.loanRequest lr left join fetch ir.loaner l where lr.code=:loanRequestCode";
        return entityManager.createQuery(query, InvestmentRequest.class).setParameter("loanRequestCode", loanRequestCode).getSingleResult();
    }
    /**
     * 客服查询用户投资请求
     * @param loaner
     * @param status
     * @param maxNum
     * @param offset
     * @return
     */
    public long countForLoanerByStatus(User loaner, List<String> statuses) {
        StringBuffer queryStringBuffer = new StringBuffer("select r from InvestmentRequest r where r.loaner=:loaner ");
    	if (statuses != null && statuses.size() != 0) {
            queryStringBuffer.append(" and r.status in (:statuses)");
        }
        queryStringBuffer.append(" order by r.createdAt DESC");
        String queryString = queryStringBuffer.toString();

        TypedQuery query = entityManager.createQuery(queryString, InvestmentRequest.class).setParameter("loaner", loaner);
        if (statuses != null && statuses.size() != 0) {
            query.setParameter("statuses", statuses);
        }
        List<InvestmentRequest> investmentRequests = query.getResultList();
        return investmentRequests.size();
    }
    
    public List<InvestmentRequest> findAllByLoanerAndStatus(User loaner, List<String> statuses,int maxNum,int offset) {
    	StringBuffer queryStringBuffer = new StringBuffer("select r from InvestmentRequest as r where r.loaner=:loaner ");
    	if (statuses != null && statuses.size() != 0) {
            queryStringBuffer.append(" and r.status in (:statuses)");
        }
        queryStringBuffer.append(" order by r.createdAt DESC");
        String queryString = queryStringBuffer.toString();

        TypedQuery query = entityManager.createQuery(queryString, InvestmentRequest.class).setParameter("loaner", loaner);
        if (statuses != null && statuses.size() != 0) {
            query.setParameter("statuses", statuses);
        }
        return query.setFirstResult(offset).setMaxResults(maxNum).getResultList();
    }
    
    public List<InvestmentRequest> findAllForLoanerByStatus(User loaner, InvestmentRequestStatus status) {
        String query = "select r from InvestmentRequest as r  where r.loaner=:loaner and r.status =:status order by r.createdAt DESC";
        return entityManager.createQuery(query, InvestmentRequest.class).setParameter("loaner", loaner).setParameter("status", status.name()).getResultList();
    }

    public List<InvestmentRequest> findAllForLoaner(User loaner) {
        String query = "select r from InvestmentRequest as r  where r.loaner=:loaner order by r.createdAt DESC";
        return entityManager.createQuery(query, InvestmentRequest.class).setParameter("loaner", loaner).getResultList();
    }



    public List<InvestmentRequest> findAllUnsent(int limit) {
        String query = "select r from InvestmentRequest as r where r.statusToXinbao is null";
        return entityManager.createQuery(query, InvestmentRequest.class).setMaxResults(limit).getResultList();
    }

    public InvestmentRequest findByPolicyNo(String policyNo) {
        String query = "select r from InvestmentRequest as r  where r.loanRequest.policy.policyNo =:policyNo";
        return getSingleResult(entityManager.createQuery(query, InvestmentRequest.class).setParameter("policyNo", policyNo));
    }
}
