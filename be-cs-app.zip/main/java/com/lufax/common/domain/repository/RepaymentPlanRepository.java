package com.lufax.common.domain.repository;

import com.lufax.common.domain.*;
import com.lufax.common.utils.DateUtils;
import org.apache.commons.lang.StringUtils;
import org.joda.time.DateTime;
import org.springframework.stereotype.Repository;

import javax.persistence.TypedQuery;
import java.util.Date;
import java.util.List;

import static com.lufax.common.domain.PlanStatus.OVERDUE;
import static com.lufax.common.domain.PlanStatus.UNPAID;

@Repository
public class RepaymentPlanRepository extends BaseRepository<RepaymentPlan> {



    public List<RepaymentPlan> findAllNeedToPayPlans(int batchAmount) {
        Date today = DateUtils.startOfToday();
        Date yesterday = new DateTime(today).minusDays(1).toDate();
        return entityManager.createQuery("select rp from RepaymentPlan rp left join fetch rp.loan l where l.status = :loanStatus and rp.status = :status and  rp.endAt between :yesterday and :today", RepaymentPlan.class).setParameter("loanStatus", TradingStatus.SIGNED).
                setParameter("status", PlanStatus.UNPAID.name()).setParameter("today", today).setParameter("yesterday", yesterday).setMaxResults(batchAmount).getResultList();
    }

    public List<RepaymentPlan> findAllByStatusTypeFor(User loanee, PlanStatus.Type type) {
        return entityManager.createQuery("select distinct p from RepaymentPlan p left join fetch p.loan l left join fetch p.records where p.loan.loanee=:loanee and p.status in (:statuses)", RepaymentPlan.class).setParameter("loanee", loanee).setParameter("statuses", type.getPlanStatus()).getResultList();
    }


    public List<RepaymentPlan> preloadAllByLoan(Loan loan) {
        return entityManager.createQuery("select distinct p from RepaymentPlan p left join fetch p.loan left join fetch p.records where p.loan=:loan order by p.planNumber asc", RepaymentPlan.class).setParameter("loan", loan).getResultList();
    }
}
