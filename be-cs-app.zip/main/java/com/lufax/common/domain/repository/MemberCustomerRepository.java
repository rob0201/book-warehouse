package com.lufax.common.domain.repository;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.lufax.common.domain.MemberCustomer;
import com.lufax.common.utils.EncryptUtils;
import com.lufax.customerService.resources.gsonTemplate.MessageInfoGson;
import com.lufax.customerService.resources.gsonTemplate.UserBankAutoInfoGson;
import com.lufax.jersey.utils.Logger;

@Repository
public class MemberCustomerRepository extends BaseRepository<MemberCustomer> {

    public MemberCustomer findByPartyNo(String partyNo) {
        return entityManager.createQuery("select u from MemberCustomer u where u.partyNo = :partyNo ", MemberCustomer.class).setParameter("partyNo", partyNo).getSingleResult();
    }

    public List<UserBankAutoInfoGson> findBankInfoByPartyNo(String partyNo) {
        String nativeSql = "SELECT DECODE(DECODE(mbu.status,'SUCCESS'," +
                " (SELECT max(mba.is_valid)" +
                " FROM member_bank_account mba" +
                " WHERE mbu.party_no  =mba.party_no" +
                " AND mba.bank_account=mbu.bank_account),mbu.status),'0','多卡无效','1','已认证','FAIL','失败','IN_AUTHENTICATE','未认证','未知') AS bank_auto_status," +
                " t.name," +
                " mbu.bank_account," +
                " to_char(mbu.created_at , 'yyyy-mm-dd hh24:mi:ss')  AS auth_amount_time," +
                " (SELECT to_char(max(mba.created_at), 'yyyy-mm-dd hh24:mi:ss')  as created_at" +
                " FROM member_bank_account mba" +
                " WHERE mbu.party_no  =mba.party_no" +
                " AND mbu.status      ='SUCCESS'" +
                " and mba.is_valid = 1 " +
                " AND mba.bank_account=mbu.bank_account" +
                " ) AS auto_time" +
                " FROM member_bank_bind_auth mbu," +
                " TBANKCODE t" +
                " WHERE mbu.bank_code=t.bankcode" +
                " AND mbu.party_no   =:partyNo"+
                " union " +
                " SELECT DECODE(mba.is_valid,'0','多卡无效','1','已认证','未知') AS bank_auto_status," +
                "       t.name," +
                "       mba.bank_account," +
                "       null as auth_amount_time," +
                "      to_char( mba.created_at , 'yyyy-mm-dd hh24:mi:ss') as auto_time" +
                " FROM member_bank_account mba,TBANKCODE t" +
                " WHERE mba.bank_code=t.bankcode " +
                " and mba.party_no        =:partyNo" +
                " AND mba.bank_account NOT IN" +
                "  (SELECT mbu.bank_account" +
                "  FROM member_bank_bind_auth mbu" +
                "  WHERE mbu.party_no=mba.party_no" +
                "  )";
        return convertBankInfoDTO(entityManager.createNativeQuery(nativeSql).setParameter("partyNo", partyNo).getResultList());
    }

    public Long countMessageInfoByMobileNo(String mobileNo, Date fromDate, Date toDate) {
        String nativeSql = "select count(*) from ("+
                "SELECT sd.updated_at," +
                " sd.properties," +
                "  st.template," +
                " decode(sd.status,'0','初始','1','正在发送','2','完成','3','失败','未知') as status," +
                " sr.created_at," +
                " st.SMS_TYPE" +
                " FROM sms_request sr," +
                " sms_request_details sd," +
                " sms_template st" +
                " WHERE sr.id           =sd.sms_request_id" +
                " AND sd.sms_template_id=st.id" +
                " AND sd.mobile_no      =:mobileNo";
        if(fromDate!=null){
            nativeSql+=" AND sr.CREATED_AT >= :fromDate";
        }
        if(toDate!=null){
            nativeSql+= " AND sr.CREATED_AT<= :toDate ";
        }
        nativeSql+=" union" +
                " SELECT ot.UPDATED_AT," +
                "  'opr' as properties," +
                "  'opr' as template," +
                "  DECODE(ot.status,'0','初始','1','发送成功','2','发送失败','3','验证成功','4','验证失败','5','locked','未知') AS status," +
                "  ot.CREATED_AT," +
                "  1 as SMS_TYPE" +
                " FROM one_time_password ot" +
                " WHERE ot.mobile_no      =:mobileNo";
        if(fromDate!=null){
            nativeSql+=" AND ot.CREATED_AT >= :fromDate";
        }
        if(toDate!=null){
            nativeSql+= " AND ot.CREATED_AT<= :toDate ";
        }
        nativeSql+=")";
        Query query= entityManager.createNativeQuery(nativeSql);
        if(fromDate!=null){
            query.setParameter("fromDate",fromDate);
        }
        if(toDate!=null){
            query.setParameter("toDate",toDate);
        }
        BigDecimal result=(BigDecimal)query.setParameter("mobileNo", mobileNo).getSingleResult();
        return  result.longValue();
    }

    public List<MessageInfoGson> findMessageInfoByMobileNo(String mobileNo, Date fromDate, Date toDate, int pageLimit, int offset) {
        String nativeSql = "select * from ("+
                "SELECT to_char(sd.updated_at , 'yyyy-mm-dd hh24:mi:ss') as updated_at," +
                " sd.properties," +
                "  st.template," +
                " decode(sd.status,'0','初始','1','正在发送','2','完成','3','失败','未知') as status," +
                " to_char(sr.created_at , 'yyyy-mm-dd hh24:mi:ss') CREATED_AT," +
                " st.SMS_TYPE" +
                " FROM sms_request sr," +
                " sms_request_details sd," +
                " sms_template st" +
                " WHERE sr.id           =sd.sms_request_id" +
                " AND sd.sms_template_id=st.id" +
                " AND sd.mobile_no      =:mobileNo";
        if(fromDate!=null){
            nativeSql+=" AND sr.CREATED_AT >= :fromDate";
        }
        if(toDate!=null){
            nativeSql+= " AND sr.CREATED_AT<= :toDate ";
        }
        nativeSql+=" union" +
                " SELECT to_char(ot.UPDATED_AT , 'yyyy-mm-dd hh24:mi:ss') as updated_at," +
                "  'opr' as properties," +
                "  'opr' as template," +
                "  DECODE(ot.status,'0','初始','1','发送成功','2','发送失败','3','验证成功','4','验证失败','5','locked','未知') AS status," +
                "  to_char(ot.CREATED_AT , 'yyyy-mm-dd hh24:mi:ss') CREATED_AT," +
                "  1 as SMS_TYPE" +
                " FROM one_time_password ot" +
                " WHERE ot.mobile_no      =:mobileNo";
        if(fromDate!=null){
            nativeSql+=" AND ot.CREATED_AT >= :fromDate";
        }
        if(toDate!=null){
            nativeSql+= " AND ot.CREATED_AT<= :toDate ";
        }
        nativeSql+=") order by CREATED_AT desc";
        Query query= entityManager.createNativeQuery(nativeSql);
        if(fromDate!=null){
            query.setParameter("fromDate",fromDate);
        }
        if(toDate!=null){
            query.setParameter("toDate",toDate);
        }
        List<Object[]> dtos =query.setParameter("mobileNo", mobileNo).setFirstResult(offset).setMaxResults(pageLimit).getResultList();
        return convertMessageInfoGSON(dtos);
    }

    private List<UserBankAutoInfoGson> convertBankInfoDTO(List<Object[]> dtos) {
        List<UserBankAutoInfoGson> result = new ArrayList<UserBankAutoInfoGson>();
        for (Object[] dto : dtos) {
            UserBankAutoInfoGson gson = new UserBankAutoInfoGson();
            gson.setBankAutoStatus(dto[0].toString());
            gson.setBankName(dto[1].toString());
            if(dto[2].toString().length()<9){
                Logger.error(this, "Bank card number less than 8 !");
                gson.setBankAccount(dto[2].toString());
            }
            else{
                gson.setBankAccount(EncryptUtils.encryptBankCardNo(dto[2].toString()));
            }

            if(dto[3]!=null){
                gson.setAuthAmountTime(dto[3].toString());
            }
            if (dto[4] != null) {
                gson.setAutoTime(dto[4].toString());
            }

            result.add(gson);
        }
        return result;
    }

    private List<MessageInfoGson> convertMessageInfoGSON(List<Object[]> dtos) {
        List<MessageInfoGson> result = new ArrayList<MessageInfoGson>();
        for (Object[] dto : dtos) {
            MessageInfoGson gson = new MessageInfoGson();
            gson.setUpdateAt(dto[0].toString());
            gson.setStatus(dto[3].toString());
            gson.setCreateAt(dto[4].toString());
//            GENERAL(0, "general", "YB"),
//            OTP(1, "otp", "OTP"),
//            MARKETING(2, "marketing", "YX"),
//            WARNING(3, "warning", "JS"),
//            SERVICE(4, "service", "FW");
            if("1".equals(dto[5].toString())){
            	gson.setCmsContext("手机OTP因涉及敏感信息，暂不显示");
            }
            else{
            	CharSequence charSequence = substitution(getReplaceableData(dto[1].toString()), dto[2].toString());
                if(charSequence!=null) gson.setCmsContext(charSequence.toString());
            }
            result.add(gson);

        }
        return result;
    }

    private Map<String, String> getReplaceableData(String properties) {
        if (properties == null)
            return null;
        String[] replacementKeyValues = properties.split("\n");
        Map<String, String> replacementProperties = new HashMap<String, String>();
        for (String s : replacementKeyValues) {
            String[] keyValues = {"", ""};
            if (!s.contains("=")) {
                Logger.error(this, "the properties does not contain the split character =");
                continue;
            }
            keyValues[0] = s.substring(0, s.indexOf("="));
            keyValues[1] = s.substring(s.indexOf("=") + 1, s.length());
            String key = "\\[\\$" + keyValues[0].trim() + "\\$\\]";
            String propertyValue = (keyValues.length == 2) ? keyValues[1].trim() : "";
            replacementProperties.put(key, propertyValue);
        }
        return replacementProperties;
    }


    private static CharSequence substitution(Map<String, String> data, CharSequence charSequence) {
        if (charSequence != null && data != null && data.entrySet() != null) {
            int flag = Pattern.CASE_INSENSITIVE | Pattern.DOTALL;
            for (Map.Entry<String, String> entry : data.entrySet()) {
                Pattern pattern = Pattern.compile(entry.getKey(), flag);
                Matcher matcher = pattern.matcher(charSequence);
                charSequence = matcher.replaceAll(Matcher.quoteReplacement(entry.getValue()));
            }
        }
        return charSequence;
    }

}
