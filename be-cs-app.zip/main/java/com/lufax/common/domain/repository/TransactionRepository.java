package com.lufax.common.domain.repository;

import org.springframework.stereotype.Repository;

@Repository
public class TransactionRepository extends BaseRepository<Long> {
    public long getNextTransactionId() {
        String result = entityManager.createNativeQuery("SELECT seq_transaction_id.nextval from Dual").getSingleResult().toString();
        return Long.valueOf(result);
    }
}
