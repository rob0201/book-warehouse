package com.lufax.common.domain.repository;

import com.lufax.common.domain.Province;
import com.lufax.common.domain.TBank;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class TBankRepository extends BaseRepository<TBank> {

    public TBank findBySubBankCode(String subBankCode) {
        List<TBank> tBanks = entityManager.createQuery("select t from TBank t where t.subBankCode=:subBankCode and t.isAvailable='Y'", TBank.class).setParameter("subBankCode", subBankCode).getResultList();
        if (tBanks.isEmpty()) {
            return new TBank();
        }
        return tBanks.get(0);
    }

    public List<Province> findProvincesByBankCode(String bankCode) {
        List<Province> provinces = entityManager.createQuery("select distinct t.province from TBank t where t.bankCode=:bankCode and t.isAvailable='Y'", Province.class).setParameter("bankCode", bankCode).getResultList();
        return provinces;
    }

    public List<TBank> findByBankCodeAndProvince(String bankCode, String provinceCode) {
        List<TBank> banks = entityManager.createQuery("select t from TBank t where t.bankCode=:bankCode and t.province.code=:provinceCode and t.isAvailable='Y'", TBank.class)
                .setParameter("bankCode", bankCode).setParameter("provinceCode", provinceCode).getResultList();
        return banks;
    }

    public boolean isExistWith(String subBankCode) {
        Long count = entityManager.createQuery("select count(t) from TBank t where t.subBankCode=:subBankCode and t.isAvailable='Y'", Long.class).setParameter("subBankCode", subBankCode).getResultList().get(0);
        return count > 0;
    }
}

