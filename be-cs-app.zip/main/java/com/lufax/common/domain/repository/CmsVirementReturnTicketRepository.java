package com.lufax.common.domain.repository;

import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.lufax.common.domain.funds.CMSCapitalStatementType;
import com.lufax.common.domain.funds.CmsVirementReturnTicket;
import com.lufax.common.utils.DateRange;

@Repository
public class CmsVirementReturnTicketRepository extends BaseRepository<CmsVirementReturnTicket> {

    public List<CmsVirementReturnTicket> findByDateRange(DateRange dateRange, int offset, int limit) {
        return entityManager.createQuery("select c from CmsVirementReturnTicket c where c.updatedDate >= :beginDate and c.updatedDate < :endDate order by c.updatedDate desc", CmsVirementReturnTicket.class)
                .setParameter("beginDate", dateRange.getStartDate())
                .setParameter("endDate", dateRange.getEndDate())
                .setFirstResult(offset)
                .setMaxResults(limit)
                .getResultList();
    }

    public List<CmsVirementReturnTicket> findUnhandledReturnTicket(int maxSize) {
        return entityManager.createQuery("select c from CmsVirementReturnTicket c where not exists (select 1 from CmsVirementRTResult r where r.returnTicketSequenceNo = c.returnTicketSequenceNo) " +
                "and exists(select 1 from CMSCapitalStatement s where s.id = c.businessNo and s.statementType in (:statementType))", CmsVirementReturnTicket.class).
                setParameter("statementType", Arrays.asList(CMSCapitalStatementType.WITHDRAWAL, CMSCapitalStatementType.VERIFICATION)).setMaxResults(maxSize).getResultList();
    }
}
