package com.lufax.common.domain.repository;

import org.springframework.stereotype.Repository;

import com.lufax.common.domain.InvestmentManagementFeeRecord;


@Repository
public class InvestmentManagementFeeRecordRepository extends BaseRepository<InvestmentManagementFeeRecord> {

}
