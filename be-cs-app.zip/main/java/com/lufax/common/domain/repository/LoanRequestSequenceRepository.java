package com.lufax.common.domain.repository;

import com.lufax.common.domain.LoanRequestSequence;
import org.springframework.stereotype.Repository;

import java.util.Date;

import static com.lufax.common.utils.DateUtils.startOfDay;

@Repository
public class LoanRequestSequenceRepository extends BaseRepository<LoanRequestSequence> {
    public Long findMaxIdBefore(Date date) {
        Long maxId = entityManager.createQuery("select max(id) from LoanRequestSequence r where r.createdAt<:today", Long.class).setParameter("today", startOfDay(date)).getSingleResult();
        if (maxId == null) {
            return 0L;
        }
        return maxId;
    }
}
