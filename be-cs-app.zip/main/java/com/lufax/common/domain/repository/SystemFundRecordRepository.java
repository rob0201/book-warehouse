package com.lufax.common.domain.repository;

import com.lufax.customerService.domain.SystemFundRecord;
import com.lufax.common.utils.DateRange;
import org.joda.time.DateTime;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class SystemFundRecordRepository extends BaseRepository<SystemFundRecord> {

    public List<SystemFundRecord> findRecords(DateRange dateRange) {
        return entityManager.createQuery("select r from SystemFundRecord r where r.statisticDate >= :startDate and r.statisticDate < :endDate order by r.statisticDate desc", SystemFundRecord.class)
                .setParameter("startDate", dateRange.getStartDate())
                .setParameter("endDate", new DateTime(dateRange.getEndDate()).plusDays(1).toDate())
                .getResultList();
    }

    public SystemFundRecord findLastRecord() {
        Long maxId = entityManager.createQuery("select max(r.id) from SystemFundRecord r", Long.class).getSingleResult();
        if (maxId == null) return null;
        return load(maxId);
    }
}
