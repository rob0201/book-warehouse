package com.lufax.common.domain.repository;

import com.lufax.common.domain.BranchBank;
import com.lufax.common.domain.Province;
import org.springframework.stereotype.Repository;

import java.text.Collator;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

@Repository
public class BranchBankRepository extends BaseRepository<BranchBank> {

    public BranchBank findByBranchId(String branchId) {
        List<BranchBank> branches = entityManager.createQuery("select t from BranchBank t where t.branchId=:branchId", BranchBank.class)
                .setParameter("branchId", branchId).getResultList();
        if (branches.isEmpty()) {
            return null;
        }
        return branches.get(0);
    }

    public BranchBank findBranchBankBySubBankCode(String subBankCode){
        List<BranchBank> branchBanks=entityManager.createQuery("select  t from BranchBank t where t.bankId=:subBankCode",BranchBank.class)
                .setParameter("subBankCode",subBankCode).getResultList();
        if(branchBanks.size()==0)
            return null;
        return branchBanks.get(0);
    }

    public List<Province> findProvincesByBankCode(String bankCode) {
        List<Province> provinces = entityManager.createQuery("select distinct t.province from BranchBank t where t.bankCode=:bankCode ", Province.class)
                .setParameter("bankCode", bankCode).getResultList();

        Collections.sort(provinces, new Comparator<Province>() {
            Collator collator = Collator.getInstance(Locale.CHINA);
            public int compare(Province o1, Province o2) {
                return collator.compare(o1.getName(), o2.getName());
            }
        });
        return provinces;
    }

    public List<BranchBank> findByBankCodeAndProvince(String bankCode, String provinceCode) {
        List<BranchBank> branches = entityManager.createQuery("select t from BranchBank t where t.bankCode=:bankCode and t.province.code=:provinceCode  order by t.branchId asc", BranchBank.class)
                .setParameter("bankCode", bankCode).setParameter("provinceCode", provinceCode).getResultList();

        Collections.sort(branches, new Comparator<BranchBank>() {
            Collator collator = Collator.getInstance(Locale.CHINA);
            public int compare(BranchBank o1, BranchBank o2) {
                return collator.compare(o1.getBranchName(), o2.getBranchName());
            }
        });
        return branches;
    }

    public boolean isExistWith(String subBankCode) {
        Long count = entityManager.createQuery("select count(t) from BranchBank t where t.bankId=:subBankCode", Long.class)
                .setParameter("subBankCode", subBankCode).getResultList().get(0);
        return count > 0;
    }
}

