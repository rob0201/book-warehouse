package com.lufax.common.domain.repository;

import com.lufax.common.domain.InsurancePolicy;
import org.springframework.stereotype.Repository;

@Repository
public class InsurancePolicyRepository extends BaseRepository<InsurancePolicy> {
}
