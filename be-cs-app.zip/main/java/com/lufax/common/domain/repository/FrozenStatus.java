package com.lufax.common.domain.repository;

public enum FrozenStatus {
    FREEZING,
    UNFREEZE,
    UNKNOWN;
    public static FrozenStatus getFrozenStatusByName(String status){
        FrozenStatus[]  frozenStatuses=FrozenStatus.values();
        for(FrozenStatus frozenStatus:frozenStatuses)
            if(frozenStatus.name().equalsIgnoreCase(status))
                return frozenStatus;
        return FrozenStatus.UNKNOWN;
    }

}
