package com.lufax.common.domain.repository;

import com.lufax.common.domain.*;
import com.lufax.common.domain.account.Money;
import org.springframework.stereotype.Repository;

import javax.persistence.TypedQuery;
import java.util.*;

import static com.lufax.common.domain.LoanToXinbaoStatus.NEED_RESEND;
import static com.lufax.common.domain.TradingStatus.OVERDUE;
import static com.lufax.common.domain.TradingStatus.Type.ONGOING;

@Repository
public class LoanRepository extends BaseRepository<Loan> {
    public Loan findByLoanRequestCode(String loanRequestCode) {
        String queryString = "select l from Loan l where l.loanRequestCode = :loanRequestCode";
        return entityManager.createQuery(queryString, Loan.class).setParameter("loanRequestCode", loanRequestCode).getSingleResult();
    }

    public Loan findLoanByLoanCode(String code) {
        String queryString = "select l from Loan l where l.code = :code";
        TypedQuery<Loan> query = entityManager.createQuery(queryString, Loan.class).setParameter("code", code);
        return getSingleResult(query);
    }

    public List<Loan> findContractUnuploadedLoans(int limit) {
        String queryString = "select l from Loan l left join fetch l.repaymentPlans where not exists (select 1 from TradeContract tc where tc.loan = l)";
        return entityManager.createQuery(queryString, Loan.class).setMaxResults(limit).getResultList();
    }

    public List<Loan> findOrderedLoansByStatusTypeFor(User loanee, TradingStatus.Type statusType) {
        String criteria = TradingStatus.Type.SETTLED.equals(statusType) ? "l.endedAt desc" : "l.loanRequestCode desc";

        String queryString = "select distinct l from Loan l left join fetch l.repaymentPlans rp where l.loanee=:loanee and l.status in (:statuses) order by " + criteria;
        return entityManager.createQuery(queryString, Loan.class).setParameter("loanee", loanee).setParameter("statuses", statusType.getTradingStatuses()).getResultList();
    }

    public List<Loan> findLoanInfoUnsentLoans(int limit) {
        String queryString = "select l from Loan l where (l.statusToXinbao is null or l.statusToXinbao=:statusToXinbao) and l.status in (:statuses)";
        return entityManager.createQuery(queryString, Loan.class).
                setParameter("statuses", ONGOING.getTradingStatuses()).setParameter("statusToXinbao", NEED_RESEND.name()).
                setMaxResults(limit).getResultList();
    }


    public List<Loan> findContractUnsentLoans(int limit) {
        String queryString = "select l from Loan l where l.contractStatusToXinBao is null and l.status in (:statuses) and exists (select 1 from TradeContract tc where tc.loan = l)";
        return entityManager.createQuery(queryString, Loan.class).setParameter("statuses", ONGOING.getTradingStatuses()).
                setMaxResults(limit).getResultList();
    }

    public Loan findForLoanee(User user, long id) {
        TypedQuery<Loan> loanTypedQuery = entityManager.createQuery("select l from Loan l where l.id = :id and l.loanee.id=:loaneeId", Loan.class).
                setParameter("id", id).setParameter("loaneeId", user.id());
        return getSingleResult(loanTypedQuery);
    }

    public List<Long> findOverdueLoansWhichAreNotUpdatedTo(Date updateDate, int limit) {
        String queryString = "select l.id from Loan l where l.status = :status and (l.overdueUpdateDate is null or l.overdueUpdateDate < :updateDate)";
        return entityManager.createQuery(queryString, Long.class).setParameter("status", OVERDUE.name()).setParameter("updateDate", updateDate).setMaxResults(limit).getResultList();
    }

    public Loan findByPolicyNo(String policyNo) {
        String queryString = "select l from Loan l where l.loanRequestCode in (select lr.code from LoanRequest lr inner join lr.policy p where p.policyNo=:policyNo)";
        return getSingleResult(entityManager.createQuery(queryString, Loan.class).setParameter("policyNo", policyNo));
    }

    public Map<Loan, Money> getPaidPrincipalsForLoans(List<Loan> loans) {
        Map<Loan, Money> result = new HashMap<Loan, Money>();
        if(loans.size() == 0){
            return result;
        }
        for (Loan loan : loans) {
            result.put(loan, Money.ZERO_YUAN);
        }
        List<RepaymentRecord> repaymentRecords = entityManager.createQuery("select r from RepaymentRecord r left join fetch r.plan p left join fetch p.loan l where l in (:loans) and r.status=:status", RepaymentRecord.class)
                .setParameter("loans", loans)
                .setParameter("status", RecordStatus.DONE.name())
                .getResultList();

        for (RepaymentRecord repaymentRecord : repaymentRecords) {
            Loan loan = repaymentRecord.getRepaymentPlan().getLoan();
            result.put(loan, result.get(loan).add(repaymentRecord.getPrincipal()));
        }
        return result;
    }
}
