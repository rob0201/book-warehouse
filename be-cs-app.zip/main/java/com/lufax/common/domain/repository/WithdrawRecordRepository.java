package com.lufax.common.domain.repository;

import static java.util.Arrays.asList;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import com.lufax.customerService.domain.WithdrawRecordsTypeForQuery;
import com.lufax.customerService.dto.RareWordFailedDTO;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Repository;

import com.lufax.common.domain.Loan;
import com.lufax.common.domain.WithdrawRecord;
import com.lufax.common.domain.WithdrawStatus;
import com.lufax.common.domain.account.Account;
import com.lufax.common.domain.account.Money;
import com.lufax.common.utils.DateRange;
import com.lufax.common.utils.DevLog;

@Repository
public class WithdrawRecordRepository extends BaseRepository<WithdrawRecord> {

	public static String rareWordApplySql = " from (select p2pUser.username as username,p2pUser.name as realName," +
											  " withdraw.id as withdrawId, " +
											  " withdraw.withdraw_type operationType, " +
											  " withdraw.withdrawal_amount amount, " +
											  " withdraw.created_at as sendTime, " +
											  " withdraw.bank_card_no as bankAccount, " +
											  " (select tb.name from tbank tb,member_bank_account mba where mba.bank_id=tb.bankid(+) and withdraw.bankcard_id=mba.id(+) ) as bankName, " +
											  " withdraw.remarks as remark, " +
											  " manual.id as manualCapitalId, " +
											  " manual.status as manualCapitalStatementStatus, " +
											  " manual.remark as reason, " +
											  " lcdUser.name as auditor, " +
											  " fcuUser.name as applier, " +
											  " lufaxBank.bank_account_code as lufaxAccount, " +
											  " manual.bank_transaction_no as transactionNo, " +
											  " manual.manual_capatial_statement_desc as manualDesc, " +
											  " manual.eoa_no as eoaNo, " +
											  " withdraw.status as withdrawStatus," +
											  " withdraw.bank_name as withdrawBankName " +
										 " from withdraw_records withdraw," +
								   		  " manual_capatial_statement manual," +
								   		  " p2pusers p2pUser," +
								   		  " accounts account," +
								   		  " operation_user fcuUser," +
								   		  " operation_user lcdUser, " +
								   		  " lufax_bank_info lufaxBank " +
								    " where p2pUser.id = account.user_id " +
											  " and withdraw.is_rare_word = 1 " +
											  " and account.id = withdraw.account_id " +
											  " and withdraw.id = manual.source_relation_id " +
											  " and manual.SOURCE_TYPE='RARE_WORDS' " +
											  " and manual.fcu = fcuUser.p2p_user_id(+) " +
											  " and manual.lcu = lcdUser.p2p_user_id(+) " +
											  " and manual.bank_account = lufaxBank.Bank_Account(+) " +
											  " and manual.status not in('NEW','CLOSED') " +
									    " union " +
									    " select p2pUser.username as username, " +
											  " p2pUser.name as realName, " +
											  " withdraw.id as withdrawId, " +
											  " withdraw.withdraw_type operationType, " +
											  " withdraw.withdrawal_amount amount, " +
											  " withdraw.created_at as sendTime, " +
											  " withdraw.bank_card_no as bankAccount, " +
											  " (select tb.name from tbank tb,member_bank_account mba where mba.bank_id=tb.bankid(+) and withdraw.bankcard_id=mba.id(+) ) as bankName, " +
											  " withdraw.remarks as remark, " +
											  " null as manualCapitalId, " +
											  " null as manualCapitalStatementStatus, " +
											  " null as reason, " +
											  " null as auditor, " +
											  " null as applier, " +
											  " null as lufaxAccount, " +
											  " null as transactionNo, " +
											  " null as manualDesc, " +
											  " null as eoaNo, " +
											  " withdraw.status as withdrawStatus, " +
											  " withdraw.bank_name as withdrawBankName " +
								    " from withdraw_records withdraw, " +
								  		  " p2pusers p2pUser, " +
								  		  " accounts account " +
								    " where p2pUser.id = account.user_id " +
											  " and withdraw.is_rare_word = 1 " +
											  " and account.id = withdraw.account_id " +
											  " and withdraw.status in ('PROCESSING','SUCCESS') " +
											  " and withdraw.id not in( select withdrawrecords.id " +
											  						  " from withdraw_records withdrawrecords, manual_capatial_statement manualStatus " +
											  						  " where withdrawrecords.id = manualStatus.source_relation_id and manualStatus.status not in('NEW','CLOSED')) " +
								 ") t " +
								 " where 1=1 ";
	public static String rareWordAutditSql = " from (select p2pUser.username as username,p2pUser.name as realName," +
											  " withdraw.id as withdrawId, " +
											  " withdraw.withdraw_type operationType, " +
											  " withdraw.withdrawal_amount amount, " +
											  " withdraw.created_at as sendTime, " +
											  " withdraw.bank_card_no as bankAccount, " +
											  " (select tb.name from tbank tb,member_bank_account mba where mba.bank_id=tb.bankid(+) and withdraw.bankcard_id=mba.id(+) ) as bankName, " +
											  " withdraw.remarks as remark, " +
											  " manual.id as manualCapitalId, " +
											  " manual.status as manualCapitalStatementStatus, " +
											  " manual.remark as reason, " +
											  " lcdUser.name as auditor, " +
											  " fcuUser.name as applier, " +
											  " lufaxBank.bank_account_code as lufaxAccount, " +
											  " manual.bank_transaction_no as transactionNo, " +
											  " manual.manual_capatial_statement_desc as manualDesc, " +
											  " manual.eoa_no as eoaNo, " +
											  " withdraw.status as withdrawStatus, " +
											  " withdraw.bank_name as withdrawBankName " +
										 " from withdraw_records withdraw," +
									   		  " manual_capatial_statement manual," +
									   		  " p2pusers p2pUser," +
									   		  " accounts account," +
									   		  " operation_user fcuUser," +
									   		  " operation_user lcdUser, " +
									   		  " lufax_bank_info lufaxBank " +
									    " where p2pUser.id = account.user_id " +
											  " and withdraw.is_rare_word = 1 " +
											  " and account.id = withdraw.account_id " +
											  " and withdraw.id = manual.source_relation_id " +
											  " and manual.SOURCE_TYPE='RARE_WORDS' " +
											  " and manual.fcu = fcuUser.p2p_user_id(+) " +
											  " and manual.lcu = lcdUser.p2p_user_id(+) " +
											  " and manual.bank_account = lufaxBank.Bank_Account(+) " +
											  " and manual.status not in('NEW','CLOSED') " +
									    " union " +
									    " select p2pUser.username as username, " +
											  " p2pUser.name as realName, " +
											  " withdraw.id as withdrawId, " +
											  " withdraw.withdraw_type operationType, " +
											  " withdraw.withdrawal_amount amount, " +
											  " withdraw.created_at as sendTime, " +
											  " withdraw.bank_card_no as bankAccount, " +
											  " (select tb.name from tbank tb,member_bank_account mba where mba.bank_id=tb.bankid(+) and withdraw.bankcard_id=mba.id(+) ) as bankName, " +
											  " withdraw.remarks as remark, " +
											  " null as manualCapitalId, " +
											  " null as manualCapitalStatementStatus, " +
											  " null as reason, " +
											  " null as auditor, " +
											  " null as applier, " +
											  " null as lufaxAccount, " +
											  " null as transactionNo, " +
											  " null as manualDesc, " +
											  " null as eoaNo, " +
											  " withdraw.status as withdrawStatus, " +
											  " withdraw.bank_name as withdrawBankName " +
									    " from withdraw_records withdraw, " +
									  		  " p2pusers p2pUser, " +
									  		  " accounts account " +
									    " where p2pUser.id = account.user_id " +
											  " and withdraw.is_rare_word = 1 " +
											  " and account.id = withdraw.account_id " +
											  " and withdraw.status in ('SUCCESS') " +
											  " and withdraw.id not in( select withdrawrecords.id " +
											  " from withdraw_records withdrawrecords, manual_capatial_statement manualStatus " +
											  " where withdrawrecords.id = manualStatus.source_relation_id and manualStatus.status not in('NEW','CLOSED')) " +
								") t " +
								"  where 1=1 ";
	public static String rareWordFailedSql = " from (select u.username    as username," +
												" withdraw.id                as withdrawId," +
												" withdraw.withdraw_type     as withdrawType," +
												" withdraw.withdrawal_amount as amount," +
												" withdraw.created_at        as sendTime," +
												" withdraw.bank_name         as bankName," +
												" tb.name                    as tbName," +
												" withdraw.bank_card_no      as bankAccount," +
												" withdraw.remarks           as remark" +
												" from withdraw_records withdraw," +
												" p2pusers u," +
												" accounts acc," +
												" member_bank_account mba, " +
												" tbank tb" +
												" where withdraw.account_id = acc.id" +
												" and acc.user_id = u.id" +
												" and mba.bank_id = tb.bankid(+)" +
												" and withdraw.status = 'PROCESSING' " +
												" and withdraw.is_rare_word = 1 " +
												") t" +
									    		" where 1=1 ";
	
    public List<WithdrawRecord> findAllByAccount(Account account) {
        return entityManager.createQuery("select wr from WithdrawRecord wr where wr.account.id=:accountId and wr.withdrawStatus <> :status order by wr.createdAt desc", WithdrawRecord.class)
                .setParameter("accountId", account.id())
                .setParameter("status", WithdrawStatus.NEW.name()).getResultList();
    }

    public Money getSuccessfulActualWithdrawAmount(DateRange dateRange) {
        Money result = entityManager.createQuery("select sum(r.actualAmount) from WithdrawRecord r where r.withdrawStatus=:success and r.updatedAt < :endDate and r.updatedAt >= :startDate", Money.class)
                .setParameter("success", WithdrawStatus.SUCCESS.name())
                .setParameter("startDate", dateRange.getStartDate())
                .setParameter("endDate", dateRange.getEndDate())
                .getSingleResult();
        if (result == null) {
            return Money.ZERO_YUAN;
        }
        return result;
    }


    public List<WithdrawRecord> findWithdrawRecordReasonForRareWordsByStatus(WithdrawRecordsTypeForQuery type, int maxNum, int offset) {
        List<String> statuses = transferWithdrawRecords(type);
        return entityManager.createQuery("select  wr from WithdrawRecord wr where wr.isRareWords=:isRareWords and wr.withdrawStatus in (:withdrawStatus)", WithdrawRecord.class)
                .setParameter("isRareWords", true).setParameter("withdrawStatus", statuses).setMaxResults(maxNum).setFirstResult(offset).getResultList();
    }


    public Long countOfWithdrawRecordReasonForRareWordsByStatus(WithdrawRecordsTypeForQuery type) {
        List<String> statuses = transferWithdrawRecords(type);
        return entityManager.createQuery("select count(wr) from WithdrawRecord wr where wr.isRareWords=:isRareWords and wr.withdrawStatus in (:withdrawStatus)", Long.class)
                .setParameter("isRareWords", true).setParameter("withdrawStatus", statuses).getSingleResult();
    }
    
    public Long countOfWithdrawRecordReasons(String userName,String status) {
    	String sql  = " select count(t.withdrawId) " + rareWordApplySql;
  			  		  
    	if(!StringUtils.isEmpty(userName)){
    		sql = sql + " and upper(t.username)= :userName ";
    	}
    	if(!StringUtils.isEmpty(status) && !"ALL".equalsIgnoreCase(status)){
    		if("NEW".equalsIgnoreCase(status)){
        		sql = sql + " and t.manualCapitalStatementStatus is null and t.withdrawStatus in (:withdrawStatus) ";
        	}else{
        		if("SUCCESS".equalsIgnoreCase(status)){
        			sql = sql + " and t.withdrawStatus=:withdrawStatus  ";
        		}else{
        			sql = sql + " and t.manualCapitalStatementStatus=:status ";
        		}
        	}
    	}
    	TypedQuery query = (TypedQuery) entityManager.createNativeQuery(sql);
    	if(!StringUtils.isEmpty(userName)){
    		query.setParameter("userName", userName.toUpperCase());
    	}
    	if(!StringUtils.isEmpty(status) && !"ALL".equalsIgnoreCase(status)){
    		if("NEW".equalsIgnoreCase(status)){
    			List<String> withdrawStatus = new ArrayList<String>();
    			withdrawStatus.add(WithdrawStatus.PROCESSING.name());
    			query.setParameter("withdrawStatus", withdrawStatus);
    		}else{
    			if("SUCCESS".equalsIgnoreCase(status)){
    				query.setParameter("withdrawStatus", WithdrawStatus.SUCCESS.name());
    			}else{
    				query.setParameter("status", status);
    			}
    		}
    	}
    	return ((BigDecimal)query.getSingleResult()).longValue();
    }
    
    public List<Object> findWithdrawRecordsWithManualRecords(String userName,String status,int firstResult,int maxResults){
    	String sql  = " select * " +  rareWordApplySql;
    	if(!StringUtils.isEmpty(userName)){
    		sql = sql + " and upper(t.username)=:userName ";
    	}
    	if(!StringUtils.isEmpty(status) && !"ALL".equalsIgnoreCase(status)){
    		if("NEW".equalsIgnoreCase(status)){
        		sql = sql + " and t.manualCapitalStatementStatus is null and t.withdrawStatus in (:withdrawStatus)  ";
        	}else{
        		if("SUCCESS".equalsIgnoreCase(status)){
        			sql = sql + " and t.withdrawStatus=:withdrawStatus ";
        		}else{
        			sql = sql + " and t.manualCapitalStatementStatus=:status ";
        		}
        	}
    	}
    	sql = sql + " order by t.sendTime asc ";
    	TypedQuery<Object> query = (TypedQuery) entityManager.createNativeQuery(sql,"RareWithdrawRecords");
    	if(!StringUtils.isEmpty(userName)){
    		query.setParameter("userName", userName.toUpperCase());
    	}
    	if(!StringUtils.isEmpty(status) && !"ALL".equalsIgnoreCase(status)){
    		if("NEW".equalsIgnoreCase(status)){
    			List<String> withdrawStatus = new ArrayList<String>();
    			withdrawStatus.add(WithdrawStatus.PROCESSING.name());
    			query.setParameter("withdrawStatus", withdrawStatus);
    		}else{
    			if("SUCCESS".equalsIgnoreCase(status)){
    				query.setParameter("withdrawStatus", WithdrawStatus.SUCCESS.name());
    			}else{
    				query.setParameter("status", status);
    			}
    		}
    	}
    	return query.setFirstResult(firstResult).setMaxResults(maxResults).getResultList();
    }

    public long countOfWithdrawRecordForAudit(String userName,String status){
    	String sql  = " select count(t.withdrawId) " + rareWordAutditSql;
	    			  
    	if(!StringUtils.isEmpty(userName)){
    		sql = sql + " and upper(t.username)=:userName ";
    	}
    	if(!StringUtils.isEmpty(status) && !"ALL".equalsIgnoreCase(status) && !"NEW".equalsIgnoreCase(status)){
    		if("SUCCESS".equalsIgnoreCase(status)){
    			sql = sql + " and t.withdrawStatus=:withdrawStatus ";
    		}else{
    			sql = sql + " and t.manualCapitalStatementStatus=:status ";
    		}
    	}
    	TypedQuery query = (TypedQuery) entityManager.createNativeQuery(sql);
    	if(!StringUtils.isEmpty(userName)){
    		query.setParameter("userName", userName.toUpperCase());
    	}
    	if(!StringUtils.isEmpty(status) && !"ALL".equalsIgnoreCase(status) && !"NEW".equalsIgnoreCase(status)){
    		if("SUCCESS".equalsIgnoreCase(status)){
    			query.setParameter("withdrawStatus", WithdrawStatus.SUCCESS.name());
    		}else{
    			query.setParameter("status", status);
    		}
    	}
    	return ((BigDecimal)query.getSingleResult()).longValue();
    }
    
    public List<Object> findWithdrawRecordsWithManualRecordsForAudit(String userName,String status,int firstResult,int maxResults){
    	String sql  = " select * " + rareWordAutditSql;
    	if(!StringUtils.isEmpty(userName)){
    		sql = sql + " and upper(t.username)=:userName ";
		}
		if(!StringUtils.isEmpty(status) && !"ALL".equalsIgnoreCase(status) && !"NEW".equalsIgnoreCase(status)){
			if("SUCCESS".equalsIgnoreCase(status)){
    			sql = sql + " and t.withdrawStatus=:withdrawStatus ";
    		}else{
    			sql = sql + " and t.manualCapitalStatementStatus=:status ";
    		}
		}
		sql = sql + " order by t.sendTime asc ";
		TypedQuery query = (TypedQuery) entityManager.createNativeQuery(sql,"RareWithdrawRecords");
		if(!StringUtils.isEmpty(userName)){
			query.setParameter("userName", userName.toUpperCase());
		}
		if(!StringUtils.isEmpty(status) && !"ALL".equalsIgnoreCase(status) && !"NEW".equalsIgnoreCase(status)){
			if("SUCCESS".equalsIgnoreCase(status)){
    			query.setParameter("withdrawStatus", WithdrawStatus.SUCCESS.name());
    		}else{
    			query.setParameter("status", status);
    		}
		}
		return query.setFirstResult(firstResult).setMaxResults(maxResults).getResultList();
    }
    
    private Predicate predicateBasedOnType(List<Account> accounts, WithdrawRecordsTypeForQuery type, CriteriaBuilder criteriaBuilder, Root<WithdrawRecord> root) {
        List<String> statuses = transferWithdrawRecords(type);
        Predicate predicate = null;
        predicate = criteriaBuilder.in(root.<WithdrawStatus>get("account")).in(accounts);
        return WithdrawRecordsTypeForQuery.ALL == type ? predicate : criteriaBuilder.and(predicate, root.<WithdrawStatus>get("withdrawStatus").in(statuses));
    }

    private List<String> transferWithdrawRecords(WithdrawRecordsTypeForQuery type) {
        List<String> statuses = new ArrayList<String>();
        List<WithdrawStatus> withdrawStatuses = (WithdrawRecordsTypeForQuery.ALL != type) ? type.getWithdrawStatuses() : asList(WithdrawStatus.values());
        for (WithdrawStatus withdrawStatus : withdrawStatuses)
            statuses.add(withdrawStatus.name());
        return statuses;
    }

    @Override
    public WithdrawRecord update(WithdrawRecord withdrawRecord) {
        withdrawRecord.setUpdatedAt(new Date());
        return super.update(withdrawRecord);
    }

    @Override
    public void persist(WithdrawRecord withdrawRecord) {
        withdrawRecord.setUpdatedAt(new Date());
        super.persist(withdrawRecord);
    }

    public List<WithdrawRecord> findBy(Loan loan) {
        return entityManager.createQuery("select wr from WithdrawRecord wr where wr.loan=:loan", WithdrawRecord.class).
                setParameter("loan", loan).getResultList();
    }

    public WithdrawRecord findLatestBy(Loan loan) {
        return getSingleResult(entityManager.createQuery("select wr from WithdrawRecord wr where wr.loan = :loan order by wr.updatedAt desc", WithdrawRecord.class).setParameter("loan", loan).setMaxResults(1));
    }
    
    public long countOfWithdrawRecordReasonsForFailed(String userName){
    	String sql  = "select count(t.withdrawId) " + rareWordFailedSql;
	    			
			if(!StringUtils.isEmpty(userName)){
				sql = sql + " and upper(t.username)=:userName ";
			}
			
			TypedQuery query = (TypedQuery) entityManager.createNativeQuery(sql);
			if(!StringUtils.isEmpty(userName)){
				query.setParameter("userName", userName.toUpperCase());
			}
		return ((BigDecimal)query.getSingleResult()).longValue();
	 }
    public List<RareWordFailedDTO> queryWithdrawRecordsForFailed(String userName,int offset, int maxNum){
    	String sql  = "select t.username,t.withdrawId,t.withdrawType,t.amount,t.sendTime,t.bankName,t.tbName,t.bankAccount,t.remark " + rareWordFailedSql;
		if(!StringUtils.isEmpty(userName)){
			sql = sql + " and upper(t.username)=:userName ";
		}
		sql = sql + " order by t.sendTime asc ";
		TypedQuery query = (TypedQuery) entityManager.createNativeQuery(sql);
		if(!StringUtils.isEmpty(userName)){
			query.setParameter("userName", userName.toUpperCase());
		}
		List<Object[]> objArrays = query.setFirstResult(offset).setMaxResults(maxNum).getResultList();
		return transferObjectToDTO(objArrays);		
    }

    private List<RareWordFailedDTO> transferObjectToDTO(List<Object[]> objArrays){
    	List<RareWordFailedDTO> rareWordFailedDTOs = new ArrayList<RareWordFailedDTO>();
    	for(Object[] objArray:objArrays){
    		RareWordFailedDTO dto = new RareWordFailedDTO();
    		dto.setUsername(String.valueOf(objArray[0]));
    		dto.setWithdrawId(((BigDecimal)objArray[1]).longValue());
    		dto.setWithdrawType((String)objArray[2]);
    		dto.setAmount((BigDecimal)objArray[3]);
    		dto.setSendTime((Date)objArray[4]);
    		dto.setBankName((String)objArray[5]);
    		dto.setTbName((String)objArray[6]);
    		dto.setBankAccount((String)objArray[7]);
    		dto.setRemark((String)objArray[8]);
    		rareWordFailedDTOs.add(dto);
    		DevLog.info(this, String.format("The rareWordFailedDTO is [%s]", dto.toString()));
    	}
    	return rareWordFailedDTOs;
    }
	
    
}
