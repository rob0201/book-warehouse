package com.lufax.common.domain.repository;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.lufax.common.domain.ASLoanRequest;
import com.lufax.common.domain.User;
import com.lufax.common.utils.DevLog;

@Repository
public class ASLoanRequestRepository extends BaseRepository<ASLoanRequest>{
    public List<ASLoanRequest> findAllForLoanee(User loanee) {
        return entityManager.createQuery("select asls from ASLoanRequest asls where asls.loaneeUserId = :loaneeUserId").setParameter("loaneeUserId", loanee.id()).getResultList();
    }
    public BigDecimal getTotalRepayAmount(ASLoanRequest request) {
    	List<Object[]> result = entityManager.createNativeQuery("select  total_repay_amount ,agn.* from as_guaranteed_note agn where agn.as_loan_request_id = :asLoanRequestId").setParameter("asLoanRequestId", request.getId()).getResultList();
    	DevLog.debug(this, "the as loan request [" + request.getId() + "] total repay amount is [" + result + "]");
    	if(result == null || result.isEmpty()) {
    		return null;
    	} else {
    		return (BigDecimal)result.get(0)[0];
    	}
    }
}
