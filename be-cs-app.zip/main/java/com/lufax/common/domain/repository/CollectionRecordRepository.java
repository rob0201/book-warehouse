package com.lufax.common.domain.repository;

import com.lufax.common.domain.CollectionRecord;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class CollectionRecordRepository extends BaseRepository<CollectionRecord> {
    public List<CollectionRecord> findAllByInvestmentId(long investmentId) {
        return entityManager.createQuery("select record from CollectionRecord record left join fetch record.plan as p where p.investment.id=:investmentId order by record.recordNumber asc", CollectionRecord.class)
                .setParameter("investmentId", investmentId)
                .getResultList();
    }

}
