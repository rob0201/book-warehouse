package com.lufax.common.domain.repository;

import com.lufax.common.domain.TBankCode;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class TBankCodeRepository extends BaseRepository<TBankCode> {

    public TBankCode findByBankCode(String bankCode) {
        List<TBankCode> bankCodes = entityManager.createQuery("select t from TBankCode t where t.bankCode=:bankCode and t.isAvailable='Y'", TBankCode.class).setParameter("bankCode", bankCode).getResultList();
        if (bankCodes.isEmpty()) {
            return TBankCode.EMPTY_BANKCODE;
        }

        return bankCodes.get(0);
    }

    public List<TBankCode> findByBankCodeList(List<String> bankCodeList) {
        List<TBankCode> bankCodes = entityManager.createQuery("select t from TBankCode t where t.bankCode in (:bankCodeList) and t.isAvailable='Y'", TBankCode.class)
                .setParameter("bankCodeList", bankCodeList).getResultList();
        return bankCodes;
    }

    public boolean isExistWith(String bankCode) {
        Long count = entityManager.createQuery("select count(t) from TBankCode t where t.bankCode=:bankCode and t.isAvailable='Y'", Long.class).setParameter("bankCode", bankCode).getResultList().get(0);
        return count > 0;
    }

    public List<TBankCode> findAllTankCodes(){
        return entityManager.createQuery("select  t from TBankCode t",TBankCode.class).getResultList();
    }
}

