package com.lufax.common.domain.repository;

import com.lufax.common.domain.ErrorDesc;
import com.lufax.common.domain.ErrorType;
import com.lufax.common.domain.OriginSystem;
import org.springframework.stereotype.Repository;

@Repository
public class ErrorDescRepository extends BaseRepository<ErrorDesc> {

    public ErrorDesc findCmsErrorBy(String code) {
        return findBy(code, OriginSystem.CMS, ErrorType.CMS_ERROR);
    }

    public ErrorDesc findCmsReturnTicketErrorBy(String code) {
        return findBy(code, OriginSystem.CMS, ErrorType.CMS_RETURN_TICKET);
    }

    private ErrorDesc findBy(String code, OriginSystem originSystem, ErrorType errorType) {
        return getSingleResult(entityManager.createQuery("select err from ErrorDesc err where err.originSystem =:originSystem and err.code=:code and err.errorType=:errorType", ErrorDesc.class)
                .setParameter("originSystem", originSystem.name())
                .setParameter("code", code)
                .setParameter("errorType", errorType.name()));
    }
}
