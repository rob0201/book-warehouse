package com.lufax.common.domain.repository;

import com.lufax.common.domain.OriginalWithholding;
import org.springframework.stereotype.Repository;

@Repository
public class OriginalWithholdingRepository extends BaseRepository<OriginalWithholding> {


}
