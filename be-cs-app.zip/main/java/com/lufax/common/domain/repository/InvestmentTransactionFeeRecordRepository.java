package com.lufax.common.domain.repository;

import java.math.BigDecimal;

import org.springframework.stereotype.Repository;

import com.lufax.common.domain.Investment;
import com.lufax.common.domain.InvestmentTransactionFeeRecord;
import com.lufax.common.domain.account.Money;


@Repository
public class InvestmentTransactionFeeRecordRepository extends BaseRepository<InvestmentTransactionFeeRecord> {

    public Money getPaidInvestmentTransactionFee(Investment investment) {
        BigDecimal paidAmount = entityManager.createQuery("select sum(r.investmentTransactionFee.amount) from InvestmentTransactionFeeRecord r where r.collectionRecord.plan.investment=:investment", BigDecimal.class)
                .setParameter("investment", investment)
                .getSingleResult();
        return null == paidAmount ? Money.ZERO_YUAN : Money.rmb(paidAmount);
    }
}
