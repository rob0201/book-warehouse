package com.lufax.common.domain.repository;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.lufax.common.domain.CollectionRecord;
import com.lufax.common.domain.Investment;
import com.lufax.common.domain.Loan;
import com.lufax.common.domain.RecordStatus;
import com.lufax.common.domain.TradingStatus;
import com.lufax.common.domain.TradingStatus.Type;
import com.lufax.common.domain.User;
import com.lufax.common.domain.account.Money;
import com.lufax.common.domain.product.ProductType;

@Repository
public class InvestmentRepository extends BaseRepository<Investment> {
	
	public Investment findByLoan(Loan loan) {
        return entityManager.createQuery("select distinct i from Investment i left join fetch i.loaner l left join fetch i.collectionPlans cps where i.loan=:loan and i.status in(:statuses)", Investment.class)
                .setParameter("loan", loan)
                .setParameter("statuses", TradingStatus.Type.ONGOING.getStatuses())
                .getSingleResult();
    }

    public Investment findByLoanWithLoaner(Loan loan) {
        return entityManager.createQuery("select distinct invest from Investment invest left join fetch invest.loaner l where invest.loan=:loan", Investment.class)
                .setParameter("loan", loan).getSingleResult();
    }

    public Investment findByIdAndUser(long id, User user) {
        return entityManager.createQuery("select invest from Investment invest left join fetch invest.loaner where invest.id = :id and invest.loaner = :loaner", Investment.class)
                .setParameter("id", id).setParameter("loaner", user).getSingleResult();
    }

    public List<Investment> findOrderedInvestmentsByStatusTypeFor(User loaner, TradingStatus.Type statusType) {
        String criteria = Type.SETTLED.equals(statusType) ? "l.endedAt desc" : "l.code desc";

        String queryString = "select distinct i from Investment i left join fetch i.collectionPlans cp join fetch i.loan l join fetch i.loaner lr where lr=:loaner and i.status in(:statuses) order by " + criteria;
        return entityManager.createQuery(queryString, Investment.class)
                .setParameter("loaner", loaner)
                .setParameter("statuses", statusType.getStatuses())
                .getResultList();
    }

    public List<Investment> findOrderedInvestmentsByStatusTypeDateForPageContorll(User loaner, TradingStatus.Type statusType, int pageLimit, int offset, Date startDateStart, Date startDateEnd, Date endDateStart, Date endDateEnd) {
        String criteria = Type.SETTLED.equals(statusType) ? "l.endedAt desc" : "l.code desc";
        StringBuffer queryStringBuffer = new StringBuffer("select distinct i from Investment i left join fetch i.collectionPlans cp join fetch i.loan l join fetch i.loaner lr where lr=:loaner and i.status in(:statuses)");

        if (startDateStart != null) {
            queryStringBuffer.append(" and l.startAt >=:startDateStart");
        }
        if (startDateEnd != null) {
            queryStringBuffer.append(" and l.startAt <=:startDateEnd");
        }
        queryStringBuffer.append("  order by " + criteria);

        String queryString = queryStringBuffer.toString();

        TypedQuery query = entityManager.createQuery(queryString, Investment.class)
                .setParameter("loaner", loaner)
                .setParameter("statuses", statusType.getStatuses());

        if (startDateStart != null) {
            query.setParameter("startDateStart", startDateStart);
        }
        if (startDateEnd != null) {
            query.setParameter("startDateEnd", startDateEnd);
        }

        List<Investment> investmentList = query.getResultList();
        List<Investment> investments = new ArrayList<Investment>();
        List<Investment> investmentsPage = new ArrayList<Investment>();
        for (Investment investment : investmentList) {
            if (endDateStart == null && endDateEnd == null) {
                investments.add(investment);
            }
            if (endDateStart != null && endDateEnd == null) {
                if (investment.getLastCollectionPlan().getEndAt().after(endDateStart)) {
                    investments.add(investment);
                }
            }
            if (endDateEnd != null && endDateStart == null) {
                if (investment.getLastCollectionPlan().getEndAt().before(endDateEnd)) {
                    investments.add(investment);
                }
            }
            if (endDateEnd != null && endDateStart != null) {
                if (investment.getLastCollectionPlan().getEndAt().before(endDateEnd) && investment.getLastCollectionPlan().getEndAt().after(endDateStart)) {
                    investments.add(investment);
                }
            }
        }

        for (int i = offset; i < investments.size() && i < pageLimit + offset; i++) {
            investmentsPage.add(investments.get(i));
        }

        /*  .setMaxResults(pageLimit)
        .setFirstResult(offset);*/


        return investmentsPage;

    }

    public List<Investment> findOrderedInvestmentsByStatusTypeDateForPageContorll(User loaner, TradingStatus.Type statusType, int pageLimit, int offset, Date startDate, Date endDate) {
        String criteria = Type.SETTLED.equals(statusType) ? "l.endedAt desc" : "l.code desc";
        StringBuffer queryStringBuffer = new StringBuffer("select distinct i from Investment i left join fetch i.collectionPlans cp join fetch i.loan l join fetch i.loaner lr where lr=:loaner and i.status in(:statuses)");

        if (startDate != null) {
            queryStringBuffer.append(" and l.startAt >=:startDate");
        }
        if (endDate != null) {
            queryStringBuffer.append(" and l.startAt <=:endDate");
        }
        queryStringBuffer.append("  order by " + criteria);

        String queryString = queryStringBuffer.toString();

        TypedQuery query = entityManager.createQuery(queryString, Investment.class)
                .setParameter("loaner", loaner)
                .setParameter("statuses", statusType.getStatuses())
                .setMaxResults(pageLimit)
                .setFirstResult(offset);

        if (startDate != null) {
            query.setParameter("startDate", startDate);
        }
        if (endDate != null) {
            query.setParameter("endDate", endDate);
        }

        return query.getResultList();

    }


    public long countFindOrderedInvestmentsByStatusTypeDateFor(User loaner, TradingStatus.Type statusType, Date startDateStart, Date startDateEnd, Date endDateStart, Date endDateEnd) {
        String criteria = Type.SETTLED.equals(statusType) ? "l.endedAt desc" : "l.code desc";
        StringBuffer queryStringBuffer = new StringBuffer("select distinct i from Investment i left join fetch i.collectionPlans cp join fetch i.loan l join fetch i.loaner lr where lr=:loaner and i.status in(:statuses)");

        if (startDateStart != null) {
            queryStringBuffer.append(" and l.startAt >=:startDateStart");
        }
        if (startDateEnd != null) {
            queryStringBuffer.append(" and l.startAt <=:startDateEnd");
        }
        queryStringBuffer.append("  order by " + criteria);
        String queryString = queryStringBuffer.toString();

        TypedQuery query = entityManager.createQuery(queryString, Investment.class)
                .setParameter("loaner", loaner)
                .setParameter("statuses", statusType.getStatuses());

        if (startDateStart != null) {
            query.setParameter("startDateStart", startDateStart);
        }
        if (startDateEnd != null) {
            query.setParameter("startDateEnd", startDateEnd);
        }


        List<Investment> investmentList = query.getResultList();
        List<Investment> investments = new ArrayList<Investment>();
        for (Investment investment : investmentList) {
            if (endDateStart == null && endDateEnd == null) {
                investments.add(investment);
            }
            if (endDateStart != null && endDateEnd == null) {
                if (investment.getLastCollectionPlan().getEndAt().after(endDateStart)) {
                    investments.add(investment);
                }
            }
            if (endDateEnd != null && endDateStart == null) {
                if (investment.getLastCollectionPlan().getEndAt().before(endDateEnd)) {
                    investments.add(investment);
                }
            }
            if (endDateEnd != null && endDateStart != null) {
                if (investment.getLastCollectionPlan().getEndAt().before(endDateEnd) && investment.getLastCollectionPlan().getEndAt().after(endDateStart)) {
                    investments.add(investment);
                }
            }
        }
        long i = 0;
        if (investments.size() == 0) return i;
        for (Investment investment : investments) {
            i++;
        }
        return i;
    }

    public long countFindOrderedInvestmentsByStatusTypeDateFor(User loaner, TradingStatus.Type statusType, Date startDate, Date endDate) {
        String criteria = Type.SETTLED.equals(statusType) ? "l.endedAt desc" : "l.code desc";
        StringBuffer queryStringBuffer = new StringBuffer("select distinct i from Investment i left join fetch i.collectionPlans cp join fetch i.loan l join fetch i.loaner lr where lr=:loaner and i.status in(:statuses)");

        if (startDate != null) {
            queryStringBuffer.append(" and l.startAt >:startDate");
        }
        if (endDate != null) {
            queryStringBuffer.append(" and l.endedAt >:endDate");
        }
        queryStringBuffer.append("  order by " + criteria);

        String queryString = queryStringBuffer.toString();

        TypedQuery query = entityManager.createQuery(queryString, Investment.class)
                .setParameter("loaner", loaner)
                .setParameter("statuses", statusType.getStatuses());

        if (startDate != null) {
            query.setParameter("startDate", startDate);
        }
        if (endDate != null) {
            query.setParameter("endDate", endDate);
        }


        List<Investment> investments = query.getResultList();
        long i = 0;
        for (Investment investment : investments) {
            i++;
        }
        return i;
    }


    public Map<TradingStatus.Type, Long> countForLoanerByStatusTypes(User loaner, List<TradingStatus.Type> types) {
        HashMap<TradingStatus.Type, Long> result = new HashMap<TradingStatus.Type, Long>();
        for (TradingStatus.Type type : types) {
            result.put(type, 0L);
        }

        ArrayList<TradingStatus> statuses = new ArrayList<TradingStatus>();
        for (TradingStatus.Type type : types) {
            statuses.addAll(type.getStatuses());
        }
        List<TradingStatus> statusList = entityManager.createQuery("select i.status from Investment i where i.loaner=:loaner and i.status in (:statuses)", TradingStatus.class)
                .setParameter("loaner", loaner)
                .setParameter("statuses", statuses)
                .getResultList();

        for (TradingStatus status : statusList) {
            result.put(status.getType(), result.get(status.getType()) + 1);
        }
        return result;
    }

    public Investment findForLoaner(long investmentId, User user) {
        TypedQuery<Investment> investmentTypedQuery = entityManager.createQuery("select invest from Investment invest where invest.id=:id and invest.loaner.id=:loanerId", Investment.class).
                setParameter("id", investmentId).setParameter("loanerId", user.id());
        return getSingleResult(investmentTypedQuery);
    }

    public Money getTotalTradeVolumeOf(List<Long> investmentRequestIdList) {
        return entityManager.createQuery("select sum(i.principal) from Investment i where i.investmentRequest.id in (:investmentRequestIdList)", Money.class)
                .setParameter("investmentRequestIdList", investmentRequestIdList)
                .getSingleResult();
    }

    public List<Investment> findContractUnUploadInvestment(int limit) {
        String queryString = "select invest from Investment invest left join fetch invest.loan join fetch invest.loaner left join fetch invest.investmentRequest where invest.investmentRequest.product.productType = :productType and not exists (select invest from TradeContract tc where tc.investment = invest)";
        return entityManager.createQuery(queryString, Investment.class).setParameter("productType", ProductType.TRANSFER_REQUEST).setMaxResults(limit).getResultList();
    }

    public List<Investment> findOngoingInvestments(int limit, int offset) {
        return entityManager.createQuery("select invest from Investment invest left join fetch invest.collectionPlans join fetch invest.investmentRequest join fetch invest.loaner where invest.status in (:tradingStatuses)", Investment.class).setParameter("tradingStatuses", Type.ONGOING.getStatuses()).setFirstResult(offset).setMaxResults(limit).getResultList();
    }

    public Long countOngoingInvestments() {
       return entityManager.createQuery("select count(invest) from Investment invest where invest.status in (:tradingStatuses)", Long.class).setParameter("tradingStatuses", Type.ONGOING.getStatuses()).getSingleResult();
    }
    /**
     * 客服正在收款
     * @param user
     * @param statusType
     * @return
     */
    public long countInvestmentsByStatusAndUser(User user, TradingStatus.Type statusType) {
    	List<Investment> investments = entityManager.createQuery("select distinct i from Investment i " +
                "left join fetch i.collectionPlans " +
                "join fetch i.investmentRequest ir " +
                "join fetch ir.product " +
                "join fetch i.loan " +
                "where i.loaner=:user " +
                "and i.status in (:statuses) " +
                "order by i.id desc", Investment.class)
                .setParameter("user", user)
                .setParameter("statuses", statusType.getStatusNames())
                .getResultList();
    	return investments.size();
    }
    
    @Transactional
    public List<Investment> findInvestmentsByStatusAndUser(User user, TradingStatus.Type statusType,int pageLimit, int offset) {
    	return entityManager.createQuery("select distinct i from Investment i " +
                "left join fetch i.collectionPlans " +
                "join fetch i.investmentRequest ir " +
                "join fetch ir.product " +
                "join fetch i.loan " +
                "where i.loaner=:user " +
                "and i.status in (:statuses) " +
                "order by ir.createdAt desc", Investment.class)
                .setParameter("user", user)
                .setParameter("statuses", statusType.getStatusNames())
                .setMaxResults(pageLimit)
                .setFirstResult(offset)
                .getResultList();
    }

    public Investment findByProductId(long productId) {
        return getSingleResult(entityManager.createQuery("select i from Investment i left join fetch i.collectionPlans left join fetch i.investmentRequest ir left join fetch ir.product p where p.id=:productId", Investment.class).setParameter("productId", productId));
    }

    @Transactional
    public Map<Investment, Money> getPaidPrincipalsForInvestments(List<Investment> investments) {
        Map<Investment, Money> result = new HashMap<Investment, Money>();
        if(investments.size() == 0){
            return result;
        }

        for (Investment investment : investments) {
            result.put(investment, Money.ZERO_YUAN);
        }

        List<CollectionRecord> collectionRecords = entityManager.createQuery("select r from CollectionRecord r left join fetch r.plan p left join fetch p.investment i where i in (:investments) and r.status=:status", CollectionRecord.class)
                .setParameter("investments", investments)
                .setParameter("status", RecordStatus.DONE.name())
                .getResultList();

        for (CollectionRecord collectionRecord : collectionRecords) {
            Investment investment = collectionRecord.getCollectionPlan().getInvestment();
            result.put(investment, result.get(investment).add(collectionRecord.getPrincipal()));
        }
        return result;
    }
}
