package com.lufax.common.domain.repository;

import com.lufax.common.domain.Province;
import org.springframework.stereotype.Repository;

@Repository
public class ProvinceRepository extends BaseRepository<Province> {

}
