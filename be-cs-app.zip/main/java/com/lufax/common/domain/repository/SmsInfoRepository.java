package com.lufax.common.domain.repository;

import com.lufax.sms.domain.SmsInfo;
import com.lufax.sms.domain.SmsStatus;

import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class SmsInfoRepository extends BaseRepository<SmsInfo> {
    public List<SmsInfo> findAllSMSToSend(int limitQuantity) {
        return entityManager.createQuery("select r from SmsInfo r where r.sendStatus =:newStatus order by r.smsId asc", SmsInfo.class).setParameter("newStatus", SmsStatus.NEW.name()).setMaxResults(limitQuantity).setFirstResult(0).getResultList();
    }
}
