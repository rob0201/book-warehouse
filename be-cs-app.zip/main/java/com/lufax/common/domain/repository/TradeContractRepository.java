package com.lufax.common.domain.repository;

import com.lufax.common.domain.TradeContract;
import org.springframework.stereotype.Repository;

@Repository
public class TradeContractRepository extends BaseRepository<TradeContract> {


}
