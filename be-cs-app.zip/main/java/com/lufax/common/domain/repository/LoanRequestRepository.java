package com.lufax.common.domain.repository;

import static com.lufax.common.utils.DateUtils.startOfDay;
import static com.lufax.common.utils.DateUtils.startOfToday;
import static java.util.Arrays.asList;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.apache.commons.lang.StringUtils;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lufax.common.domain.Identity;
import com.lufax.common.domain.LoanRequest;
import com.lufax.common.domain.LoanRequestStatus;
import com.lufax.common.domain.LoanRequestToXinbaoStatus;
import com.lufax.common.domain.User;
import com.lufax.common.domain.UserIdentity;
import com.lufax.common.domain.product.ProductStatus;

@Repository
public class LoanRequestRepository extends BaseRepository<LoanRequest> {
    @Autowired
    BizParametersRepository bizParametersRepository;

    private static final int LOAN_REQUEST_CONFIRMATION_WAITING_DAYS = 3;

    private static final int LOAN_REQUEST_SEND_MESSAGE_WAITING_DAYS = 2;

    public List<LoanRequest> findAllByStatuses(List<LoanRequestStatus> statuses, int maxNum, int offset) {
        if (statuses.isEmpty()) {
            return Collections.EMPTY_LIST;
        }
        List<String> loanRequestStatuses = transferLoanRequestStatus(statuses);
        return entityManager.createQuery("select r from LoanRequest r left join fetch r.loanee u where r.status in (:statuses) order by r.id desc", LoanRequest.class)
                .setParameter("statuses", loanRequestStatuses).setMaxResults(maxNum).setFirstResult(offset).getResultList();
    }

    public Long countByStatuses(List<LoanRequestStatus> statuses) {
        List<String> loanRequestStatuses = transferLoanRequestStatus(statuses);
        return entityManager.createQuery("select count(r) from LoanRequest r where r.status in (:statuses)", Long.class).setParameter("statuses", loanRequestStatuses).getResultList().get(0);
    }


    public LoanRequest findByCode(String loanRequestCode) {
        return entityManager.createQuery("select r from LoanRequest r where r.code=:code", LoanRequest.class).setParameter("code", loanRequestCode).getSingleResult();
    }


    public List<LoanRequest> findAllSmsUnsent(int limit) {
        Date twoDaysAgo = new DateTime(startOfToday()).minusDays(LOAN_REQUEST_SEND_MESSAGE_WAITING_DAYS).toDate();
        return entityManager.createQuery("select r from LoanRequest r left join fetch r.loanee where r.status = :status and  r.updatedAt < :time and r.flag is null order by r.id asc")
                .setParameter("status", LoanRequestStatus.WAITING_CONFIRM).setParameter("time", twoDaysAgo).setMaxResults(limit).getResultList();
    }

    public LoanRequest findByPolicyNo(String policyNo) {
        return entityManager.createQuery("select l from LoanRequest l left join fetch l.policy left join fetch l.loanee where l.policy.policyNo=:policyNo", LoanRequest.class).setParameter("policyNo", policyNo).getSingleResult();
    }

    public boolean hasPolicyNo(String policyNo) {
        Long num = entityManager.createQuery("select count(l) from LoanRequest l where l.policy.policyNo=:policyNo", Long.class).setParameter("policyNo", policyNo).getResultList().get(0);
        return num > 0;
    }

    public List<LoanRequest> findUnconfirmedLoanRequests(int limit) {
        List<LoanRequestStatus> statuses = new ArrayList<LoanRequestStatus>();
        statuses.add(LoanRequestStatus.UN_CONFIRMED_EXPIRED);
        statuses.add(LoanRequestStatus.LOANEE_WEBSITE_DENIED);
        statuses.add(LoanRequestStatus.LOANEE_TELEPHONE_DENIED);
        statuses.add(LoanRequestStatus.CANCELED);
        List<String> loanRequestStatuses = transferLoanRequestStatus(statuses);
        return entityManager.createQuery("select r from LoanRequest r where r.status in (:statuses) and statusToXinBao in (:statusToXinbao)")
                .setParameter("statuses", loanRequestStatuses)
                .setParameter("statusToXinbao", asList(LoanRequestToXinbaoStatus.MAT_SUCC.name(), LoanRequestToXinbaoStatus.MAT_FAIL.name()))
                .setMaxResults(limit)
                .getResultList();
    }

    private List<String> transferLoanRequestStatus(List<LoanRequestStatus> statuses) {
        List<String> loanRequestStatuses = new ArrayList<String>();
        for (LoanRequestStatus loanRequestStatus : statuses)
            loanRequestStatuses.add(loanRequestStatus.name());
        return loanRequestStatuses;
    }

    public List<LoanRequest> findAllExpiredUnConfirmedLoanRequests(int limit) {
        Date expiryBoundary = new DateTime().minusDays(LOAN_REQUEST_CONFIRMATION_WAITING_DAYS).toDate();
        Date daysAgo = startOfDay(expiryBoundary);

        return entityManager.createQuery("select r from LoanRequest r left join fetch r.loanee where r.status = :status and r.updatedAt < :time order by r.id asc")
                .setParameter("status", LoanRequestStatus.WAITING_CONFIRM.name()).setParameter("time", daysAgo)
                .setMaxResults(limit).getResultList();
    }

    public List<LoanRequest> findAllForLoanee(User loanee) {
        return entityManager.createQuery("select l from LoanRequest l left join fetch l.policy where l.loanee = :loanee order by l.createdAt DESC").setParameter("loanee", loanee).getResultList();
    }

	public List<LoanRequest> findLoanRequestInExceptionStatus(String mobileNo, String identityNumber) {
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<LoanRequest> criteriaQuery = cb.createQuery(LoanRequest.class);
        Root<LoanRequest> root = criteriaQuery.from(LoanRequest.class);
        Join<LoanRequest, User> user = root.join("loanee", JoinType.INNER);
        criteriaQuery.select(root);
        List<Predicate> predicateList = new ArrayList<Predicate>();
        if (mobileNo != null && !"".equals(mobileNo)) {
            Predicate predicate = cb.equal(user.<String>get("mobileNo"), mobileNo);
            predicateList.add(predicate);
        }
        if (identityNumber != null && !"".equals(identityNumber)) {
            Predicate predicate = cb.equal(user.<UserIdentity>get("identity").<Identity>get("identity").<String>get("number"), identityNumber);
            predicateList.add(predicate);
        }
//        predicateList.add(cb.notEqual(root.<String>get("status"), LoanRequestStatus.SUCCESS.name()));
//        predicateList.add(cb.notEqual(root.<String>get("status"), LoanRequestStatus.WAITING_INVEST.name()));
//        predicateList.add(cb.notEqual(root.<String>get("status"), LoanRequestStatus.CHECK_SUCCESS.name()));
        Predicate predicate = cb.not(cb.in(root.<String>get("status")).value(LoanRequestStatus.SUCCESS.name()).value(LoanRequestStatus.WAITING_INVEST.name()).value(LoanRequestStatus.CHECK_SUCCESS.name()));
        predicateList.add(predicate);
        

        Predicate[] predicates = new Predicate[predicateList.size()];
        predicateList.toArray(predicates);
        criteriaQuery.where(predicates);
        return entityManager.createQuery(criteriaQuery).getResultList();
	}
	
	/**
     * 贷款请求取消查询：状态为等待上架的产品
     */
    public long countOfProductForCanncel(String cardNo,String loanRequestCode){
    	String hql = "select count(l) from LoanRequest l  where (l.product.productStatus = :planned or l.product.productStatus = :unplanned or l.product.productStatus =:offline ) ";
    	if(!StringUtils.isEmpty(cardNo)){
    		hql = hql + " and l.loanee.identity.identity.number=:cardNo ";
    	}
    	if(!StringUtils.isEmpty(loanRequestCode)){
    		hql = hql + " and l.code=:loanRequestCode ";
    	}
    	TypedQuery query  = (TypedQuery)entityManager.createQuery(hql);
    	if(!StringUtils.isEmpty(cardNo)){
    		query.setParameter("cardNo", cardNo);
    	}
    	if(!StringUtils.isEmpty(loanRequestCode)){
    		query.setParameter("loanRequestCode", loanRequestCode);
    	}
    	query.setParameter("planned", ProductStatus.PLANNED.name()).setParameter("unplanned", ProductStatus.UNPLANNED.name()).setParameter("offline", ProductStatus.OFFLINE.name());
    	return (Long)query.getSingleResult();
    }
    
    /**
     * 贷款请求取消查询：状态为等待上架的产品
     */
    public List<LoanRequest> queryProductForCanncel(String cardNo,String loanRequestCode,int maxNum,int offSet){
    	String hql = "select l from LoanRequest l  where (l.product.productStatus = :planned or l.product.productStatus = :unplanned or l.product.productStatus =:offline ) ";
    	if(!StringUtils.isEmpty(cardNo)){
    		hql = hql + " and l.loanee.identity.identity.number=:cardNo ";
    	}
    	if(!StringUtils.isEmpty(loanRequestCode)){
    		hql = hql + " and l.code=:loanRequestCode ";
    	}
    	hql = hql + " order by l.product.createdAt desc ";
    	TypedQuery query  = (TypedQuery)entityManager.createQuery(hql);
    	if(!StringUtils.isEmpty(cardNo)){
    		query.setParameter("cardNo", cardNo);
    	}
    	if(!StringUtils.isEmpty(loanRequestCode)){
    		query.setParameter("loanRequestCode", loanRequestCode);
    	}
    	query.setParameter("planned", ProductStatus.PLANNED.name()).setParameter("unplanned", ProductStatus.UNPLANNED.name()).setParameter("offline", ProductStatus.OFFLINE.name()).setFirstResult(offSet).setMaxResults(maxNum);
    	return query.getResultList();
    }
	
}
