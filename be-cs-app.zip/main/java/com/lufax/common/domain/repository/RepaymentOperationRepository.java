package com.lufax.common.domain.repository;

import com.lufax.common.domain.RechargeRecord;
import com.lufax.common.domain.RepaymentOperation;
import com.lufax.common.utils.DevLog;
import org.springframework.stereotype.Repository;

@Repository
public class RepaymentOperationRepository extends BaseRepository<RepaymentOperation> {
    public RepaymentOperation findByRechargeRecord(RechargeRecord rechargeRecord) {
        RepaymentOperation repaymentOperation=null;
        try{
         repaymentOperation = entityManager.createQuery("select r from RepaymentOperation r where r.rechargeRecord=:rechargeRecord", RepaymentOperation.class).setParameter("rechargeRecord", rechargeRecord).getSingleResult();
        }catch (Exception e){
            DevLog.info(this,"when try to find repaymentOperation , the rechargeRecord id is "+rechargeRecord.id());
        }
        return   repaymentOperation;
    }
}
