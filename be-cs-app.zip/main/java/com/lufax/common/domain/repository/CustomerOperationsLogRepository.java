package com.lufax.common.domain.repository;

import com.lufax.customerService.domain.OperationsLog;
import org.springframework.stereotype.Repository;

@Repository
public class CustomerOperationsLogRepository extends BaseRepository<OperationsLog> {

}
