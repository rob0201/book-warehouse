package com.lufax.common.domain.repository;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaBuilder.In;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.lufax.common.domain.InsurancePolicyStatus;
import com.lufax.common.domain.OriginalInsurancePolicy;
import com.lufax.common.utils.EmptyChecker;

@Repository
public class OriginalInsurancePolicyRepository extends BaseRepository<OriginalInsurancePolicy> {
    public boolean isInsurancePolicyExist(String policyNo) {
        Long numOfOriginalInsurancePolicy = entityManager.createQuery("select count(o) from OriginalInsurancePolicy o where o.policyNo=:policyNo", Long.class).setParameter("policyNo", policyNo).getResultList().get(0);
        return numOfOriginalInsurancePolicy > 0;
    }
    public OriginalInsurancePolicy findByPolicyNo(String policyNo) {
        return entityManager.createQuery("select o from OriginalInsurancePolicy o where o.policyNo=:policyNo", OriginalInsurancePolicy.class).setParameter("policyNo", policyNo).getSingleResult();
    }

    public List<OriginalInsurancePolicy> findAllUnsynchronizedWithMemberSystem(int limit) {
        return entityManager.createQuery("select oip from OriginalInsurancePolicy oip where oip.sentToMemberSystem = :sentToMemberSystem", OriginalInsurancePolicy.class)
                            .setParameter("sentToMemberSystem", false).setMaxResults(limit).getResultList();
    }
    
	public long countOriginalInsurancePolicyWithoutStatus(String policyNo, Date fromDate, Date toDate, List<InsurancePolicyStatus> withoutStatusList) {
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<Long> criteriaQuery = cb.createQuery(Long.class);
        Root<OriginalInsurancePolicy> root = criteriaQuery.from(OriginalInsurancePolicy.class);
        criteriaQuery.select(cb.count(root));
        List<Predicate> predicateList = new ArrayList<Predicate>();
        if (policyNo != null && !"".equals(policyNo)) {
            Predicate predicate = cb.equal(root.<String>get("policyNo"), policyNo);
            predicateList.add(predicate);
        }
        if (fromDate != null) {
            Predicate predicate = cb.greaterThanOrEqualTo(root.<Date>get("createdAt"), fromDate);
            predicateList.add(predicate);
        }
        if (toDate != null) {
            Predicate predicate = cb.lessThanOrEqualTo(root.<Date>get("createdAt"), toDate);
            predicateList.add(predicate);
        }
        if(!EmptyChecker.isEmpty(withoutStatusList)){
        	In<String> inCb = cb.in(root.<String>get("status"));
            for(InsurancePolicyStatus status : withoutStatusList){
            	inCb = inCb.value(status.name());
            }
        	predicateList.add(cb.not(inCb));
        }
        
        Predicate[] predicates = new Predicate[predicateList.size()];
        predicateList.toArray(predicates);
        criteriaQuery.where(predicates);
        return entityManager.createQuery(criteriaQuery).getSingleResult();
	}
	
	public List<OriginalInsurancePolicy> findOriginalInsurancePolicyWithoutStatus(String policyNo, Date fromDate, Date toDate, List<InsurancePolicyStatus> withoutStatusList, int firstNum, int maxNum) {
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<OriginalInsurancePolicy> criteriaQuery = cb.createQuery(OriginalInsurancePolicy.class);
        Root<OriginalInsurancePolicy> root = criteriaQuery.from(OriginalInsurancePolicy.class);
        criteriaQuery.select(root);
        List<Predicate> predicateList = new ArrayList<Predicate>();
        if (policyNo != null && !"".equals(policyNo)) {
            Predicate predicate = cb.equal(root.<String>get("policyNo"), policyNo);
            predicateList.add(predicate);
        }
        if (fromDate != null) {
            Predicate predicate = cb.greaterThanOrEqualTo(root.<Date>get("createdAt"), fromDate);
            predicateList.add(predicate);
        }
        if (toDate != null) {
            Predicate predicate = cb.lessThanOrEqualTo(root.<Date>get("createdAt"), toDate);
            predicateList.add(predicate);
        }
        for(InsurancePolicyStatus status : withoutStatusList){
        	Predicate predicate = cb.notEqual(root.<String>get("status"), status.name());
            predicateList.add(predicate);
        }

        Predicate[] predicates = new Predicate[predicateList.size()];
        predicateList.toArray(predicates);
        criteriaQuery.where(predicates);
        return entityManager.createQuery(criteriaQuery).setFirstResult(firstNum).setMaxResults(maxNum).getResultList();
	}
}
