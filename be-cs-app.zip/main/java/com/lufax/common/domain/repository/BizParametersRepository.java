package com.lufax.common.domain.repository;

import com.lufax.common.domain.BizParameters;
import com.lufax.common.domain.PaymentMethodFactory;
import com.lufax.common.domain.account.Money;
import com.lufax.common.utils.DevLog;
import com.lufax.common.utils.StringUtils;
import org.springframework.stereotype.Repository;

import javax.persistence.TypedQuery;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.lufax.common.domain.BizParameters.*;
import static java.util.Arrays.asList;

@Repository
public class BizParametersRepository extends BaseRepository<BizParameters> {

    public BigDecimal findParameterValueByCode(String parameterCode) {
        DevLog.debug(this, String.format("query for biz parameter with code : %s", parameterCode));
        BizParameters result = getSingleResult(queryByCodes(asList(parameterCode)));

        if (result == null) {
            DevLog.warn(this, String.format("biz parameter value for %s has not been found", parameterCode));
            return null;
        }

        DevLog.info(this, String.format("biz parameter value %s for %s", result.getParameterValue(), parameterCode));
        return result.getParameterValue();
    }

    public Map<String, BigDecimal> findAllParameterValuesByCodes(List<String> parameterCodes) {
        DevLog.info(this, String.format("query for biz parameter with codes : %s", StringUtils.join(parameterCodes, ",")));
        List<BizParameters> parameters = queryByCodes(parameterCodes).getResultList();

        Map<String, BigDecimal> results = new HashMap<String, BigDecimal>();
        for (BizParameters bizParameter : parameters) {
            results.put(bizParameter.getParameterCode(), bizParameter.getParameterValue());
        }

        for (String parameterCode : parameterCodes) {
            if (results.get(parameterCode) == null) {
                DevLog.info(this, String.format("biz parameter value for %s has not been found", parameterCode));
                continue;
            }
            DevLog.info(this, String.format("biz parameter value %s for %s", results.get(parameterCode), parameterCode));
            results.put(parameterCode, results.get(parameterCode));
        }
        return results;
    }

    private TypedQuery<BizParameters> queryByCodes(List<String> codes) {
        String queryString = "select b from BizParameters b where b.parameterCode in (:parameterCodes) and b.startDate = (select max(c.startDate) from BizParameters c where c.parameterCode = b.parameterCode and c.startDate <= sysdate)";
        return entityManager.createQuery(queryString, BizParameters.class).setParameter("parameterCodes", codes);
    }

    public Map<String, BigDecimal> getInterestRateParameters(int numberOfInstalments) {
        String baseInterestRateKey = PaymentMethodFactory.getBaseInterestRateKey(numberOfInstalments);
        Map<String, BigDecimal> interestRateParameters = findAllParameterValuesByCodes(asList(baseInterestRateKey, INTEREST_FLOAT_RATE));
        interestRateParameters.put(BASE_INTEREST_RATE, interestRateParameters.remove(baseInterestRateKey));
        return interestRateParameters;
    }

    public BigDecimal getBaseInterestRate(int numberOfInstalments) {
        return findParameterValueByCode(PaymentMethodFactory.getBaseInterestRateKey(numberOfInstalments));
    }

    public BigDecimal getInterestFloatRate() {
        return findParameterValueByCode(INTEREST_FLOAT_RATE);
    }

    public BigDecimal getManagementFeeRateForLoanee() {
        return findParameterValueByCode(MANAGEMENT_FEE_RATE_LOANEE);
    }


    public BigDecimal getMaxLoanRequestAmount() {
        return findParameterValueByCode(LOAN_REQUEST_MAX_AMOUNT);
    }

    public Money getGuarantorWithdrawalMinAmount() {
        BigDecimal parameterValue = findParameterValueByCode(GUARANTOR_WITHDRAWAL_MIN_AMOUNT);
        return Money.rmb(parameterValue);
    }


    public Map<String, BigDecimal> getLoanRequestConfirmParameters() {
        return findAllParameterValuesByCodes(asList(LOAN_TRANSACTION_FEE_RATE, MANAGEMENT_FEE_RATE_LOANER, OVERDUE_FLOAT_RATE, OVERDUE_EXTENSION_DAYS));
    }

    public BigDecimal getTransactionFeeRate() {
        return findParameterValueByCode(LOAN_TRANSACTION_FEE_RATE);
    }

    public BigDecimal getLoanRequestValidPeriod() {
        return findParameterValueByCode(LOAN_REQUEST_VALID_PERIOD);
    }

    public BizParameters findByCode(String parameterCode) {
        return getSingleResult(queryByCodes(asList(parameterCode)));
    }

    public Map<String, BigDecimal> findAllBizParametersMap() {
        String queryString = "select b from BizParameters b where b.startDate <= sysdate order by b.startDate asc";
        return convertToMap(entityManager.createQuery(queryString, BizParameters.class).getResultList());
    }

    private Map<String, BigDecimal> convertToMap(List<BizParameters> parameters) {
        Map<String, BigDecimal> results = new HashMap<String, BigDecimal>();
        for (BizParameters bizParameter : parameters) {
            results.put(bizParameter.getParameterCode(), bizParameter.getParameterValue());
        }
        return results;
    }

    public Map<String, BigDecimal> getPrepayParameters() {
        return findAllParameterValuesByCodes(asList(LOANER_PANEL_RATE_MORE_THAN_11_MONTHS, LOANER_PANEL_RATE_BETWEEN_5_AND_11_MONTHS, LOANER_PANEL_RATE_WITHIN_5_MONTHS,
                INSURANCE_MANAGEMENT_FEE_MORE_THAN_11_MONTHS, INSURANCE_MANAGEMENT_FEE_BETWEEN_5_AND_11_MONTHS, INSURANCE_MANAGEMENT_FEE_WITHIN_5_MONTHS,
                P2P_PREPAY_FEE_MORE_THAN_11_MONTHS, P2P_PREPAY_FEE_BETWEEN_5_AND_11_MONTHS, P2P_PREPAY_FEE_WITHIN_5_MONTHS));
    }
}
