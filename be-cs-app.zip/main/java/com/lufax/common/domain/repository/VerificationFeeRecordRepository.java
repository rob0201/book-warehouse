package com.lufax.common.domain.repository;

import com.lufax.common.domain.VerificationFeeRecord;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

import static com.lufax.common.domain.VerificationFeeStatus.FAILURE;
import static com.lufax.common.domain.VerificationFeeStatus.SUCCESS;
import static com.lufax.sms.domain.SmsSentStatus.UNSENT;

@Repository
public class VerificationFeeRecordRepository extends BaseRepository<VerificationFeeRecord> {
    @Autowired
    BizParametersRepository bizParametersRepository;



    public List findAllUnSent(int warningDays, int limit) {
        Date queryDate = new DateTime().minusDays(warningDays).toDate();
        StringBuilder query = new StringBuilder();
        query.append(" select b from VerificationFeeRecord b where ");
        query.append(" b.smsSentStatus =:smsSentStatus ");
        query.append(" and (b.status =:failedStatus or (b.status =:successStatus and b.virementAt < :queryDate)) ");
        return entityManager.createQuery(query.toString())
                .setParameter("smsSentStatus", UNSENT.name())
                .setParameter("failedStatus", FAILURE.name())
                .setParameter("successStatus", SUCCESS.name())
                .setParameter("queryDate", queryDate)
                .setMaxResults(limit)
                .getResultList();
    }
}
