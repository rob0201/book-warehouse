package com.lufax.common.domain.repository;

import com.lufax.common.domain.LoanRequestStatus;
import com.lufax.common.domain.StatusChangeHistory;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class StatusChangeHistoryRepository extends BaseRepository<StatusChangeHistory> {

    public List<StatusChangeHistory> findByLoanRequestCode(String loanRequestCode) {
        return entityManager.createQuery("select sch from StatusChangeHistory sch where sch.loanRequestCode=:loanRequestCode", StatusChangeHistory.class).setParameter("loanRequestCode", loanRequestCode).getResultList();
    }

    public List<StatusChangeHistory> findByLoanCode(String loanCode) {
        return entityManager.createQuery("select sch from StatusChangeHistory sch where sch.loanCode=:loanCode", StatusChangeHistory.class).setParameter("loanCode", loanCode).getResultList();
    }

    public List<StatusChangeHistory> findByInvestmentRequestId(long investmentRequestId) {
        return entityManager.createQuery("select sch from StatusChangeHistory sch where sch.investmentRequestId=:investmentRequestId", StatusChangeHistory.class).setParameter("investmentRequestId", investmentRequestId).getResultList();
    }

    public List<StatusChangeHistory> findByInvestmentId(long investmentId) {
        return entityManager.createQuery("select sch from StatusChangeHistory sch where sch.investmentId=:investmentId", StatusChangeHistory.class).setParameter("investmentId", investmentId).getResultList();
    }

    public StatusChangeHistory findByLoanRequestCodeAndStatus(String loanRequestCode, LoanRequestStatus status) {
        return getSingleResult(entityManager.createQuery("select sch from StatusChangeHistory sch where sch.loanRequestCode=:loanRequestCode and sch.status=:status", StatusChangeHistory.class)
                .setParameter("loanRequestCode", loanRequestCode).setParameter("status", status.toString()));
    }
}

