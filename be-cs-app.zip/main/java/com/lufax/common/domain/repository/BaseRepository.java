package com.lufax.common.domain.repository;

import org.springframework.transaction.annotation.Transactional;

import javax.persistence.*;
import java.lang.reflect.ParameterizedType;
import java.util.List;

public abstract class BaseRepository<T> {

    @PersistenceContext
    protected EntityManager entityManager;

    @Transactional
    public void persist(T domainObject) {
        entityManager.persist(domainObject);
    }

    public T load(long id) {
        return entityManager.find(getDomainClass(), id);
    }

    public T load(String id) {
        return entityManager.find(getDomainClass(), id);
    }

    @Transactional
    public T update(T domainObject) {
        return entityManager.merge(domainObject);
    }

    @Transactional
    public  <T> void  remove(T domainObject){
        entityManager.remove(domainObject);
    }

    private Class<T> getDomainClass() {
        return (Class<T>) (((ParameterizedType) getClass().getGenericSuperclass()).getActualTypeArguments()[0]);
    }

    public T findFirst(String query, Object... parameters) {
        Query queryObject = entityManager.createQuery(query).setMaxResults(1);
        for (int i = 0; i < parameters.length; i++)
            queryObject.setParameter(i + 1, parameters[i]);
        List result = queryObject.getResultList();
        return result.isEmpty() ? null : (T) result.get(0);
    }

    public T getSingleResult(TypedQuery<T> entity) {
        try {
            return entity.getSingleResult();
        } catch (NoResultException exception) {
            return null;
        }
    }
}
