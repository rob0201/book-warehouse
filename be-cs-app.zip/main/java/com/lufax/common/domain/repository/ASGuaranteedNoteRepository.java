package com.lufax.common.domain.repository;

import org.springframework.stereotype.Service;

import com.lufax.common.domain.ASGuaranteedNote;
import com.lufax.common.utils.DevLog;

@Service
public class ASGuaranteedNoteRepository extends BaseRepository<ASGuaranteedNote>{
    public ASGuaranteedNote findByAsLoanRequestId(Long asLoanRequestId) {
    	try {
    		return entityManager.createQuery("select agn from ASGuaranteedNote agn where agn.asLoanRequestId = :asLoanRequestId",ASGuaranteedNote.class).setParameter("asLoanRequestId", asLoanRequestId).getSingleResult();
    	} catch(Exception e) {
    		DevLog.warn(this, "The as loanRequest id [" + asLoanRequestId + "] don't find the as guarantee node");
    		return null;
    	}
    }
    public ASGuaranteedNote findByAsLoanRequestCode(String asLoanRequestCode) {
    	try {
    		return entityManager.createQuery("select agn from ASGuaranteedNote agn where agn.asLoanRequestCode = :asLoanRequestCode",ASGuaranteedNote.class).setParameter("asLoanRequestCode", asLoanRequestCode).getSingleResult();
    	} catch(Exception e) {
    		DevLog.warn(this, "The as loanRequest code [" + asLoanRequestCode + "] don't find the as guarantee node");
    		return null;
    	}
    }
}
