package com.lufax.common.domain.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.lufax.common.domain.SpecialDay;

@Repository
public class SpecialDayRepository extends BaseRepository<SpecialDay> {
    public List<SpecialDay> findAll() {
        return entityManager.createQuery("select b from SpecialDay b ", SpecialDay.class).getResultList();
    }
}
