package com.lufax.common.domain.repository;

import com.lufax.common.domain.Loan;
import com.lufax.common.domain.RecordStatus;
import com.lufax.common.domain.RepaymentRecord;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class RepaymentRecordRepository extends BaseRepository<RepaymentRecord> {
    public List<RepaymentRecord> findAllSettledByLoan(Loan loan) {
        return entityManager.createQuery("select record from RepaymentRecord record left join fetch record.plan p where p.loan=:loan and record.status=:status order by record.recordNumber asc", RepaymentRecord.class)
                .setParameter("loan", loan)
                .setParameter("status", RecordStatus.DONE.name())
                .getResultList();
    }

    public List<RepaymentRecord> findAllUnsent(int limit) {
        return entityManager.createQuery("select record from RepaymentRecord record left join fetch record.plan where record.statusToXinbao is null and record.status=:status", RepaymentRecord.class)
                .setParameter("status", RecordStatus.DONE.name())
                .setMaxResults(limit)
                .getResultList();
    }
}
