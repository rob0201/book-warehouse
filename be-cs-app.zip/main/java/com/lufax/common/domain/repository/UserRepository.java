package com.lufax.common.domain.repository;

import com.lufax.common.domain.*;
import com.lufax.common.utils.DevLog;
import org.joda.time.DateTime;
import org.springframework.stereotype.Repository;

import javax.persistence.TypedQuery;
import java.util.Date;
import java.util.List;

import static com.lufax.common.utils.DateUtils.startOfDay;

@Repository
public class UserRepository extends BaseRepository<User> {
    private Long p2pUserId;
    private Long guarantorUserId;

    public User findByCredential(Credential credential) {
        return findFirst("select u from User u where u.credential = ?1 and u.status !=?2", credential, UserStatus.DELETED.name());
    }

    //Will use this method for user 5 info identify in the future
    public boolean isUserIdentityExist(UserIdentity userIdentity) {
        DateTime startTime = new DateTime(startOfDay(userIdentity.getBirthDay()));
        Date start = startTime.toDate();
        Date end = startTime.plusDays(1).toDate();
        String queryString = "select count(u) from User u where u.identity.name=:name and u.identity.gender=:gender and u.identity.birthDay>=:start and u.identity.birthDay<=:end and u.identity.identity.number=:number and u.identity.identity.type=:type";
        Long numOfUser = entityManager.createQuery(queryString, Long.class)
                .setParameter("name", userIdentity.getName())
                .setParameter("gender", userIdentity.getGender())
                .setParameter("start", start)
                .setParameter("end", end)
                .setParameter("number", userIdentity.getIdentity().getNumber())
                .setParameter("type", userIdentity.getIdentity().getType()).getResultList().get(0);
        return numOfUser > 0;
    }

    public boolean mobileUsedByOtherIdentities(String number, String mobileNo) {
        String queryString = "select count(u) from User u where u.identity.identity.number!=:number and u.mobileNo=:mobileNo and u.status !=:status";
        Long numOfUser = entityManager.createQuery(queryString, Long.class)
                .setParameter("number", number)
                .setParameter("mobileNo", mobileNo).setParameter("status", UserStatus.DELETED.name()).getResultList().get(0);
        return numOfUser > 0;
    }

    public boolean identityUsedByOtherMobiles(String number, String mobileNo) {
        String queryString = "select count(u) from User u where u.identity.identity.number=:number and u.mobileNo!=:mobileNo and u.status !=:status";
        Long numOfUser = entityManager.createQuery(queryString, Long.class)
                .setParameter("number", number)
                .setParameter("mobileNo", mobileNo).setParameter("status", UserStatus.DELETED.name()).getResultList().get(0);
        return numOfUser > 0;
    }

    public User findById(long userId) {
        try {
            return entityManager.createQuery("select u from User u where u.id = :id and u.status !=:status", User.class).setParameter("id", userId).setParameter("status", UserStatus.DELETED.name()).getSingleResult();
        } catch (Exception ex) {
            DevLog.error(this,"Failed to load the user id [" + userId + "]", ex);
            return null;
        }
    }

    public User findByUserName(String userName) {
        return findFirst("select distinct u from User u left join fetch u.accounts where u.credential.username = ?1", userName);
    }

    public User findByPartyNo(String partyNo) {
        String queryString = "select u from User u where u.partyNo = :partyNo and u.status != :status";
        TypedQuery<User> userTypedQuery = entityManager.createQuery(queryString, User.class).setParameter("partyNo", partyNo).setParameter("status", UserStatus.DELETED.name());
        return getSingleResult(userTypedQuery);
    }

    //Will use this method instead of findByIdentityNumberAndMobileNo in the future
    public User findByUserIdentity(UserIdentity userIdentity) {
        String queryString = "select u from User u where u.identity.name=:name and u.identity.gender=:gender and u.identity.identity.number=:number and u.identity.identity.type=:type";
        return entityManager.createQuery(queryString, User.class).setParameter("name", userIdentity.getName()).setParameter("gender", userIdentity.getGender()).setParameter("number", userIdentity.getIdentity().getNumber()).setParameter("type", userIdentity.getIdentity().getType()).getSingleResult();
    }

    public User findByIdentityNumberAndMobileNo(String number, String mobileNo) {
        String queryString = "select u from User u where u.identity.identity.number=:number and u.mobileNo =:mobileNo and u.status !=:status";
        TypedQuery<User> userTypedQuery = entityManager.createQuery(queryString, User.class)
                .setParameter("number", number).setParameter("mobileNo", mobileNo).setParameter("status", UserStatus.DELETED.name());
        return getSingleResult(userTypedQuery);
    }

    public List<User> findAllByMobileNo(String mobileNo) {
        String queryString = "select u from User u where u.mobileNo =:mobileNo and u.status !=:status";
        return entityManager.createQuery(queryString, User.class)
                .setParameter("mobileNo", mobileNo).setParameter("status", UserStatus.DELETED.name()).getResultList();
    }

    public List<User> findAllByIdentityNumber(String identityNumber) {
        String queryString = "select u from User u where u.identity.identity.number =:identityNumber and u.status !=:status";
        return entityManager.createQuery(queryString, User.class)
                .setParameter("identityNumber", identityNumber).setParameter("status", UserStatus.DELETED.name()).getResultList();
    }

    public User findP2PUser() {
        if (p2pUserId == null) {
            User p2p = findByUserRole(UserRole.P2P);
            p2pUserId = p2p.id();
            return p2p;
        }
        return load(p2pUserId);
    }

    public User findGuarantorUser() {
        if (guarantorUserId == null) {
            User guarantor = findByUserRole(UserRole.GUARANTOR);
            guarantorUserId = guarantor.id();
            return guarantor;
        }
        return load(guarantorUserId);
    }

    private User findByUserRole(UserRole userRole) {
        return findFirst("select distinct u from User u left join fetch u.accounts where u.userRole = ?1", userRole.name());
    }

    public List<User> findAllRareWordsUsers() {
        return entityManager.createQuery("select distinct u from User u where u.isRareWord=:isRareWord and u.bankIdentity.bankCode=:bankCode", User.class)
                .setParameter("isRareWord", true)
                .setParameter("bankCode", "A00")
                .getResultList();
    }

    public List<User> findAllRareWordsUsers2() {
        return entityManager.createQuery("select distinct u from User u where u.isRareWord=:isRareWord ", User.class)
                .setParameter("isRareWord", true)
                .getResultList();
    }

    public List<User> findAllUsersByRareWords(String rareWord) {
        return entityManager.createQuery("select distinct u from User u where u.identity.name like :rareWord", User.class).setParameter("rareWord", "%" + rareWord + "").getResultList();
    }

//    public List<User> findAllUsers() {
//        return entityManager.createQuery("select distinct u from User u where u.", User.class).getResultList();
//    }

    public List<String> findMobileByUserIds(List<Long> userIds){
    	return entityManager.createQuery("select u.mobileNo from User u where u.id in(:userIds)").setParameter("userIds", userIds).getResultList();
    }
    
    public List<String> findEmailByUserIds(List<Long> userIds){
    	return entityManager.createQuery("select u.email from User u where u.id in(:userIds)").setParameter("userIds", userIds).getResultList();
    }
}
