package com.lufax.common.domain.repository;

import java.util.List;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.lufax.common.domain.CollectionPlan;
import com.lufax.common.domain.PlanStatus;
import com.lufax.common.domain.User;

@Repository
public class CollectionPlanRepository extends BaseRepository<CollectionPlan> {
	
	public List<CollectionPlan> findByInvestmentIdWithAllRecords(long investmentId) {
        return entityManager.createQuery("select distinct c from CollectionPlan c " +
                "left join fetch c.records r " +
                "left join fetch r.investmentManagementFeeRecord " +
                "left join fetch r.investmentTransactionFeeRecord " +
                "where c.investment.id =:investmentId " +
                "order by c.planNumber asc", CollectionPlan.class)
                .setParameter("investmentId", investmentId)
                .getResultList();
    }
	
	@Transactional
    public List<CollectionPlan> findAllByInvestmentId(long investmentId) {
        return entityManager.createQuery("select distinct c from CollectionPlan c left join fetch c.records where c.investment.id = :investmentId order by c.planNumber", CollectionPlan.class)
                .setParameter("investmentId", investmentId)
                .getResultList();
    }

    public List<CollectionPlan> findAllByStatusTypeFor(User loaner, PlanStatus.Type statusType) {
        return entityManager.createQuery("select distinct c from CollectionPlan c left join fetch c.investment i left join fetch i.loan l left join fetch c.records where c.investment.loaner = :loaner and c.status in (:statuses)", CollectionPlan.class)
                .setParameter("loaner", loaner)
                .setParameter("statuses", statusType.getPlanStatus())
                .getResultList();
    }


}
