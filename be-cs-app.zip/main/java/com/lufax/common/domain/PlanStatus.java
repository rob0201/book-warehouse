package com.lufax.common.domain;

import java.util.ArrayList;
import java.util.List;

public enum PlanStatus {
	UNPAID(Type.ONGOING, "未付", "9"),
    PROCESSING(Type.ONGOING, "代扣中", "6"),
    OVERDUE(Type.ONGOING, "逾期", "2"),
    PAID(Type.SETTLED, "已付清", "1"),
    PREPAID(Type.SETTLED, "提前还清", "4"),
    TRANSFER(Type.SETTLED, "已转让", "7"),
    COMP_DONE(Type.SETTLED, "代偿后结清", "5"),
    UNKNOWN(Type.UNKNOWN,"unknown","unknown");

    private Type type;
    private String value;
    private String code;

    PlanStatus(Type type, String value, String code) {
        this.type = type;
        this.value = value;
        this.code = code;
    }

    public String getValue() {
        return value;
    }

    public String getCode() {
        return code;
    }

    public boolean isSettled() {
        return Type.SETTLED == type;
    }

    public boolean isOngoing() {
        return Type.ONGOING == type;
    }

    public static PlanStatus getPlanStatusByName(String status){
        PlanStatus[] planStatuses=PlanStatus.values();
        for(PlanStatus planStatus:planStatuses)
            if(planStatus.name().equalsIgnoreCase(status))
                return planStatus;
        return  UNKNOWN;
    }

    public static enum Type {
        ONGOING,
        SETTLED,
        UNKNOWN;

        public List<PlanStatus> getStatuses() {
            List<PlanStatus> result = new ArrayList<PlanStatus>();
            for (PlanStatus status : PlanStatus.values()) {
                if (this.equals(status.type)) {
                    result.add(status);
                }
            }
            return result;
        }

        public List<String> getPlanStatus(){
            List<PlanStatus> planStatuses=getStatuses();
            if(planStatuses==null)
                return null;
            List<String> statuses=new ArrayList<String>();
            for(PlanStatus planStatus:planStatuses)
                statuses.add(planStatus.name());
            return statuses;

        }
    }
}
