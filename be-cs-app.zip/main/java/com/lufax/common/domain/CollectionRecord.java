package com.lufax.common.domain;

import java.util.Date;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.lufax.common.domain.account.Money;

@Entity
@Table(name = "COLLECTION_RECORDS")
public class CollectionRecord extends Record {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_COLLECTION_RECORDS")
    @SequenceGenerator(name = "SEQ_COLLECTION_RECORDS", sequenceName = "SEQ_COLLECTION_RECORDS", allocationSize = 1)
    private long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "COLLECTION_PLAN_ID")
    private CollectionPlan plan;
    
//    @OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL, mappedBy = "collectionRecord")
//    private InvestmentManagementFeeRecord investmentManagementFeeRecord;
    
    @OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL, mappedBy = "collectionRecord")
    private InvestmentManagementFeeRecord investmentManagementFeeRecord;

    @OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL, mappedBy = "collectionRecord")
    private InvestmentTransactionFeeRecord investmentTransactionFeeRecord;
    
//    @Embedded
//    @AttributeOverrides({@AttributeOverride(name = "amount", column = @Column(name = "MANAGEMENT_FEE"))})
//    private Money managementFee = Money.ZERO_YUAN;
//
//    

    public Money getManagementFee() {
    	if(investmentManagementFeeRecord != null) {
    		return investmentManagementFeeRecord.getInvestmentManagementFee();
    	}
		return managementFee;
	}

	public void setManagementFee(Money managementFee) {
		this.managementFee = managementFee;
	}

	public CollectionRecord() {
    }

    public CollectionRecord(RepaymentOperation repaymentOperation, CollectionPlan collectionPlan, RecordStatus status, Money principal, Money interest, Money managementFee, Money overduePenalValue, Money penalValue) {
        this(repaymentOperation, collectionPlan, principal.add(interest).add(penalValue).add(overduePenalValue), principal, interest, managementFee, penalValue, overduePenalValue, status, new Date());
    }

    public CollectionRecord(RepaymentOperation repaymentOperation, CollectionPlan collectionPlan, Money principal, Money interest, Money managementFee, Money penalValue, Money overduePenalValue, RecordStatus status, Date createAt) {
        this(repaymentOperation, collectionPlan, principal.add(interest).add(penalValue).add(overduePenalValue), principal, interest, managementFee, penalValue, overduePenalValue, status, createAt);
    }

    public CollectionRecord(RepaymentOperation repaymentOperation, CollectionDetail collectionDetail, Money penalValue) {
        this(repaymentOperation, collectionDetail.getPlan(), collectionDetail.getRemainingAmount(), collectionDetail.getRemainingPrincipal(), collectionDetail.getRemainingInterest(), collectionDetail.getRemainingManagementFee(), penalValue, collectionDetail.getRemainingOverduePenalty(), RecordStatus.DONE, repaymentOperation.getCreatedAt());
    }

    public CollectionRecord(RepaymentOperation repaymentOperation, CollectionPlan collectionPlan, RecordStatus recordStatus, RepaymentMoneyAllocation repaymentMoneyAllocation, Money managementFee) {
        this(repaymentOperation, collectionPlan, repaymentMoneyAllocation.getPrincipal(), repaymentMoneyAllocation.getInterest(), managementFee, repaymentMoneyAllocation.getPenalValue(), repaymentMoneyAllocation.getOverduePenaltyToProceed(), recordStatus, repaymentOperation.getCreatedAt());
    }

    public CollectionRecord(RepaymentOperation repaymentOperation, CollectionPlan collectionPlan, Money amount, Money principal, Money interest, Money managementFee, Money penalValue, Money overduePenalValue, RecordStatus status, Date createdAt) {
        super(repaymentOperation, collectionPlan.getPlanNumber(), amount, principal, interest, managementFee, penalValue, overduePenalValue, status, createdAt);
        this.plan = collectionPlan;
    }

    public long id() {
        return id;
    }

    public CollectionPlan getCollectionPlan() {
        return plan;
    }
    
    public Money getInvestmentManagementFee() {
        if (null == investmentManagementFeeRecord) {
            return Money.ZERO_YUAN;
        }
        return investmentManagementFeeRecord.getInvestmentManagementFee();
    }

    public Money getInvestmentTransactionFee() {
        if (null == investmentTransactionFeeRecord) {
            return Money.ZERO_YUAN;
        }
        return investmentTransactionFeeRecord.getInvestmentTransactionFee();
    }

    public Money getAmountSubtractInvestMgmtFee() {
        return this.amount.subtract(getInvestmentManagementFee());
    }
    
    public Money getNetAmount() {
        return getAmount().subtract(getInvestmentManagementFee()).subtract(getInvestmentTransactionFee());
    }

    public void setInvestmentManagementFeeRecord(InvestmentManagementFeeRecord investmentManagementFeeRecord) {
        this.investmentManagementFeeRecord = investmentManagementFeeRecord;
    }

    public InvestmentManagementFeeRecord getInvestmentManagementFeeRecord() {
        return investmentManagementFeeRecord;
    }

    public InvestmentTransactionFeeRecord getInvestmentTransactionFeeRecord() {
        return investmentTransactionFeeRecord;
    }

    public void setInvestmentTransactionFeeRecord(InvestmentTransactionFeeRecord investmentTransactionFeeRecord) {
        this.investmentTransactionFeeRecord = investmentTransactionFeeRecord;
    }
    
}
