package com.lufax.common.domain;

public enum Gender {
    MALE("M", "男","1"),
    FEMALE("F","女","2"),
    FEMAIE("-1","unknown","-1"),
    UNKNOWN("9","未知","9");

    private String value;
    private String chineseDes;
    private String xinbaoValue;

    Gender(String value, String chineseDes, String xinbaoValue) {
        this.value = value;
        this.chineseDes = chineseDes;
        this.xinbaoValue = xinbaoValue;
    }

    public String getValue() {
        return value;
    }

    public String getChineseDes() {
        return chineseDes;
    }

    public String getXinbaoValue(){
        return xinbaoValue;
    }

    public static Gender getGenderBy(String code) {
        if (MALE.getValue().equals(code)) return MALE;
        if (FEMALE.getValue().equals(code)) return FEMALE;
        return UNKNOWN;
    }

    public static Gender getGenderByXinbaoValue(String xinbaoValue){
        if(MALE.getXinbaoValue().equals(xinbaoValue)) return MALE;
        if(FEMALE.getXinbaoValue().equals(xinbaoValue))return FEMALE;
        return UNKNOWN;
    }

}
