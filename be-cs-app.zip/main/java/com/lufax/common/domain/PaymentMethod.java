package com.lufax.common.domain;

public enum PaymentMethod {
    //等额本息
    AVERAGE_CAPITAL_PLUS_INTEREST ,
    UNKNOWN;
    public static PaymentMethod getPaymentMethodByName(String method){
        PaymentMethod[] paymentMethods=PaymentMethod.values();
        for(PaymentMethod paymentMethod:paymentMethods)
            if(paymentMethod.name().equalsIgnoreCase(method))
                return paymentMethod;
        return UNKNOWN;
    }
}
