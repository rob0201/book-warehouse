package com.lufax.common.domain;

import com.lufax.common.domain.account.Money;
import com.lufax.common.utils.NumberUtils;

import java.math.BigDecimal;

import static com.lufax.common.domain.BizParameters.*;
import static com.lufax.common.utils.BigDecimalUtils.*;

public class PaymentMethodFactory {
    private int countOfInstalments;

    private BigDecimal monthlyRate;
    private BigDecimal powOfAll;
    private BigDecimal powSubtractOne;
    private BigDecimal divideValue;

    public PaymentMethodFactory(BigDecimal annualInterestRate, int countOfInstalments) {
        this.countOfInstalments = countOfInstalments;
        this.monthlyRate = divide(annualInterestRate, new BigDecimal(12));
        this.powOfAll = pow(add(monthlyRate, BigDecimal.ONE), countOfInstalments);
        powSubtractOne = subtract(powOfAll, BigDecimal.ONE);
        divideValue = divide(multiply(monthlyRate, powOfAll), powSubtractOne);
    }

    public static BigDecimal getInterestRate(BigDecimal baseInterestRate, BigDecimal interestFloatRate) {
        return NumberUtils.withPercentageScale(multiply(baseInterestRate, add(interestFloatRate, BigDecimal.ONE)));
    }

    public static String getBaseInterestRateKey(int numberOfInstalments) {
        if (numberOfInstalments <= 6)
            return INTEREST_RATE_0TO6;
        else if (numberOfInstalments > 6 && numberOfInstalments <= 12)
            return INTEREST_RATE_6TO12;
        else if (numberOfInstalments > 12 && numberOfInstalments <= 24)
            return INTEREST_RATE_12TO24;
        else if (numberOfInstalments > 24 && numberOfInstalments <= 36)
            return INTEREST_RATE_24TO36;
        return INTEREST_RATE_36_MORE;
    }

    public Money getMonthlyIncomeToLoaner(Money principal) {
        return principal.multiply(divideValue);
    }

    public Money getMonthlyInterestForGivenInstalment(int instalmentNumber, Money principal) {
        BigDecimal powIndex = pow(add(monthlyRate, BigDecimal.ONE), instalmentNumber - 1);
        return principal.multiply(divide(multiply(monthlyRate, subtract(powOfAll, powIndex)), powSubtractOne));
    }

    public Money getMonthlyPrincipalForGivenInstalment(int instalmentNumber, Money principal) {
        BigDecimal monthlyIncomeForLoaner = getMonthlyIncomeToLoaner(principal).getAmount();
        BigDecimal interestForGivenInstalment = getMonthlyInterestForGivenInstalment(instalmentNumber, principal).getAmount();

        return Money.rmb(subtract(monthlyIncomeForLoaner, interestForGivenInstalment).toString());
    }

    public Money getRemainingPrincipalExcludingGivenInstalment(int instalmentIndex, Money principal) {
        BigDecimal powIndex = pow(add(monthlyRate, BigDecimal.ONE), instalmentIndex);

        return principal.multiply(divide(subtract(powOfAll, powIndex), powSubtractOne));
    }

    public Money getSettledPrincipalIncludingGivenInstalment(int instalmentIndex, Money principal) {
        return principal.subtract(getRemainingPrincipalExcludingGivenInstalment(instalmentIndex, principal));
    }

    public Money getTotalIncomeToLoaner(Money principal) {
        return principal.multiply(multiply(divide(multiply(monthlyRate, powOfAll), powSubtractOne), new BigDecimal(countOfInstalments)));
    }

    public Money getTotalInterest(Money principal) {
        return getTotalIncomeToLoaner(principal).subtract(principal);
    }

    public Money getLastMonthIncomeToLoaner(Money principal, int countOfInstalments) {
        BigDecimal totalIncomeToLoaner = getTotalIncomeToLoaner(principal).getAmount();
        BigDecimal incomesToLoaner = multiply(getMonthlyIncomeToLoaner(principal).getAmount(), new BigDecimal(countOfInstalments - 1));
        return Money.rmb(subtract(totalIncomeToLoaner, incomesToLoaner).toString());
    }

    public Money getLastMonthInterestToLoaner(Money principal, int countOfInstalments) {
        return getLastMonthIncomeToLoaner(principal, countOfInstalments)
                .subtract(getLastMonthPrincipalToLoaner(principal, countOfInstalments));
    }

    public Money getLastMonthPrincipalToLoaner(Money principal, int countOfInstalments) {
        if (countOfInstalments == 1)
            return principal;
        BigDecimal result = getMonthlyPrincipalForGivenInstalment(1, principal).getAmount();
        for (int i = 2; i < countOfInstalments; i++) {
            result = add(result, getMonthlyPrincipalForGivenInstalment(i, principal).getAmount());
        }
        return principal.subtract(Money.rmb(result.toString()));
    }

    public Money getMonthlyManagementFee(BigDecimal managementFeeRate, Money principal) {
        return principal.multiply(managementFeeRate).divide(new BigDecimal(12));
    }
    public static void main(String[] args) {
    	PaymentMethodFactory facotry = new PaymentMethodFactory(new BigDecimal("0.1022"), 12);
    	System.out.println(facotry.getTotalIncomeToLoaner(Money.rmb("355.00")));
	}
}
