package com.lufax.common.domain;

import com.lufax.common.utils.XinbaoXMLFieldHelper;

public enum LoanRequestToXinbaoStatus {
    CON_SUCC,
    CON_FAIL,
    MAT_SUCC,
    MAT_FAIL,
    UNKNOWN;


    public static LoanRequestToXinbaoStatus processFlagForUnConfirm(String status) {
        if (XinbaoXMLFieldHelper.FROM_XINBAO_SUCCESS_FLAG.equals(status))
            return CON_SUCC;
        return CON_FAIL;
    }

    public static LoanRequestToXinbaoStatus processFlagForMatchResult(String status) {
        if (XinbaoXMLFieldHelper.FROM_XINBAO_SUCCESS_FLAG.equals(status))
            return MAT_SUCC;
        return MAT_FAIL;
    }
    public static  LoanRequestToXinbaoStatus getLoanRequestToXinbaoStatusByName(String status){
        LoanRequestToXinbaoStatus[] loanRequestToXinbaoStatuses=LoanRequestToXinbaoStatus.values();
        for(LoanRequestToXinbaoStatus loanRequestToXinbaoStatus:loanRequestToXinbaoStatuses)
            if(loanRequestToXinbaoStatus.name().equalsIgnoreCase(status))
                return loanRequestToXinbaoStatus;
        return UNKNOWN;
    }
}
