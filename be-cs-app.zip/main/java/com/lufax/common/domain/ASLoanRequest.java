package com.lufax.common.domain;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "AS_LOAN_REQUESTS")
public class ASLoanRequest {
//  ID	NUMBER(19,0)	No		1	ID
    @Id
    @Column(name = "ID")
    private long id;

//    CODE	VARCHAR2(32 BYTE)	Yes		2	贷款申请编号
    @Column(name = "CODE")
    private String code;    
//    APPLIED_AMOUNT	NUMBER(19,2)	Yes		3	贷款申请金额
    @Column(name = "APPLIED_AMOUNT")
    private BigDecimal appliedAmount;
//    NUM_OF_INSTALMENTS	NUMBER(3,0)	Yes		4	贷款期数
    @Column(name = "NUM_OF_INSTALMENTS")
    private Integer numOfInstalments;
//    LOAN_PURPOSE	VARCHAR2(512 BYTE)	Yes		5	贷款目的
    @Column(name = "LOAN_PURPOSE")
    private String loanPurpose;
//    INTEREST_RATE	NUMBER(20,15)	Yes		6	年化利率
    @Column(name = "INTEREST_RATE")
    private BigDecimal interestRate;
//    PAYMENT_METHOD	VARCHAR2(512 BYTE)	Yes		7	还款算法
    @Column(name = "PAYMENT_METHOD")
    private String paymentMethod;
//    STATUS	VARCHAR2(32 BYTE)	Yes		8	状态
    @Column(name = "STATUS")
    private String status;
//    LOANEE_USER_ID	NUMBER(19,0)	No		9	贷款人ID
    @Column(name = "LOANEE_USER_ID")
    private Long loaneeUserId;
//    AS_LOAN_ACCEPT_ID	VARCHAR2(32 BYTE)	Yes		10	安硕贷款受理号
    @Column(name = "AS_LOAN_ACCEPT_ID")
    private String asLaonAcceptId;
////    STATUS_TO_AS	VARCHAR2(32 BYTE)	Yes		11	发送给安硕状态
//    @Column(name = "STATUS_TO_AS")
//    private String statusOfAs;
//    AS_QUERY_RESULT	VARCHAR2(32 BYTE)	Yes		12	安硕查询结果
    @Column(name = "AS_QUERY_RESULT")
    private String asQueryResult;
//    CREATED_AT	DATE	Yes	SYSDATE	13	创建时间
    @Column(name = "CREATED_AT")
    private Date createdAt;
//    UPDATED_AT	DATE	Yes		14	更新时间
    @Column(name = "UPDATED_AT")
    private Date updatedAt;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public BigDecimal getAppliedAmount() {
		return appliedAmount;
	}
	public void setAppliedAmount(BigDecimal appliedAmount) {
		this.appliedAmount = appliedAmount;
	}
	public Integer getNumOfInstalments() {
		return numOfInstalments;
	}
	public void setNumOfInstalments(Integer numOfInstalments) {
		this.numOfInstalments = numOfInstalments;
	}
	public String getLoanPurpose() {
		return loanPurpose;
	}
	public void setLoanPurpose(String loanPurpose) {
		this.loanPurpose = loanPurpose;
	}
	public BigDecimal getInterestRate() {
		return interestRate;
	}
	public void setInterestRate(BigDecimal interestRate) {
		this.interestRate = interestRate;
	}
	public String getPaymentMethod() {
		return paymentMethod;
	}
	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Long getLoaneeUserId() {
		return loaneeUserId;
	}
	public void setLoaneeUserId(Long loaneeUserId) {
		this.loaneeUserId = loaneeUserId;
	}
	public String getAsLaonAcceptId() {
		return asLaonAcceptId;
	}
	public void setAsLaonAcceptId(String asLaonAcceptId) {
		this.asLaonAcceptId = asLaonAcceptId;
	}
//	public String getStatusOfAs() {
//		return statusOfAs;
//	}
//	public void setStatusOfAs(String statusOfAs) {
//		this.statusOfAs = statusOfAs;
//	}
	public String getAsQueryResult() {
		return asQueryResult;
	}
	public void setAsQueryResult(String asQueryResult) {
		this.asQueryResult = asQueryResult;
	}

	public Date getCreatedAt() {
		return createdAt;
	}
	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}
	public Date getUpdatedAt() {
		return updatedAt;
	}
	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}
    
}
