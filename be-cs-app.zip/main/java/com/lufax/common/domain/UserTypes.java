package com.lufax.common.domain;


public enum UserTypes {
    INNER_EMPLOYEE,
    OTHERS;
}
