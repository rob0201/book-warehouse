package com.lufax.common.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.MappedSuperclass;
import javax.persistence.OneToOne;

@MappedSuperclass
public class InvestmentFeeRecord {
    @Column(name = "STATUS")
    private boolean feeChargeStatus;

    @Column(name = "CREATED_AT")
    private Date createdAt;

    @Column(name = "UPDATE_AT")
    private Date updateAt;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "COLLECTION_RECORD_ID")
    private CollectionRecord collectionRecord;

    @Column(name = "ERROR_DESC")
    private String errDesc;

    @Column(name = "RETRY_TIMES")
    private int retryTimes;


    public InvestmentFeeRecord() {

    }

    public InvestmentFeeRecord(CollectionRecord collectionRecord) {
        this.collectionRecord = collectionRecord;
        this.createdAt = new Date();
    }

    public void setFeeChargeStatus(boolean feeChargeStatus) {
        this.feeChargeStatus = feeChargeStatus;
        this.updateAt = new Date();
    }

    public boolean getFeeChargeStatus() {
        return feeChargeStatus;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public boolean isFailed() {
        return !feeChargeStatus;
    }

    public void addRetryTimes() {
        this.retryTimes = ++retryTimes;
    }
}
