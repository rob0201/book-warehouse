package com.lufax.common.domain;

import com.lufax.common.utils.EmptyChecker;
import com.lufax.common.utils.MapUtils;

import javax.persistence.*;
import java.util.Date;
import java.util.Map;


@Entity
@Table(name = "ORIGINAL_INSURANCE_POLICIES")
public class OriginalInsurancePolicy {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_ORI_INSURANCE_POLICIES")
    @SequenceGenerator(name = "SEQ_ORI_INSURANCE_POLICIES", sequenceName = "SEQ_ORI_INSURANCE_POLICIES", allocationSize = 1)
    private long id;

    @Column(name = "POLICY_NO")
    private String policyNo;

    @Column(name = "FULL_DESCRIPTION")
    private String fullDescription;

    //    @Enumerated(EnumType.STRING)
    @Column(name = "STATUS")
    private String status;

    @Column(name = "CREATED_AT")
    private Date createdAt;

    @Column(name = "SENT_TO_MEMBER_SYSTEM")
    private Boolean sentToMemberSystem;
    
    @Column(name = "NAME")
    private String name;
    
    @Column(name = "IDENTITY_NUMBER")
    private String identityNumber;
    
    @Column(name = "MOBILE_NO")
    private String mobileNo;
    
    public OriginalInsurancePolicy() {
    }

    public OriginalInsurancePolicy(String policyNo, String fullDescription, InsurancePolicyStatus status, Boolean sentToMemberSystem, Date createdAt) {
        this.policyNo = policyNo;
        this.fullDescription = fullDescription;
        this.status = (status != null) ? status.name() : null;
        this.sentToMemberSystem = sentToMemberSystem;
        this.createdAt = createdAt;
    }

    public OriginalInsurancePolicy(String policyNo, String fullDescription, InsurancePolicyStatus status) {
        this(policyNo, fullDescription, status, false, new Date());
    }

    public String getPolicyNo() {
        return policyNo;
    }

    public Map<String, String> getFullDescriptionAsMap() {
        return MapUtils.convertFromString(fullDescription);
    }

    public InsurancePolicyStatus getStatus() {
        return InsurancePolicyStatus.getInsurancePolicyStatusByName(status);
    }

    public void setSentToMemberSystem(boolean sentToMemberSystem) {
        this.sentToMemberSystem = sentToMemberSystem;
    }

    public void setFullDescription(String fullDescription) {
        this.fullDescription = fullDescription;
    }

    public void setStatus(InsurancePolicyStatus status) {
        this.status = (status != null) ? status.name() : null;
    }

    public boolean isSentToMemberSystem() {
        if (sentToMemberSystem == null) {
            return false;
        }
        return sentToMemberSystem;
    }

    public long id() {
        return id;
    }

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public Boolean getSentToMemberSystem() {
		return sentToMemberSystem;
	}

	public void setSentToMemberSystem(Boolean sentToMemberSystem) {
		this.sentToMemberSystem = sentToMemberSystem;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getIdentityNumber() {
		return identityNumber;
	}

	public void setIdentityNumber(String identityNumber) {
		this.identityNumber = identityNumber;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getFullDescription() {
		return fullDescription;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getBranchName() {
		if(EmptyChecker.isEmpty(this.fullDescription) || this.fullDescription.indexOf("branchName=") < 0){
			return null;
		}
		String tmp = this.fullDescription.substring(this.fullDescription.indexOf("branchName="));
		String branchName = tmp.substring("branchName=".length(),tmp.indexOf(",") < 0 ? tmp.length() : tmp.indexOf(","));
		return branchName;
	}
	
}
