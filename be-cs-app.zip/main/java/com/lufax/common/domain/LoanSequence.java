package com.lufax.common.domain;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "LOAN_SEQUENCE")
public class LoanSequence {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_LOAN_SEQUENCE")
    @SequenceGenerator(name = "SEQ_LOAN_SEQUENCE", sequenceName = "SEQ_LOAN_SEQUENCE", allocationSize = 1)
    private long id;

    @Column(name = "CREATED_AT")
    private Date createdAt;

    public LoanSequence() {
    }

    public LoanSequence(Date createdAt) {
        this.createdAt = createdAt;
    }

    public long id() {
        return this.id;
    }

    public Date getCreatedAt() {
        return createdAt;
    }
}
