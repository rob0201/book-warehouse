package com.lufax.common.domain;

import static com.lufax.common.web.helper.ConstantsHelper.PDF_SUFFIX;

public enum RechargeContractType {
    ATTORNEY("p2pAttorney.vm"),
    UNKNOWN("unknown");

    private String template;

    RechargeContractType(String template) {
        this.template = template;
    }

    public String getTemplate() {
        return template;
    }

    public String contractNameOf(RechargeRecord rechargeRecord) {
        return String.format("%s_%s.%s", rechargeRecord.getTradeNo(), toString().toLowerCase(), PDF_SUFFIX);
    }
    public static RechargeContractType getRechargeContractTypeByName(String name){
        RechargeContractType[]  rechargeContractTypes=RechargeContractType.values();
        for(RechargeContractType rechargeContractType:rechargeContractTypes)
            if(rechargeContractType.name().equalsIgnoreCase(name))
                return rechargeContractType;
        return UNKNOWN;
    }
}
