package com.lufax.common.domain;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;

@Entity
@Table(name = "BIZ_PARAMETERS")
public class BizParameters {
    public static final String LOANER_PANEL_RATE_MORE_THAN_11_MONTHS = "prepayment.loaner.penal.rate.11.months.more";
    public static final String LOANER_PANEL_RATE_BETWEEN_5_AND_11_MONTHS = "prepayment.loaner.penal.rate.5to11.months";
    public static final String LOANER_PANEL_RATE_WITHIN_5_MONTHS = "prepayment.loaner.penal.rate.0to5.months";
    public static final String INSURANCE_MANAGEMENT_FEE_MORE_THAN_11_MONTHS = "prepayment.insurance.mgt.fee.rate.11.months.more";
    public static final String INSURANCE_MANAGEMENT_FEE_BETWEEN_5_AND_11_MONTHS = "prepayment.insurance.mgt.fee.rate.5to11.months";
    public static final String INSURANCE_MANAGEMENT_FEE_WITHIN_5_MONTHS = "prepayment.insurance.mgt.fee.rate.0to5.months";
    public static final String P2P_PREPAY_FEE_MORE_THAN_11_MONTHS = "prepayment.p2p.penal.rate.11.months.more";
    public static final String P2P_PREPAY_FEE_BETWEEN_5_AND_11_MONTHS = "prepayment.p2p.penal.rate.5to11.months";
    public static final String P2P_PREPAY_FEE_WITHIN_5_MONTHS = "prepayment.p2p.penal.rate.0to5.months";

    public static final String LOAN_TRANSACTION_FEE_RATE = "loan.transaction.fee.rate";
    public static final String PREPAYMENT_PENAL_VALUE_RATE_P2P = "prepayment.penal.value.rate.p2p";
    public static final String PREPAYMENT_PENAL_VALUE_RATE_LOANER = "prepayment.penal.value.rate.loaner";
    public static final String PREPAYMENT_PENAL_VALUE_RATE_XINBAO = "prepayment.penal.value.rate.xinbao";
    public static final String WITHDRAW_FEE = "withdraw.fee";
    public static final String INTEREST_RATE_0TO6 = "interest.base.rate.0to6.months";
    public static final String INTEREST_RATE_6TO12 = "interest.base.rate.6to12.months";
    public static final String INTEREST_RATE_12TO24 = "interest.base.rate.12to24.months";
    public static final String INTEREST_RATE_24TO36 = "interest.base.rate.24to36.months";
    public static final String INTEREST_RATE_36_MORE = "interest.base.rate.36.more.months";
    public static final String BASE_INTEREST_RATE = "interest.base.rate";
    public static final String INTEREST_FLOAT_RATE = "interest.float.rate";
    public static final String MANAGEMENT_FEE_RATE_LOANEE = "management.fee.rate.loanee";
    public static final String MANAGEMENT_FEE_RATE_LOANER = "management.fee.rate.loaner";
    public static final String WITHDRAW_MIN_AMOUNT = "withdraw.min.amount";
    public static final String WITHDRAW_MAX_AMOUNT = "withdraw.max.amount";
    public static final String RECHARGE_MAX_AMOUNT = "recharge.max.amount";
    public static final String RECHARGE_MIN_AMOUNT_CMS = "recharge.min.amount.cms";
    public static final String RECHARGE_MIN_AMOUNT_ALIPAY = "recharge.min.amount.alipay";
    public static final String RECHARGE_FEE_RATE_ALIPAY = "recharge.fee.rate.alipay";
    public static final String CMS_RECHARGE_FEE_THRESHOLD = "cms.recharge.fee.threshold";
    public static final String CMS_RECHARGE_FEE_AMOUNT = "cms.recharge.fee.amount";
    public static final String LOAN_REQUEST_MAX_AMOUNT = "loan.request.max.amount";
    public static final String GUARANTOR_WITHDRAWAL_MIN_AMOUNT = "guarantor.withdrawal.min.amount";
    public static final String LOAN_REQUEST_VALID_PERIOD = "loan.request.valid.period";
    public static final String OVERDUE_EXTENSION_DAYS = "overdue.extension.days";
    public static final String OVERDUE_FLOAT_RATE = "overdue.float.rate";
    public static final String VERIFIED_SUCCESS_WARNING_DAYS = "verified.success.warning.days";

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_BIZ_PARAMETERS")
    @SequenceGenerator(name = "SEQ_BIZ_PARAMETERS", sequenceName = "SEQ_BIZ_PARAMETERS", allocationSize = 1)
    private long id;

    @Column(name = "PARAMETER_CODE")
    private String parameterCode;

    @Column(name = "START_DATE")
    private Date startDate;

    @Column(name = "PARAMETER_VALUE")
    private BigDecimal parameterValue;

    @Column(name = "CREATED_BY")
    private String createdBy;

    @Column(name = "CREATED_DATE")
    private Date createdDate;

    @Column(name = "UPDATED_BY")
    private String updatedBy;
    @Column(name = "UPDATED_DATE")
    private Date updatedDate;

    public BizParameters() {
        String defaultOperator = "SYSTEM";
        Date now = new Date();
        this.createdBy = defaultOperator;
        this.updatedBy = defaultOperator;
        this.createdDate = now;
        this.updatedDate = now;
    }

    public void setParameterCode(String parameterCode) {
        this.parameterCode = parameterCode;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public void setParameterValue(BigDecimal parameterValue) {
        this.parameterValue = parameterValue;
    }

    public String getParameterCode() {
        return parameterCode;
    }

    public Date getStartDate() {
        return startDate;
    }

    public BigDecimal getParameterValue() {
        return parameterValue;
    }
}
