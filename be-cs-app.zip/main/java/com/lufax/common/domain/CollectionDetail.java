package com.lufax.common.domain;

import com.lufax.common.domain.account.Money;
//import com.lufax.common.utils.DevLog;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

public class CollectionDetail {
    private CollectionPlan plan;
    private BigDecimal interestRate;
    private boolean isRateChange = false;
    private List<CollectionRecord> collectionRecords;

    private Money collectedAmount = Money.ZERO_YUAN;
    private Money collectedPrincipal = Money.ZERO_YUAN;
    private Money collectedInterest = Money.ZERO_YUAN;
    private Money collectedPenalValue = Money.ZERO_YUAN;
    private Money collectedOverduePenalty = Money.ZERO_YUAN;
    private Money paidManagementFee = Money.ZERO_YUAN;
    
    private Money paidInvestmentManagementFee = Money.ZERO_YUAN;
    private Money paidInvestmentTransactionFee = Money.ZERO_YUAN;
    private Money managerFee = Money.ZERO_YUAN;
    private Money amount;
    private Money principal;
    
    

    public Money getPrincipal() {
		return principal;
	}


	public void setPrincipal(Money principal) {
		this.principal = principal;
	}


	public Money getAmount() {
		return amount;
	}


	public void setAmount(Money amount) {
		this.amount = amount;
	}


	public CollectionDetail(CollectionPlan collectionPlan) {
        this.plan = collectionPlan;
        this.interestRate = plan.getInterestRate();
        managerFee = collectionPlan.getManagementFee();
        collectionRecords = collectionPlan.getRecordsOrderByCreationDateAscending();
//        DevLog.info(this, String.format("The collectionRecords'size is [%s]", collectionRecords==null?0:collectionRecords.size()));
        for (CollectionRecord collectionRecord : collectionRecords) {
            collectedAmount = collectedAmount.add(collectionRecord.getAmount());
            collectedPrincipal = collectedPrincipal.add(collectionRecord.getPrincipal());
            collectedInterest = collectedInterest.add(collectionRecord.getInterest());
            collectedPenalValue = collectedPenalValue.add(collectionRecord.getPenalValue());
            collectedOverduePenalty = collectedOverduePenalty.add(collectionRecord.getOverduePenalValue());
            paidManagementFee = paidManagementFee.add(collectionRecord.getManagementFee());
            
            paidInvestmentManagementFee = paidInvestmentManagementFee.add(collectionRecord.getInvestmentManagementFee());
            paidInvestmentTransactionFee = paidInvestmentTransactionFee.add(collectionRecord.getInvestmentTransactionFee());

        }
        amount = plan.getTotal();
        principal = plan.getPrincipal();
    }


	public Money getManagerFee() {
		return managerFee;
	}


	public void setManagerFee(Money managerFee) {
		this.managerFee = managerFee;
	}


	public int getPlanNumber() {
        return plan.getPlanNumber();
    }

    public Date getPayTime() {
        CollectionRecord latestCollectionRecord = plan.getLatestRecord();
        if (latestCollectionRecord != null) {
            return latestCollectionRecord.getUpdatedAt();
        }
        return null;
    }

    public Date getEndAt() {
        return plan.getEndAt();
    }



    public Money getCollectedAmount() {
        return collectedAmount;
    }

//    public Money getPrincipal() {
//        return plan.getPrincipal();
//    }

    public Money getCollectedPrincipal() {
        return collectedPrincipal;
    }

    public Money getInterest() {
        return plan.getInterest();
    }

    public Money getCollectedInterest() {
        return collectedInterest;
    }

    public Money getManagementFee() {
        return plan.getManagementFee();
    }

    public Money getPaidManagementFee() {
        return paidManagementFee;
    }

    public Money getCollectedPenalValue() {
        return collectedPenalValue;
    }

    public Money getOverduePenaltyToCollect() {
        return plan.isSettled() ? collectedOverduePenalty : plan.getOverduePenaltyToCollect();
    }
    

    public Money getRemainingOverduePenalty() {
        return plan.getOverduePenaltyToCollect().subtract(collectedOverduePenalty);
    }

    public Money getCollectedOverduePenalty() {
        return collectedOverduePenalty;
    }

    public boolean isOverdue() {
        return plan.isOverdue();
    }

    public PlanStatus getStatus() {
        return plan.getStatus();
    }

    public List<CollectionRecord> getCollectionRecords() {
        return collectionRecords;
    }

    public Money getNetIncome() {
        return collectedAmount.subtract(paidManagementFee);
    }

    public Money getRemainingAmount() {
        return getAmount().subtract(collectedAmount);
    }

    public Money getRemainingPrincipal() {
        return plan.getPrincipal().subtract(collectedPrincipal);
    }

    public Money getRemainingInterest() {
        return plan.getInterest().subtract(collectedInterest);
    }

    public Money getRemainingManagementFee() {
        return plan.getManagementFee().subtract(paidManagementFee);
    }

    public CollectionPlan getPlan() {
        return plan;
    }

	public Money getPaidInvestmentManagementFee() {
		return paidInvestmentManagementFee;
	}

	public Money getPaidInvestmentTransactionFee() {
		return paidInvestmentTransactionFee;
	}

	public BigDecimal getInterestRate() {
		return interestRate;
	}

	public boolean isRateChange() {
		return isRateChange;
	}

	public void setRateChange(boolean isRateChange) {
		this.isRateChange = isRateChange;
	}


	public void setPlan(CollectionPlan plan) {
		this.plan = plan;
	}


	public void setInterestRate(BigDecimal interestRate) {
		this.interestRate = interestRate;
	}


	public void setCollectionRecords(List<CollectionRecord> collectionRecords) {
		this.collectionRecords = collectionRecords;
	}


	public void setCollectedAmount(Money collectedAmount) {
		this.collectedAmount = collectedAmount;
	}


	public void setCollectedPrincipal(Money collectedPrincipal) {
		this.collectedPrincipal = collectedPrincipal;
	}


	public void setCollectedInterest(Money collectedInterest) {
		this.collectedInterest = collectedInterest;
	}


	public void setCollectedPenalValue(Money collectedPenalValue) {
		this.collectedPenalValue = collectedPenalValue;
	}


	public void setCollectedOverduePenalty(Money collectedOverduePenalty) {
		this.collectedOverduePenalty = collectedOverduePenalty;
	}


	public void setPaidManagementFee(Money paidManagementFee) {
		this.paidManagementFee = paidManagementFee;
	}


	public void setPaidInvestmentManagementFee(Money paidInvestmentManagementFee) {
		this.paidInvestmentManagementFee = paidInvestmentManagementFee;
	}


	public void setPaidInvestmentTransactionFee(Money paidInvestmentTransactionFee) {
		this.paidInvestmentTransactionFee = paidInvestmentTransactionFee;
	}


	@Override
	public String toString() {
		return "CollectionDetail [plan=" + plan + ", interestRate=" + interestRate + ", isRateChange=" + isRateChange + ", collectionRecords="
				+ collectionRecords + ", collectedAmount=" + collectedAmount + ", collectedPrincipal=" + collectedPrincipal + ", collectedInterest="
				+ collectedInterest + ", collectedPenalValue=" + collectedPenalValue + ", collectedOverduePenalty=" + collectedOverduePenalty
				+ ", paidManagementFee=" + paidManagementFee + ", paidInvestmentManagementFee=" + paidInvestmentManagementFee
				+ ", paidInvestmentTransactionFee=" + paidInvestmentTransactionFee + ", managerFee=" + managerFee + ", amount=" + amount + "]";
	}
    
}
