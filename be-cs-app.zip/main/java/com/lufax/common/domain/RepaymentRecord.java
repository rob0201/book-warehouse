package com.lufax.common.domain;

import com.lufax.common.domain.account.Money;

import javax.persistence.*;

import static com.lufax.common.domain.account.Money.ZERO_YUAN;

@Entity
@Table(name = "REPAYMENT_RECORDS")
public class RepaymentRecord extends Record {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_REPAYMENT_RECORDS")
    @SequenceGenerator(name = "SEQ_REPAYMENT_RECORDS", sequenceName = "SEQ_REPAYMENT_RECORDS", allocationSize = 1)
    private long id;

    @Embedded
    @AttributeOverrides({@AttributeOverride(name = "amount", column = @Column(name = "INSURANCE_FEE"))})
    private Money insuranceFee;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "REPAYMENT_PLAN_ID")
    private RepaymentPlan plan;

    @Column(name = "STATUS_TO_XINBAO")
    private Boolean statusToXinbao;

    @Embedded
    @AttributeOverrides({@AttributeOverride(name = "amount", column = @Column(name = "INSURANCE_MGMT_FEE"))})
    private Money insuranceManagementFee;

    public RepaymentRecord() {
    }

    //constructor for tests
    public RepaymentRecord(RepaymentOperation repaymentOperation, RepaymentPlan repaymentPlan, Money penalValue) {
        this(repaymentOperation, repaymentPlan, RecordStatus.DONE, repaymentPlan.getPrincipal(), repaymentPlan.getInterest(), repaymentPlan.getManagementFee(), repaymentPlan.getInsuranceFee(), repaymentPlan.getOverduePenaltyToPay(), penalValue, ZERO_YUAN);
    }

    //TODO:related to prepay
    public RepaymentRecord(RepaymentOperation repaymentOperation, PrepaymentDetail loanPrepaymentDetail, RepaymentPlan repaymentPlan) {
        this(repaymentOperation, repaymentPlan, RecordStatus.DONE, loanPrepaymentDetail.getRemainingPrincipal(), loanPrepaymentDetail.getInterestOfCurrentPlan(), loanPrepaymentDetail.getManagementFeeForLoaneeOfCurrentPlan(), loanPrepaymentDetail.getInsuranceFeeOfCurrentPlan(), repaymentPlan.getOverduePenaltyToPay(), loanPrepaymentDetail.getPenalValue(), loanPrepaymentDetail.getInsuranceManagementFee());
        this.insuranceManagementFee = loanPrepaymentDetail.getInsuranceManagementFee();
    }

    public RepaymentRecord(RepaymentOperation repaymentOperation, RepaymentDetail repaymentDetail) {
        this(repaymentOperation, repaymentDetail.getPlan(), RecordStatus.DONE, repaymentDetail.getRemainingPrincipal(), repaymentDetail.getRemainingInterest(), repaymentDetail.getRemainingManagementFee(), repaymentDetail.getRemainingInsuranceFee(), repaymentDetail.getRemainingOverduePenaltyToPay(), ZERO_YUAN, ZERO_YUAN);
    }

    public RepaymentRecord(RepaymentOperation repaymentOperation, RepaymentPlan repaymentPlan, RecordStatus recordStatus, RepaymentMoneyAllocation repaymentMoneyAllocation, Money managementFee) {
        this(repaymentOperation, repaymentPlan, recordStatus, repaymentMoneyAllocation.getPrincipal(), repaymentMoneyAllocation.getInterest(), managementFee, repaymentMoneyAllocation.getInsuranceFee(), repaymentMoneyAllocation.getOverduePenaltyToProceed(), repaymentMoneyAllocation.getPenalValue(), ZERO_YUAN);
    }

    public RepaymentRecord(RepaymentOperation repaymentOperation, RepaymentPlan repaymentPlan, RecordStatus status, Money principal, Money interest, Money managementFee, Money insuranceFee, Money overduePenalValue, Money penalValue, Money insuranceManagementFee) {
        super(repaymentOperation, repaymentPlan.getPlanNumber(),
                principal.add(interest).add(insuranceFee).add(managementFee).add(overduePenalValue).add(penalValue).add(insuranceManagementFee),
                principal, interest, managementFee, penalValue, overduePenalValue, status, repaymentOperation.getCreatedAt());
        this.plan = repaymentPlan;
        this.insuranceFee = insuranceFee;
    }

    public long id() {
        return id;
    }

    public RepaymentPlan getRepaymentPlan() {
        return plan;
    }

    public Money getInsuranceFee() {
        return insuranceFee;
    }

    public Boolean getStatusToXinbao() {
        return statusToXinbao;
    }

    public void setStatusToXinbao(Boolean statusToXinbao) {
        this.statusToXinbao = statusToXinbao;
    }

    public Money getInsuranceManagementFee() {
        return insuranceManagementFee == null ? ZERO_YUAN : insuranceManagementFee;
    }
}
