package com.lufax.common.domain;

public enum WithHoldingStatus {
    WAITING,
    SUCCESS,
    BIG_AMOUNT,
    UN_OVERDUE,
    PROCESSING,
    NOT_EXIST,
    UNKNOWN;

    public static WithHoldingStatus getStatusByLoan(Loan loan) {
        if (loan == null) return NOT_EXIST;
        if (!loan.isOverdue()) return UN_OVERDUE;
        if (loan.hasProcessingPlan()) return PROCESSING;
        return SUCCESS;
    }
    public static WithHoldingStatus getWithHoldingStatusByName(String name){
        WithHoldingStatus[] withHoldingStatuses=WithHoldingStatus.values();
        for(WithHoldingStatus withHoldingStatus:withHoldingStatuses)
            if(withHoldingStatus.name().equalsIgnoreCase(name))
                return withHoldingStatus;
        return UNKNOWN;
    }
}
