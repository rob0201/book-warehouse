package com.lufax.common.domain;

public enum RecordStatus {
    ONGOING, DONE, CANCEL,UNKNOWN;
    public static RecordStatus getRecordStatusByName(String status){
        RecordStatus[] recordStatuses=RecordStatus.values();
        for(RecordStatus recordStatus:recordStatuses)
            if(recordStatus.name().equalsIgnoreCase(status))
                return recordStatus;
        return UNKNOWN;
    }
}
