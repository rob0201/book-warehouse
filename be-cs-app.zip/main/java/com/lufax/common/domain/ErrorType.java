package com.lufax.common.domain;

public enum ErrorType {
    CMS_ERROR, CMS_RETURN_TICKET ,UNKNOWN;
    public static ErrorType getErrorTypeByType(String type){
        ErrorType[] errorTypes=ErrorType.values();
        for(ErrorType errorType:errorTypes)
            if(errorType.name().equalsIgnoreCase(type))
                return errorType;
        return UNKNOWN;
    }

}
