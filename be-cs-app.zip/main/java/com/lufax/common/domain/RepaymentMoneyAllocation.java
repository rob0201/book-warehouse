package com.lufax.common.domain;

import com.lufax.common.domain.account.Money;

import java.util.SortedMap;
import java.util.TreeMap;

import static com.lufax.common.domain.account.Money.ZERO_YUAN;
import static com.lufax.common.domain.account.Money.min;

public class RepaymentMoneyAllocation {
    private SortedMap<String, Money> paymentInOrder = new TreeMap<String, Money>();
    private static final String INSURANCE_FEE = "1";
    private static final String OVERDUE_PENALTY_TO_PROCEED = "2";
    private static final String INTEREST = "3";
    private static final String PRINCIPAL = "4";

    public RepaymentMoneyAllocation(RepaymentDetail repaymentDetail, Money availableAmount) {
        paymentInOrder.put(INSURANCE_FEE, repaymentDetail.getRemainingInsuranceFee());
        paymentInOrder.put(OVERDUE_PENALTY_TO_PROCEED, repaymentDetail.getRemainingOverduePenaltyToPay());
        paymentInOrder.put(INTEREST, repaymentDetail.getRemainingInterest());
        paymentInOrder.put(PRINCIPAL, repaymentDetail.getRemainingPrincipal());

        for (String key : paymentInOrder.keySet()) {
            Money actual = min(paymentInOrder.get(key), availableAmount);
            paymentInOrder.put(key, actual);
            availableAmount = availableAmount.subtract(actual);
        }
    }

    public Money getPrincipal() {
        return paymentInOrder.get(PRINCIPAL);
    }

    public Money getInterest() {
        return paymentInOrder.get(INTEREST);
    }

    public Money getInsuranceFee() {
        return paymentInOrder.get(INSURANCE_FEE);
    }

    public Money getOverduePenaltyToProceed() {
        return paymentInOrder.get(OVERDUE_PENALTY_TO_PROCEED);
    }

    public Money getPenalValue() {
        return ZERO_YUAN;
    }
}
