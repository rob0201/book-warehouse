package com.lufax.common.domain;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "STATUS_CHANGE_HISTORY")
public class StatusChangeHistory {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_STATUS_CHANGE_HISTORY")
    @SequenceGenerator(name = "SEQ_STATUS_CHANGE_HISTORY", sequenceName = "SEQ_STATUS_CHANGE_HISTORY", allocationSize = 1)
    private long id;

//    @Enumerated(EnumType.STRING)
    @Column(name = "CHANGE_TYPE")
    private String statusChangeType;

    @Column(name = "LOAN_REQUEST_CODE")
    private String loanRequestCode;

    @Column(name = "INVESTMENT_REQUEST_ID")
    private long investmentRequestId;

    @Column(name = "CHANGE_AT")
    private Date changeAt;

    @Column(name = "STATUS")
    private String status;

    @Column(name = "LOAN_CODE")
    private String loanCode;

    @Column(name = "INVESTMENT_ID")
    private long investmentId;

    public StatusChangeHistory() {
        this.changeAt = new Date();
    }

    public StatusChangeHistory(LoanRequest loanRequest) {
        this();
        this.loanRequestCode = loanRequest.getCode();
        this.statusChangeType = StatusChangeType.LOAN_REQUEST.name();
        this.status = loanRequest.getStatus().toString();
        this.changeAt = new Date();
    }

    public StatusChangeHistory(InvestmentRequest investmentRequest) {
        this();
        this.investmentRequestId = investmentRequest.id();
        this.statusChangeType = StatusChangeType.INVESTMENT_REQUEST.name();
        this.status = investmentRequest.getStatus().toString();
        this.changeAt = new Date();
    }

    public StatusChangeHistory(Loan loan) {
        this();
        this.loanCode = loan.getCode();
        this.statusChangeType = StatusChangeType.LOAN.name();
        this.status = loan.getStatus().toString();
    }

    public StatusChangeHistory(Investment investment) {
        this();
        this.investmentId = investment.id();
        this.statusChangeType = StatusChangeType.INVESTMENT.name();
        this.status = investment.getStatus().toString();
    }

    public long getId() {
        return id;
    }

    public StatusChangeType getStatusChangeType() {
        return StatusChangeType.getStatusChangeTypeByType(statusChangeType);
    }

    public void setStatusChangeType(StatusChangeType statusChangeType) {
        this.statusChangeType =(statusChangeType!=null)? statusChangeType.name():null;
    }

    public String getLoanRequestCode() {
        return loanRequestCode;
    }

    public void setLoanRequestCode(String loanRequestCode) {
        this.loanRequestCode = loanRequestCode;
    }

    public long getInvestmentRequestId() {
        return investmentRequestId;
    }

    public void setInvestmentRequestId(long investmentRequestId) {
        this.investmentRequestId = investmentRequestId;
    }

    public Date getChangeAt() {
        return changeAt;
    }

    public void setChangeAt(Date changeAt) {
        this.changeAt = changeAt;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public boolean equals(Object o) {
        return EqualsBuilder.reflectionEquals(this, o);
    }

    @Override
    public int hashCode() {
        return HashCodeBuilder.reflectionHashCode(this);
    }

    public String getLoanCode() {
        return loanCode;
    }

    public void setLoanCode(String loanCode) {
        this.loanCode = loanCode;
    }

    public long getInvestmentId() {
        return investmentId;
    }

    public void setInvestmentId(long investmentId) {
        this.investmentId = investmentId;
    }
}
