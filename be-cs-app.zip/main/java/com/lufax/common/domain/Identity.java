package com.lufax.common.domain;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;

@Embeddable
public class Identity {
    public static enum Type {
        IDENTITY_CARD("1", "身份证", "0"),
        PASSPORT("2", "护照", "2"),
        MILITARY_ID_OR_SOLDIER_CARD("3", "军官证或士兵证", "3"),
        HONGKONG_MACAO_TAIWAN("6", "港澳通行证/回乡证或台胞证", "5"),
        HOUSEHOLD_REGISTER("L", "户口本", "1"),
        OTHERS("0", "其它", "X"),

        MILITARY_CARD("M", "军官证", "3"),
        SOLDIER_CARD("N", "士兵证", "4"),
        HONGKONG_MACAO("O", "港澳居民来往内地通行证", "5"),
        TAIWAN_PASSPORT("P", "台湾同胞来往内地通行证", "6"),
        TEMPORARY_ID_CARD("Q", "临时身份证", "7"),
        FOREIGNER_CARD("R", " 外国人居留证", "8"),
        POLICE_CARD("S", " 警官证", "9"),
        UNKNOWN("unknown","unknown","unknown");


        private String value;
        private String chineseDes;
        private String bankUnionKey;

        Type(String value, String chineseDes, String bankUnionKey) {
            this.value = value;
            this.chineseDes = chineseDes;
            this.bankUnionKey = bankUnionKey;
        }

        public String getValue() {
            return value;
        }

        public String getChineseDes() {
            return chineseDes;
        }

        public String getBankUnionKey() {
            return bankUnionKey;
        }


        public static Identity.Type toP2PIdType(String code) {
            for (Identity.Type p2pIdType : Identity.Type.values()) {
                if (p2pIdType.getValue().equals(code)) {
                    return p2pIdType;
                }
            }
            return null;
        }
        public static Type getTypeByName(String name){
            Type[] types=Type.values();
            for(Type type:types)
                if(type.name().equalsIgnoreCase(name))
                    return type;
            return UNKNOWN;
        }
    }

    @Enumerated(EnumType.STRING)
    @Column(name = "IDENTITY_TYPE")
    private Type type;
    @Column(name = "IDENTITY_NUMBER")
    private String number;

    public Identity(Type type, String number) {
        this.type = type;
        this.number = number;
    }

    private Identity() {
    }

    public Type getType() {
        return type;
    }

    public String getNumber() {
        return number;
    }

    @Override
    public boolean equals(Object o) {
        return EqualsBuilder.reflectionEquals(this, o);
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(type).append(number).hashCode();
    }

}
