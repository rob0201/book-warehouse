package com.lufax.common.domain;


public enum XinbaoStatus {
    SUCCESS,
    FAILURE,
    WAITING,
    NOT_SEND,
    APPLYING;
}
