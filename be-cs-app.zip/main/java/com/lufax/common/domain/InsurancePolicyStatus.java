package com.lufax.common.domain;

public enum InsurancePolicyStatus {
	VALID("VALID"),
    INVALID_ID("身份证号不匹配"),
    INVALID_MB("手机号不匹配"),
    INVALID("用户没有注册"),
    LR_ERROR("借款请求异常，状态无效、没有申请借款"),
    LR_WARN("LR_WARN"),
    UNKONWN("未知类型");
	
	private String desc;
	
	private InsurancePolicyStatus(String desc){
		this.desc = desc;
	}

    public static InsurancePolicyStatus getInsurancePolicyStatusByName(String status) {
        InsurancePolicyStatus[] insurancePolicyStatuses = InsurancePolicyStatus.values();
        for (InsurancePolicyStatus insurancePolicyStatus : insurancePolicyStatuses)
            if (insurancePolicyStatus.name().equalsIgnoreCase(status))
                return insurancePolicyStatus;
        return UNKONWN;
    }

	public String getDesc() {
		return desc;
	}
}
