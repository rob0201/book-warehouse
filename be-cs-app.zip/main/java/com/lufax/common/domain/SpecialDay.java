package com.lufax.common.domain;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "SPECIAL_DAYS")
public class SpecialDay {

    @Id
    @Column(name = "SPECIAL_DATE")
    private Date specialDate;

    @Column(name = "IS_WORKDAY")
    private String isWorkday;

    @Column(name = "MEMO")
    private String memo;

    @Column(name = "OPERATOR")
    private String operator;

    @Column(name = "CREATED_AT")
    private Date createdAt;

    public SpecialDay() {
    }

    public SpecialDay(Date specialDate, String isWorkday, String memo, String operator) {
        this.specialDate = specialDate;
        this.isWorkday = isWorkday;
        this.memo = memo;
        this.operator = operator;
        this.createdAt = new Date();
    }

    public Date getSpecialDate() {
        return specialDate;
    }

    public boolean isWorkday() {
        return "Y".equals(isWorkday);
    }

    public String getMemo() {
        return memo;
    }

    public String getOperator() {
        return operator;
    }

    public Date getCreatedAt() {
        return createdAt;
    }
}
