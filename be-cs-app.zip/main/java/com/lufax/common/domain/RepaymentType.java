package com.lufax.common.domain;

public enum RepaymentType {
    WITHHOLDING,
    MANUAL_REPAYMENT ,
    UNKNOWN;
    public  static RepaymentType getRepaymentTypeByName(String name){
        RepaymentType[] repaymentTypes=RepaymentType.values();
        for(RepaymentType repaymentType:repaymentTypes)
            if(repaymentType.name().equalsIgnoreCase(name))
                return repaymentType;
        return UNKNOWN;
    }
}
