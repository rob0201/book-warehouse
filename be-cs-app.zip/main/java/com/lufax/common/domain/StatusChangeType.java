package com.lufax.common.domain;

public enum StatusChangeType {
    LOAN_REQUEST("贷款申请"),
    INVESTMENT_REQUEST("投资申请"),
    LOAN("贷款"),
    INVESTMENT("投资"),
    UNKNOWN("unknown");

    private String value;

    StatusChangeType(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
    public static StatusChangeType getStatusChangeTypeByType(String type){
        StatusChangeType[] statusChangeTypes=StatusChangeType.values();
        for(StatusChangeType statusChangeType:statusChangeTypes)
            if(statusChangeType.name().equalsIgnoreCase(type))
                return statusChangeType;
        return UNKNOWN;
    }
}
