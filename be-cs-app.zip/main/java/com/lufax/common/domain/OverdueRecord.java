package com.lufax.common.domain;

import com.lufax.common.domain.account.Money;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "OVERDUE_RECORDS")
public class OverdueRecord {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_OVERDUE_RECORDS")
    @SequenceGenerator(name = "SEQ_OVERDUE_RECORDS", sequenceName = "SEQ_OVERDUE_RECORDS", allocationSize = 1)
    private long id;

    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "amount", column = @Column(name = "PENALTY"))
    })
    private Money penalty;

    @Column(name = "PENAL_DATE")
    private Date penalDate;

    @Column(name = "CREATED_AT")
    private Date createdAt;

    @ManyToOne
    @JoinColumn(name = "REPAYMENT_PLAN_ID")
    private RepaymentPlan repaymentPlan;

    public OverdueRecord() {
    }

    public OverdueRecord(RepaymentPlan plan, Money penalty, Date penalDate) {
        this.repaymentPlan = plan;
        this.penalty = penalty;
        this.penalDate = penalDate;
        this.createdAt = new Date();
    }

    public long id() {
        return id;
    }

    public Money getPenalty() {
        return penalty;
    }

    public Date getPenalDate() {
        return penalDate;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public RepaymentPlan getRepaymentPlan() {
        return repaymentPlan;
    }
}
