package com.lufax.common.domain;

import com.lufax.common.domain.account.Money;

import javax.persistence.*;
import java.util.Date;

import static com.lufax.common.domain.account.Money.ZERO_YUAN;

@MappedSuperclass
public class Record {
    @Column(name = "RECORD_NUMBER")
    protected int recordNumber;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "REPAYMENT_OPERATION_ID")
    protected RepaymentOperation repaymentOperation;

    @Embedded
    @AttributeOverrides({@AttributeOverride(name = "amount", column = @Column(name = "AMOUNT"))})
    protected Money amount;

    @Embedded
    @AttributeOverrides({@AttributeOverride(name = "amount", column = @Column(name = "PRINCIPAL"))})
    protected Money principal;

    @Embedded
    @AttributeOverrides({@AttributeOverride(name = "amount", column = @Column(name = "INTEREST"))})
    protected Money interest;

    @Embedded
    @AttributeOverrides({@AttributeOverride(name = "amount", column = @Column(name = "MANAGEMENT_FEE"))})
    protected Money managementFee;

    @Embedded
    @AttributeOverrides({@AttributeOverride(name = "amount", column = @Column(name = "PENAL_VALUE"))})
    protected Money penalValue;

    @Embedded
    @AttributeOverrides({@AttributeOverride(name = "amount", column = @Column(name = "OVERDUE_PENAL_VALUE"))})
    protected Money overduePenalValue;

    //    @Enumerated(EnumType.STRING)
    @Column(name = "STATUS")
    protected String status;

    @Column(name = "CREATED_AT")
    protected Date createdAt;

    @Column(name = "UPDATED_AT")
    protected Date updatedAt;

    public Record() {
    }

    public Record(RepaymentOperation repaymentOperation, int planNumber, Money amount, Money principal, Money interest, Money managementFee, Money penalValue, Money overduePenalValue, RecordStatus status, Date createdAt) {
        this.repaymentOperation = repaymentOperation;
        this.recordNumber = planNumber;
        this.amount = amount;
        this.principal = principal;
        this.interest = interest;
        this.managementFee = managementFee;
        this.penalValue = penalValue;
        this.overduePenalValue = overduePenalValue;
        this.status = (status != null) ? status.name() : null;
        this.createdAt = createdAt;
        this.updatedAt = createdAt;
    }

    public RepaymentOperation getRepaymentOperation() {
        return repaymentOperation;
    }

    public void setRepaymentOperation(RepaymentOperation repaymentOperation) {
        this.repaymentOperation = repaymentOperation;
    }

    public int getRecordNumber() {
        return recordNumber;
    }

    public Money getAmount() {
        return amount;
    }

    public Money getPrincipal() {
        return principal;
    }

    public Money getInterest() {
        return interest;
    }

    public Money getManagementFee() {
        return managementFee;
    }

    public Money getPenalValue() {
        return penalValue == null ? ZERO_YUAN : penalValue;
    }

    public Money getOverduePenalValue() {
        return overduePenalValue == null ? ZERO_YUAN : overduePenalValue;
    }

    public RecordStatus getStatus() {
        return RecordStatus.getRecordStatusByName(status);
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public Date getUpdatedAt() {
        return updatedAt;
    }

    public boolean isSettled() {
        return RecordStatus.DONE.equals(RecordStatus.getRecordStatusByName(status));
    }

    public boolean isOngoing() {
        return RecordStatus.ONGOING == RecordStatus.getRecordStatusByName(status);
    }

    public void setStatus(RecordStatus status) {
        this.status = (status != null) ? status.name() : null;
    }

    public boolean isDone() {
        return RecordStatus.DONE.equals(RecordStatus.getRecordStatusByName(status));
    }

	public void setRecordNumber(int recordNumber) {
		this.recordNumber = recordNumber;
	}

	public void setAmount(Money amount) {
		this.amount = amount;
	}

	public void setPrincipal(Money principal) {
		this.principal = principal;
	}

	public void setInterest(Money interest) {
		this.interest = interest;
	}

	public void setManagementFee(Money managementFee) {
		this.managementFee = managementFee;
	}

	public void setPenalValue(Money penalValue) {
		this.penalValue = penalValue;
	}

	public void setOverduePenalValue(Money overduePenalValue) {
		this.overduePenalValue = overduePenalValue;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}
    
}
