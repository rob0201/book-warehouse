package com.lufax.common.domain;

import static com.lufax.common.domain.PlanStatus.UNPAID;
import static com.lufax.common.utils.DateUtils.endOfDay;
import static com.lufax.common.utils.DateUtils.endOfToday;
import static java.util.Arrays.asList;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.FetchType;
import javax.persistence.MappedSuperclass;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;

import org.apache.commons.collections.CollectionUtils;
import org.joda.time.DateTime;
import org.joda.time.Days;

import com.lufax.common.domain.account.Money;
import com.lufax.common.utils.OverduePenaltyCalculator;

@MappedSuperclass
public abstract class Plan<T extends Record> {
    @Column(name = "PLAN_NUMBER")
    protected int planNumber;

    @Column(name = "OVERDUE_UPDATE_DATE")
    protected Date overdueUpdateDate;

    @Embedded
    @AttributeOverrides({@AttributeOverride(name = "amount", column = @Column(name = "OVERDUE_PENALTY"))})
    protected Money overduePenalty;

    @Embedded
    @AttributeOverrides({@AttributeOverride(name = "amount", column = @Column(name = "OVERDUE_PENALTY_TO_PROCEED"))})
    protected Money overduePenaltyToProceed;

    @Embedded
    @AttributeOverrides({@AttributeOverride(name = "amount", column = @Column(name = "AMOUNT"))})
    protected Money amount;

    @Embedded
    @AttributeOverrides({@AttributeOverride(name = "amount", column = @Column(name = "PRINCIPAL"))})
    protected Money principal;

    @Embedded
    @AttributeOverrides({@AttributeOverride(name = "amount", column = @Column(name = "INTEREST"))})
    protected Money interest;

    @Embedded
    @AttributeOverrides({@AttributeOverride(name = "amount", column = @Column(name = "MANAGEMENT_FEE"))})
    protected Money managementFee;

    //    @Enumerated(EnumType.STRING)
    @Column(name = "STATUS")
    protected String status;

    @Column(name = "END_AT")
    protected Date endAt;

    
    @OneToMany(fetch = FetchType.LAZY, mappedBy = "plan")
    @OrderBy("createdAt DESC")
    protected List<T> records;
    
    @Column(name = "INTEREST_RATE")
    protected BigDecimal interestRate;

    public Plan() {
    }

    public Plan(int planNumber, Money amount, Money principal, Money interest, Money managementFee, Date endAt, BigDecimal interestRate) {
        this.planNumber = planNumber;
        this.amount = amount;
        this.principal = principal;
        this.interest = interest;
        this.managementFee = managementFee;
        this.status = PlanStatus.UNPAID.name();
        this.endAt = endAt;
        this.interestRate = interestRate;
    }
    
    public Plan(int planNumber, Money amount, Money principal, Money interest, Money managementFee, Date endAt) {
        this.planNumber = planNumber;
        this.amount = amount;
        this.principal = principal;
        this.interest = interest;
        this.managementFee = managementFee;
        this.status = PlanStatus.UNPAID.name();
        this.endAt = endAt;
    }

    abstract public long id();

    abstract public Money overduePenaltyOfPreviousPlan();

    abstract public Money overduePenaltyOfPreviousPlan(Date date);

    abstract public BigDecimal getAnnualInterestRate();

    abstract public BigDecimal getOverdueFloatRate();

    abstract public int getOverdueBufferDays();

    abstract public int getNumberOfInstalments();

    abstract protected List<T> getRecordsBelongingTo(RepaymentOperation repaymentOperation);

    public boolean isSettled() {
        return PlanStatus.getPlanStatusByName(status).isSettled();
    }

    public boolean isOngoing() {
        return PlanStatus.getPlanStatusByName(status).isOngoing();
    }
    public boolean isPaid() {
        return PlanStatus.PAID.equals(PlanStatus.getPlanStatusByName(status));
    }

    public boolean isPrepaid() {
        return PlanStatus.PREPAID.equals(PlanStatus.getPlanStatusByName(status));
    }

    public boolean isTransferred() {
        return PlanStatus.TRANSFER.equals(PlanStatus.getPlanStatusByName(status));
    }

    public boolean isCompensated() {
        return PlanStatus.COMP_DONE.equals(PlanStatus.getPlanStatusByName(status));
    }
    public boolean isUnpaid() {
        return PlanStatus.UNPAID.equals(PlanStatus.getPlanStatusByName(status));
    }

    public boolean isOverdue() {
        return PlanStatus.OVERDUE.equals(PlanStatus.getPlanStatusByName(status));
    }

    public boolean isProcessing() {
        return PlanStatus.PROCESSING.equals(PlanStatus.getPlanStatusByName(status));
    }

    public Money getAmount() {
        return amount;
    }

    public Money getTotal() {
        if (isOverdueUpdateToDate()) {
            return amount;
        }
        return getTotalExcludingOverduePenaltyToProceed().add(calculateOverduePenaltyToProceed());
    }

    public Money getTotal(Date date) {
        if (isOverdueUpdateToDate(date)) {
            return amount;
        }
        return getTotalExcludingOverduePenaltyToProceed().add(calculateOverduePenaltyToProceed(date));
    }

    protected abstract Money getTotalExcludingOverduePenaltyToProceed();


    public void updateOverdueStatusTo(Date date) {
        overduePenalty = calculateOverduePenaltyTo(date);
        overduePenaltyToProceed = calculateOverduePenaltyToProceed();
        overdueUpdateDate = date;
        amount = getTotalExcludingOverduePenaltyToProceed().add(overduePenaltyToProceed);
    }

    protected Money calculateOverduePenaltyToProceed() {
        int instalments = getNumberOfInstalments();
        if (instalments == 1) {
            return getOverduePenalty();
        } else if (planNumber == 1) {
            return Money.ZERO_YUAN;
        } else if (planNumber == instalments) {
            return getOverduePenalty().add(overduePenaltyOfPreviousPlan());
        }
        return overduePenaltyOfPreviousPlan();
    }

    protected Money calculateOverduePenaltyToProceed(Date date) {
        int instalments = getNumberOfInstalments();
        if (instalments == 1) {
            return getOverduePenalty(date);
        } else if (planNumber == 1) {
            return Money.ZERO_YUAN;
        } else if (planNumber == instalments) {
            return getOverduePenalty(date).add(overduePenaltyOfPreviousPlan(date));
        }
        return overduePenaltyOfPreviousPlan(date);
    }

    public Money getOverduePenalty() {
        if (isOverdueUpdateToDate()) {
            return overduePenalty == null ? Money.ZERO_YUAN : overduePenalty;
        }
        return calculateOverduePenaltyTo(new Date());
    }

    public Money getOverduePenalty(Date date) {
        if (isOverdueUpdateToDate(date)) {
            return overduePenalty == null ? Money.ZERO_YUAN : overduePenalty;
        }
        return calculateOverduePenaltyTo(date);
    }

    protected Money getOverduePenaltyToProceed() {
        if (isOverdueUpdateToDate()) {
            return overduePenaltyToProceed == null ? Money.ZERO_YUAN : overduePenaltyToProceed;
        }
        return calculateOverduePenaltyToProceed();
    }

    protected Money getOverduePenaltyToProceed(Date date) {
        if (isOverdueUpdateToDate(date)) {
            return overduePenaltyToProceed == null ? Money.ZERO_YUAN : overduePenaltyToProceed;
        }
        return calculateOverduePenaltyToProceed(date);
    }

    protected boolean isOverdueUpdateToDate() {
        return isSettled() || endOfToday().equals(overdueUpdateDate) || !isTradeOverdue();
    }

    protected boolean isOverdueUpdateToDate(Date date) {
        return isSettled() || endOfToday(date).equals(overdueUpdateDate) || !isTradeOverdue();
    }

    protected abstract boolean isTradeOverdue();

    public Money calculateOverduePenaltyTo(Date date) {
        return OverduePenaltyCalculator.calculate(this, date);
    }

    public int getOverdueDaysUntil(Date date) {
        if (!isOverdue()) {
            return 0;
        }

        DateTime endOfToday = new DateTime(endOfDay(date));
        return Days.daysBetween(new DateTime(getEndAt()), endOfToday).getDays();
    }

    public List<T> getRecords() {
        if (records == null) {
            records = new ArrayList<T>();
        }
        return records;
    }

    public void addRecords(T... records) {
        getRecords().addAll(asList(records));
    }

    protected boolean containsRecord(T record) {
        return getRecords().contains(record);
    }

    public List<T> getSettledRecords() {
        List<T> result = new ArrayList<T>();
        for (T record : getRecords()) {
            if (record.isSettled()) {
                result.add(record);
            }
        }
        return result;
    }

    public T getOngoingRecord() {
        for (T record : getRecords()) {
            if (RecordStatus.ONGOING.equals(record.getStatus())) {
                return record;
            }
        }
        return null;
    }

    public List<T> getRecords(RecordStatus status) {
        ArrayList<T> results = new ArrayList<T>();
        for (T record : getRecords()) {
            if (status == record.getStatus()) {
                results.add(record);
            }
        }
        return results;
    }

    public T getLatestRecord() {
        List<T> settledRecords = getSettledRecords();
        return CollectionUtils.isEmpty(settledRecords) ? null : settledRecords.get(0);
    }

    public List<T> getRecordsOrderByCreationDateAscending() {
        List<T> result = new ArrayList<T>();
        result.addAll(getSettledRecords());
        Collections.reverse(result);
        return result;
    }

    public Money getScheduledPrincipal(RepaymentOperation repaymentOperation) {
        Money result = Money.ZERO_YUAN;
        for (Record record : getRecordsBelongingTo(repaymentOperation)) {
            if (record.getStatus() == RecordStatus.DONE || record.getStatus() == RecordStatus.ONGOING) {
                result = result.add(record.getPrincipal());
            }
        }
        return result;
    }

    public List<RepaymentOperation> getRepaymentOperationsOrderByCreationDateAscending() {
        List<RepaymentOperation> repaymentOperations = new ArrayList<RepaymentOperation>();

        Set<RepaymentOperation> set = new HashSet<RepaymentOperation>();
        for (Record Record : getRecords()) {
            set.add(Record.getRepaymentOperation());
        }

        repaymentOperations.addAll(set);
        Collections.sort(repaymentOperations, new Comparator<RepaymentOperation>() {
            public int compare(RepaymentOperation repaymentOperation, RepaymentOperation other) {
                return repaymentOperation.getCreatedAt().before(other.getCreatedAt()) ? -1 : 1;
            }
        });
        return repaymentOperations;
    }

    public boolean passEndDate() {
        return new Date().after(endAt) && UNPAID.equals(PlanStatus.getPlanStatusByName(status));
    }

    public int getPlanNumber() {
        return planNumber;
    }

    public Money getPrincipal() {
        return principal;
    }

    public Money getInterest() {
        return interest;
    }

    public Money getManagementFee() {
        return managementFee;
    }

    public PlanStatus getStatus() {
        return PlanStatus.getPlanStatusByName(status);
    }

    public void setStatus(PlanStatus status) {
        this.status = (status != null) ? status.name() : null;
    }

    public Date getEndAt() {
        return endAt;
    }

    public void setEndAt(Date endAt) {
        this.endAt = endAt;
    }

    public Date getOverdueUpdateDate() {
        return overdueUpdateDate;
    }

    abstract public Loan getLoan();

    public void setOverdueUpdateDate(Date overdueUpdateDate) {
        this.overdueUpdateDate = overdueUpdateDate;
    }

    public void setOverduePenalty(Money overduePenalty) {
        this.overduePenalty = overduePenalty;
    }

	public BigDecimal getInterestRate() {
		return interestRate;
	}
    
}

