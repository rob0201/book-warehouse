package com.lufax.common.domain;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "RECHARGE_RECORD_SEQUENCE")
public class RechargeRecordSequence {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_RECHARGE_RECORD_SEQUENCE")
    @SequenceGenerator(name = "SEQ_RECHARGE_RECORD_SEQUENCE", sequenceName = "SEQ_RECHARGE_RECORD_SEQUENCE", allocationSize = 1)
    private long id;

    @Column(name = "CREATED_AT")
    private Date createdAt;

    public RechargeRecordSequence() {
    }

    public RechargeRecordSequence(Date createdAt) {
        this.createdAt = createdAt;
    }

    public long id() {
        return this.id;
    }

    public Date getCreatedAt() {
        return createdAt;
    }
}
