package com.lufax.common.domain;

import com.lufax.common.domain.account.Money;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "BANK_BIND_AUTH")
public class BankBindAuth {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_BANK_BIND_AUTH")
    @SequenceGenerator(name = "SEQ_BANK_BIND_AUTH", sequenceName = "SEQ_BANK_BIND_AUTH", allocationSize = 1)
    private long id;

    @Column(name = "USER_ID")
    private long userId;

    @Column(name = "BANK_CODE")
    private String bankCode;

    @Column(name = "BANK_ID")
    private String subBankCode;

    @Column(name = "BANK_ACCOUNT")
    private String bankAccount;

    @Embedded
    @AttributeOverrides({@AttributeOverride(name = "amount", column = @Column(name = "AUTH_AMOUNT"))})
    private Money authAmount;

//    @Enumerated(EnumType.STRING)
    @Column(name="STATUS")
    private String status;

    @Column(name = "FAIL_COUNT")
    private int failCount;

    @Column(name = "CREATED_AT")
    private Date createdAt;

    public BankBindAuth() {
    }

    public BankBindAuth(long userId, String bankCode, String subBankCode, String bankAccount,
                        Money authAmount, BankBindStatus status, int failCount) {
        this.userId = userId;
        this.bankCode = bankCode;
        this.subBankCode = subBankCode;
        this.bankAccount = bankAccount;
        this.authAmount = authAmount;
        this.status = (status!=null)?status.name():null;
        this.failCount = failCount;
        this.createdAt = new Date();
    }

    public long getUserId() {
        return userId;
    }

    public BankBindStatus getStatus() {
        return BankBindStatus.getBankBindStatusByName(status);
    }

    public void setStatus(BankBindStatus status) {
        this.status = (status!=null)?status.name():null;
    }

    public long getId() {
        return id;
    }

    public String getBankCode() {
        return bankCode;
    }

    public String getSubBankCode() {
        return subBankCode;
    }

    public String getBankAccount() {
        return bankAccount;
    }

    public int getFailCount() {
        return failCount;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public Money getAuthAmount() {
        return authAmount;
    }

    public void setFailCount(int failCount) {
        this.failCount = failCount;
    }
}
