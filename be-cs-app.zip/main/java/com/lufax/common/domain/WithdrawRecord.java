package com.lufax.common.domain;

import java.util.Date;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.ColumnResult;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.Table;

import com.lufax.common.domain.account.Account;
import com.lufax.common.domain.account.Money;
import com.lufax.common.web.helper.ConstantsHelper;
import com.lufax.customerService.domain.PaymentChannel;


@SqlResultSetMapping(
name="RareWithdrawRecords",
columns={ @ColumnResult(name="username"),
  		  @ColumnResult(name="withdrawId"),
		  @ColumnResult(name="operationType"),
		  @ColumnResult(name="amount"),
		  @ColumnResult(name="sendTime"),
		  @ColumnResult(name="realName"),
		  @ColumnResult(name="bankName"),
		  @ColumnResult(name="bankAccount"),
		  @ColumnResult(name="remark"),
		  @ColumnResult(name="auditor"),
		  @ColumnResult(name="reason"),
		  @ColumnResult(name="manualCapitalId"),
		  @ColumnResult(name="manualCapitalStatementStatus"),
		  @ColumnResult(name="applier"),      
		  @ColumnResult(name="lufaxAccount"), 
		  @ColumnResult(name="transactionNo"),
		  @ColumnResult(name="manualDesc"),   
		  @ColumnResult(name="eoaNo"),
		  @ColumnResult(name="withdrawStatus"),
		  @ColumnResult(name="withdrawBankName")}
)
@Entity
@Table(name = "WITHDRAW_RECORDS")
public class WithdrawRecord {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_WITHDRAW_RECORDS")
    @SequenceGenerator(name = "SEQ_WITHDRAW_RECORDS", sequenceName = "SEQ_WITHDRAW_RECORDS", allocationSize = 1)
    private long id;

    //    @Enumerated(EnumType.STRING)
    @Column(name = "WITHDRAW_TYPE")
    private String withdrawType;

    @Column(name = "BANK_CARD_NO")
    private String bankCardNo;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ACCOUNT_ID")
    private Account account;

    @AttributeOverrides({@AttributeOverride(name = "amount", column = @Column(name = "WITHDRAWAL_AMOUNT"))})
    private Money withdrawAmount;

    @AttributeOverrides({@AttributeOverride(name = "amount", column = @Column(name = "WITHDRAWAL_FEE"))})
    private Money withdrawFee;

    @AttributeOverrides({@AttributeOverride(name = "amount", column = @Column(name = "ACTUAL_AMOUNT"))})
    private Money actualAmount;

    //    @Enumerated(EnumType.STRING)
    @Column(name = "STATUS")
    private String withdrawStatus;

    @Column(name = "CREATED_AT")
    private Date createdAt;

    @Column(name = "UPDATED_AT")
    private Date updatedAt;

    @Column(name = "REMARKS")
    private String remarks;

    @Column(name = "BANK_NAME")
    private String bankName;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "LOAN_ID")
    private Loan loan;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ERROR_DESC_ID")
    private ErrorDesc errorDescription;

    @Column(name = "FROZEN_CODE")
    private Long frozenCode;

    @Column(name=" IS_RARE_WORD")
    private boolean isRareWords;

//    @Enumerated(EnumType.STRING)
    @Column(name="PAYMENT_CHANNEL")
    private String paymentChannel;

    @Column(name="LAUNCH_CHANNEL")
    private String launchChannel;

    public WithdrawRecord(WithdrawType withdrawType, String bankCardNo, Account account, Money withdrawAmount, Money withdrawFee, WithdrawStatus withdrawStatus, String remarks, Loan loan, String bankName) {
        this.withdrawType = (withdrawType != null) ? withdrawType.name() : null;
        this.bankCardNo = bankCardNo;
        this.account = account;
        this.withdrawAmount = withdrawAmount;
        this.withdrawFee = withdrawFee;
        this.withdrawStatus = (withdrawStatus != null) ? withdrawStatus.name() : null;
        this.actualAmount = Money.rmb("0.00");
        this.remarks = remarks;
        this.loan = loan;
        this.bankName = bankName;
        this.createdAt = new Date();
        this.launchChannel= ConstantsHelper.LAUNCH_CHANNEL_P2P;
    }

    public WithdrawRecord(WithdrawRecord withdrawRecord){
        this.withdrawType = (withdrawRecord.getWithdrawType()!=null)?withdrawRecord.getWithdrawType().name():null;
        this.bankCardNo = withdrawRecord.getBankCardNo();
        this.account = withdrawRecord.getAccount();
        this.withdrawAmount = withdrawRecord.getWithdrawAmount();
        this.withdrawFee = withdrawRecord.getWithdrawFee();
        this.withdrawStatus = (withdrawRecord.getWithdrawStatus() != null) ? withdrawRecord.getWithdrawStatus().name() : null;
        this.actualAmount = withdrawRecord.getActualAmount();
        this.remarks = withdrawRecord.getRemarks();
        this.loan = withdrawRecord.getLoan();
        this.bankName = withdrawRecord.getBankName();
        this.paymentChannel=(withdrawRecord.getPaymentChannel()!=null)?withdrawRecord.getPaymentChannel().name():null;
        this.errorDescription=withdrawRecord.getErrorDescription();
        this.createdAt = new Date();
        this.isRareWords=withdrawRecord.isRareWords();
        this.withdrawStatus=WithdrawStatus.NEW.name();
        this.launchChannel=withdrawRecord.getLaunchChannel();


    }

    public WithdrawRecord() {
    }

    public long id() {
        return id;
    }

    public String getLaunchChannel() {
        return launchChannel;
    }

    public void setLaunchChannel(String launchChannel) {
        this.launchChannel = launchChannel;
    }

    public String getLoanRequestCode() {
        return loan == null ? null : loan.getLoanRequestCode();
    }

    public PaymentChannel getPaymentChannel() {
        return PaymentChannel.getPaymentChannelByName(paymentChannel);
    }

    public void setPaymentChannel(PaymentChannel paymentChannel) {
        this.paymentChannel = paymentChannel.name();
    }

    public String getBankCardNo() {
        return bankCardNo;
    }

    public Account getAccount() {
        return account;
    }

    public Money getWithdrawAmount() {
        return withdrawAmount;
    }

    public Long getFrozenCode() {
        return frozenCode;
    }

    public Money getWithdrawFee() {
        return withdrawFee;
    }

    public WithdrawStatus getWithdrawStatus() {
        return WithdrawStatus.getWithdrawStatusByName(withdrawStatus);
    }

    public void setWithdrawStatus(WithdrawStatus withdrawStatus) {
        this.withdrawStatus = (withdrawStatus != null) ? withdrawStatus.name() : null;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public Money getActualAmount() {
        return actualAmount;
    }

    public void setActualAmount(Money actualAmount) {
        this.actualAmount = actualAmount;
    }

    public String getRemarks() {
        return remarks;
    }

    public WithdrawType getWithdrawType() {
        return WithdrawType.getWithdrawTypeByName(withdrawType);
    }

    public String getBankName() {
        return bankName;
    }

    public void setUpdatedAt(Date updatedAt) {
        this.updatedAt = updatedAt;
    }

    public Date getUpdatedAt() {
        return updatedAt;
    }

    public boolean isSuccessful() {
        return WithdrawStatus.SUCCESS.equals(WithdrawStatus.getWithdrawStatusByName(this.withdrawStatus));
    }

    public boolean isFailed() {
        return WithdrawStatus.FAILURE.equals(WithdrawStatus.getWithdrawStatusByName(this.withdrawStatus));
    }

    public boolean isInProcess() {
        return WithdrawStatus.PROCESSING.equals(WithdrawStatus.getWithdrawStatusByName(this.withdrawStatus));
    }

    public boolean isCustomerWithdrawal() {
        return WithdrawType.CUSTOMER_WITHDRAWAL.equals(WithdrawType.getWithdrawTypeByName(withdrawType));
    }

    public boolean isLoanGranting() {
        return WithdrawType.LOAN_GRANTING.equals(WithdrawType.getWithdrawTypeByName(withdrawType));
    }

    public void setLoan(Loan loan) {
        this.loan = loan;
    }

    public void setFrozenCode(Long frozenCode) {
        this.frozenCode = frozenCode;
    }

    public Loan getLoan() {
        return loan;
    }

    public void setErrorDescription(ErrorDesc errorDescription) {
        this.errorDescription = errorDescription;
    }

    public ErrorDesc getErrorDescription() {
        return errorDescription;
    }

    public String getFailDescription() {
        return errorDescription == null ? "" : errorDescription.getDescription();
    }

    public String getShortFailDesc() {
        return errorDescription == null ? "" : errorDescription.getShortDesc();
    }

    public boolean isRareWords() {
        return isRareWords;
    }

    public void setRareWords(boolean rareWords) {
        isRareWords = rareWords;
    }
}
