package com.lufax.common.domain;

import com.lufax.common.domain.account.Money;
import com.lufax.sms.domain.SmsSentStatus;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "VERIFICATION_FEE_RECORDS")
public class VerificationFeeRecord {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_VERIFICATION_FEE_RECORDS")
    @SequenceGenerator(name = "SEQ_VERIFICATION_FEE_RECORDS", sequenceName = "SEQ_VERIFICATION_FEE_RECORDS", allocationSize = 1)
    private long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "USER_ID")
    private User user;

    @AttributeOverrides({@AttributeOverride(name = "amount", column = @Column(name = "AMOUNT"))})
    private Money amount;

    //    @Enumerated(EnumType.STRING)
    @Column(name = "STATUS")
    private String status;

    @Column(name = "CREATED_AT")
    private Date createdAt;

    @Column(name = "VIREMENT_AT")
    private Date virementAt;

    //    @Enumerated(EnumType.STRING)
    @Column(name = "SMS_SENT_STATUS")
    private String smsSentStatus;

    public VerificationFeeRecord() {
    }

    public VerificationFeeRecord(User user, Money amount, VerificationFeeStatus status) {
        this.user = user;
        this.amount = amount;
        this.status = (status != null) ? status.name() : null;
        this.createdAt = new Date();
        this.smsSentStatus = SmsSentStatus.UNSENT.name();
    }

    public void setStatus(VerificationFeeStatus status) {
        this.status = (status != null) ? status.name() : null;
    }

    public void setVirementAt(Date virementAt) {
        this.virementAt = virementAt;
    }

    public long getId() {
        return id;
    }

    public User getUser() {
        return user;
    }

    public Money getAmount() {
        return amount;
    }

    public VerificationFeeStatus getStatus() {
        return VerificationFeeStatus.getVerificationFeeStatusByName(status);
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public Date getVirementAt() {
        return virementAt;
    }

    public void setSmsSentStatus(SmsSentStatus smsSentStatus) {
        this.smsSentStatus = (smsSentStatus != null) ? smsSentStatus.name() : null;
    }

    public SmsSentStatus getSmsSentStatus() {
        return SmsSentStatus.getSmsSentStatusByName(smsSentStatus);
    }
}
