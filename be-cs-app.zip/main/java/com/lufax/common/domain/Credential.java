package com.lufax.common.domain;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

import javax.persistence.Embeddable;

import static com.lufax.common.utils.Encryption.SHA;

@Embeddable
public class Credential {
    private String username;
    private String password;

    private Credential() {
    }

    public Credential(String username, String password) {
        this.username = username;
        this.password = SHA.encryptAsBase64(password);
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    @Override
    public boolean equals(Object o) {
        return EqualsBuilder.reflectionEquals(this, o);
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(username).append(password).hashCode();
    }

    public String getPassword() {
        return password;
    }
}
