package com.lufax.common.domain;

import static com.lufax.common.web.helper.ConstantsHelper.CMS_WITHDRAW_FEE_TYPE;
import static com.lufax.common.web.helper.ConstantsHelper.INSURANCE_FEE_TRANSACTION_TYPE_VALUE;
import static com.lufax.common.web.helper.ConstantsHelper.INVESTMENT_TRANSACTION_FEE_VALUE;
import static com.lufax.common.web.helper.ConstantsHelper.MANAGEMENT_FEE_TRANSACTION_TYPE_VALUE;
import static com.lufax.common.web.helper.ConstantsHelper.PENAL_TRANSACTION_TYPE_VALUE;
import static com.lufax.common.web.helper.ConstantsHelper.RECHARGE_FEE_TRANSACTION_TYPE_VALUE;
import static com.lufax.common.web.helper.ConstantsHelper.TRANSACTION_FEE_TRANSACTION_TYPE_VALUE;
import static com.lufax.common.web.helper.ConstantsHelper.TRANSFER_FEE_TRANSACTION_TYPE_VALUE;

import com.lufax.common.utils.DevLog;

public enum TransactionType {
    RECHARGE("充值", FundType.INCOME),
    WITHDRAWALS("取现", FundType.EXPENSE),
    EXPENSE_RECHARGE_FEE(RECHARGE_FEE_TRANSACTION_TYPE_VALUE, FundType.EXPENSE),
    INCOME_RECHARGE_FEE(RECHARGE_FEE_TRANSACTION_TYPE_VALUE, FundType.INCOME),
    EXPENSE_WITHDRAWALS_FEE(CMS_WITHDRAW_FEE_TYPE, FundType.EXPENSE),
    INCOME_WITHDRAWALS_FEE(CMS_WITHDRAW_FEE_TYPE, FundType.INCOME),
    FROZEN_FUND("资金冻结", FundType.FREEZE_RELATED),
    FROZEN_FUND_LOANREQUEST("贷款请求资金冻结", FundType.FREEZE_RELATED),
    FROZEN_FUND_WITHDRAW("取现资金冻结", FundType.FREEZE_RELATED),
    UNFROZEN_FUND("资金解冻", FundType.UNFREEZE_RELATED),
    UNFROZEN_FUND_CMSWITHDRAW("取现失败资金解冻", FundType.UNFREEZE_RELATED),
    UNFROZEN_FUND_INVESTMENT("投资失败资金解冻", FundType.UNFREEZE_RELATED),
    UNFROZEN_FUND_INVESTMENT_SUCCESS("投资成功资金解冻", FundType.UNFREEZE_RELATED),  //added for flush need
    INVESTMENT("投标成功", FundType.EXPENSE),
    LOAN("借款成功", FundType.INCOME),

    // TODO to be removed since it was divided into PRINCIPAL_REPAYMENT and INTEREST_REPAYMENT
    REPAYMENT("偿还本息", FundType.EXPENSE),

    PRINCIPAL_REPAYMENT("偿还本金", FundType.EXPENSE),
    INTEREST_REPAYMENT("偿还利息", FundType.EXPENSE),
    RE_OVERDUE_PENALTY("偿还逾期罚息", FundType.EXPENSE),

    // TODO to be removed since it was divided into PRINCIPAL_COLLECTION and INTEREST_COLLECTION
    COLLECTION("收回本息", FundType.INCOME),

    PRINCIPAL_COLLECTION("收回本金", FundType.INCOME),
    INTEREST_COLLECTION("收回利息", FundType.INCOME),
    CO_OVERDUE_PENALTY("收回逾期罚息", FundType.INCOME),
    MANAGEMENT_FEE_REPAYMENT(MANAGEMENT_FEE_TRANSACTION_TYPE_VALUE, FundType.EXPENSE),
    MANAGEMENT_FEE_COLLECTION_LOANEE(MANAGEMENT_FEE_TRANSACTION_TYPE_VALUE, FundType.INCOME),
    MANAGEMENT_FEE_COLLECTION_LOANER(MANAGEMENT_FEE_TRANSACTION_TYPE_VALUE, FundType.INCOME),
    MANAGEMENT_FEE_COLLECTION(MANAGEMENT_FEE_TRANSACTION_TYPE_VALUE, FundType.INCOME),
    INSURANCE_FEE_COLLECTION(INSURANCE_FEE_TRANSACTION_TYPE_VALUE, FundType.INCOME),
    INSURANCE_FEE_REPAYMENT(INSURANCE_FEE_TRANSACTION_TYPE_VALUE, FundType.EXPENSE),
    PENAL_COLLECTION(PENAL_TRANSACTION_TYPE_VALUE, FundType.INCOME),
    PENAL_COLLECTION_LOANER(PENAL_TRANSACTION_TYPE_VALUE, FundType.INCOME),
    PENAL_COLLECTION_XINBAO(PENAL_TRANSACTION_TYPE_VALUE, FundType.INCOME),
    PENAL_COLLECTION_P2P(PENAL_TRANSACTION_TYPE_VALUE, FundType.INCOME),
    PENAL_REPAYMENT(PENAL_TRANSACTION_TYPE_VALUE, FundType.EXPENSE),
    PENAL_REPAYMENT_LOANER(PENAL_TRANSACTION_TYPE_VALUE, FundType.EXPENSE),
    PENAL_REPAYMENT_XINBAO(PENAL_TRANSACTION_TYPE_VALUE, FundType.EXPENSE),
    PENAL_REPAYMENT_P2P(PENAL_TRANSACTION_TYPE_VALUE, FundType.EXPENSE),
    EXPENSE_TRANSACTION_FEE(TRANSACTION_FEE_TRANSACTION_TYPE_VALUE, FundType.EXPENSE),
    INCOME_TRANSACTION_FEE(TRANSACTION_FEE_TRANSACTION_TYPE_VALUE, FundType.INCOME),
    WITHDRAW_RETURN_TICKET("取现退票", FundType.INCOME),

    //added for COMMON system
    FLUSH_FREEZE_FUND("冻结冲正", FundType.UNFREEZE_RELATED),
    FLUSH_UNFREEZE_FUND("解冻冲正", FundType.FREEZE_RELATED),
    FLUSH_TRANSFER_COLLECTION("转账冲正", FundType.INCOME),
    FLUSH_TRANSFER_REPAYMENT("转账冲正", FundType.EXPENSE),
    EXPENSE_EXCEPTION_RETURN("异常款返还",FundType.EXPENSE),
    INCOME_EXCEPTION_RETURN("异常款返还",FundType.INCOME),

    //added by SME system
    PROFIT_TRANSFERED_IN("收回转让款", FundType.INCOME),
    PROFIT_TRANSFERED_OUT("支付转让款", FundType.EXPENSE),

    MARGINS_IN("收回保证金", FundType.INCOME),
    MARGINS_OUT("支付保证金", FundType.EXPENSE),

    MARGINS_MAG_PENAL_BOND_IN("收回管理违约金", FundType.INCOME),
    MARGINS_MAG_PENAL_BOND_OUT("偿还管理违约金", FundType.EXPENSE),

    MARGINS_MAG_PENAL_BOND_PENALTY_IN("收回管理违约金罚息", FundType.INCOME),
    MARGINS_MAG_PENAL_BOND_PENALTY_OUT("偿还管理违约金罚息", FundType.EXPENSE),

    INVESTMENT_TRANSACTION_FEE_REPAYMENT(INVESTMENT_TRANSACTION_FEE_VALUE, FundType.EXPENSE),
    INVESTMENT_TRANSACTION_FEE_COLLECTION(INVESTMENT_TRANSACTION_FEE_VALUE, FundType.INCOME),


    SHOT_OVER_IN("收款尾差", FundType.INCOME),
    SHOT_OVER_OUT("扣款尾差", FundType.EXPENSE),
    SHOT_OVER_REPAY_OUT("偿还尾差", FundType.EXPENSE),

    RECHARGE_FOR_COMPENSATE("代偿充值", FundType.INCOME),
    PRINCIPAL_COLLECTION_COMPENSATE("收回代偿本金", FundType.INCOME),
    INTEREST_COLLECTION_COMPENSATE("收回代偿利息", FundType.INCOME),
    OVERDUE_PENALTY_COLLECTION_COMPENSATE("收回代偿逾期罚息", FundType.INCOME),
    PRINCIPAL_REPAYMENT_COMPENSATE("偿还代偿本金", FundType.EXPENSE),
    INTEREST_REPAYMENT_COMPENSATE("偿还代偿利息", FundType.EXPENSE),
    OVERDUE_PENALTY_REPAYMENT_COMPENSATE("偿还代偿逾期罚息", FundType.EXPENSE),

    SUBROGATION_REPAYMENT("追偿支出",FundType.EXPENSE),
    SUBROGATION_COLLECTION("追偿收入",FundType.INCOME),
    
    INVESTMENT_TRANSFER("转让成功", FundType.INCOME),
    EXPENSE_TRANSFER_FEE(TRANSFER_FEE_TRANSACTION_TYPE_VALUE, FundType.EXPENSE),
    INCOME_TRANSFER_FEE(TRANSFER_FEE_TRANSACTION_TYPE_VALUE, FundType.INCOME);


    private String value;

    private FundType fundType;

    private TransactionType(String value, FundType fundType) {
        this.value = value;
        this.fundType = fundType;
    }

    public String getValue() {
        return value;
    }

    public boolean isIncome() {
        return FundType.INCOME.equals(this.fundType);
    }

    public boolean isExpense() {
        return FundType.EXPENSE.equals(this.fundType);
    }

    //是否冻结相关或解冻相关
    public boolean isFrozenRelated() {
        //return FundType.FROZEN_RELATED.equals(this.fundType);
        return isFreezeRelated() || isUnfreezeRelated();
    }

    public FundType getFundType() {
        return fundType;
    }

    //是否冻结相关
    public boolean isFreezeRelated() {
        return FundType.FREEZE_RELATED.equals(this.fundType);
    }

    //是否解冻相关
    public boolean isUnfreezeRelated() {
        return FundType.UNFREEZE_RELATED.equals(this.fundType);
    }

    public enum FundType {
        INCOME, EXPENSE,
        //FROZEN_RELATED, //原来的冻结和解冻相关交易类型均关联该FROZEN_RELATED资金类型
        FREEZE_RELATED, UNFREEZE_RELATED
    }
	
	public static TransactionType convertToTransactionType(String name){
		TransactionType[] types = TransactionType.values();
		for(TransactionType type : types){
			if(type.name().equals(name)){
				return type;
			}
		}
		return null;
	}
	
//<<<<<<< HEAD
//	public static TransactionType convertValueToTransactionType(String value){
//		TransactionType[] types = TransactionType.values();
//		for(TransactionType type : types){
//			
//=======
	public static TransactionType convertToTransactionTypeByValue(String value){
		TransactionType[] types = TransactionType.values();
		for(TransactionType type : types){
			DevLog.debug(TransactionType.class, String.format("The transactionTypeValue is  [%s], the parameterValue is [%s]",type.getValue(),value));
			if(type.getValue().equals(value)){
				return type;
			}
		}
		return null;
	}
}
