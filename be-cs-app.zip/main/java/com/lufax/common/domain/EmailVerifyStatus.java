package com.lufax.common.domain;

public enum EmailVerifyStatus {
    NO_VERIFIED("0", "未提交"),
    SUBMITTED_NOT_VERIFIED("1", "已提交未认证(认证邮件未发送)"),
    IN_VERIFIED("2", "认证中(邮件已发送，等待用户确认)"),
    SUCCESS("3", "认证成功"),
    UNKNOWN("unkonwn", "unkonwn");

    private String value;
    private String emailVerifyStatusDesc;

    EmailVerifyStatus(String value, String emailVerifyStatusDesc) {
        this.value = value;
        this.emailVerifyStatusDesc = emailVerifyStatusDesc;
    }

    public String getValue() {
        return value;
    }

    public String getEmailVerifyStatusDesc() {
        return emailVerifyStatusDesc;
    }

}
