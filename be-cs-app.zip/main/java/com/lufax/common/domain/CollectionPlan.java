package com.lufax.common.domain;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.joda.time.DateTime;

import com.lufax.common.domain.account.Money;

@Entity
@Table(name = "COLLECTION_PLANS")
public class CollectionPlan extends Plan<CollectionRecord> {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_COLLECTION_PLANS")
    @SequenceGenerator(name = "SEQ_COLLECTION_PLANS", sequenceName = "SEQ_COLLECTION_PLANS", allocationSize = 1)
    private long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "INVESTMENT_ID")
    private Investment investment;

    public CollectionPlan() {

    }

    public CollectionPlan(int planNumber, Money amount, Money principal, Money interest, PlanStatus status, Date endAt, Investment investment, Money managementFee, Money overduePenalty, Money overduePenaltyToProceed, BigDecimal interestRate) {
        this(planNumber, amount, principal, interest, status, endAt, investment, managementFee);
        this.overduePenalty = overduePenalty;
        this.overduePenaltyToProceed = overduePenaltyToProceed;
        this.interestRate = interestRate;
    }

    public CollectionPlan(int planNumber, Money amount, Money principal, Money interest, PlanStatus status, Date endAt, Investment investment, Money managementFee) {
        super(planNumber, amount, principal, interest, managementFee, endAt, (investment == null || investment.getLoan() == null) ? new BigDecimal(0) : investment.getLoan().getAnnualInterestRate());
        this.status = status.name();
        this.investment = investment;
    }

    public long id() {
        return id;
    }

    public boolean isInCollectionPlan(DateTime now) {
        DateTime lastEndAt = new DateTime(endAt).minusMonths(1);
        return now.isAfter(lastEndAt) && (now.isBefore(endAt.getTime()));
    }

    public Investment getInvestment() {
        return investment;
    }

    @Override
    public BigDecimal getAnnualInterestRate() {
        return investment.getAnnualInterestRate();
    }

    @Override
    public BigDecimal getOverdueFloatRate() {
        return investment.getOverdueFloatRate();
    }

    @Override
    public int getOverdueBufferDays() {
        return investment.getOverdueBufferDays();
    }

    @Override
    public int getNumberOfInstalments() {
        return investment.getNumberOfInstalments();
    }

    public Money getOverduePenaltyToCollect() {
        return getOverduePenaltyToProceed();
    }

    public Money overduePenaltyOfPreviousPlan() {
        return investment.getCollectionPlan(planNumber - 1).getOverduePenalty();
    }

    @Override
    public Money overduePenaltyOfPreviousPlan(Date date) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public List<CollectionRecord> getRecordsBelongingTo(RepaymentOperation repaymentOperation) {
        List<CollectionRecord> result = new ArrayList<CollectionRecord>();
        for (CollectionRecord collectionRecord : repaymentOperation.getCollectionRecords()) {
            if (containsRecord(collectionRecord)) {
                result.add(collectionRecord);
            }
        }
        return result;
    }

    @Override
    protected Money getTotalExcludingOverduePenaltyToProceed() {
        return principal.add(interest);
    }

    @Override
    protected boolean isTradeOverdue() {
        return investment.isOverdue();
    }

    @Override
    public Loan getLoan() {
        return investment.getLoan();
    }

    public String toString() {
        return new StringBuilder("Collection plan: ")
                .append("plan number: ").append(this.planNumber)
                .append("amount: ").append(this.amount)
                .append("principal: ").append(this.principal)
                .append("interest: ").append(this.interest).toString();
    }
    
    public Money getRemainingAmount() {
        if (isSettled()) {
            return Money.ZERO_YUAN;
        }
        return getTotal().subtract(getTotalCollectedAmount());
    }
    
    public Money getTotalCollectedAmount() {
        Money totalCollectedAmount = Money.ZERO_YUAN;
        for (CollectionRecord collectionRecord : getSettledRecords()) {
            totalCollectedAmount = totalCollectedAmount.add(collectionRecord.getAmount());
        }
        return totalCollectedAmount;
    }
    
    public Money getRemainingInterest() {
        if (isSettled()) {
            return Money.ZERO_YUAN;
        }
        return getInterest().subtract(getTotalCollectedInterest());
    }

    public Money getTotalCollectedInterest() {
        Money totalCollectedInterest = Money.ZERO_YUAN;
        for (CollectionRecord collectionRecord : getSettledRecords()) {
            totalCollectedInterest = totalCollectedInterest.add(collectionRecord.getInterest());
        }
        return totalCollectedInterest;
    }
    
    public Money getEstimatedUnchargedInvestMgmtFee() {
        if (isSettled()) {
            return Money.ZERO_YUAN;
        }
        return getEstimatedInvestMgmtFee().subtract(getChargedInvestMgmtFee());
    }
    
    private Money getEstimatedInvestMgmtFee() {
        return (getTotal().subtract(principal)).multiply(investment.getInvestMgmtFeeRate()).roundUp();
    }

    private Money getChargedInvestMgmtFee() {
        Money totalChargedAmount = Money.ZERO_YUAN;
        for (CollectionRecord collectionRecord : getSettledRecords()) {
            totalChargedAmount = totalChargedAmount.add(collectionRecord.getInvestmentManagementFee());
        }
        return totalChargedAmount;
    }
    protected Money calculateOverduePenaltyToProceed() {
    	if(!investment.getProduct().isSplited()) {
	        int instalments = getNumberOfInstalments();
	        if (instalments == 1) {
	            return getOverduePenalty();
	        } else if (planNumber == 1) {
	            return Money.ZERO_YUAN;
	        } else if (planNumber == instalments) {
	            return getOverduePenalty().add(overduePenaltyOfPreviousPlan());
	        }
        } else {
        	int instalments = getNumberOfInstalments();
        	int totalInstalments = investment.getCollectionPlans().size();
        	if (planNumber == 1) {
        		return Money.ZERO_YUAN;
	        } else if (planNumber == instalments && instalments == totalInstalments) {
	            return getOverduePenalty().add(overduePenaltyOfPreviousPlan());
	        }
        }
        return overduePenaltyOfPreviousPlan();
    }
}
