package com.lufax.common.domain;

import javax.persistence.*;
import java.util.Date;

import static com.lufax.common.web.helper.ConstantsHelper.CMS_USER_NAME;

@Entity
@Table(name = "BRANCH_BANKS")
public class BranchBank {
    @Id
    @Column(name = "BRANCH_ID")
    private String branchId;

    @Column(name = "BRANCH_NAME")
    private String branchName;

    @Column(name = "BANK_CODE")
    private String bankCode;

    @Column(name = "BANK_ID")
    private String bankId;

    @Column(name = "PARENT_ID")
    private String parentId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "STATE")
    private Province province;

    @Column(name = "AREA")
    private String area;

    @Column(name = "CREATED_BY")
    private String createdBy;

    @Column(name = "CREATED_DATE")
    private Date createdDate;

    @Column(name = "UPDATED_BY")
    private String updatedBy;

    @Column(name = "UPDATED_DATE")
    private Date updatedDate;

    public BranchBank() {
    }

    public BranchBank(String branchId, String branchName, String bankCode, String bankId, String parentId, Province province, String area) {
        this.branchId = branchId;
        this.branchName = branchName;
        this.bankCode = bankCode;
        this.bankId = bankId;
        this.parentId = parentId;
        this.province = province;
        this.area = area;
        this.createdBy = CMS_USER_NAME;
        this.createdDate = new Date();
        this.updatedBy = CMS_USER_NAME;
        this.updatedDate = new Date();
    }

    public String getBranchId() {
        return branchId;
    }

    public String getBranchName() {
        return branchName;
    }

    public String getBankCode() {
        return bankCode;
    }

    public String getBankId() {
        return bankId;
    }

    public String getParentId() {
        return parentId;
    }

    public Province getProvince() {
        return province;
    }

    public String getArea() {
        return area;
    }
}
