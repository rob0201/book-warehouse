package com.lufax.common.domain;

public enum InvestmentRequestStatus {
	@Deprecated
    WAITING_LOANEE_CONFIRM("等待对方确认合同", "等待对方确认合同"),
    @Deprecated
    LOANEE_TELEPHONE_DENIED("投资失败", "失败(借款人电话拒绝)"),   //delete  投资失败
    @Deprecated
    LOANEE_WEBSITE_DENIED("投资失败", "失败(借款人网上拒绝)"),
    @Deprecated
    OPERATION_CANCELED("投资失败", "失败(运营人员后台取消)"),
    @Deprecated
    UN_CONFIRMED_EXPIRED("投资失败", "失败(超时)"),
    @Deprecated
    WAITING_INVEST("等待投资", "待投资"),
    @Deprecated
    CANCELED("失败", "取消"),
    SUCCESS("成功", "成功"),
    FAIL("投资失败", "其他原因"),
    LOW_BALANCE("投资失败", "余额不足"),
    PAID("已付款", "已付款"),
    NEW("新投资申请", "新投资申请"),
    UNKNOWN("unkonwn", "unkonwn");

    private String value;
    private String customerServiceDesc;

    InvestmentRequestStatus(String value, String customerServiceDesc) {
        this.value = value;
        this.customerServiceDesc = customerServiceDesc;
    }

    public String getValue() {
        return value;
    }

    public String getCustomerServiceDesc() {
        return customerServiceDesc;
    }

    public static boolean isFailed(InvestmentRequestStatus investmentRequestStatus) {
        if (investmentRequestStatus.getValue() == "投资失败") {
            return true;
        }
        return false;
    }

    public static InvestmentRequestStatus getInvestmentRequestStatusByName(String status) {
        InvestmentRequestStatus[] investmentRequestStatuses = InvestmentRequestStatus.values();
        for (InvestmentRequestStatus investmentRequestStatus : investmentRequestStatuses)
            if (investmentRequestStatus.name().equalsIgnoreCase(status))
                return investmentRequestStatus;
        return UNKNOWN;

    }
}
