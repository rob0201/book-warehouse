package com.lufax.common.domain;

import com.lufax.common.utils.DateUtils;

import java.util.Date;

import static com.lufax.common.web.helper.ConstantsHelper.PDF_SUFFIX;
import static java.util.Arrays.asList;

public enum TradeContractType {
    LOAN("p2pContract.vm"),
    WITHHOLDING("p2pWithholdingContract.vm"),
    AUTHORIZATION("p2pAuthorizationAgreement.vm"),
    AUTHORIZATION_2ND("contract/p2pAuthorizationAgreementSecondaryMarket.vm"),
    TRANSFER("contract/p2pLoanTransferredContract.vm"),
    UNKNOWN("unknown");

    private String template;

    TradeContractType(String template) {
        this.template = template;
    }

    public String getTemplate() {
        return template;
    }

    public String contractNameOf(Loan loan) {
        return String.format("%s_%s.%s", loan.getCode(), toString().toLowerCase(), PDF_SUFFIX);
    }

    public static String codeOf(String code) {
        return String.format("10-0001-%s-%s", DateUtils.formatDateAsString(new Date()), code.substring(code.length() - 6));
    }

    public boolean allowForLoaner() {
        return asList(LOAN, AUTHORIZATION).contains(this);
    }

    public boolean allowForLoanee() {
        return asList(LOAN, WITHHOLDING).contains(this);
    }
    public static TradeContractType getTradeContractTypeByName(String name){
        TradeContractType[] tradeContractTypes=TradeContractType.values();
        for(TradeContractType tradeContractType:tradeContractTypes)
            if(tradeContractType.name().equalsIgnoreCase(name))
                return tradeContractType;
        return UNKNOWN;
    }
}
