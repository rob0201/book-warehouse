package com.lufax.common.domain;

import com.lufax.common.domain.account.Money;
import org.joda.time.DateTime;
import org.joda.time.Days;

import java.math.BigDecimal;
import java.util.Date;
import java.util.Map;

import static com.lufax.common.utils.BigDecimalUtils.divide;
import static com.lufax.common.utils.DateUtils.isOnSameDayOfMonth;
import static com.lufax.common.utils.DateUtils.startOfDay;

public class PrepaymentDetail {

    private static final BigDecimal THIRTY = new BigDecimal("30");
    public static final BigDecimal PANEL_FEE_MORE_THAN_11_MONTHS = new BigDecimal("0.01");
    public static final BigDecimal PANEL_FEE_BETWEEN_5_AND_11_MONTHS = new BigDecimal("0.02");
    public static final BigDecimal PANEL_FEE_WITHIN_5_MONTHS = new BigDecimal("0.03");

    private BigDecimal LOANER_PANEL_RATE_MORE_THAN_11_MONTHS;
    private BigDecimal LOANER_PANEL_RATE_BETWEEN_5_AND_11_MONTHS;
    private BigDecimal LOANER_PANEL_RATE_WITHIN_5_MONTHS;

    private BigDecimal INSURANCE_MANAGEMENT_FEE_MORE_THAN_11_MONTHS;
    private BigDecimal INSURANCE_MANAGEMENT_FEE_BETWEEN_5_AND_11_MONTHS;
    private BigDecimal INSURANCE_MANAGEMENT_FEE_WITHIN_5_MONTHS;

    private BigDecimal P2P_PREPAY_FEE_MORE_THAN_11_MONTHS;
    private BigDecimal P2P_PREPAY_FEE_BETWEEN_5_AND_11_MONTHS;
    private BigDecimal P2P_PREPAY_FEE_WITHIN_5_MONTHS;

    private Money prepayAmount;
    private Money remainingPrincipal;

    private Money penalValue;
    private Money insuranceManagementFee;
    private Money p2pPrepayFee;
    private Money insuranceFeeOfCurrentPlan = Money.ZERO_YUAN;
    private Money interestOfCurrentPlan = Money.ZERO_YUAN;
    private Money overduePenaltyToPayOfCurrentPlan = Money.ZERO_YUAN;
    private Money managementFeeForLoanerOfCurrentPlan = Money.ZERO_YUAN;
    private Money managementFeeForLoaneeOfCurrentPlan = Money.ZERO_YUAN;
    private boolean prepayWithCurrent = false;


    public PrepaymentDetail(Loan loan) {
        RepaymentPlan startPlan = loan.getCurrentRepaymentPlan();
        if (startPlan.isSettled() || startPlan.isDueToPay()) {
            startPlan = loan.getRepaymentPlan(startPlan.planNumber + 1);
        }
        Money amountOfCurrentPlan = Money.ZERO_YUAN;
        if (startPlan.isInProgress()) {
            prepayWithCurrent = true;
            insuranceFeeOfCurrentPlan = startPlan.getInsuranceFee();
            overduePenaltyToPayOfCurrentPlan = startPlan.getOverduePenaltyToPay();
            BigDecimal daysPastForCurrentPlan = daysBetween(startPlan.endDateOfPreviousPlan(), new Date());
            BigDecimal ratio = divide(daysPastForCurrentPlan, THIRTY);
            interestOfCurrentPlan = startPlan.getInterest().multiply(ratio).roundUp();
            managementFeeForLoaneeOfCurrentPlan = startPlan.getManagementFee().multiply(ratio).roundUp();
            managementFeeForLoanerOfCurrentPlan = loan.getInvestment().getCollectionPlan(startPlan.planNumber).getManagementFee().multiply(ratio).roundUp();
            amountOfCurrentPlan = insuranceFeeOfCurrentPlan.add(interestOfCurrentPlan).add(overduePenaltyToPayOfCurrentPlan).add(managementFeeForLoaneeOfCurrentPlan);
        }

        remainingPrincipal = getRemainingPrincipal(loan, startPlan);
        penalValue = remainingPrincipal.multiply(getPenalRate(loan)).roundUp();
        prepayAmount = amountOfCurrentPlan.add(remainingPrincipal).add(penalValue).add(insuranceManagementFee).add(p2pPrepayFee);
    }

    public PrepaymentDetail(Loan loan, Date date, Map<String, BigDecimal> prepayParameters) {
        setConstantParameterValues(prepayParameters);
        RepaymentPlan startPlan = loan.getCurrentRepaymentPlan(date);
        if (startPlan.isSettled() || startPlan.isDueToPay(date)) {
            startPlan = loan.getRepaymentPlan(startPlan.planNumber + 1);
        }
        Money amountOfCurrentPlan = Money.ZERO_YUAN;
        if (startPlan.isInProgress(date)) {
            prepayWithCurrent = true;
            //todo      finish
            overduePenaltyToPayOfCurrentPlan = startPlan.getOverduePenaltyToPay(date);
            BigDecimal daysPastForCurrentPlan = daysBetween(startPlan.endDateOfPreviousPlan(), date);
            BigDecimal ratio = divide(daysPastForCurrentPlan, THIRTY);
            insuranceFeeOfCurrentPlan = startPlan.getInsuranceFee().multiply(ratio).roundUp();
            interestOfCurrentPlan = startPlan.getInterest().multiply(ratio).roundUp();
            managementFeeForLoaneeOfCurrentPlan = startPlan.getManagementFee().multiply(ratio).roundUp();
            managementFeeForLoanerOfCurrentPlan = loan.getInvestment().getCollectionPlan(startPlan.planNumber).getManagementFee().multiply(ratio).roundUp();
            //todo
            amountOfCurrentPlan = insuranceFeeOfCurrentPlan.add(interestOfCurrentPlan).add(overduePenaltyToPayOfCurrentPlan).add(managementFeeForLoaneeOfCurrentPlan);
        }

        remainingPrincipal = getRemainingPrincipal(loan, startPlan);
        penalValue = remainingPrincipal.multiply(getRate(loan, "PANEL_RATE", date)).roundUp();
        insuranceManagementFee = remainingPrincipal.multiply(getRate(loan, "INSURANCE_MANAGEMENT_FEE_RATE", date)).roundUp();
        p2pPrepayFee = remainingPrincipal.multiply(getRate(loan, "P2P_PREPAY_FEE_RATE", date)).roundUp();
        prepayAmount = amountOfCurrentPlan.add(remainingPrincipal).add(penalValue).add(insuranceManagementFee).add(p2pPrepayFee);
    }

    private void setConstantParameterValues(Map<String, BigDecimal> prepayParameters) {
        LOANER_PANEL_RATE_MORE_THAN_11_MONTHS = prepayParameters.get(BizParameters.LOANER_PANEL_RATE_MORE_THAN_11_MONTHS);
        LOANER_PANEL_RATE_BETWEEN_5_AND_11_MONTHS = prepayParameters.get(BizParameters.LOANER_PANEL_RATE_BETWEEN_5_AND_11_MONTHS);
        LOANER_PANEL_RATE_WITHIN_5_MONTHS = prepayParameters.get(BizParameters.LOANER_PANEL_RATE_WITHIN_5_MONTHS);

        INSURANCE_MANAGEMENT_FEE_MORE_THAN_11_MONTHS = prepayParameters.get(BizParameters.INSURANCE_MANAGEMENT_FEE_MORE_THAN_11_MONTHS);
        INSURANCE_MANAGEMENT_FEE_BETWEEN_5_AND_11_MONTHS = prepayParameters.get(BizParameters.INSURANCE_MANAGEMENT_FEE_BETWEEN_5_AND_11_MONTHS);
        INSURANCE_MANAGEMENT_FEE_WITHIN_5_MONTHS = prepayParameters.get(BizParameters.INSURANCE_MANAGEMENT_FEE_WITHIN_5_MONTHS);

        P2P_PREPAY_FEE_MORE_THAN_11_MONTHS = prepayParameters.get(BizParameters.P2P_PREPAY_FEE_MORE_THAN_11_MONTHS);
        P2P_PREPAY_FEE_BETWEEN_5_AND_11_MONTHS = prepayParameters.get(BizParameters.P2P_PREPAY_FEE_BETWEEN_5_AND_11_MONTHS);
        P2P_PREPAY_FEE_WITHIN_5_MONTHS = prepayParameters.get(BizParameters.P2P_PREPAY_FEE_WITHIN_5_MONTHS);
    }

    private Money getRemainingPrincipal(Loan loan, RepaymentPlan startPlan) {
        Money result = Money.ZERO_YUAN;
        for (RepaymentPlan repaymentPlan : loan.getRepaymentPlans()) {
            if (repaymentPlan.planNumber >= startPlan.planNumber) {
                result = result.add(repaymentPlan.getPrincipal());
            }
        }
        return result;
    }

    private BigDecimal daysBetween(Date from, Date to) {
        return new BigDecimal(Days.daysBetween(new DateTime(startOfDay(from)), new DateTime(startOfDay(to))).getDays());
    }

    private BigDecimal getPenalRate(Loan loan) {
        DateTime startAt = new DateTime(loan.getStartAt());
        DateTime endAtAfter5MonthsPlusOneDay = startAt.plusMonths(5);
        DateTime endAtAfter11MonthsPlusOneDay = startAt.plusMonths(11);
        if (!isOnSameDayOfMonth(startAt, endAtAfter5MonthsPlusOneDay)) {
            endAtAfter5MonthsPlusOneDay = endAtAfter5MonthsPlusOneDay.plusDays(1);
        }
        if (!isOnSameDayOfMonth(startAt, endAtAfter11MonthsPlusOneDay)) {
            endAtAfter11MonthsPlusOneDay = endAtAfter11MonthsPlusOneDay.plusDays(1);
        }
        if (endAtAfter5MonthsPlusOneDay.isAfterNow()) {
            return PANEL_FEE_WITHIN_5_MONTHS;
        } else if (endAtAfter11MonthsPlusOneDay.isAfterNow()) {
            return PANEL_FEE_BETWEEN_5_AND_11_MONTHS;
        } else {
            return PANEL_FEE_MORE_THAN_11_MONTHS;
        }
    }

    private BigDecimal getRate(Loan loan, String rateType, Date date) {
        DateTime startAt = new DateTime(loan.getStartAt());
        DateTime startAtOf6st = startAt.plusMonths(5);
        DateTime startAtOf12st = startAt.plusMonths(11);
        DateTime dateTime = new DateTime(date);
        if (!isOnSameDayOfMonth(startAt, startAtOf6st)) {
            startAtOf6st = startAtOf6st.plusDays(1);
        }
        if (!isOnSameDayOfMonth(startAt, startAtOf12st)) {
            startAtOf12st = startAtOf12st.plusDays(1);
        }
        if (rateType.equalsIgnoreCase("PANEL_RATE")) {
            if (startAtOf6st.isAfter(dateTime)) {
                return LOANER_PANEL_RATE_WITHIN_5_MONTHS;
            } else if (startAtOf12st.isAfter(dateTime)) {
                return LOANER_PANEL_RATE_BETWEEN_5_AND_11_MONTHS;
            } else {
                return LOANER_PANEL_RATE_MORE_THAN_11_MONTHS;
            }
        } else if (rateType.equals("INSURANCE_MANAGEMENT_FEE_RATE")) {
            if (startAtOf12st.isAfter(dateTime)) {
                return INSURANCE_MANAGEMENT_FEE_WITHIN_5_MONTHS;
            } else if (startAtOf12st.isAfter(dateTime)) {
                return INSURANCE_MANAGEMENT_FEE_BETWEEN_5_AND_11_MONTHS;
            } else {
                return INSURANCE_MANAGEMENT_FEE_MORE_THAN_11_MONTHS;
            }
        } else {
            if (startAtOf12st.isAfter(dateTime)) {
                return P2P_PREPAY_FEE_WITHIN_5_MONTHS;
            } else if (startAtOf12st.isAfter(dateTime)) {
                return P2P_PREPAY_FEE_BETWEEN_5_AND_11_MONTHS;
            } else {
                return P2P_PREPAY_FEE_MORE_THAN_11_MONTHS;
            }
        }
    }

    private BigDecimal getPenalRate(Loan loan, Date date) {
        DateTime startAt = new DateTime(loan.getStartAt());
        DateTime endAtAfter5MonthsPlusOneDay = startAt.plusMonths(5);
        DateTime endAtAfter11MonthsPlusOneDay = startAt.plusMonths(11);
        if (!isOnSameDayOfMonth(startAt, endAtAfter5MonthsPlusOneDay)) {
            endAtAfter5MonthsPlusOneDay = endAtAfter5MonthsPlusOneDay.plusDays(1);
        }
        if (!isOnSameDayOfMonth(startAt, endAtAfter11MonthsPlusOneDay)) {
            endAtAfter11MonthsPlusOneDay = endAtAfter11MonthsPlusOneDay.plusDays(1);
        }
        if (endAtAfter5MonthsPlusOneDay.isAfter(new DateTime(date))) {
            return PANEL_FEE_WITHIN_5_MONTHS;
        } else if (endAtAfter11MonthsPlusOneDay.isAfter(new DateTime(date))) {
            return PANEL_FEE_BETWEEN_5_AND_11_MONTHS;
        } else {
            return PANEL_FEE_MORE_THAN_11_MONTHS;
        }
    }

    public Money getPrepayAmount() {
        return prepayAmount;
    }

    public Money getInsuranceFeeOfCurrentPlan() {
        return insuranceFeeOfCurrentPlan;
    }

    public Money getRemainingPrincipal() {
        return remainingPrincipal;
    }

    public Money getInterestOfCurrentPlan() {
        return interestOfCurrentPlan;
    }

    public Money getManagementFeeForLoaneeOfCurrentPlan() {
        return managementFeeForLoaneeOfCurrentPlan;
    }

    public Money getPenalValue() {
        return penalValue;
    }

    public Money getOverduePenaltyToPayOfCurrentPlan() {
        return overduePenaltyToPayOfCurrentPlan;
    }

    public Money getOverduePenaltyToPayOfCurrentPlan(Date date) {
        return overduePenaltyToPayOfCurrentPlan;
    }

    public Money getManagementFeeForLoanerOfCurrentPlan() {
        return managementFeeForLoanerOfCurrentPlan;
    }

    public boolean isPrepayWithCurrent() {
        return prepayWithCurrent;
    }

    public Money getInsuranceManagementFee() {
        return insuranceManagementFee;
    }
}
