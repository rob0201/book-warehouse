package com.lufax.common.domain;

public enum VerificationFeeStatus {
    PROCESSING,
    SUCCESS,
    FAILURE,
    UNKNOWN;
    public static  VerificationFeeStatus getVerificationFeeStatusByName(String status){
        VerificationFeeStatus[] verificationFeeStatuses=VerificationFeeStatus.values();
        for(VerificationFeeStatus verificationFeeStatus:verificationFeeStatuses)
            if(verificationFeeStatus.name().equalsIgnoreCase(status))
                return verificationFeeStatus;
        return UNKNOWN;
    }
}
