package com.lufax.common.domain.funds;

import java.util.ArrayList;
import java.util.List;

import static com.lufax.common.domain.funds.CMSCapitalStatementType.*;
import static java.util.Arrays.asList;

public enum CMSCapitalStatementDetailType {
    CUSTOMER_RECHARGE(RECHARGE, "充值代扣"),
    AUTO_RECHARGE(RECHARGE, "还款代扣"),
    OVERDUE_AUTO_RECHARGE(RECHARGE, "逾期代扣"),
    CUSTOMER_WITHDRAWAL(WITHDRAWAL, "取现代付"),
    GUARANTOR_WITHDRAWAL(WITHDRAWAL, "担保自动取现代付"),
    LOAN_GRANTING(WITHDRAWAL, "自动放款代付"),
    VERIFICATION_FEE(VERIFICATION, "验证费"),
    ANYEDAI_TRANSFER_FEE(RECHARGE, "手续费（安业贷）"),
    ANYEDAI_RECHARGE(RECHARGE, "还款（安业贷）"),
    ANYEDAI_WITHDRAWAL(WITHDRAWAL, "系统放款（安业贷）"),
    UNKNOWN(CMSCapitalStatementType.UNKNOWN,"unkonwn");

    private CMSCapitalStatementType type;

    private String desc;

    CMSCapitalStatementDetailType(CMSCapitalStatementType type, String desc) {
        this.type = type;
        this.desc = desc;
    }

    public String getDesc() {
        return desc;
    }


    public static List<CMSCapitalStatementDetailType> valuesOf(List<CMSCapitalStatementType> types) {
        List<CMSCapitalStatementDetailType> results = new ArrayList<CMSCapitalStatementDetailType>();
        for (CMSCapitalStatementDetailType detailType : values()) {
            if (types.contains(detailType.type))
                results.add(detailType);
        }
        return results;
    }

    public static List<CMSCapitalStatementDetailType> valuesOfRechargeAndWithdraw() {
        return valuesOf(asList(RECHARGE, WITHDRAWAL));
    }
    public static CMSCapitalStatementDetailType getCmsCapitalStatementDetailTypeByType(String type){
        CMSCapitalStatementDetailType[] cmsCapitalStatementDetailTypes=CMSCapitalStatementDetailType.values();
        for(CMSCapitalStatementDetailType cmsCapitalStatementDetailType:cmsCapitalStatementDetailTypes)
            if(cmsCapitalStatementDetailType.name().equalsIgnoreCase(type))
                return cmsCapitalStatementDetailType;
        return UNKNOWN;
    }
}
