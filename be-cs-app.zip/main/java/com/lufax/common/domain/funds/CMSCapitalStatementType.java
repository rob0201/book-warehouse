package com.lufax.common.domain.funds;

public enum CMSCapitalStatementType {
    WITHDRAWAL("取现"),
    RECHARGE("充值"),
    VERIFICATION("验证费"),
    UNKNOWN("unkonwn");

    private String value;

    CMSCapitalStatementType(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
    public static CMSCapitalStatementType getCmsCapitalStatementType(String type){
        CMSCapitalStatementType[] cmsCapitalStatementTypes=CMSCapitalStatementType.values();
        for(CMSCapitalStatementType cmsCapitalStatementType:cmsCapitalStatementTypes)
            if(cmsCapitalStatementType.name().equalsIgnoreCase(type))
                return cmsCapitalStatementType;
        return UNKNOWN;
    }
}
