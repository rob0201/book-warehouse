package com.lufax.common.domain.funds.repository;

import com.lufax.common.domain.funds.CMSCapitalStatement;
import com.lufax.common.domain.funds.CMSCapitalStatementDetailType;
import com.lufax.common.domain.repository.BaseRepository;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Repository
public class CmsCapitalStatementRepository extends BaseRepository<CMSCapitalStatement> {

    public static final String QUERY_BY_STATUS_OR_RESENT_AND_TYPE_AND_DATE_RANGE = "from CMSCapitalStatement s where " +
            "(s.status = :status or s.user <> s.originator) and s.initialTime between :startDate and :endDate " +
            "and s.detailType in (:detailTypes) and " +
            "s.createdAt = (select max(s2.createdAt) from CMSCapitalStatement s2 where s2.recordId = s.recordId and s2.statementType = s.statementType) " +
            "order by s.initialTime DESC";

    private List<String> transferCMSCapitalStatementDetailTypes(List<CMSCapitalStatementDetailType> types) {
        List<String> cmsCapitalStatementDetailTypes = new ArrayList<String>();
        for (CMSCapitalStatementDetailType cmsCapitalStatementDetailType : types)
            cmsCapitalStatementDetailTypes.add(cmsCapitalStatementDetailType.name());
        return cmsCapitalStatementDetailTypes;
    }

    @Override
    public void persist(CMSCapitalStatement cmsCapitalStatement) {
        cmsCapitalStatement.setUpdatedAt(new Date());
        super.persist(cmsCapitalStatement);
    }

    @Override
    public CMSCapitalStatement update(CMSCapitalStatement cmsCapitalStatement) {
        cmsCapitalStatement.setUpdatedAt(new Date());
        return super.update(cmsCapitalStatement);
    }
}
