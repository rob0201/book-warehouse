package com.lufax.common.domain.funds;

import static com.lufax.common.web.helper.ConstantsHelper.HANDLED_CMS_WITHDRAW_CODE;

public enum CMSCapitalStatementStatus {
    WAITING("处理中"),
    NEW("新建"),
    SUCCESS("成功"),
    FAILURE("失败"),
    UNKONWN("unkonwn");

    private String value;

    CMSCapitalStatementStatus(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    public static CMSCapitalStatementStatus valueOfCmsResult(String cmsResult) {
        return HANDLED_CMS_WITHDRAW_CODE.equals(cmsResult) ? CMSCapitalStatementStatus.SUCCESS : CMSCapitalStatementStatus.FAILURE;
    }
    public static  CMSCapitalStatementStatus getCmsCapitalStatementStatusByName(String name){
        CMSCapitalStatementStatus[] cmsCapitalStatementStatuses=CMSCapitalStatementStatus.values();
        for(CMSCapitalStatementStatus cmsCapitalStatementStatus:cmsCapitalStatementStatuses)
            if(cmsCapitalStatementStatus.name().equalsIgnoreCase(name))
                return cmsCapitalStatementStatus;
        return UNKONWN;
    }
}
