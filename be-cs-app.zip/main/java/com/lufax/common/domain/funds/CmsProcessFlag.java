package com.lufax.common.domain.funds;

public enum CmsProcessFlag {
    SUCCESS("1", "success"),
    FAILED("0", "failed");

    private String value;
    private String message;

    CmsProcessFlag(String value, String message) {
        this.value = value;
        this.message = message;
    }

    public String getValue() {
        return value;
    }

    public String getMessage() {
        return message;
    }
}

