package com.lufax.common.domain.funds.service;

public interface RechargeListener {

}
