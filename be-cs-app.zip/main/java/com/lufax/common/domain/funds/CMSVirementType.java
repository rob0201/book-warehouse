package com.lufax.common.domain.funds;

public enum CMSVirementType {
    TO_P2P("D", "P2PD", "收入"),
    TO_CMS("C", "P2PC", "支出"),
    VERIFY("C", "P2PC01", "验证费"),
    UNKONWN("unknown","unknown","unknown");

    private String code;
    private String businessCode;
    private String description;

    CMSVirementType(String code, String businessCode, String description) {
        this.code = code;
        this.businessCode = businessCode;
        this.description = description;
    }

    public String getCode() {
        return code;
    }

    public String getBusinessCode() {
        return businessCode;
    }

    public String getDescriptionForJob() {
        if(VERIFY.description.equals(description)){
            return TO_CMS.description;
        }
        return description;
    }
    public  static CMSVirementType getCmsVirementTypeByType(String type){
        CMSVirementType[] cmsVirementTypes=CMSVirementType.values();
        for(CMSVirementType cmsVirementType:cmsVirementTypes)
            if(cmsVirementType.name().equalsIgnoreCase(type))
                return  cmsVirementType;
        return UNKONWN;
    }

}
