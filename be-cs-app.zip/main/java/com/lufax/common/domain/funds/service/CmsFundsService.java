package com.lufax.common.domain.funds.service;

import com.lufax.common.domain.RechargeRecord;
import com.lufax.common.domain.User;
import com.lufax.common.domain.WithdrawRecord;
import com.lufax.common.domain.account.Account;
import com.lufax.common.domain.account.Money;
import com.lufax.common.domain.funds.CMSCapitalStatement;
import com.lufax.common.domain.funds.CMSCapitalStatementDetailType;
import com.lufax.common.domain.funds.CMSCapitalStatementType;
import com.lufax.common.domain.funds.CMSVirementType;
import com.lufax.common.domain.funds.repository.CmsCapitalStatementRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class CmsFundsService {
    @Autowired
    private CmsCapitalStatementRepository cmsCapitalStatementRepository;

    @Transactional
    public void applyToRecharge(User user, CMSCapitalStatementDetailType detailType, RechargeRecord rechargeRecord) {
        CMSCapitalStatement cmsCapitalStatement = new CMSCapitalStatement(user, rechargeRecord.id(), CMSCapitalStatementType.RECHARGE, detailType,
                CMSVirementType.TO_P2P, rechargeRecord.getAmount(), rechargeRecord.getRechargeFee(), rechargeRecord.getRechargeAt());
        cmsCapitalStatementRepository.persist(cmsCapitalStatement);
    }

    @Transactional
    public void applyToWithdraw(Account account, CMSCapitalStatementDetailType detailType, WithdrawRecord withdrawRecord, Money transferAmount, Money withdrawFee) {
        CMSCapitalStatement statement = new CMSCapitalStatement(account.getUser(), withdrawRecord.id(), CMSCapitalStatementType.WITHDRAWAL, detailType, CMSVirementType.TO_CMS,
                transferAmount, withdrawFee, withdrawRecord.getUpdatedAt());

        cmsCapitalStatementRepository.persist(statement);
    }

    @Transactional
    public void reApplyToWithdraw(User originator, CMSCapitalStatement cmsCapitalStatement) {
        cmsCapitalStatementRepository.persist(cmsCapitalStatement.resendBy(originator));
    }
}
