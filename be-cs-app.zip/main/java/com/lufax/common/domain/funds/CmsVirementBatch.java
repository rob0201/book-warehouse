package com.lufax.common.domain.funds;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

@Entity
@Table(name = "CMS_VIREMENT_BATCH")
public class CmsVirementBatch {
    @Id
    @Column(name = "BATCH_NO")
    private String batchNo;

    @Column(name = "ACCOUNT")
    private String account;

    @Column(name = "BATCHPERSON")
    private String batchPerson;

    @Column(name = "BATCHDATE")
    private Date batchDate;

    @Column(name = "PAYTYPE")
    private String payType;

    @Column(name = "CURRENCY")
    private String currency;

    @Column(name = "PAYKIND")
    private String payKind;

    @Column(name = "CMS_STATUS")
    private String cmsStatus;

    @Column(name = "BRANCHID")
    private String branchid;

    @Column(name = "CREATED_BY")
    private String createdBy;

    @Column(name = "UPDATED_BY")
    private String updatedBy;

    @Column(name = "CREATED_DATE")
    private Date createdDate;

    @Column(name = "UPDATED_DATE")
    private Date updatedDate;

    public CmsVirementBatch() {
    }

    public void setBatchPerson(String batchPerson) {
        this.batchPerson = batchPerson;
    }

    public void setBatchDate(Date batchDate) {
        this.batchDate = batchDate;
    }

    public void setPayType(String payType) {
        this.payType = payType;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public void setPayKind(String payKind) {
        this.payKind = payKind;
    }

    public void setCmsStatus(String cmsStatus) {
        this.cmsStatus = cmsStatus;
    }

    public void setBranchid(String branchid) {
        this.branchid = branchid;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    public void setBatchNo(String batchNo) {
        this.batchNo = batchNo;
    }

    public String getBatchNo() {
        return batchNo;
    }

    public void setAccount(String account) {
        this.account = account;
    }
}
