package com.lufax.common.domain.funds;

import java.util.Date;

import javax.persistence.*;

import com.lufax.common.domain.User;
import com.lufax.common.domain.account.Money;
import com.lufax.common.utils.Encryption;
import com.lufax.common.web.helper.ConstantsHelper;

@Entity
@Table(name = "CMS_CAPITAL_STATEMENTS")
public class CMSCapitalStatement {
    public static final String SIGNATURE_KEY = "www.pingan.com/cms";

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_CMS_CAPITAL_STATEMENTS")
    @SequenceGenerator(name = "SEQ_CMS_CAPITAL_STATEMENTS", sequenceName = "SEQ_CMS_CAPITAL_STATEMENTS", allocationSize = 1)
    private long id;

    //    @Enumerated(EnumType.STRING)
    @Column(name = "STATUS")
    private String status;

    //    @Enumerated(EnumType.STRING)
    @Column(name = "STATEMENT_TYPE")
    private String statementType;

    //    @Enumerated(EnumType.STRING)
    @Column(name = "DETAIL_TYPE")
    private String detailType;

    @Column(name = "BANK_ID")
    private String bankId;

    @Column(name = "RECORD_ID")
    private long recordId;

    @Column(name = "BANK_ACCOUNT_NO")
    private String bankAccountNo;

    @Column(name = "BANK_ACCOUNT_NAME")
    private String bankAccountName;

    @Embedded
    @AttributeOverrides({@AttributeOverride(name = "amount", column = @Column(name = "TRANSFER_AMOUNT"))})
    private Money transferAmount;

    @Embedded
    @AttributeOverrides({@AttributeOverride(name = "amount", column = @Column(name = "COMMISSION_FEE"))})
    private Money commissionFee;

    @Column(name = "CREATED_AT")
    private Date createdAt;

    @Column(name = "UPDATED_AT")
    private Date updatedAt;

    @Column(name = "INITIAL_TIME")
    private Date initialTime;

    //    @Enumerated(EnumType.STRING)
    @Column(name = "VIREMENT_TYPE")
    private String virementType;

    @Column(name = "REMARK")
    private String remark;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "USER_ID")
    private User user;

    @Column(name = "MANUAL_VERIFIED")
    private String manualVerified;

//     optional = true, cascade = CascadeType.MERGE

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ORIGINATOR_ID")
    private User originator;

    @Column(name = "RESENT")
    private Boolean resent;

    @Version
    private long version;


    @Transient
    private Boolean isValidate = false;

    @Transient
    private String reason;

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public Boolean getValidate() {
        return isValidate;
    }

    public void setValidate(Boolean validate) {
        isValidate = validate;
    }

    public CMSCapitalStatement() {
    }

    public CMSCapitalStatement(User user, User originator,
                               long recordId, CMSCapitalStatementType statementType, CMSCapitalStatementDetailType detailType, CMSVirementType virementType, CMSCapitalStatementStatus status,
                               Money transferAmount, Money commissionFee, String bankId, String bankAccountNo,
                               Date initialTime, Date createdAt) {
        this.status = (status != null) ? status.name() : null;
        this.statementType = (statementType != null) ? statementType.name() : null;
        this.detailType = (statementType != null) ? detailType.name() : null;
        this.initialTime = initialTime;
        this.bankId = bankId;
        this.recordId = recordId;
        this.bankAccountNo = bankAccountNo;
        this.bankAccountName = user.getName();
        this.transferAmount = transferAmount;
        this.commissionFee = commissionFee;
        this.createdAt = createdAt;
        this.updatedAt = createdAt;
        this.virementType = (virementType != null) ? virementType.name() : null;
        this.user = user;
        this.originator = originator;
        this.resent = false;
    }

    public CMSCapitalStatement(User user, long recordId,
                               CMSCapitalStatementType statementType, CMSCapitalStatementDetailType detailType, CMSVirementType virementType,
                               Money transferAmount, Money commissionFee,
                               Date initialTime) {
        this(user, user, recordId, statementType, detailType, virementType, CMSCapitalStatementStatus.NEW, transferAmount, commissionFee, user.getBankIdentity().getSubBankCode(), user.getBankIdentity().getBankAccount(), initialTime, new Date());
    }

    public CMSCapitalStatement(CMSCapitalStatement cmsCapitalStatement) {
        this(cmsCapitalStatement.getUser(), cmsCapitalStatement.getUser(),
                cmsCapitalStatement.getRecordId(), cmsCapitalStatement.getStatementType(), cmsCapitalStatement.getDetailType(), cmsCapitalStatement.getVirementType(), CMSCapitalStatementStatus.NEW,
                cmsCapitalStatement.getTransferAmount(), cmsCapitalStatement.getCommissionFee(),
                cmsCapitalStatement.getUser().getBankIdentity().getSubBankCode(), cmsCapitalStatement.getUser().getBankIdentity().getBankAccount(),
                cmsCapitalStatement.getInitialTime(), new Date());
    }

    public long id() {
        return this.id;
    }

    public String getBankId() {
        return bankId;
    }

    public String getBankAccountNo() {
        return bankAccountNo;
    }

    public String getBankAccountName() {
        return bankAccountName;
    }

    public Money getTransferAmount() {
        return transferAmount;
    }

    public Money getCommissionFee() {
        return commissionFee;
    }

    public void setCommissionFee(Money commissionFee) {
        this.commissionFee = commissionFee;
    }

    public long getRecordId() {
        return recordId;
    }

    public Date getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Date updatedAt) {
        this.updatedAt = updatedAt;
    }

    public CMSVirementType getVirementType() {
        return CMSVirementType.getCmsVirementTypeByType(virementType);
    }

    public String getSignature() {
        return Encryption.MD5.encryptAsHex(this.bankAccountNo + this.bankAccountName + this.transferAmount + SIGNATURE_KEY, ConstantsHelper.DEFAULT_CHARSET);
    }

    public CMSCapitalStatementStatus getStatus() {
        return CMSCapitalStatementStatus.getCmsCapitalStatementStatusByName(status);
    }

    public CMSCapitalStatementType getStatementType() {
        return CMSCapitalStatementType.getCmsCapitalStatementType(statementType);
    }

    public void setStatus(CMSCapitalStatementStatus status) {
        this.status = (status != null) ? status.name() : null;
    }

    public String getRemark() {
        return remark;
    }

    public boolean isFailed() {
        return CMSCapitalStatementStatus.FAILURE.equals(CMSCapitalStatementStatus.getCmsCapitalStatementStatusByName(status));
    }

    public boolean isSuccessful() {
        return CMSCapitalStatementStatus.SUCCESS.equals(CMSCapitalStatementStatus.getCmsCapitalStatementStatusByName(status));
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public User getUser() {
        return this.user;
    }


    public boolean isWithdraw() {
        return CMSCapitalStatementType.getCmsCapitalStatementType(statementType).equals(CMSCapitalStatementType.WITHDRAWAL);
    }

    public boolean isRecharge() {
        return CMSCapitalStatementType.getCmsCapitalStatementType(statementType).equals(CMSCapitalStatementType.RECHARGE);
    }

    public boolean isVerification() {
        return CMSCapitalStatementType.getCmsCapitalStatementType(statementType).equals(CMSCapitalStatementType.VERIFICATION);
    }

    public boolean isWaiting() {
        return CMSCapitalStatementStatus.WAITING == CMSCapitalStatementStatus.getCmsCapitalStatementStatusByName(status);
    }

    public User getOriginator() {
        return originator;
    }

    public CMSCapitalStatementDetailType getDetailType() {
        return CMSCapitalStatementDetailType.getCmsCapitalStatementDetailTypeByType(detailType);
    }

    public Date getInitialTime() {
        return initialTime;
    }

    public CMSCapitalStatement resendBy(User originator) {
        resent = false;

        CMSCapitalStatement cmsCapitalStatement = new CMSCapitalStatement(this);
        cmsCapitalStatement.originator = originator;
        return cmsCapitalStatement;
    }

    public void setResent(boolean resent) {
        this.resent = resent;
    }

    public boolean isResent() {
        return resent;
    }

    public boolean ableToResent() {
        return !isResent() && isFailed();
    }

    public void setRecordId(long recordId) {
        this.recordId = recordId;
    }

    public String getManualVerified() {
        return manualVerified;
    }

    public void setManualVerified(String manualVerified) {
        this.manualVerified = manualVerified;
    }

}
