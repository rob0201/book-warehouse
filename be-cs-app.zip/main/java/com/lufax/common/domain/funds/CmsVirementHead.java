package com.lufax.common.domain.funds;

import com.lufax.common.domain.account.Money;

import javax.persistence.*;
import java.util.Date;

import static com.lufax.common.web.helper.ConstantsHelper.CMS_USER_NAME;

@Entity
@Table(name = "CMS_VIREMENT_HEAD")
public class CmsVirementHead {
    @Id
    @Column(name = "BIZ_DRAW_SEQUENCENO")
    private String bizDrawSequenceNo;

    @Column(name = "SUM_BILLNO")
    private long countOfStatements;

    @Embedded
    @AttributeOverrides({@AttributeOverride(name = "amount", column = @Column(name = "SUM_AMOUNT"))})
    private Money totalAmount;

    @Column(name = "CREATED_BY")
    private String createdBy;

    @Column(name = "CREATED_DATE")
    private Date createdDate;

    @Column(name = "UPDATED_BY")
    private String updatedBy;

    @Column(name = "UPDATED_DATE")
    private Date updatedDate;

    public CmsVirementHead() {
    }

    public CmsVirementHead(String bizDrawSequenceNo, long countOfStatements, Money totalAmount) {
        Date now = new Date();
        this.bizDrawSequenceNo = bizDrawSequenceNo;
        this.countOfStatements = countOfStatements;
        this.totalAmount = totalAmount;
        createdDate = now;
        updatedDate = now;
        createdBy = CMS_USER_NAME;
        updatedBy = CMS_USER_NAME;
    }

    public String getBizDrawSequenceNo() {
        return bizDrawSequenceNo;
    }

    public long getCountOfStatements() {
        return countOfStatements;
    }

    public Money getTotalAmount() {
        return totalAmount;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public Date getUpdatedDate() {
        return updatedDate;
    }


}
