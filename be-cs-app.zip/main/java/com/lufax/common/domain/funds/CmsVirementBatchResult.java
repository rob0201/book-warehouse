package com.lufax.common.domain.funds;

import javax.persistence.*;
import java.util.Date;

import static com.lufax.common.web.helper.ConstantsHelper.CMS_USER_NAME;

@Entity
@Table(name = "CMS_VIREMENT_BATCH_RESULT")
public class CmsVirementBatchResult {
    @Id
    @Column(name = "BATCH_SEQUENCENO")
    private String batchSequenceNo;

    @Column(name = "BATCH_NO")
    private String batchNo;

    @Column(name = "PROCESS_FLAG")
    private String processFlag;

    @Column(name = "MESSAGE")
    private String message;

    @Column(name = "CREATED_BY")
    private String createdBy;

    @Column(name = "UPDATED_BY")
    private String updatedBy;

    @Column(name = "CREATED_DATE")
    private Date createdDate;

    @Column(name = "UPDATED_DATE")
    private Date updatedDate;

    public CmsVirementBatchResult() {
    }

    public CmsVirementBatchResult(String batchSequenceNo, String batchNo, CmsProcessFlag processFlag) {
        this.batchSequenceNo = batchSequenceNo;
        this.batchNo = batchNo;
        this.processFlag = processFlag.getValue();
        this.message = processFlag.getMessage();

        Date now = new Date();
        this.createdBy = CMS_USER_NAME;
        this.createdDate = now;
        this.updatedBy = CMS_USER_NAME;
        this.updatedDate = now;
    }

    public String getProcessFlag() {
        return processFlag;
    }

    public String getBatchSequenceNo() {
        return batchSequenceNo;
    }
}
