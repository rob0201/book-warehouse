package com.lufax.common.domain.funds;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "cms_virement_batch_detail")
public class CMSVirementBatchDetail {
    @Id
    @Column(name = "business_no")
    private String businessNo;

    @Column(name = "batch_no")
    private String batchNo;

    //only 'bat-0007' is handled by CMS completed status
//    @Enumerated(EnumType.STRING)
    @Column(name = "cms_status")
    private String cmsStatus;

   //only 'PBB00' is success code
    @Column(name = "cms_result")
    private String cmsResult;

    @Column(name = "bank_result_code")
    private String bankResultCode;

    @Column(name = "bank_result_msg")
    private String bankResultMsg;

    @Column(name = "created_by")
    private String createdBy;

    @Column(name = "created_date")
    private Date createdAt;

    @Column(name = "updated_by")
    private String updatedBy;

    @Column(name = "updated_date")
    private Date updatedAt;

    public CMSVirementBatchDetail() {
    }

    public String getBusinessNo() {
        return businessNo;
    }

    public String getBatchNo() {
        return batchNo;
    }

    public CMSCapitalStatementStatus getCmsStatementStatus() {
        return CMSCapitalStatementStatus.valueOfCmsResult(cmsResult);
    }

    public String getBankResultMsg() {
        return bankResultMsg;
    }

    public void setBusinessNo(String businessNo) {
        this.businessNo = businessNo;
    }

    public void setCmsStatus(String cmsStatus) {
        this.cmsStatus = cmsStatus;
    }

    public void setCmsResult(String cmsResult) {
        this.cmsResult = cmsResult;
    }

    public void setBankResultMsg(String bankResultMsg) {
        this.bankResultMsg = bankResultMsg;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public void setUpdatedAt(Date updatedAt) {
        this.updatedAt = updatedAt;
    }

    public void setBatchNo(String batchNo) {
        this.batchNo = batchNo;
    }

    public String getCmsResult() {
        return cmsResult;
    }
}
