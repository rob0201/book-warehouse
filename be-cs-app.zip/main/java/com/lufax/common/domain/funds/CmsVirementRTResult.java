package com.lufax.common.domain.funds;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

import static com.lufax.common.web.helper.ConstantsHelper.CMS_USER_NAME;

@Entity
@Table(name = "CMS_VIREMENT_RT_RESULT")
public class CmsVirementRTResult {
    @Id
    @Column(name = "RETURNTICKET_SEQUENCENO")
    private String returnTicketSequenceNo;

    @Column(name = "CMS_RETURNTICKETNO")
    private String cmsReturnTicketNo;

    @Column(name = "RETURNTICKET_STATUS")
    private String returnTickeStatus;

    @Column(name = "RETURNTICKET_MESSAGE")
    private String returnTicketMessage;

    @Column(name = "CREATED_BY")
    private String createdBy;

    @Column(name = "CREATED_DATE")
    private Date createdDate;

    @Column(name = "UPDATED_BY")
    private String updatedBy;

    @Column(name = "UPDATED_DATE")
    private Date updatedDate;

    public CmsVirementRTResult(){
    }

    public CmsVirementRTResult(String returnTicketSequenceNo, String cmsReturnTicketNo) {
        this.returnTicketSequenceNo = returnTicketSequenceNo;
        this.cmsReturnTicketNo = cmsReturnTicketNo;
        this.returnTickeStatus = "1";
        this.returnTicketMessage = "sucess";
        this.createdBy = CMS_USER_NAME;
        this.updatedBy = CMS_USER_NAME;
        Date now = new Date();
        this.createdDate = now;
        this.updatedDate = now;
    }

    public String getReturnTicketSequenceNo() {
        return this.returnTicketSequenceNo;
    }
}
