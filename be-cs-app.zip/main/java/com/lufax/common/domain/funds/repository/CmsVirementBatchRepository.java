package com.lufax.common.domain.funds.repository;

import com.lufax.common.domain.funds.CmsVirementBatch;
import com.lufax.common.domain.repository.BaseRepository;
import org.springframework.stereotype.Repository;

import java.util.List;


@Repository
public class CmsVirementBatchRepository extends BaseRepository<CmsVirementBatch> {

    public List<CmsVirementBatch> findAllUnhandledBatches(int limit) {
        String query = "select b from CmsVirementBatch as b where b.batchNo not in (select batchNo from CmsVirementBatchResult)";
        return entityManager.createQuery(query, CmsVirementBatch.class).setMaxResults(limit).getResultList();
    }
}
