package com.lufax.common.domain.funds;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "TERROR")
public class CmsTransactionError {

    @Id
    @Column(name = "ERRORID")
    private String errorId;

    @Column(name = "DESCRIPTION")
    private String description;

    @Column(name = "CREATED_BY")
    private String createdBy;

    @Column(name = "CREATED_DATE")
    private Date createdDate;

    @Column(name = "UPDATED_BY")
    private String updatedBy;

    @Column(name = "UPDATED_DATE")
    private Date updatedDate;

    public CmsTransactionError() {
    }

    public CmsTransactionError(String errorId, String description, String createdBy, String updatedBy) {
        this.errorId = errorId;
        this.description = description;
        this.createdBy = createdBy;
        this.createdDate = new Date();
        this.updatedBy = updatedBy;
        this.updatedDate = createdDate;
    }

    public String getErrorId() {
        return errorId;
    }

    public String getDescription() {
        return description;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public Date getUpdatedDate() {
        return updatedDate;
    }
}
