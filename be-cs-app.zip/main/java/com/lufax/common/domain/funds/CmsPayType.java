package com.lufax.common.domain.funds;

public enum CmsPayType {
    PERSONAL("0"),
    COMPANY("1"),
    UNKNOWN("-1");

    private String value;

    CmsPayType(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
    public  static CmsPayType getCmsPayTypeByType(String type){
        CmsPayType[]  cmsPayTypes=CmsPayType.values();
        for(CmsPayType cmsPayType:cmsPayTypes)
            if(cmsPayType.name().equalsIgnoreCase(type))
                return cmsPayType;
        return UNKNOWN;
    }
}
