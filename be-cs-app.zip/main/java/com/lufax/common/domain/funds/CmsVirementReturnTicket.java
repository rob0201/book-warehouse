package com.lufax.common.domain.funds;


import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "CMS_VIREMENT_RETURNTICKET")
public class CmsVirementReturnTicket {
    @Id
    @Column(name = "RETURNTICKET_SEQUENCENO")
    private String returnTicketSequenceNo;

    @Column(name = "CMS_RETURNTICKETNO")
    private String cmsReturnTicketNo;

    @Column(name = "BUSINESS_NO")
    private String businessNo;

    @Column(name = "TOBANK_NO")
    private String toBankNo;

    @Column(name = "VOUCHER_DATE")
    private Date voucherDate;

    @Column(name = "JOURNAL_DATE")
    private Date journalDate;

    @Column(name = "CMS_RETURN_USER")
    private String cmsReturnUser;

    @Column(name = "CMS_RETURN_DATE")
    private Date cmsReturnDate;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ERRORID")
    private CmsTransactionError cmsTransactionError;

    @Column(name = "BANK_RESULT_CODE")
    private String bankResultCode;

    @Column(name = "BANK_RESULT_MSG")
    private String bankResultMsg;

    @Column(name = "CREATED_BY")
    private String createdBy;

    @Column(name = "CREATED_DATE")
    private Date createdDate;

    @Column(name = "UPDATED_BY")
    private String updatedBy;

    @Column(name = "UPDATED_DATE")
    private Date updatedDate;

    public CmsVirementReturnTicket() {
    }

    //only used in Test
    public CmsVirementReturnTicket(String businessNo, String toBankNo, Date voucherDate, Date journalDate, String cmsReturnUser, Date cmsReturnDate, String bankResultCode, String bankResultMsg, String createdBy, String updatedBy, Date updatedDate, CmsTransactionError cmsTransactionError) {
        this.businessNo = businessNo;
        this.toBankNo = toBankNo;
        this.voucherDate = voucherDate;
        this.journalDate = journalDate;
        this.cmsReturnUser = cmsReturnUser;
        this.cmsReturnDate = cmsReturnDate;
        this.bankResultCode = bankResultCode;
        this.bankResultMsg = bankResultMsg;
        this.createdBy = createdBy;
        this.cmsTransactionError = cmsTransactionError;
        this.createdDate = new Date();
        this.updatedBy = updatedBy;
        this.updatedDate = updatedDate;
        this.returnTicketSequenceNo=businessNo;
        this.cmsReturnTicketNo=businessNo;
    }

    public String getBusinessNo() {
        return businessNo;
    }

    public Date getVoucherDate() {
        return voucherDate;
    }

    public CmsTransactionError getCmsTransactionError() {
        return cmsTransactionError;
    }

    public String getReturnTicketSequenceNo() {
        return returnTicketSequenceNo;
    }

    public String getCmsReturnTicketNo() {
        return cmsReturnTicketNo;
    }
}
