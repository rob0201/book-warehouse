package com.lufax.common.domain;

public enum UserStatus {
    AUTHENTICATED("已授权"),
    NOT_AUTHENTICATED("未授权"),
    DELETED("已删除"),
    INVALIDATION("注销用户"),
    UNKNOWN("unknown");



    private String value;

    UserStatus(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    public static UserStatus toP2PStatus(String nameAuthentication) {
        //0 未认证， 1 投资人, 2 借贷人, 3 公安部认证
        if("1".equals(nameAuthentication) || "2".equals(nameAuthentication) || "3".equals(nameAuthentication)){
            return  AUTHENTICATED;
        }
        return NOT_AUTHENTICATED;
    }
    public static UserStatus getUserStatusByName(String name){
        UserStatus[] userStatuses=UserStatus.values();
        for(UserStatus userStatus:userStatuses)
            if(userStatus.name().equalsIgnoreCase(name))
                return userStatus;
        return UNKNOWN;
    }
}
