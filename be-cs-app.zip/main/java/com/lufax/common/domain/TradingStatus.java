package com.lufax.common.domain;

import java.util.ArrayList;
import java.util.List;

public enum TradingStatus {
	SIGNED(Type.ONGOING, "已签约"),
    OVERDUE(Type.ONGOING, "逾期"),
    COMPENSATE(Type.ONGOING, "代偿中"),
    PAID(Type.SETTLED, "完成"),
    PREPAID(Type.SETTLED, "已提前还款"),
    TRANSFER(Type.SETTLED, "已转让"),
    COMP_DONE(Type.SETTLED, "代偿完成"),
    UNKNOWN(Type.UNKOWN, "unknown");

    private Type type;
    private String value;

    TradingStatus(Type type, String value) {
        this.type = type;
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    public boolean isSettled() {
        return type.equals(Type.SETTLED);
    }

    public Type getType() {
        return type;
    }

    public static TradingStatus getTradingStatusByName(String status) {
        TradingStatus[] tradingStatuses = TradingStatus.values();
        for (TradingStatus tradingStatus : tradingStatuses)
            if (tradingStatus.name().equalsIgnoreCase(status))
                return tradingStatus;
        return UNKNOWN;
    }

    public static enum Type {
        ONGOING,
        SETTLED,
        UNKOWN;

        public List<TradingStatus> getStatuses() {
            List<TradingStatus> result = new ArrayList<TradingStatus>();
            for (TradingStatus status : TradingStatus.values()) {
                if (this.equals(status.type)) {
                    result.add(status);
                }
            }
            return result;
        }
        
        public List<String> getStatusNames() {
            List<String> result = new ArrayList<String>();
            for (TradingStatus status : TradingStatus.values()) {
                if (this.equals(status.type)) {
                    result.add(status.name());
                }
            }
            return result;
        }
        
        

        public List<String> getTradingStatuses() {
            List<TradingStatus> tradingStatuses = getStatuses();
            if (tradingStatuses == null)
                return null;
            List<String> statuses = new ArrayList<String>();
            for (TradingStatus tradingStatus : tradingStatuses)
                statuses.add(tradingStatus.name());
            return statuses;
        }
    }
}
