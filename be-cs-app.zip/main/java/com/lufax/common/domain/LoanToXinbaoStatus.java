package com.lufax.common.domain;

import com.lufax.common.utils.XinbaoXMLFieldHelper;

public enum LoanToXinbaoStatus {
    RPY_SUCCESS,
    RPY_FAILURE,
    DETAIL_SUCCESS,
    DETAIL_FAILURE,
    NEED_RESEND,
    UNKNOWN;

    public static LoanToXinbaoStatus processFlagToRpy(String status) {
        if (XinbaoXMLFieldHelper.FROM_XINBAO_SUCCESS_FLAG.equals(status))
            return RPY_SUCCESS;
        return RPY_FAILURE;
    }

    public static LoanToXinbaoStatus processFlagToDetail(String status) {
        if (XinbaoXMLFieldHelper.FROM_XINBAO_SUCCESS_FLAG.equals(status))
            return DETAIL_SUCCESS;
        return DETAIL_FAILURE;
    }
    public static LoanToXinbaoStatus getLoanToXinbaoStatusByName(String status){
        LoanToXinbaoStatus[] loanToXinbaoStatuses=LoanToXinbaoStatus.values();
        for(LoanToXinbaoStatus loanToXinbaoStatus:loanToXinbaoStatuses)
            if(loanToXinbaoStatus.name().equalsIgnoreCase(status))
                return loanToXinbaoStatus;
        return UNKNOWN;
    }
}
