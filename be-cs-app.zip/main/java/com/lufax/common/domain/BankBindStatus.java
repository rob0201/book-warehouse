package com.lufax.common.domain;

public enum BankBindStatus {
    SUCCESS,
    FAIL,
    IN_AUTHENTICATE,
    UNKONWN;
    public static BankBindStatus getBankBindStatusByName(String status){
        BankBindStatus[] bankBindStatuses=BankBindStatus.values();
        for(BankBindStatus bankBindStatus:bankBindStatuses)
            if(bankBindStatus.name().equalsIgnoreCase(status))
                return bankBindStatus;
        return UNKONWN;
    }

     public static BankBindStatus getBankBindStatusByOrdinal(int ordinal){
        BankBindStatus[] bankBindStatuses=BankBindStatus.values();
        for(BankBindStatus bankBindStatus:bankBindStatuses)
            if(bankBindStatus.ordinal()==ordinal)
                return bankBindStatus;
        return UNKONWN;
    }
}
