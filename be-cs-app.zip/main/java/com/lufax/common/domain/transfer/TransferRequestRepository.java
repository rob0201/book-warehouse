package com.lufax.common.domain.transfer;

import com.lufax.common.domain.product.TransferRequest;
import com.lufax.common.domain.repository.BaseRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class TransferRequestRepository extends BaseRepository<TransferRequest> {

    public List<TransferRequest> findByInvestmentIdWithData(long investmentId) {
        return entityManager.createQuery("select t from TransferRequest t " +
                "left join fetch t.transferRequestData " +
                "where t.investment.id = :investmentId " +
                "order by t.createdAt desc", TransferRequest.class)
                .setParameter("investmentId", investmentId)
                .getResultList();
    }

}
