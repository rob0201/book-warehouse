package com.lufax.common.domain;

public enum OriginSystem {
    CMS("资金管理平台"),
    UNKNOWN("unknown");

    private String value;

    OriginSystem(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
    public static OriginSystem getOriginSystemByName(String name){
        OriginSystem[] originSystems=OriginSystem.values();
        for(OriginSystem originSystem:originSystems)
            if(originSystem.name().equalsIgnoreCase(name))
                return originSystem;
        return UNKNOWN;
    }
}
