package com.lufax.common.domain;

import com.lufax.common.domain.account.Money;

import javax.persistence.*;
import java.util.Date;

import static com.lufax.common.domain.account.Money.ZERO_YUAN;

@Entity
@Table(name = "RECHARGE_RECORDS")
public class RechargeRecord {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_RECHARGE_RECORDS")
    @SequenceGenerator(name = "SEQ_RECHARGE_RECORDS", sequenceName = "SEQ_RECHARGE_RECORDS", allocationSize = 1)
    private long id;

    //    @Enumerated(EnumType.STRING)
    @Column(name = "RECHARGE_TYPE")
    private String rechargeType;

    @Column(name = "FOREIGN_TRADE_NO")
    private String foreignTradeNo;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "USER_ID")
    private User user;

    @Column(name = "BATCH_NO")
    private String batchNo;

    @AttributeOverrides({@AttributeOverride(name = "amount", column = @Column(name = "AMOUNT"))})
    private Money amount;

    @AttributeOverrides({@AttributeOverride(name = "amount", column = @Column(name = "RECHARGE_FEE"))})
    private Money rechargeFee;

    //    @Enumerated(EnumType.STRING)
    @Column(name = "RECHARGE_STATUS")
    private String rechargeStatus;

    @Column(name = "TRADE_TIME")
    private Date tradeTime;

    @Column(name = "RECHARGE_AT")
    private Date rechargeAt;

    @Column(name = "UPDATED_AT")
    private Date updatedAt;

    @Column(name = "TRADE_NO")
    private String tradeNo;

    @AttributeOverrides({@AttributeOverride(name = "amount", column = @Column(name = "NET_AMOUNT"))})
    private Money netAmount;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ERROR_DESC_ID")
    private ErrorDesc errorDescription;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "REPAYMENT_PLAN_ID", nullable = true)
    private RepaymentPlan repaymentPlan;

    @Column(name = "REMARK")
    private String remark;
    
    @Version
    private long version;
    
    public RechargeRecord(){
    	
    }

    public RechargeRecord(User user, Money amount, RechargeType rechargeType, String tradeNo, RepaymentPlan repaymentPlan, Date date) {
        this(user, amount, rechargeType, date);
        this.tradeNo = tradeNo;
        this.repaymentPlan = repaymentPlan;
    }

    public RechargeRecord(User user, Money amount, RechargeType rechargeType, Date date) {
        this.user = user;
        this.amount = amount;
        this.rechargeType = rechargeType.name();
        this.rechargeFee = rechargeType.fee(amount, ZERO_YUAN);
        this.rechargeStatus = RechargeStatus.NEW.name();
        this.rechargeAt = date;
        this.updatedAt = this.rechargeAt;
        this.netAmount = ZERO_YUAN;
    }

    public RechargeRecord(User user, Money amount, RechargeType rechargeType, String tradeNo, RepaymentPlan repaymentPlan, Date date, RechargeStatus rechargeStatus) {
        this(user, amount, rechargeType, date, rechargeStatus);
        this.tradeNo = tradeNo;
        this.repaymentPlan = repaymentPlan;
    }

    public RechargeRecord(User user, Money amount, RechargeType rechargeType, Date date, RechargeStatus rechargeStatus) {
        this.user = user;
        this.amount = amount;
        this.rechargeType = rechargeType.name();
        this.rechargeFee = rechargeType.fee(amount, ZERO_YUAN);
        this.rechargeStatus = rechargeStatus.name();
        this.rechargeAt = date;
        this.updatedAt = this.rechargeAt;
        this.netAmount = ZERO_YUAN;
    }

    public RechargeRecord(User user, Money amount, RechargeType rechargeType, String tradeNo, RepaymentPlan repaymentPlan, Date date, RechargeStatus rechargeStatus, String rechargeRecordBatchNo) {
        this(user, amount, rechargeType, date, rechargeStatus, rechargeRecordBatchNo);
        this.tradeNo = tradeNo;
        this.repaymentPlan = repaymentPlan;
    }

    public RechargeRecord(User user, Money amount, RechargeType rechargeType, Date date, RechargeStatus rechargeStatus, String rechargeRecordBatchNo) {
        this.user = user;
        this.amount = amount;
        this.rechargeType = rechargeType.name();
        this.rechargeFee = rechargeType.fee(amount, ZERO_YUAN);
        this.rechargeStatus = rechargeStatus.name();
        this.rechargeAt = date;
        this.updatedAt = this.rechargeAt;
        this.netAmount = ZERO_YUAN;
        this.batchNo = rechargeRecordBatchNo;
    }

    public RechargeRecord(User user, Money amount, Money rechargeFeeThreshold, RechargeType rechargeType, String tradeNo, RepaymentPlan repaymentPlan, Date date, RechargeStatus rechargeStatus, String rechargeRecordBatchNo) {
        this(user, amount, rechargeFeeThreshold, rechargeType, date, rechargeStatus, rechargeRecordBatchNo);
        this.tradeNo = tradeNo;
        this.repaymentPlan = repaymentPlan;
    }

    public RechargeRecord(User user, Money amount, Money rechargeFeeThreshold, RechargeType rechargeType, Date date, RechargeStatus rechargeStatus, String rechargeRecordBatchNo) {
        this.user = user;
        this.amount = amount;
        this.rechargeType = rechargeType.name();
        this.rechargeFee = rechargeType.fee(amount, rechargeFeeThreshold);
        this.rechargeStatus = rechargeStatus.name();
        this.rechargeAt = date;
        this.updatedAt = this.rechargeAt;
        this.netAmount = ZERO_YUAN;
        this.batchNo = rechargeRecordBatchNo;
    }

    public RechargeRecord(User user, Money amount, Money rechargeFeeThreshold, RechargeType rechargeType, String tradeNo, RepaymentPlan repaymentPlan, Date date, RechargeStatus rechargeStatus) {
        this(user, amount, rechargeFeeThreshold, rechargeType, date, rechargeStatus);
        this.tradeNo = tradeNo;
        this.repaymentPlan = repaymentPlan;
    }

    public RechargeRecord(User user, Money amount, Money rechargeFeeThreshold, RechargeType rechargeType, Date date, RechargeStatus rechargeStatus) {
        this.user = user;
        this.amount = amount;
        this.rechargeType = rechargeType.name();
        this.rechargeFee = rechargeType.fee(amount, rechargeFeeThreshold);
        this.rechargeStatus = rechargeStatus.name();
        this.rechargeAt = date;
        this.updatedAt = this.rechargeAt;
        this.netAmount = ZERO_YUAN;
    }

    public RechargeRecord(RechargeRecord rechargeRecord) {
        this.user = rechargeRecord.getUser();
        this.amount = rechargeRecord.getAmount();
        this.rechargeType =rechargeRecord.getRechargeType().name();
        this.rechargeFee = rechargeRecord.getRechargeFee();
        this.rechargeStatus = rechargeRecord.getRechargeStatus().name();
        this.rechargeAt = rechargeRecord.getRechargeAt();
        this.updatedAt = rechargeRecord.getUpdatedAt();
        this.netAmount = rechargeRecord.getNetAmount();
        this.batchNo = rechargeRecord.getBatchNo();
        this.tradeNo=rechargeRecord.getTradeNo();
        this.errorDescription=rechargeRecord.getErrorDescription();
        this.foreignTradeNo=rechargeRecord.getForeignTradeNo();
        this.tradeTime=rechargeRecord.getTradeTime();
        this.repaymentPlan=rechargeRecord.getRepaymentPlan();



    }

    public long id() {
        return id;
    }

    public String getBatchNo() {
        return batchNo;
    }

    public void setBatchNo(String batchNo) {
        this.batchNo = batchNo;
    }

    public RechargeType getRechargeType() {
        return RechargeType.getRechargeTypeByType(rechargeType);
    }

    public void setRechargeType(RechargeType rechargeType) {
        this.rechargeType = (rechargeType != null) ? rechargeType.name() : null;
    }

    public String getForeignTradeNo() {
        return foreignTradeNo;
    }

    public void setForeignTradeNo(String foreignTradeNo) {
        this.foreignTradeNo = foreignTradeNo;
    }

    public Money getAmount() {
        return amount;
    }

    public Money getRechargeFee() {
        return rechargeFee;
    }

    public RechargeStatus getRechargeStatus() {
        return RechargeStatus.getRechargeStatusByName(rechargeStatus);
    }

    public void setRechargeStatus(RechargeStatus rechargeStatus) {
        this.rechargeStatus = (rechargeStatus != null) ? rechargeStatus.name() : null;
    }

    public void setTradeTime(Date tradeTime) {
        this.tradeTime = tradeTime;
    }

    public Date getTradeTime() {
        return tradeTime;
    }

    public Date getRechargeAt() {
        return rechargeAt;
    }

    public void setRechargeAt(Date rechargeAt) {
        this.rechargeAt = rechargeAt;
    }

    public User getUser() {
        return user;
    }

    public void setTradeNo(String tradeNo) {
        this.tradeNo = tradeNo;
    }

    public String getTradeNo() {
        return tradeNo;

    }

    public void setRechargeFee(Money rechargeFee) {
        this.rechargeFee = rechargeFee;
    }

    public Date getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Date updatedAt) {
        this.updatedAt = updatedAt;
    }

    public Money getNetAmount() {
        return netAmount;
    }

    public void setNetAmount(Money netAmount) {
        this.netAmount = netAmount;
    }

    public void setErrorDescription(ErrorDesc errorDescription) {
        this.errorDescription = errorDescription;
    }

    public ErrorDesc getErrorDescription() {
        return errorDescription;
    }

    public String getFailDescription() {
        return errorDescription == null ? "" : errorDescription.getDescription();
    }

    public String getShortFailDesc() {
        return errorDescription == null ? "" : errorDescription.getShortDesc();
    }

    public String getContractName(RechargeContractType contractType) {
        return contractType.contractNameOf(this);
    }

    public RepaymentPlan getRepaymentPlan() {
        return repaymentPlan;
    }

    public boolean isNew() {
        return RechargeStatus.NEW.name() == rechargeStatus;
    }

    public boolean isAlipay() {
        return RechargeType.getRechargeTypeByType(this.rechargeType) == RechargeType.ALIPAY;
    }

    public boolean isCms() {
        return RechargeType.getRechargeTypeByType(this.rechargeType) == RechargeType.CMS;
    }

    public boolean isAuto() {
        return RechargeType.getRechargeTypeByType(this.rechargeType) == RechargeType.AUTO;
    }

    public boolean isWithHolding() {
        return RechargeType.getRechargeTypeByType(this.rechargeType) == RechargeType.WITHHOLD;
    }

    public boolean isCmsOrAutoOrWithHolding() {
        RechargeType type = RechargeType.getRechargeTypeByType(rechargeType);
        return RechargeType.CMS.equals(type) || RechargeType.AUTO.equals(type) || RechargeType.WITHHOLD.equals(type);
    }

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}
    
}
