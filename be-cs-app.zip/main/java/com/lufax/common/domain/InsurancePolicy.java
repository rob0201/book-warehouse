package com.lufax.common.domain;

import com.lufax.common.domain.account.Money;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;

@Entity
@Table(name = "INSURANCE_POLICIES")
public class InsurancePolicy {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_INSURANCE_POLICIES")
    @SequenceGenerator(name = "SEQ_INSURANCE_POLICIES", sequenceName = "SEQ_INSURANCE_POLICIES", allocationSize = 1)
    private long id;

    @Column(name = "POLICY_NO")
    private String policyNo;

    @Embedded
    @AttributeOverrides({@AttributeOverride(name = "amount", column = @Column(name = "INSURANCE_TOTAL_AMOUNT"))})
    private Money insuranceTotalAmount;

    @Embedded
    @AttributeOverrides({@AttributeOverride(name = "amount", column = @Column(name = "INSURANCE_VALUE_PER_MONTH"))})
    private Money insuranceValuePerMonth;

    @Column(name="INSURANCE_RATE_PER_MONTH")
    private BigDecimal insuranceRatePerMonth;

    @Column(name = "INSURE_START_DATE")
    private Date insuranceStartDate;

    @Column(name = "INSURE_END_DATE")
    private Date insuranceEndDate;

    @Column(name = "PAY_START_DATE")
    private Date payStartDate;

    public InsurancePolicy() {
    }

    public InsurancePolicy(String policyNo, Money insuranceTotalAmount, Money insuranceValuePerMonth,BigDecimal insuranceRatePerMonth, Date insuranceStartDate, Date insuranceEndDate, Date payStartDate) {
        this.policyNo = policyNo;
        this.insuranceTotalAmount = insuranceTotalAmount;
        this.insuranceValuePerMonth = insuranceValuePerMonth;
        this.insuranceRatePerMonth = insuranceRatePerMonth;
        this.insuranceStartDate = insuranceStartDate;
        this.insuranceEndDate = insuranceEndDate;
        this.payStartDate = payStartDate;
    }

    public long getId() {
        return id;
    }

    public String getPolicyNo() {
        return policyNo;
    }

    public Money getInsuranceValuePerMonth() {
        return insuranceValuePerMonth;
    }

    public BigDecimal getInsuranceRatePerMonth() {
        return insuranceRatePerMonth;
    }
}
