package com.lufax.common.domain;

public enum RechargeStatus {
    NEW("新建"),
    PROCESSING("处理中"),
    SUCCESS("成功"),
    FAILURE("失败"),

    UNKNOWN("unknown");

    private String value;

    RechargeStatus(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    public static RechargeStatus getRechargeStatusByName(String status) {
        RechargeStatus[] rechargeStatuses = RechargeStatus.values();
        for (RechargeStatus rechargeStatus : rechargeStatuses)
            if (rechargeStatus.name().equalsIgnoreCase(status))
                return rechargeStatus;
        return UNKNOWN;
    }
}
