package com.lufax.common.domain;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "TRADE_CONTRACTS")
public class TradeContract {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_TRADE_CONTRACTS")
    @SequenceGenerator(name = "SEQ_TRADE_CONTRACTS", sequenceName = "SEQ_TRADE_CONTRACTS", allocationSize = 1)
    private long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "LOAN_ID")
    private Loan loan;

    //    @Enumerated(EnumType.STRING)
    @Column(name = "CONTRACT_TYPE")
    private String contractType;

    @Column(name = "STORE_ID")
    private String storeId;

    @Column(name = "CREATED_AT")
    private Date createdAt;

    @Column(name = "UPDATED_AT")
    private Date updatedAt;

    public TradeContract() {
    }

    public TradeContract(Loan loan, TradeContractType contractType, String storeId) {
        this.loan = loan;
        this.contractType = (contractType != null) ? contractType.name() : null;
        this.storeId = storeId;
        this.createdAt = this.updatedAt = new Date();
    }

    public String getStoreId() {
        return storeId;
    }

    public TradeContractType getContractType() {
        return TradeContractType.getTradeContractTypeByName(contractType);
    }

    public boolean isLoanContract() {
        return TradeContractType.LOAN == TradeContractType.getTradeContractTypeByName(contractType);
    }

    public boolean isAuthorizationContract() {
        return TradeContractType.AUTHORIZATION == TradeContractType.getTradeContractTypeByName(contractType);
    }
}
