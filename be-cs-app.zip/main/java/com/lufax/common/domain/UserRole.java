package com.lufax.common.domain;

public enum UserRole {
    P2P,
    GUARANTOR,
    ADMIN,
    CUSTOM,
    COMMON,
    OPERATOR,
    SYS,
    ENTERPRISE,
    UNKNOWN;

    public static UserRole getUserRoleByName(String name) {
        UserRole[] userRoles = UserRole.values();
        for (UserRole userRole : userRoles)
            if (userRole.name().equalsIgnoreCase(name))
                return userRole;
        return UNKNOWN;
    }

}
