package com.lufax.common.domain;

import com.lufax.common.domain.account.Money;

import java.util.Date;
import java.util.List;

import static com.lufax.common.domain.account.Money.ZERO_YUAN;

public class RepaymentDetail {
    private RepaymentPlan plan;
    private List<RepaymentRecord> repaymentRecords;

    private Money paidAmount = ZERO_YUAN;
    private Money paidPrincipal = ZERO_YUAN;
    private Money paidInterest = ZERO_YUAN;
    private Money paidInsuranceFee = ZERO_YUAN;
    private Money paidManagementFee = ZERO_YUAN;
    private Money paidPenalValue = ZERO_YUAN;
    private Money paidInsuranceManagementFee = ZERO_YUAN;
    private Money paidOverduePenaltyToPay = ZERO_YUAN;

    public RepaymentDetail(RepaymentPlan plan) {
        this.plan = plan;
        this.repaymentRecords = plan.getRecordsOrderByCreationDateAscending();

        for (RepaymentRecord repaymentRecord : repaymentRecords) {
            paidAmount = paidAmount.add(repaymentRecord.getAmount());
            paidPrincipal = paidPrincipal.add(repaymentRecord.getPrincipal());
            paidInterest = paidInterest.add(repaymentRecord.getInterest());
            paidInsuranceFee = paidInsuranceFee.add(repaymentRecord.getInsuranceFee());
            paidManagementFee = paidManagementFee.add(repaymentRecord.getManagementFee());
            paidPenalValue = paidPenalValue.add(repaymentRecord.getPenalValue());
            paidInsuranceManagementFee = paidInsuranceManagementFee.add(repaymentRecord.getInsuranceManagementFee());
            paidOverduePenaltyToPay = paidOverduePenaltyToPay.add(repaymentRecord.getOverduePenalValue());
        }
    }

    public RepaymentPlan getPlan() {
        return plan;
    }

    public long id() {
        return plan.id();
    }

    public int getPlanNumber() {
        return plan.getPlanNumber();
    }

    public Date getPayTime() {
        RepaymentRecord latestRepaymentRecord = plan.getLatestRecord();
        if (latestRepaymentRecord != null) {
            return latestRepaymentRecord.getUpdatedAt();
        }
        return null;
    }

    public Money getPrincipal() {
        return plan.getPrincipal();
    }

    public Money getInterest() {
        return plan.getInterest();
    }

    public Money getInsuranceFee() {
        return plan.getInsuranceFee();
    }

    public Money getManagementFee() {
        return plan.getManagementFee();
    }

    public PlanStatus getStatus() {
        return plan.getStatus();
    }

    public Money getAmount() {
        return plan.isSettled() ? paidAmount : plan.getTotal();
    }

    public Money getAmount(Date date) {
        return plan.isSettled() ? paidAmount : plan.getTotal(date);
    }

    public Money getPenalValue() {
        return plan.isOngoing() ? ZERO_YUAN : paidPenalValue;
    }

    public boolean isOverdue() {
        return plan.isOverdue();
    }

    public boolean isWithholding() {
        return plan.isProcessing();
    }

    public Money getOverduePenaltyToPay() {
        return plan.getOverduePenaltyToPay();
    }

    public Money getPaidPrincipal() {
        return paidPrincipal;
    }

    public Money getPaidInterest() {
        return paidInterest;
    }

    public Money getPaidInsuranceFee() {
        return paidInsuranceFee;
    }

    public Money getPaidAmount() {
        return paidAmount;
    }

    public Money getPaidOverduePenaltyToPay() {
        return paidOverduePenaltyToPay;
    }

    public List<RepaymentRecord> getRepaymentRecords() {
        return repaymentRecords;
    }

    public Money getPaidManagementFee() {
        return paidManagementFee;
    }

    public Money getPaidPenalValue() {
        return paidPenalValue;
    }

    public Money getPaidInsuranceManagementFee() {
        return paidInsuranceManagementFee;
    }

    public Money getRemainingAmount() {
        return getAmount().subtract(paidAmount);
    }

    public Money getRemainingAmount(Date date) {
        return getAmount(date).subtract(paidAmount);
    }

    public Money getRemainingAmountExceptManageFee() {
        return getRemainingAmount().subtract(getRemainingManagementFee());
    }

    public Money getRemainingPrincipal() {
        return plan.getPrincipal().subtract(paidPrincipal);
    }

    public Money getRemainingInterest() {
        return plan.getInterest().subtract(paidInterest);
    }

    public Money getRemainingInsuranceFee() {
        return plan.getInsuranceFee().subtract(paidInsuranceFee);
    }

    public Money getRemainingManagementFee() {
        return plan.getManagementFee().subtract(paidManagementFee);
    }

    public Money getRemainingOverduePenaltyToPay() {
        return plan.getOverduePenaltyToPay().subtract(paidOverduePenaltyToPay);
    }
    public Money getRemainingOverduePenaltyToPay(Date date) {
        return plan.getOverduePenaltyToPay(date).subtract(paidOverduePenaltyToPay);
    }

    public Money getRemainingPreviousOverduePenalty() {
        Money previousPlanOverduePenalty;
        if (plan.getNumberOfInstalments() == 1) {
            previousPlanOverduePenalty = plan.getOverduePenaltyToPay();
        } else {
            previousPlanOverduePenalty = plan.overduePenaltyOfPreviousPlan();
        }
        Money leftToPayCurrent = previousPlanOverduePenalty.subtract(paidOverduePenaltyToPay);
        return leftToPayCurrent.greaterThan(Money.ZERO_YUAN) ? leftToPayCurrent : Money.ZERO_YUAN;
    }

    public Money getRemainingCurrentOverduePenalty() {
        Money overduePenalty = plan.getOverduePenalty();
        Money previousPlanOverduePenalty;
        if (plan.getNumberOfInstalments() == 1) {
            previousPlanOverduePenalty = plan.getOverduePenaltyToPay();
        } else {
            previousPlanOverduePenalty = plan.overduePenaltyOfPreviousPlan();
        }
        Money leftToPayCurrent = paidOverduePenaltyToPay.subtract(previousPlanOverduePenalty);
        return leftToPayCurrent.greaterThan(Money.ZERO_YUAN) ? overduePenalty.subtract(leftToPayCurrent) : overduePenalty;
    }

    public PlanStatus getPlanStatus() {
        if (ZERO_YUAN.equals(getRemainingInsuranceFee()) && ZERO_YUAN.equals(getRemainingInterest()) && ZERO_YUAN.equals(getRemainingOverduePenaltyToPay()) && ZERO_YUAN.equals(getRemainingPrincipal())) {
            return PlanStatus.PAID;
        }
        return PlanStatus.PROCESSING;
    }

    public Date getEndAt() {
        return plan.getEndAt();
    }

}
