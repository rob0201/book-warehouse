package com.lufax.common.utils;

public class XinbaoXMLFieldHelper {

    public final static String FROM_XINBAO_SUCCESS_FLAG = "01";
    public final static String FROM_XINBAO_FAILED_FLAG = "02";

    public static final String TO_XINBAO_SUCCESS_FLAG = "1";
    public static final String TO_XINBAO_FAILED_FLAG = "0";

    public static final String POLICY_NO = "policyNo";
    public static final String REF_NO = "refNo";
    public static final String LNS_ACCT = "lnsAcct";
    public static final String PROCESS_FLAG = "processFlag";
    public static final String MESSAGE = "message";
    public static final String CUSTOMER_NAME = "custName";
    public static final String CUSTOMERNAME = "customerName";
    public static final String RP_TERM = "rpTerm";

    public static final String ID_TYPE = "idType";
    public static final String ID = "id";
    public static final String BIRTHDAY = "birthday";
    public static final String SEX = "sex";
    public static final String MATCH_FLAG = "matchFlag";
    public static final String MATCH_TIME = "matchTime";
    public static final String CUSTOMERID = "id";
    public static final String FAILREASON = "failReason";

    public static final String RPTERM = "rpTerm";
    public static final String RETYPE = "reType";
    public static final String SUAMOUNT = "suAmount";
    public static final String AMOUNT = "amount";

    public static Boolean processFlagToBoolean(String status) {
        if (FROM_XINBAO_SUCCESS_FLAG.equals(status))
            return Boolean.TRUE;
        return Boolean.FALSE;
    }
}
