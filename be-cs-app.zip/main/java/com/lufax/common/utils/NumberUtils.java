package com.lufax.common.utils;

import com.lufax.common.domain.account.Money;
import com.lufax.common.web.helper.ConstantsHelper;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;

public class NumberUtils {

    public static String formatCurrency(Money money) {
        return new DecimalFormat(ConstantsHelper.CURRENCY_FORMAT).format(money.getAmount());
    }

    public static String formatCurrency(String amount) {
        return formatCurrency(Money.rmb(amount));
    }

    public static String formatCurrency(BigDecimal amount) {
        return formatCurrency(Money.rmb(amount));
    }

    public static BigDecimal withPercentageScale(BigDecimal value) {
        return value.setScale(ConstantsHelper.PERCENTAGE_SCALE, RoundingMode.HALF_UP);
    }

    public static BigDecimal withCurrencyScale(BigDecimal value) {
        return value.setScale(ConstantsHelper.CURRENCY_SCALE, RoundingMode.HALF_UP);
    }

    public static boolean isLessThanZero(BigDecimal value) {
        return value.compareTo(BigDecimal.ZERO) < 0;
    }

    public static boolean isEqualsToZero(BigDecimal value) {
        return value.compareTo(BigDecimal.ZERO) == 0;
    }

    public static boolean isLessOrEqualThanZero(BigDecimal value) {
        return value.compareTo(BigDecimal.ZERO) <= 0;
    }

    public static boolean isGreaterOrEqualThan(BigDecimal value1, BigDecimal value2) {
        return value1.compareTo(value2) >= 0;
    }
}
