package com.lufax.common.utils;

import java.io.IOException;

import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

import com.lufax.jersey.utils.Logger;


public class ExcellTableDataFileParser extends TableDataFileParser {

	private Object EMPTY[][] = new Object[1][1];
	private Object data[][] = EMPTY;

    private int rows;
    private int columns;
	
	public ExcellTableDataFileParser(String fileName) {
		super(fileName);
		try {
			Workbook book = Workbook.getWorkbook(file);
			//获得第一个工作表对象 
			Sheet sheet=book.getSheet(0);
			
			rows = sheet.getRows();
			columns = sheet.getColumns();
			
			if(rows > 0 && columns > 0){
				data = new Object[rows][columns];
				
				for(int i = 0; i < rows; i++){
					for(int j = 0; j < columns; j++){
						Object content = sheet.getCell(j, i).getContents(); 
						data[i][j] = content;
					}
				}
			}
			book.close(); 
		} catch (BiffException e) {
			Logger.warn(this, "exception occurred when parsing file", e);
		} catch (IOException e) {
			Logger.warn(this, "exception occurred when parsing file", e);
		} 
	}

	public int getRows() {
		if(data == EMPTY){
			return 0;
		}
		return data.length;
	}

	public Object get(int rowNum, int colNum) {
        if(rowNum >= rows || colNum >= columns){
            return "";
        }
		return data[rowNum][colNum];
	}
	
}
