package com.lufax.common.utils;


import org.apache.commons.lang.StringUtils;

public class EncryptUtils {
    private static final int DEFAULT_CARD_NUMBER_DISPLAY_LENGTH = 4;

    public static String encryptBankCardNo(String cardNo) {
        if (cardNo == null || cardNo.length() <= DEFAULT_CARD_NUMBER_DISPLAY_LENGTH) {
            return cardNo;
        }

        String preStr = cardNo.substring(DEFAULT_CARD_NUMBER_DISPLAY_LENGTH, cardNo.length() - DEFAULT_CARD_NUMBER_DISPLAY_LENGTH);
        preStr = preStr.replaceAll(".", "*");
        return cardNo.substring(0, DEFAULT_CARD_NUMBER_DISPLAY_LENGTH).concat(preStr).concat(cardNo.substring(cardNo.length() - DEFAULT_CARD_NUMBER_DISPLAY_LENGTH));
    }

    public static String encryptIdentityNumber(String identityNumber) {
        if (StringUtils.isBlank(identityNumber)) {
            return identityNumber;
        }

        if (identityNumber.length() == 18) {
           return identityNumber.replaceAll(".{6}(\\d{8}).{4}", "******$1****");
        }  else {
           return identityNumber.replaceAll(".{6}(\\d{6}).{3}", "******$1***");
        }


    }

    public static String encryptMobileNumber(String mobileNumber) {
        if (StringUtils.isBlank(mobileNumber)) {
            return mobileNumber;
        }

        return mobileNumber.replaceAll("(\\d{3})\\d{4}(\\d{4})", "$1****$2");
    }
}
