package com.lufax.common.utils.recharge;

public interface RechargeResult {

    String STATUS_PARAM_KEY = "status";
    String NET_AMOUNT_PARAM_KEY = "netAmount";
    String FEE_PARAM_KEY = "fee";

    public String getTradeNo();

    public boolean isRechargeSuccess();

    public String getForeignTradeNo();

    boolean isValid();

    void setValid(boolean valid);

    String getAmount();

    String getFee();

    String getNetAmount();

    void setConfirmed(boolean confirmed);

    String confirmResult();

    String resultParams();
}
