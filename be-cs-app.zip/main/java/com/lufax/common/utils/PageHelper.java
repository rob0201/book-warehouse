package com.lufax.common.utils;


import java.util.List;

public class PageHelper {
    public static List getOnePageData(int currPage, int pageSize, List dataList) {
        int fromIndex = pageSize * (currPage - 1);
        int toIndex = (pageSize * currPage) > dataList.size() ? dataList.size() : pageSize * currPage;
        return dataList.subList(fromIndex, toIndex);
    }
}
