package com.lufax.common.utils;

import com.lufax.customerService.pojo.ExtProductSME;
import com.lufax.customerService.pojo.ProductInsertApply;
import com.lufax.customerService.pojo.SMEProductType;

import java.util.Calendar;


public class ProductUtils {
	
	//获取产品收款期
	public static String getCollectBetween(ProductInsertApply product) {
		String startDate = DateUtils.formatDate(product.getInterestStartDate());
		String endDate = DateUtils.formatDate(product.getDeadLine());
		return startDate + "至" + endDate;
	}

	//获取产品期限
	public static String resolveCountOfInstalments(ProductInsertApply product) {
		if(SMEProductType.JYT.equals(product.getProductType()) || SMEProductType.HUIXIN.equals(product.getProductType())||SMEProductType.YINGTONG.equals(product.getProductType())){
			return DateUtils.diffDay(product.getInterestStartDate(), product.getDeadLine()) + "天";
		} else {
			return product.getLoanPeriod();
		}
	}
	
	//获取产品期限
	public static String resolveCountOfInstalments(ExtProductSME product) {
		if(SMEProductType.JYT.equals(product.getProductType()) || SMEProductType.HUIXIN.equals(product.getProductType())||SMEProductType.YINGTONG.equals(product.getProductType())){
			return DateUtils.diffDay(product.getInterestStartDate(), product.getDeadLine()) + "天";
		} else {
			return product.getLoanPeriod();
		}
	}
	
	//获取产品页面展现名
	public static String resolveProductName(ProductInsertApply product) {
		if(SMEProductType.JYT.equals(product.getProductType()) || SMEProductType.HUIXIN.equals(product.getProductType())||SMEProductType.YINGTONG.equals(product.getProductType())){
			return product.getName() + product.getCode();
		} else {
			return product.getName();
		}
	}
	
	//获取借款人姓名
	public static String getLoaneeName(ExtProductSME product){
		if(SMEProductType.ANYEDAI.equals(product)){
			return product.getLegalPerson().getName();
		} else if(SMEProductType.HUIXIN.equals(product) || SMEProductType.JYT.equals(product)){
			return product.getAgency().getName();
		}
		
		return null;
	}
}
