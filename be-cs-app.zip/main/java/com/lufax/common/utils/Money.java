package com.lufax.common.utils;

import static java.math.BigDecimal.ONE;
import static java.math.BigDecimal.ZERO;

import java.math.BigDecimal;
import java.math.RoundingMode;

import javax.persistence.Embeddable;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Transient;

import org.apache.commons.lang.builder.EqualsBuilder;


@Embeddable
public class Money implements Comparable<Money> {
    // Currently only RMB is supported
    private static enum Currency {
        RMB;
    }

    public static final Money ONE_YUAN = Money.rmb(ONE);
    public static final Money ZERO_YUAN = Money.rmb(ZERO);

    @Enumerated(EnumType.STRING)
    @Transient
    private Currency currency;

    private BigDecimal amount;

    private Money() {
        this.currency = Currency.RMB;
    }

    private Money(BigDecimal amount) {
        this.currency = Currency.RMB;
        this.amount = amount;
    }

    public static Money rmb(String amount) {
        return new Money(new BigDecimal(amount));
    }

    public static Money rmb(BigDecimal amount) {
        return new Money(amount);
    }

    public Money multiply(BigDecimal multiplicand) {
        return new Money(amount.multiply(multiplicand));
    }

    public Money multiply(int multiplicand) {
        return new Money(amount.multiply(new BigDecimal(multiplicand)));
    }

    public Money divide(BigDecimal divisor) {
        return new Money(amount.divide(divisor, 10, RoundingMode.HALF_UP));
    }

    public Money subtract(Money subtrahend) {
        return new Money(amount.subtract(subtrahend.amount));
    }

    public Money add(Money balance) {
        return new Money(amount.add(balance.amount));
    }

    public BigDecimal getAmount() {
        return NumberUtils.withCurrencyScale(amount);
    }

    public Money roundUp() {
        return new Money(getAmount());
    }

    public boolean greaterThanOrEqualsTo(Money another) {
        return compareTo(another) >= 0;
    }

    public boolean lessThanOrEqualsTo(Money another) {
        return compareTo(another) <= 0;
    }

    public boolean greaterThan(Money another) {
        return compareTo(another) > 0;
    }

    public boolean lessThan(Money another) {
        return compareTo(another) < 0;
    }

    public int compareTo(Money another) {
        if (currency == another.currency) {
            return amount.compareTo(another.amount);
        }
        throw new IllegalArgumentException("Only money with same currency could compare!");
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Money money = (Money) o;

        return new EqualsBuilder().append(NumberUtils.withCurrencyScale(amount), NumberUtils.withCurrencyScale(money.amount))
                .append(currency, money.currency).isEquals();
    }

    @Override
    public int hashCode() {
        int result = currency != null ? currency.hashCode() : 0;
        result = 31 * result + (amount != null ? amount.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return currency.name() + amount;
    }

    public String amountToString() {
        return amount.toString();
    }
}
