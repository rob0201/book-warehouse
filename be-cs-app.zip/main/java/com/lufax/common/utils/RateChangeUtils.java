package com.lufax.common.utils;

import com.lufax.customerService.domain.PointInterestRate;
import com.lufax.customerService.domain.RateChangePlan;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.TreeMap;

public class RateChangeUtils {

    public static List<PointInterestRate> convertToPointInterestRateList(BigDecimal interestFloatRate, List<RateChangePlan> rateChangePlanDone) {
        TreeMap<Date, PointInterestRate> pointInterestRateMap = new TreeMap<Date, PointInterestRate>();
        for (RateChangePlan rateChangePlan : rateChangePlanDone) {
            Date executeDate = rateChangePlan.getExecuteDate();
            PointInterestRate pointInterestRate = pointInterestRateMap.get(executeDate);
            if (pointInterestRate == null) {
                pointInterestRate = new PointInterestRate(executeDate);
                pointInterestRate.setInterestFloatRate(interestFloatRate);
                pointInterestRateMap.put(executeDate, pointInterestRate);
            }
            pointInterestRate.setInterestRate(rateChangePlan);
        }
        return new ArrayList<PointInterestRate>(pointInterestRateMap.values());
    }

}