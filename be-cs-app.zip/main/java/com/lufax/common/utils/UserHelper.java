package com.lufax.common.utils;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.google.gson.Gson;
import com.lufax.common.metadata.User;
import com.lufax.jersey.client.JerseyService;
import com.lufax.jersey.exception.InvokeRemoteServiceException;
import com.sun.jersey.api.client.ClientResponse;

@Component
public class UserHelper {

    @Autowired
    private BEProperties beProperties;
    @Autowired
    @Qualifier("mgrJerseyService")
    private JerseyService jerseyService;

    public  com.lufax.common.domain.User tranferToP2pUser(User user) {
        com.lufax.common.domain.User p2pUser = new com.lufax.common.domain.User();
        p2pUser.setId(user.getP2pUserId());
        p2pUser.setUsername(user.getName());
        return p2pUser;
    }


    public  String getCurrentUserName(long p2pUserId) {
        User operator = getUser(p2pUserId);
        return operator == null ? null : operator.getName();
    }
    
    
	public User getUser(Long p2pUserId) {
		String path = String.format(beProperties.getBeUser(), p2pUserId);
        try {
            ClientResponse clientResponse = jerseyService.getInstance(path).invokeJersey();
            if (ClientResponse.Status.OK.getStatusCode() == clientResponse.getStatus()) {
                String result = clientResponse.getEntity(String.class);
                User user = new Gson().fromJson(result, User.class);
                return user;
            } else {
            	DevLog.warn(this, String.format("get user by p2pUser Id %s, return code is %s", p2pUserId, clientResponse.getStatus()));
                clientResponse.close();
            }
        } catch (InvokeRemoteServiceException e) {
        	DevLog.error(this, "get user , remote invoke error",e);
            return null;
        }
        return null;
	}

}
