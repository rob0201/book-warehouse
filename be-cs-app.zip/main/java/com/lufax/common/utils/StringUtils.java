package com.lufax.common.utils;

import org.hibernate.util.StringHelper;

import java.util.Collection;

public class StringUtils {

    public final static String EMPTY = "";

    public static boolean equals(Object arg1, Object arg2) {
        if (arg1 == null || arg2 == null) {
            return false;
        }
        return arg1.toString().equals(arg2.toString());
    }

    public static String toString(Object obj) {
        if (obj == null) {
            return EMPTY;
        } else {
            return String.valueOf(obj);
        }
    }
         public static String join(Collection collection, String seperator) {
        if(collection == null || collection.size() == 0) {
            return "";
        }
        return StringHelper.join(seperator, collection.iterator());
    }
      public static String join(String[] strings, String seperator) {
        if(strings == null || strings.length == 0) {
            return "";
        }
        return StringHelper.join(seperator, strings);
    }
       public static boolean isBlank(String str) {
        int strLen;
        if (str == null || (strLen = str.length()) == 0) {
            return true;
        }
        for (int i = 0; i < strLen; i++) {
            if ((Character.isWhitespace(str.charAt(i)) == false)) {
                return false;
            }
        }
        return true;

    }
}
