package com.lufax.common.utils;

import com.lufax.common.domain.account.Money;

public class MoneyUtils {
    private static final int ASCII_ZERO = 48;
    private static final String[] BIG_LETTERS = new String[]{"零", "壹", "贰", "叁", "肆", "伍", "陆", "柒", "捌", "玖"};
    private static final String[] INTEGRAL_UNITS = new String[]{"圆", "拾", "佰", "仟", "萬",
            "拾", "佰", "仟",
            "亿", "拾", "佰", "仟", "萬", "拾萬"};
    private static final String[] DECIMAL_UNITS = new String[]{"分", "角"};

    public static String toChinese(Money money) {
        String[] array = money.getAmount().toString().split("\\.");
        return cleanZero(rmbInChinese(array[0], INTEGRAL_UNITS) + rmbInChinese(array[1], DECIMAL_UNITS));
    }

    private static String rmbInChinese(String number, String[] units) {
        StringBuilder result = new StringBuilder();
        int length = number.length();
        for (int i = 0; i < length; i++) {
            result.append(BIG_LETTERS[number.charAt(i) - ASCII_ZERO]).append(units[length - i - 1]);
        }
        return result.toString();
    }

    private static String cleanZero(String rmbInChinese) {
        while (rmbInChinese.charAt(0) == '零') {
            rmbInChinese = rmbInChinese.substring(2);
            if (rmbInChinese.length() == 0) {
                return "零圆";
            }
        }

        return rmbInChinese.replaceAll("零[仟|佰|拾]", "零").replaceAll("零{2,}", "零").replaceAll("零([亿|萬|圆])", "$1")
                .replaceAll("零[角|分]", "").replaceAll("亿萬", "亿");
    }
}
