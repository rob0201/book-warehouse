package com.lufax.common.utils;

import com.sun.jersey.api.representation.Form;
import org.springframework.beans.BeanWrapper;
import org.springframework.beans.BeanWrapperImpl;

import javax.servlet.http.HttpServletRequest;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Method;
import java.util.*;

//TODO 没有测试bean嵌套bena
//TODO 集合及混合嵌套支持不足，完善中
//TODO json2Bean
//TODO bean2Json(支持domain2Json)
//TODO json2Map
//TODO map2Json
public class BeanUtils {
    private static ThreadLocal<Set> set = new ThreadLocal<Set>() {
        public Set initialValue() {
            return new HashSet();
        }
    };

    public static Map<String, String> getDataMap(HttpServletRequest request) {
        Map<String, String> map = new HashMap<String, String>();
        Enumeration e = request.getParameterNames();
        while (e.hasMoreElements()) {
            String k = String.valueOf(e.nextElement());
            map.put(k, StringUtils.toString(request.getParameter(k)));
            //request.getParameterMap().put(k, StringUtils.objToString(request.getParameter(k)));
        }

        //request.getParameterMap().putAll(map);
        return map;
    }

    public static <T> T form2Bean(Form form, Class<T> clazz) {
        return BeanUtils.map2Bean(form2Map(form), clazz);
    }

    public static Map<String, String> form2Map(Form form) {
        Map<String, String> map = new HashMap<String, String>();
        for (String key : form.keySet()) {
            String firstValue = form.getFirst(key);
            if (!EmptyChecker.isEmpty(firstValue)) {
                map.put(key, firstValue);
            }
        }
        return map;
    }

    public static <T> T bean2Bean(Object srcBean, T obj) {
        BeanWrapper src = new BeanWrapperImpl(srcBean);
        BeanWrapper dest = new BeanWrapperImpl(obj);

        for (PropertyDescriptor prop : dest.getPropertyDescriptors()) {
            String name = prop.getName();

            if (!src.isReadableProperty(name) || !dest.isWritableProperty(name)) {
                continue;
            }

            if (!EmptyChecker.isEmpty(dest.getPropertyValue(name))) {
                continue;
            }

            Object convertedValue = convertType(src.getPropertyValue(name), prop.getPropertyType());

            if (convertedValue == null) {
                continue;
            }

            dest.setPropertyValue(name, convertedValue);
        }

        return (T) dest.getWrappedInstance();
    }

    public static <T> T bean2Bean(Object srcBean, Class<T> destClazz) {
        BeanWrapper src = new BeanWrapperImpl(srcBean);
        BeanWrapper dest = new BeanWrapperImpl(destClazz);

        for (PropertyDescriptor prop : dest.getPropertyDescriptors()) {
            String name = prop.getName();

            if (!src.isReadableProperty(name) || !dest.isWritableProperty(name)) {
                continue;
            }

            Object convertedValue = convertType(src.getPropertyValue(name), prop.getPropertyType());

            if (convertedValue == null) {
                continue;
            }

            dest.setPropertyValue(name, convertedValue);
        }

        return (T) dest.getWrappedInstance();
    }

    public static Map<String, Object> bean2Map(Object bean) {
        if (set.get().contains(bean)) {
            return null;
        }

        set.get().add(bean);

        Map<String, Object> map = new HashMap<String, Object>();
        BeanWrapper bw = new BeanWrapperImpl(bean);

        for (PropertyDescriptor prop : bw.getPropertyDescriptors()) {
            String name = prop.getName();

            if (!bw.isReadableProperty(name)) {
                continue;
            }

            Object value = bw.getPropertyValue(name);
            if (value == null) {
                map.put(name, value);
                continue;
            }

            if (value.getClass().getName().startsWith("java") || Enum.class.isAssignableFrom(value.getClass())) {
                map.put(name, value);
                continue;
            }

            Map subMap = bean2Map(value);
            map.put(name, subMap);
        }

        set.get().remove(bean);
        return map;
    }

    public static Map<String, Object> bean2map(Object bean) {
        return bean2map(bean, new HashSet());
    }

    public static List<Map<String, Object>> list2map(Object[] beans) {
        return null;
    }

    public static List<Map<String, Object>> list2map(Collection beans) {
        return null;
    }

    //TODO Object[] beans?
    private static List<Map<String, Object>> list2map(Object[] beans, Set hashSet) {
        //for (Object bean : beans) {}
        return null;
    }

    private static List<Map<String, Object>> list2map(Collection beans, Set hashSet) {
        //for (Object bean : beans) {}
        return null;
    }

    private static Map<String, Object> bean2map(Object bean, Set hashSet) {
        if (EmptyChecker.isEmpty(bean) || hashSet.contains(bean)) {
            return null;
        }

        hashSet.add(bean);

        Map<String, Object> map = new HashMap<String, Object>();
        BeanWrapper bw = new BeanWrapperImpl(bean);

        for (PropertyDescriptor prop : bw.getPropertyDescriptors()) {
            String name = prop.getName();

            if (!bw.isReadableProperty(name)) {
                continue;
            }

            Object value = bw.getPropertyValue(name);
            if (value == null) {
                map.put(name, value);
                continue;
            }

            if (value.getClass().getName().startsWith("java") || Enum.class.isAssignableFrom(value.getClass())) {
                map.put(name, value);
                continue;
            }

            map.put(name, bean2map(value, hashSet));
        }

        hashSet.remove(bean);
        return map;
    }

    public static <T> T map2Bean(Map<?, ?> map, Class<T> destClazz) {
        BeanWrapper bw = new BeanWrapperImpl(destClazz);

        for (PropertyDescriptor prop : bw.getPropertyDescriptors()) {
            String name = prop.getName();

            if (!bw.isWritableProperty(name)) {
                continue;
            }

            Object value = map.get(name);

            if (value == null) {
                if (name.length() == 1) {
                    value = map.get(name.toUpperCase());
                } else {
                    value = map.get(Character.toUpperCase(name.charAt(0)) + name.substring(1));
                }

                if (value == null) {
                    continue;
                }
            }

            Object convertedValue = convertType(value, prop.getPropertyType());

            if (convertedValue == null) {
                continue;
            }

            bw.setPropertyValue(name, convertedValue);
        }

        return (T) bw.getWrappedInstance();
    }

    public static Object convertType(Object value, Class destClazz) {
        if (value == null) {
            return null;
        }

        if (value.getClass() == destClazz) {
            return value;
        }

        //TODO String2Map\String2Bean
        if (String.class == destClazz) {
            //TODO 如果目标是String，而源是Bean，那还要Bean2Map,然后再toString.
            // TODO 默认该bean复写toString方法。
            return value.toString();
        }

        if (DateUtils.isDateClass(destClazz)) {
            return DateUtils.fishForParseDate(value, destClazz);
        }

        if (Enum.class.isAssignableFrom(destClazz)) {
            String enumValue = String.valueOf(value);

            if (enumValue.length() < 1) {
                return null;
            }

            return Enum.valueOf(destClazz, enumValue);
        }

        //TODO 类型不一致场合，且都为Bean时，须再次bean2bean
        return value;
    }

    public Object reimplement(Object target, Method method, Object[] args)
            throws Throwable {
        com.lufax.common.utils.DevLog.info(this, "before executing method[" + method.getName() +
                "] on Object[" + target.getClass().getName() + "].");

//        System.out.println("sorry,We will do nothing this time.");

        com.lufax.common.utils.DevLog.info(this, "end of executing method[" + method.getName() +
                "] on Object[" + target.getClass().getName() + "].");
        return null;

    }
}