package com.lufax.common.utils;

public class TransactionHistoryRemarkHelper {

    private static final String RECHARGE_AUTO_REMARK = "自动扣款 （贷款申请号：%s）";

    private static final String RECHARGE_WITHHOLD_REMARK = "逾期自动扣款 （贷款申请号：%s）";

    private static final String RECHARGE_ALIPY_REMARK = "支付宝即时到账";

    private static final String RECHARGE_FEE_ALIPY_REMARK = "支付宝转账手续费";

    private static final String WITHDRAW_REMARK = "取现：%s";

    private static final String INVESTMENT_REMARK = "投资：%s （贷款申请号：%s）";

    private static final String INVESTMENT_REQUEST_FAILURE_UNFROZEN_FUND_REMARK = "投资失败：%s （贷款申请号：%s）";

    private static final String LOAN_REMARK = "贷款：%s （贷款申请号：%s）";

    private static final String XINBAO_REMARK = "担保 （贷款申请号：%s）";

    private static final String XINBAO_LOANEE_REMARK = "%s （贷款申请号：%s）";

    private static final String P2P_REMARK = "P2P";

    private static final String TRANSACTION_FEE_REMARK_FOR_LOANEE = "贷款：%s";

    private static final String TRANSACTION_FEE_REMARK_FOR_LOANER = "收款：%s";

    private static final String RECHARGE_COMPENSATE_REMARK = "代偿自动充值";

    private static final String RECHARGE_SUBROGATION_REMARK = "追偿自动充值";
    
    private static final String TRANSFER_INVESTMENT_REMARK = "投资：%s （转让申请号：%s）";
    private static final String TRANSFER_REMARK = "转让：%s （转让申请号：%s）";

    public static String getRechargeAutoRemark(String loanRequestCode) {
        return String.format(RECHARGE_AUTO_REMARK, loanRequestCode);
    }

    public static String getRechargeWithHoldRemark(String loanRequestCode) {
        return String.format(RECHARGE_WITHHOLD_REMARK, loanRequestCode);
    }

    public static String getRechargeAlipyRemark() {
        return String.format(RECHARGE_ALIPY_REMARK);
    }

    public static String getRechargeFeeAlipyRemark() {
        return String.format(RECHARGE_FEE_ALIPY_REMARK);
    }

    public static String getWithdrawRemark(String bankName) {
        return String.format(WITHDRAW_REMARK, bankName);
    }

    public static String getInvestmentRemark(String loaneeName, String loanRequestCode) {
        return String.format(INVESTMENT_REMARK, loaneeName, loanRequestCode);
    }

    public static String getInvestmentRequestUnfrozenFundRemark(String loaneeName, String loanRequestCode) {
        return String.format(INVESTMENT_REQUEST_FAILURE_UNFROZEN_FUND_REMARK, loaneeName, loanRequestCode);
    }

    public static String getLoanRemark(String loanerName, String loanRequestCode) {
        return String.format(LOAN_REMARK, loanerName, loanRequestCode);
    }

    public static String getRechargeCompensateRemark() {
        return RECHARGE_COMPENSATE_REMARK;
    }


    public static String getRechargeSubrogationRemark() {
        return RECHARGE_SUBROGATION_REMARK;
    }
    
    public static String getTransferInvestmentRemark(String submitUserName, String transferRequestCode) {
        return String.format(TRANSFER_INVESTMENT_REMARK, submitUserName, transferRequestCode);
    }
    public static String getTransferRemark(String loanerName, String transferRequestCode) {
        return String.format(TRANSFER_REMARK, loanerName, transferRequestCode);
    }


}
