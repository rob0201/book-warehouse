package com.lufax.common.utils;

import org.joda.time.DateTime;

import java.io.File;
import java.io.IOException;

public class FileUtils {

    public static String getAlipayReconciliationFileName(DateTime dateTime) {
        return String.format("alipay-%s.xls", DateUtils.formatDate(dateTime.toDate()));
    }
    public static String getCMSReconciliationFileName(DateTime dateTime) {
        return String.format("cms-%s.xls", DateUtils.formatDate(dateTime.toDate()));
    }
    public static String getCmsCapitalStatementsFailedFileName(DateTime dateTime) {
        return String.format("cms-fail-%s.xls", DateUtils.formatDate(dateTime.toDate()));
    }

    public static String getCmsCapitalStatementReturnTicketFileName(DateTime dateTime){
        return String.format("cms-return-ticket-%s.xls", DateUtils.formatDate(dateTime.toDate()));
    }

    public static File forceMkdir(String dirName) {
        return forceMkdir(new File(dirName));
    }

    public static File forceMkdir(File directory) {
        try {
            org.apache.commons.io.FileUtils.forceMkdir(directory);
            return directory;
        } catch (IOException e) {
            throw new RuntimeException(e.getMessage(), e);
        }
    }

    public static void forceDelete(File directory) {
        if(directory == null || !directory.exists()) {
            return;
        }
        try {
            org.apache.commons.io.FileUtils.forceDelete(directory);
        } catch (IOException e) {
            throw new RuntimeException(e.getMessage(), e);
        }
    }
}