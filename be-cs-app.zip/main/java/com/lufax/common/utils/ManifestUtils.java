package com.lufax.common.utils;

import java.io.IOException;
import java.io.InputStream;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.jar.Manifest;

import javax.servlet.ServletContext;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class ManifestUtils {
	private static final Log log = LogFactory.getLog(ManifestUtils.class
			.getName());

	public static final String MANIFEST_CLASS_LOADER = "./META-INF/MANIFEST.MF";

	public static final String MANIFEST_CLASS_LOADER_ESPECIAL = "./../../META-INF/MANIFEST.MF";

	public static final String MANIFEST_RESOURCE = "/META-INF/MANIFEST.MF";

	public static void main(String[] args) throws URISyntaxException,
			IOException {
		System.out.println(getManifest().getMainAttributes().entrySet());
	}

	public static Manifest getManifest() throws URISyntaxException, IOException {
		URL url = ManifestUtils.class.getProtectionDomain().getCodeSource()
				.getLocation();

		log.debug(String.format("CodeSource URL : %s", url.toString()));

		return getManifest(new URL(url, MANIFEST_CLASS_LOADER));
		// return new JarFile(new File(url.toURI())).getManifest();
	}

	public static Manifest getManifest(ServletContext ctx)
			throws URISyntaxException, IOException {
		return getManifest(ctx.getResource(MANIFEST_RESOURCE));
	}

	public static Manifest getManifest(Class<?> c) throws IOException {
		return getManifest(c.getClassLoader());
	}

	public static Manifest getManifest(ClassLoader loader) throws IOException {
		return getManifest(getResource(loader, MANIFEST_CLASS_LOADER));
	}

	public static Manifest getManifest(URL url) throws IOException {

		log.debug(String.format("MF URL : %s", url.toString()));
		return getManifest(url.openStream());
	}

	public static Manifest getManifest(InputStream in) throws IOException {
		try {
			return new Manifest(in);
		} finally {
			in.close();
		}
	}

	// TODO ResourceUtils
	public static URL getResource(ClassLoader loader, String name)
			throws IOException {
		if (loader == null)
			return getResource(name);
		else {
			final URL resource = loader.getResource(name);
			if (resource != null) {
				return resource;
			} else {
				return getResource(name);
			}
		}
	}

	// TODO ResourceUtils
	public static URL getResource(String name) {
		return ClassLoader.getSystemResource(name);
	}
}
