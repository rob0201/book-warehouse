package com.lufax.common.utils;

import java.util.HashMap;
import java.util.Map;

public class MapUtils {
    public static Map<String, String> convertFromString(String mapAsString) {
        Map<String, String> map = new HashMap<String, String>();

        String actualInput = mapAsString.substring(1, mapAsString.length() - 1);

        String[] keyValuePairs = actualInput.split(",");
        for (String keyValuePair : keyValuePairs) {
            String[] keyValue = keyValuePair.split("=");
            map.put(keyValue[0].trim(), keyValue.length > 1 ? keyValue[1].trim() : "");
        }

        return map;
    }
}
