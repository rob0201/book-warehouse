package com.lufax.common.utils;

import java.io.File;

abstract public class TableDataFileParser {
	
	protected File file;
	
	public TableDataFileParser(String fileName){
		this.file = new File(fileName);
	}
	
	abstract public int getRows();
	
	abstract public Object get(int rowNum, int colNum);

}
