package com.lufax.common.utils;

import com.lufax.common.domain.BizParameters;
import com.lufax.common.domain.PaymentMethodFactory;
import com.lufax.common.domain.Plan;
import com.lufax.common.domain.RepaymentOperation;
import com.lufax.common.domain.account.Money;
import com.lufax.common.domain.repository.BizParametersRepository;
import com.lufax.customerService.domain.PointInterestRate;
import com.lufax.customerService.domain.RateChangePlan;
import com.lufax.customerService.domain.repository.RateChangePlanRepository;
import com.lufax.customerService.service.RateChangeService;
import org.joda.time.DateTime;
import org.joda.time.Days;
import org.springframework.web.context.WebApplicationContext;

import java.math.BigDecimal;
import java.util.*;

import static com.lufax.common.utils.BigDecimalUtils.add;
import static com.lufax.common.utils.BigDecimalUtils.multiply;
import static com.lufax.common.web.helper.ConstantsHelper.REQUEST_COMPENSATE_DAYS;
import static com.lufax.common.domain.BizParameters.INTEREST_FLOAT_RATE;

public class OverduePenaltyCalculator {

    private static final BigDecimal DAYS_360 = new BigDecimal("360");
    public static List<PointInterestRate> INTEREST_RATE_LIST = new ArrayList<PointInterestRate>();
    public static WebApplicationContext currentWebApplicationContext = null;
    private static long lastRateUpdateDay = 0;

    protected static Money calculate(Money principal, int overdueDays, BigDecimal annualInterestRate, BigDecimal overdueFloatRate) {
        BigDecimal overdueInterestRate = multiply(annualInterestRate, add(overdueFloatRate, BigDecimal.ONE));
        return principal.multiply(overdueInterestRate).divide(DAYS_360).multiply(new BigDecimal(overdueDays));
    }

    public static Money calculate(Plan plan, Date currentDate) {

        if (plan.getLoan().passedCompensateDay(currentDate)) {
            currentDate = plan.getLoan().getCompensateDateForWillCompensate(REQUEST_COMPENSATE_DAYS);
        }

        List<RepaymentOperation> repaymentOperations = plan.getRepaymentOperationsOrderByCreationDateAscending();

        Money scheduledPrincipalInExtension = calculateScheduledPricipalInExtension(plan, repaymentOperations);
        Money overduePrincipal = plan.getPrincipal().subtract(scheduledPrincipalInExtension);
        Money overduePenalty = Money.ZERO_YUAN;

        Date dateFrom = plan.getEndAt();

        for (RepaymentOperation repaymentOperation : repaymentOperations) {
            if (!isInExtensionPeriod(calculateOverdueDays(plan.getEndAt(), repaymentOperation.getCreatedAt()), plan.getOverdueBufferDays())) {
                Date dateTo = repaymentOperation.getCreatedAt();
                Money scheduledPrincipal = plan.getScheduledPrincipal(repaymentOperation);

                if (scheduledPrincipal.greaterThan(Money.ZERO_YUAN)) {
                    overduePenalty = overduePenalty.add(calculate(scheduledPrincipal, dateFrom, dateTo, plan, currentDate));

                    overduePrincipal = overduePrincipal.subtract(scheduledPrincipal);
                    overduePenalty = overduePenalty.add(calculate(overduePrincipal, dateFrom, dateTo, plan, currentDate));

                    dateFrom = repaymentOperation.getCreatedAt();
                }
            }
        }

        if (overduePrincipal.lessThan(Money.ZERO_YUAN)) {
            return overduePenalty;
        }

        return overduePenalty.add(calculate(overduePrincipal, dateFrom, currentDate, plan, currentDate)).roundUp();
    }

    private static boolean isInExtensionPeriod(int overdueDays, int overdueExtensionDays) {
        return new BigDecimal(overdueDays).compareTo(new BigDecimal(overdueExtensionDays)) != 1;
    }

    protected static Money calculate(Money overduePrincipal, Date dateFrom, Date dateTo, Plan plan, Date compareDate) {
        if (isInExtensionPeriod(calculateOverdueDays(plan.getEndAt(), compareDate), plan.getOverdueBufferDays())) {
            return Money.ZERO_YUAN;
        }
        if (plan.getEndAt().after(dateFrom)) {
            dateFrom = plan.getEndAt();
        }
        if (dateFrom.compareTo(dateTo) >= 0) {
            return Money.ZERO_YUAN;
        }
        Money overduePenalty = Money.ZERO_YUAN;
        List<PointInterestRate> actualInterestRates = createActualInterestRates(plan);
        if (!isRateChangedBetweenDateRange(plan.getEndAt(), dateTo, actualInterestRates)) {
            return overduePenalty.add(calculate(overduePrincipal, calculateOverdueDays(dateFrom, dateTo), plan.getAnnualInterestRate(), plan.getOverdueFloatRate()));
        }

        overduePenalty = calculateOverduePenaltyWhenRateChange(overduePrincipal, dateFrom, dateTo, plan, actualInterestRates);

        return overduePenalty;
    }

    private static Money calculateScheduledPricipalInExtension(Plan plan, List<RepaymentOperation> repaymentOperations) {
        Money scheduledPrincipalInExtension = Money.ZERO_YUAN;
        for (RepaymentOperation repaymentOperation : repaymentOperations) {
        	if(repaymentOperation != null) {
	            if (isInExtensionPeriod(calculateOverdueDays(plan.getEndAt(), repaymentOperation.getCreatedAt()), plan.getOverdueBufferDays())) {
	                scheduledPrincipalInExtension = scheduledPrincipalInExtension.add(plan.getScheduledPrincipal(repaymentOperation));
	            }
        	}
        }
        return scheduledPrincipalInExtension;
    }

    private static int calculateOverdueDays(Date dateFrom, Date dateTo) {
        return Days.daysBetween(new DateTime(DateUtils.endOfDay(dateFrom)), new DateTime(DateUtils.endOfDay(dateTo))).getDays();
    }

    private static List<PointInterestRate> createActualInterestRates(Plan plan) {
        List<PointInterestRate> actualPointInterestRates = new ArrayList<PointInterestRate>();
        for (PointInterestRate pointInterestRate : INTEREST_RATE_LIST) {
            try {
                PointInterestRate actualPointInterestRate = (PointInterestRate) pointInterestRate.clone();
                actualPointInterestRate.setExecuteDate(pointInterestRate.calculateActualExecuteDate(plan.getLoan()));
                addToListWhenDifferentExecuteDate(actualPointInterestRates, actualPointInterestRate);
            } catch (CloneNotSupportedException e) {
                e.printStackTrace();
            }
        }
        return actualPointInterestRates;
    }

    private static void addToListWhenDifferentExecuteDate(List<PointInterestRate> actualPointInterestRates, PointInterestRate actualPointInterestRate) {
        if (existExecuteDate(actualPointInterestRates, actualPointInterestRate)) {
            actualPointInterestRates.remove(actualPointInterestRates.size() - 1);
        }
        actualPointInterestRates.add(actualPointInterestRate);
    }

    private static boolean existExecuteDate(List<PointInterestRate> actualPointInterestRates, PointInterestRate actualPointInterestRate) {
        if (actualPointInterestRates.size() == 0) return false;
        Date oldExecuteDate = actualPointInterestRates.get(actualPointInterestRates.size() - 1).getExecuteDate();
        Date newExecuteDate = actualPointInterestRate.getExecuteDate();
        if (oldExecuteDate == null || newExecuteDate == null) return false;
        return newExecuteDate.equals(oldExecuteDate);
    }

    private static Money calculateOverduePenaltyWhenRateChange(Money overduePrincipal, Date dateFrom, Date dateTo, Plan plan, List<PointInterestRate> actualInterestRates) {
        Money overduePenalty = Money.ZERO_YUAN;
        ArrayList<PointInterestRate> rateChangeListInRange = getRateChangeListWithinDateRange(dateFrom, dateTo, actualInterestRates);
        BigDecimal annualInterestRate = getAnnualInterestRateAtDateFrom(dateFrom, plan, actualInterestRates);
        if (null == rateChangeListInRange || rateChangeListInRange.size() == 0) {
            return calculate(overduePrincipal, calculateOverdueDays(dateFrom, dateTo), annualInterestRate, plan.getOverdueFloatRate());
        }
        Date tmpStartDate = dateFrom;
        for (int i = 0; i < rateChangeListInRange.size(); i++) {
            PointInterestRate pointInterestRate = rateChangeListInRange.get(i);
            Date oneDayBeforeExecuteDate = new DateTime(pointInterestRate.getExecuteDate()).minusDays(1).toDate();
            overduePenalty = overduePenalty.add(calculate(overduePrincipal, calculateOverdueDays(tmpStartDate, oneDayBeforeExecuteDate), annualInterestRate, plan.getOverdueFloatRate()));
            annualInterestRate = PaymentMethodFactory.getInterestRate(pointInterestRate.getBaseInterestRate(plan.getNumberOfInstalments()), pointInterestRate.getInterestFloatRate());
            if (i == rateChangeListInRange.size() - 1) {
                overduePenalty = overduePenalty.add(calculate(overduePrincipal, calculateOverdueDays(oneDayBeforeExecuteDate, dateTo), annualInterestRate, plan.getOverdueFloatRate()));
            }
            tmpStartDate = oneDayBeforeExecuteDate;
        }
        return overduePenalty;
    }

    private static BigDecimal getAnnualInterestRateAtDateFrom(Date dateFrom, Plan plan, List<PointInterestRate> actualInterestRates) {
        BigDecimal annualInterestRate = plan.getAnnualInterestRate();
        for (PointInterestRate pointInterestRate : actualInterestRates) {
            if (pointInterestRate.getExecuteDate().compareTo(dateFrom) <= 0) {
                annualInterestRate = PaymentMethodFactory.getInterestRate(pointInterestRate.getBaseInterestRate(plan.getNumberOfInstalments()), pointInterestRate.getInterestFloatRate());
            }
        }
        return annualInterestRate;
    }

    private static ArrayList<PointInterestRate> getRateChangeListWithinDateRange(Date dateFrom, Date dateTo, List<PointInterestRate> actualInterestRates) {
        ArrayList<PointInterestRate> rateChangeListInRange = new ArrayList<PointInterestRate>();
        for (PointInterestRate pointInterestRate : actualInterestRates) {
            if (pointInterestRate.getExecuteDate().compareTo(dateFrom) >= 0 &&
                    pointInterestRate.getExecuteDate().compareTo(dateTo) <= 0) {
                rateChangeListInRange.add(pointInterestRate);
            }
        }
        return rateChangeListInRange;
    }

    private static boolean isRateChangedBetweenDateRange(Date dateFrom, Date dateTo, List<PointInterestRate> actualInterestRates) {
        if (null == actualInterestRates || actualInterestRates.size() == 0) {
            return false;
        }
        for (PointInterestRate pointInterestRate : actualInterestRates) {
            if (pointInterestRate.getExecuteDate().compareTo(dateFrom) >= 0 &&
                    pointInterestRate.getExecuteDate().compareTo(dateTo) <= 0) {
                return true;
            }
        }
        return false;
    }

    private static void updateInterestRateList(BizParametersRepository bizParametersRepository, RateChangePlanRepository rateChangePlanRepository) {
        DevLog.info(OverduePenaltyCalculator.class, "update valid and done rate change plan list to OverduePenaltyCalculator");
        BigDecimal interestFloatRate = bizParametersRepository.findParameterValueByCode(INTEREST_FLOAT_RATE);
        List<RateChangePlan> rateChangePlanDone = rateChangePlanRepository.findRateChangePlanValidAndDone();
        INTEREST_RATE_LIST = RateChangeUtils.convertToPointInterestRateList(interestFloatRate, rateChangePlanDone);
    }

    public static Date getLastExecuteDate() {
        if (INTEREST_RATE_LIST == null || INTEREST_RATE_LIST.size() == 0) {
            return null;
        }
        return INTEREST_RATE_LIST.get(INTEREST_RATE_LIST.size() - 1).getExecuteDate();
    }
}
