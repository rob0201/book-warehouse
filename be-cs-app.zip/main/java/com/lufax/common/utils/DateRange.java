package com.lufax.common.utils;

import com.lufax.common.exception.DateRangeException;
import com.lufax.common.exception.P2PErrorCode;

import java.util.Date;

import static com.lufax.common.utils.DateUtils.startOfToday;

public class DateRange {

    private Date startDate;
    private Date endDate;

    public DateRange(Date startDate, Date endDate) {
        this.startDate = startDate;
        this.endDate = endDate;
    }

    public Date getStartDate() {
        return startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public static DateRange getDateRange(String startDate, String endDate) {
        if (org.apache.commons.lang.StringUtils.isEmpty(startDate) || org.apache.commons.lang.StringUtils.isEmpty(endDate)) {
            throw new DateRangeException(P2PErrorCode.DATE_RANGE_INVALID);
        }

        Date start = DateUtils.parseDate(startDate);
        Date end = DateUtils.parseDate(endDate);
        if (start == null || end == null) {
            throw new DateRangeException(P2PErrorCode.DATE_RANGE_INVALID);
        }

        if (start.after(end)) {
            throw new DateRangeException(P2PErrorCode.START_DATE_AFTER_END_DATE);
        }

        if (end.compareTo(startOfToday()) > 0) {
            throw new DateRangeException(P2PErrorCode.END_DATE_AFTER_YESTERDAY);
        }

        return new DateRange(start, end);
    }
}
