package com.lufax.common.utils;

import static com.lufax.common.web.helper.ConstantsHelper.CMS_DRAW_SEQUENCE_FORMAT;
import static com.lufax.common.web.helper.ConstantsHelper.DATE_STRING_FORMAT;
import static com.lufax.common.web.helper.ConstantsHelper.DATE_TIME_FORMAT;
import static com.lufax.common.web.helper.ConstantsHelper.MATCH_TIME_FORMAT;
import static com.lufax.common.web.helper.ConstantsHelper.MEMBER_SYSTEM_DATE_FORMAT;
import static com.lufax.common.web.helper.ConstantsHelper.XINBAO_DATE_FORMAT;

import java.text.ParseException;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.joda.time.DateTime;

public class DateUtils {

    public final static String DATE_FORMAT_DEFAULT = "yyyy-MM-dd";
    public final static String DATE_FORMAT_SOLIDUS = "yyyy/MM/dd";
    public final static String DATE_FORMAT_COMPACT = "yyyyMMdd";
    public final static String DATE_FORMAT_UTC_DEFAULT = "MM-dd-yyyy";
    public final static String DATE_FORMAT_UTC_SOLIDUS = "MM/dd/yyyy";
    public final static String DATE_FORMAT_TAODA_DIRECTORY = "yyyyMMdd HHmmss";

    public final static String DATE_FORMAT_CHINESE = "yyyy年MM月dd日";
    public final static String DATE_TIME_FORMAT_COMPACT = "yyyyMMdd hhmmss";
    public final static String DATE_TIME_FORMAT_CHINESE = "yyyy年MM月dd日 HH时mm分ss秒";

    public final static String DATE_TIME_FORMAT_DEFAULT = "yyyy-MM-dd HH:mm:ss";
    public final static String DATE_TIME_FORMAT_SOLIDUS = "yyyy/MM/dd HH:mm:ss";
    public final static String DATE_TIME_FORMAT_UTC_DEFAULT = "MM-dd-yyyy HH:mm:ss";
    public final static String DATE_TIME_FORMAT_UTC_SOLIDUS = "MM/dd/yyyy HH:mm:ss";

    private static Map<String, String> dateFormatRegisterMap = new HashMap<String, String>();
    private static Map<String, SimpleDateFormat> dateFormatMap = new HashMap<String, SimpleDateFormat>();

    static {
        //各种日期格式注册，有新需要请在此处添加 ，无需其它改动
        dateFormatRegisterMap.put(DATE_FORMAT_COMPACT, "^\\d{8}$");
        dateFormatRegisterMap.put(DATE_FORMAT_DEFAULT, "^\\d{4}-\\d{1,2}-\\d{1,2}$");
        dateFormatRegisterMap.put(DATE_FORMAT_SOLIDUS, "^\\d{4}/\\d{1,2}/\\d{1,2}$");
        dateFormatRegisterMap.put(DATE_FORMAT_UTC_DEFAULT, "^\\d{1,2}-\\d{1,2}-\\d{4}$");
        dateFormatRegisterMap.put(DATE_FORMAT_UTC_SOLIDUS, "^\\d{1,2}/\\d{1,2}/\\d{4}$");
        dateFormatRegisterMap.put(DATE_TIME_FORMAT_DEFAULT, "^\\d{4}-\\d{1,2}-\\d{1,2}\\s*\\d{1,2}:\\d{1,2}:\\d{1,2}$");
        dateFormatRegisterMap.put(DATE_TIME_FORMAT_SOLIDUS, "^\\d{4}/\\d{1,2}/\\d{1,2}\\s*\\d{1,2}:\\d{1,2}:\\d{1,2}$");
        dateFormatRegisterMap.put(DATE_TIME_FORMAT_UTC_DEFAULT, "^\\d{1,2}-\\d{1,2}-\\d{4}\\s*\\d{1,2}:\\d{1,2}:\\d{1,2}$");
        dateFormatRegisterMap.put(DATE_TIME_FORMAT_UTC_SOLIDUS, "^\\d{1,2}/\\d{1,2}/\\d{4}\\s*\\d{1,2}:\\d{1,2}:\\d{1,2}$");

        dateFormatMap.put(DATE_FORMAT_DEFAULT, new SimpleDateFormat(DATE_FORMAT_DEFAULT));
        dateFormatMap.put(DATE_FORMAT_SOLIDUS, new SimpleDateFormat(DATE_FORMAT_SOLIDUS));
        dateFormatMap.put(DATE_FORMAT_COMPACT, new SimpleDateFormat(DATE_FORMAT_COMPACT));
        dateFormatMap.put(DATE_FORMAT_UTC_DEFAULT, new SimpleDateFormat(DATE_FORMAT_UTC_DEFAULT));
        dateFormatMap.put(DATE_FORMAT_UTC_SOLIDUS, new SimpleDateFormat(DATE_FORMAT_UTC_SOLIDUS));
        dateFormatMap.put(DATE_TIME_FORMAT_DEFAULT, new SimpleDateFormat(DATE_TIME_FORMAT_DEFAULT));
        dateFormatMap.put(DATE_TIME_FORMAT_SOLIDUS, new SimpleDateFormat(DATE_TIME_FORMAT_SOLIDUS));
        dateFormatMap.put(DATE_TIME_FORMAT_UTC_DEFAULT, new SimpleDateFormat(DATE_TIME_FORMAT_UTC_DEFAULT));
        dateFormatMap.put(DATE_TIME_FORMAT_UTC_SOLIDUS, new SimpleDateFormat(DATE_TIME_FORMAT_UTC_SOLIDUS));
    }

    public static String format(String formatString, Date date) {
        return new SimpleDateFormat(formatString).format(date);
    }


    public static Date parse(String formatString, String dateString) {
        try {
            return new SimpleDateFormat(formatString).parse(dateString);
        } catch (ParseException e) {
            DevLog.debug(DateUtils.class, "Failed to parse[%s] to date", formatString);
            throw new RuntimeException(e);
        }
    }
    
    public static Date parseStrToDate(String formatString, String dateString) {
        try {
            return new SimpleDateFormat(formatString).parse(dateString);
        } catch (ParseException e) {
            DevLog.debug(DateUtils.class, "Failed to parse[%s] to date", formatString);
            throw new RuntimeException(e);
        }
    }


    public static long parseDateToLong(String date) {
        date = date.replace("-", "");
        Long result = Long.valueOf(date);
        return result;
    }

    public static Date parseDate(String src) {

        if (EmptyChecker.isEmpty(src)) {
            return null;
        }

        return parseDate(src, DATE_FORMAT_DEFAULT);
    }

//    public static Date parseDate(String src, String dateTemplate) {
//
//        if (EmptyChecker.isEmpty(src)) {
//            return null;
//        }
//
//        try {
//            return getSimpleDateFormat(dateTemplate).parse(src);
//        } catch (ParseException e) {
//            throw new RuntimeException(String.format("unsupported date template:%s", src), e);
//        }
//    }

    public static <T> T parseDate(String src, Class<T> dateClazz) {

        if (EmptyChecker.isEmpty(src)) {
            return null;
        }

        return convertDate(parseDate(src), dateClazz);
    }

    public static <T> T parseDate(String src, String dateTemplate, Class<T> dateClazz) {

        if (EmptyChecker.isEmpty(src)) {
            return null;
        }

        return convertDate(parseDate(src, dateTemplate), dateClazz);
    }

    public static Date fishForParseDate(String src) {

        if (EmptyChecker.isEmpty(src)) {
            return null;
        }

        return fishForParseDate(src, Date.class);
    }

    public static <T> T fishForParseDate(Object obj, Class<T> dateClazz) {

        if (EmptyChecker.isEmpty(obj)) {
            return null;
        }

        if (Date.class.isAssignableFrom(obj.getClass())) {
            return convertDate((Date) obj, dateClazz);
        }

        if (DateTime.class.isAssignableFrom(obj.getClass())) {
            return convertDate((DateTime) obj, dateClazz);
        }

        String src = obj.toString();

        for (Map.Entry<String, String> entry : dateFormatRegisterMap.entrySet()) {
            if (src.matches(entry.getValue())) {
                return convertDate(parseDate(src, entry.getKey()), dateClazz);
            }
        }

        throw new RuntimeException(String.format("unsupported date string format:%s", src));
    }

    public static boolean isDate(Object obj) {

        if (EmptyChecker.isEmpty(obj)) {
            return false;
        }
        return isDateClass(obj.getClass());
    }

    public static boolean isDateClass(Class<?> clazz) {
        return (Date.class.isAssignableFrom(clazz) || DateTime.class.isAssignableFrom(clazz));
    }

    public static String formatDate(Date date) {

        if (EmptyChecker.isEmpty(date)) {
            return null;
        }

        return formatDate(date, DATE_FORMAT_DEFAULT);
    }
    public static String formatDateToSeconds(Date date){
          if (EmptyChecker.isEmpty(date)) {
            return null;
        }

        return formatDate(date, DATE_TIME_FORMAT_DEFAULT);
    }
    public static String formatDate(Date date, String dateTemplate) {
        if (EmptyChecker.isEmpty(date) || EmptyChecker.isEmpty(dateTemplate)) {
            return null;
        }

        return getSimpleDateFormat(dateTemplate).format(date);
    }

    public static <T> T convertDate(Date src, Class<T> dateClazz) {

        if (EmptyChecker.isEmpty(src)) {
            return null;
        }

        try {

            return dateClazz.getConstructor(long.class).newInstance(src.getTime());
        } catch (Exception e) {
            String errorMessage = String.format("unsupported date type:%s", dateClazz.getName());
            com.lufax.common.utils.DevLog.error(DateUtils.class, errorMessage);
            throw new RuntimeException(errorMessage, e);
        }
    }

    public static <T> T convertDate(DateTime src, Class<T> dateClazz) {

        if (EmptyChecker.isEmpty(src)) {
            return null;
        }

        try {

            return dateClazz.getConstructor(long.class).newInstance(src.getMillis());
        } catch (Exception e) {
            String errorMessage = String.format("unsupported date type:%s", dateClazz.getName());
            com.lufax.common.utils.DevLog.error(DateUtils.class, errorMessage);
            throw new RuntimeException(errorMessage, e);
        }
    }

    public static SimpleDateFormat getSimpleDateFormat(String dateTemplate) {
        synchronized (dateFormatMap) {
            if (!dateFormatMap.containsKey(dateTemplate)) {
                dateFormatMap.put(dateTemplate, new SimpleDateFormat(dateTemplate));
            }

            return dateFormatMap.get(dateTemplate);
        }
    }

    private static long render(long i, int j, int k) {
        return (i + (i > 0 ? j : -j)) / k;
    }

    public static long diffSecond(Date start, Date end) {
        return render(end.getTime() - start.getTime(), 999, 1000);
    }

    public static long diffMinute(Date end) {
        return diffMinute(new Date(System.currentTimeMillis()), end);
    }

    public static long diffMinute(Date start, Date end) {
        return render(diffSecond(start, end), 59, 60);
    }

    public static long diffHour(Date start, Date end) {
        return render(diffMinute(start, end), 59, 60);
    }

    public static long diffDay(Date start, Date end) {
        return offset(start, end, Calendar.DAY_OF_YEAR);
    }

    public static long diffMonth(Date start, Date end) {
        return offset(start, end, Calendar.MONTH) + diffYear(start, end);
    }

    public static long diffYear(Date start, Date end) {
        Calendar s = Calendar.getInstance();
        Calendar e = Calendar.getInstance();

        s.setTime(start);
        e.setTime(end);

        return e.get(Calendar.YEAR) - s.get(Calendar.YEAR);
    }

    private static long offset(Date start, Date end, int offsetCalendarField) {

        boolean bool = start.before(end);
        long rtn = 0;
        Calendar s = Calendar.getInstance();
        Calendar e = Calendar.getInstance();

        s.setTime(bool ? start : end);
        e.setTime(bool ? end : start);

        rtn -= s.get(offsetCalendarField);
        rtn += e.get(offsetCalendarField);

        while (s.get(Calendar.YEAR) < e.get(Calendar.YEAR)) {
            rtn += s.getActualMaximum(offsetCalendarField);
            s.add(Calendar.YEAR, 1);
        }

        return bool ? rtn : -rtn;
    }

    public static Date add(Date date, int n, int calendarField) {
        Calendar c = Calendar.getInstance();
        c.setTime(date);
        c.add(calendarField, n);

        return c.getTime();
    }

//    public static void main(String[] args) {
//        DateUtils du = new DateUtils();
//
//        for (Field f : DateUtils.class.getDeclaredFields()) {
//            f.setAccessible(true);
//
//            try {
//                System.out.print(f.getName());
//                System.out.print(" = ");
//                System.out.println(f.get(du));
//            } catch (IllegalAccessException e) {
//            }
//        }
//
//        System.out.println((-2 - 999) / 1000);
//        System.out.println((2 + 999) / 1000);
//        System.out.println(diffMinute(DateUtils.parseDate("2011-11-19")));
//        System.out.println(diffDay(DateUtils.parseDate("2010-10-10"), DateUtils.parseDate("2020-10-10")));
//        System.out.println(diffMonth(DateUtils.parseDate("2010-10-10"), DateUtils.parseDate("2020-10-10")));
//    }

    public static String formatDateAsCmsDrawSequence(Date date) {
        return formatDate(date, CMS_DRAW_SEQUENCE_FORMAT);
    }

    public static DateTime parseAsDateTime(String date) {
        return new DateTime(parseDate(date));
    }

    public static Date startOfToday() {
        return startOfDay(new Date());
    }


    private static Date parseDate(String dateString, String dateFormat) {
        try {
            return new SimpleDateFormat(dateFormat).parse(dateString, new ParsePosition(0));
        } catch (Exception e) {
        	e.printStackTrace();
            return null;
        }
    }

    public static String formatDateTime(Date date) {
        return (date == null) ? null : formatDate(date, DATE_TIME_FORMAT);
    }

    public static Date parseDateTime(String date) {
        return parseDate(date, DATE_TIME_FORMAT);
    }

    public static String formatDateAsMatchTime(Date date) {
        return formatDate(date, MATCH_TIME_FORMAT);
    }


    public static boolean beforeToday(Date date) {
        return date.compareTo(DateUtils.startOfToday()) < 0;
    }

    public static boolean afterToday(Date date) {
        return date.compareTo(DateUtils.startOfToday()) > 0;
    }

    public static Date startOfDay(Date date) {
        return new DateTime(date).dayOfYear().roundFloorCopy().toDate();
    }

    public static String formatDateAsString(Date date) {
        return formatDate(date, DATE_STRING_FORMAT);
    }

    public static Date endOfToday() {
        return endOfDay(new Date());
    }

    public static Date endOfToday(Date date) {
        return endOfDay(date);
    }

    public static Date endOfDay(Date date) {
        DateTime startDateTime = new DateTime(date).dayOfYear().roundFloorCopy();
        return startDateTime.plusDays(1).minusMillis(1).toDate();
    }

    public static boolean isOnSameDayOfMonth(DateTime datetime, DateTime other) {
        return datetime.getDayOfMonth() == other.getDayOfMonth();
    }

    public static String formatDateForXinbao(Date date) {
        return formatDate(date, XINBAO_DATE_FORMAT);
    }

    public static Date parseXinbaoDateFormat(String dateString) throws ParseException {
        return parseDate(dateString, XINBAO_DATE_FORMAT);
    }


    public static String parseMemberSystemDateFormat(String xinbaoDateFormat) throws ParseException {
        return formatDate(parseXinbaoDateFormat(xinbaoDateFormat), MEMBER_SYSTEM_DATE_FORMAT);
    }

    public static String getYearOfFourBits(Date date) {
        return new DateTime(date).getYear() + "";
    }

    public static String getMonthOfTwoBits(Date date) {
        String month = new DateTime(date).getMonthOfYear() + "";
        if (month.length() == 1) {
            month = "0" + month;
        }
        return month;
    }

    public static String getDayOfTwoBits(Date date) {
        String day = new DateTime(date).getDayOfMonth() + "";
        if (day.length() == 1) {
            day = "0" + day;
        }
        return day;
    }

    public static boolean isMondayToFriday(Date date) {
        int dayOfWeek = new DateTime(date).getDayOfWeek();
        return dayOfWeek != 6 && dayOfWeek != 7;
    }

    public static Date getLastMonthDate(int monthRangge) {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.MONTH, monthRangge);
        return calendar.getTime();
    }

    public static Date getLastDayDate(int DayRangge) {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_MONTH, DayRangge);
        return calendar.getTime();
    }
}
