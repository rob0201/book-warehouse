package com.lufax.common.utils;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.apache.commons.codec.binary.Base64;

public class LoginCheckHelper {

	/**
	 * 生成加密后的密码字符串
	 * 
	 * @param inputPassword
	 * @param userSult
	 * @return
	 */
	public static String createPassword(String inputPassword, String userSult) {
		String code = inputPassword + userSult;
		return encryptBase64(encrypt(code));
	}

	/**
	 * BASE64 加密
	 * 
	 * @param code
	 * @return
	 */
	private static String encryptBase64(byte[] code) {
		return Base64.encodeBase64URLSafeString(code);
	}

	private static byte[] encrypt(String code) {
		MessageDigest md = null;
		try {
			md = MessageDigest.getInstance("MD5");
		} catch (NoSuchAlgorithmException e) {
			return new byte[0];
		}
		return md.digest(code.getBytes());
	}

	public static void main(String[] args) {
		System.out.println(createPassword("111111","asdfasdf"));
	}

}
