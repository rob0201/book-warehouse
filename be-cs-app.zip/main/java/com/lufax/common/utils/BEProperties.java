package com.lufax.common.utils;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class BEProperties {

    @Value("${remote.sme.repaymentRecord.deny}")
    private String smeRepaymentRecordDeny;
    @Value("${reomte.sme.productCount}")
    private String remoteSmeProductCount;
    @Value("${reomte.sme.collectPlan}")
    private String remoteSmeCollectPlan;
    @Value("${reomte.sme.collectPlanDetail}")
    private String remoteSmeCollectPlanDetail;
    @Value("${reomte.sme.productCollectRecord}")
    private String remoteSmeProductCollectRecord;

    // add by zhouchengming606 at 2012-11-5 start
    @Value(value = "${remote.be.authorityProvider.validateUserPermissionUrl}")
    private String validateUserPermissionUrl;
    @Value(value = "${remote.be.user.userRoles}")
    private String beUserRoles;
    @Value(value = "${remote.be.user.all.userRoles}")
    private String beAllUserRoles;
    @Value("${remote.be.menu.root}")
    private String beMenuRoot;
    @Value("${remote.be.menu.menuTree}")
    private String beMenuTreeUrl;
    @Value("${remote.be.user}")
    private String beUser;
    
    
    @Value("${sms.sender.id}")
    private String smsSenderId;

    @Value("${sms.sender.name}")
    private String smsSenderName;

    @Value("${sms.send.series.id}")
    private String smsSendSeriesId;

    @Value("${sms.service.id}")
    private String smsServiceId;

    @Value("${remote.sme}")
    private String smeHost;

    @Value("${xinbao.loans.repayment-details.url}")
    private String xinbaoLoansRepaymentDetailsUrl;

    @Value("${xinbao.loans.repayment-history.url}")
    private String xinbaoLoansRepaymentHistoryUrl;

    @Value("${p2p.loans.prepayment-calculator.url}")
    private String P2PLoansPrepaymentCalculatorUrl;

    @Value("${p2p.investment.collection-history.url}")
    private String P2PInvestmentCollectionHistoryUrl;

    @Value("${p2p.investment.collection-details.url}")
    private String P2PInvestmentCollectionDetailsUrl;
    
    
    // add by zhouchengming606 at 2012-11-5 end

    

    public String getSmeRepaymentRecordDeny() {
		return smeRepaymentRecordDeny;
	}

	public String getXinbaoLoansRepaymentDetailsUrl() {
		return xinbaoLoansRepaymentDetailsUrl;
	}

	public void setXinbaoLoansRepaymentDetailsUrl(String xinbaoLoansRepaymentDetailsUrl) {
		this.xinbaoLoansRepaymentDetailsUrl = xinbaoLoansRepaymentDetailsUrl;
	}

	public String getXinbaoLoansRepaymentHistoryUrl() {
		return xinbaoLoansRepaymentHistoryUrl;
	}

	public void setXinbaoLoansRepaymentHistoryUrl(String xinbaoLoansRepaymentHistoryUrl) {
		this.xinbaoLoansRepaymentHistoryUrl = xinbaoLoansRepaymentHistoryUrl;
	}

	public void setSmeRepaymentRecordDeny(String smeRepaymentRecordDeny) {
		this.smeRepaymentRecordDeny = smeRepaymentRecordDeny;
	}

	public String getSmsSenderId() {
		return smsSenderId;
	}

	public void setSmsSenderId(String smsSenderId) {
		this.smsSenderId = smsSenderId;
	}

	public String getSmsSenderName() {
		return smsSenderName;
	}

	public void setSmsSenderName(String smsSenderName) {
		this.smsSenderName = smsSenderName;
	}

	public String getSmsSendSeriesId() {
		return smsSendSeriesId;
	}

	public void setSmsSendSeriesId(String smsSendSeriesId) {
		this.smsSendSeriesId = smsSendSeriesId;
	}

	public String getSmsServiceId() {
		return smsServiceId;
	}

	public void setSmsServiceId(String smsServiceId) {
		this.smsServiceId = smsServiceId;
	}

	public String getSmeHost() {
		return smeHost;
	}

	public void setSmeHost(String smeHost) {
		this.smeHost = smeHost;
	}

	public String getP2PLoansPrepaymentCalculatorUrl() {
		return P2PLoansPrepaymentCalculatorUrl;
	}

	public void setP2PLoansPrepaymentCalculatorUrl(
			String p2pLoansPrepaymentCalculatorUrl) {
		P2PLoansPrepaymentCalculatorUrl = p2pLoansPrepaymentCalculatorUrl;
	}

	public String getP2PInvestmentCollectionHistoryUrl() {
		return P2PInvestmentCollectionHistoryUrl;
	}

	public void setP2PInvestmentCollectionHistoryUrl(
			String p2pInvestmentCollectionHistoryUrl) {
		P2PInvestmentCollectionHistoryUrl = p2pInvestmentCollectionHistoryUrl;
	}

	public String getP2PInvestmentCollectionDetailsUrl() {
		return P2PInvestmentCollectionDetailsUrl;
	}

	public void setP2PInvestmentCollectionDetailsUrl(
			String p2pInvestmentCollectionDetailsUrl) {
		P2PInvestmentCollectionDetailsUrl = p2pInvestmentCollectionDetailsUrl;
	}

	public void setRemoteSmeProductCount(String remoteSmeProductCount) {
		this.remoteSmeProductCount = remoteSmeProductCount;
	}

	public void setRemoteSmeCollectPlan(String remoteSmeCollectPlan) {
		this.remoteSmeCollectPlan = remoteSmeCollectPlan;
	}

	public void setRemoteSmeCollectPlanDetail(String remoteSmeCollectPlanDetail) {
		this.remoteSmeCollectPlanDetail = remoteSmeCollectPlanDetail;
	}

	public void setRemoteSmeProductCollectRecord(
			String remoteSmeProductCollectRecord) {
		this.remoteSmeProductCollectRecord = remoteSmeProductCollectRecord;
	}

	public void setValidateUserPermissionUrl(String validateUserPermissionUrl) {
		this.validateUserPermissionUrl = validateUserPermissionUrl;
	}

	public void setBeUserRoles(String beUserRoles) {
		this.beUserRoles = beUserRoles;
	}

	public void setBeAllUserRoles(String beAllUserRoles) {
		this.beAllUserRoles = beAllUserRoles;
	}

	public void setBeMenuRoot(String beMenuRoot) {
		this.beMenuRoot = beMenuRoot;
	}

	public void setBeMenuTreeUrl(String beMenuTreeUrl) {
		this.beMenuTreeUrl = beMenuTreeUrl;
	}

	public void setBeUser(String beUser) {
		this.beUser = beUser;
	}

	public String getRemoteSmeProductCount() {
        return remoteSmeProductCount;
    }

    public String getRemoteSmeCollectPlan() {
        return remoteSmeCollectPlan;
    }

    public String getRemoteSmeCollectPlanDetail() {
        return remoteSmeCollectPlanDetail;
    }

    public String getRemoteSmeProductCollectRecord() {
        return remoteSmeProductCollectRecord;
    }

    public String getBeMenuRoot() {
        return beMenuRoot;
    }

    public String getBeMenuTreeUrl() {
        return beMenuTreeUrl;
    }

    public String getBeUserRoles() {
        return beUserRoles;
    }

    public String getBeUser() {
        return beUser;
    }

    public String getBeAllUserRoles() {
        return beAllUserRoles;
    }

    public String getValidateUserPermissionUrl() {
        return validateUserPermissionUrl;
    }
}
