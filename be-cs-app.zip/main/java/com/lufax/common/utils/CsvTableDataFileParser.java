package com.lufax.common.utils;

import com.lufax.jersey.utils.Logger;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;


public class CsvTableDataFileParser extends TableDataFileParser {

	private List<String[]> data = new ArrayList<String[]>();

    private int rows = 0;
    private int columns = 0;

	public CsvTableDataFileParser(String fileName) {
		super(fileName);


        InputStreamReader fr = null;
        BufferedReader br = null;
        try {
            fr = new InputStreamReader(new FileInputStream(file), "GBK");
            br = new BufferedReader(fr);
            String rec = null;
            while ((rec = br.readLine()) != null) {
                String[] argsArr = rec.split(",");
                columns = argsArr.length;
                String[] rowData = new String[columns];
                for (int i = 0; i < columns; i++) {
                    rowData[i] = argsArr[i];
                }
                data.add(rowData);
            }
            rows = data.size();
        } catch (IOException e) {
            Logger.warn(this, "exception occurred when parsing file", e);
        } finally {
            try {
                if (fr != null)
                    fr.close();
                if (br != null)
                    br.close();
            } catch (IOException e) {
                Logger.warn(this, "exception occurred when parsing file", e);
            }
        }
	}

	public int getRows() {
        return rows;
	}

	public Object get(int rowNum, int colNum) {
        if(rowNum >= rows || colNum >= columns){
            return "";
        }
		return data.get(rowNum)[colNum];
	}
	
}
