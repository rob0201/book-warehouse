package com.lufax.common.resources;

import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import com.google.gson.Gson;
import com.lufax.common.metadata.User;
import com.lufax.common.utils.BEProperties;
import com.lufax.common.utils.DevLog;
import com.lufax.jersey.client.JerseyRequestParam;
import com.lufax.jersey.exception.InvokeRemoteServiceException;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.core.InjectParam;

@Path("/authorityProvider")
public class AuthorityProviderResource {

    @InjectParam
    private BEProperties beProperties;
    @InjectParam
    private ServiceProvider serviceProvider;
    
    @GET
    @Path("/validateUser/{userName}")
    @Produces(value = MediaType.APPLICATION_JSON)
    public String getUserInfo(@PathParam("userName") String userName) {

        DevLog.debug(this, String.format("findIndex user is exist or not by user name : [%s]", userName));

        User user = null;
        try {
        	//TODO
//            user = userDAO.findUserByName(userName);
        } catch (Exception e) {
            DevLog.error(this, "Failed to get the user by name [" + userName + "]",e);
            return null;
        }
        return new Gson().toJson(user);
    }

    @GET
    @Path("/validateUserPermissionUrl/{userId}/{sysName}")
    @Produces(value = MediaType.TEXT_PLAIN)
    public String validatePermissionUrls(@PathParam("userId") Long p2pUserId, @PathParam("sysName") String sysName, @QueryParam("requestURI") String requestURI) {
    	String path = String.format(beProperties.getValidateUserPermissionUrl(), p2pUserId, sysName);
		try {
			Map<String,String> param = new HashMap<String,String>(4);
			param.put("requestURI", requestURI);
			JerseyRequestParam jerseyRequestParam = new JerseyRequestParam();
			jerseyRequestParam.setParameters(param);
			ClientResponse clientResponse = serviceProvider.getMgrJerseyService().getInstance(path).withUser(p2pUserId+"").invokeJersey(jerseyRequestParam);
			if (ClientResponse.Status.OK.getStatusCode() == clientResponse.getStatus()) {
				return clientResponse.getEntity(String.class);
			} else {
				DevLog.warn(this, "get user permission url return status code is " + clientResponse.getStatus());
                clientResponse.close();
			}
		} catch (InvokeRemoteServiceException e) {
			DevLog.error(this, "get user permission url, remote invoke error",e);
		}
		return "false";
    }
}
