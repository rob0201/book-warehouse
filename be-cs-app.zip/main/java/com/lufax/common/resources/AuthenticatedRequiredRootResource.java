package com.lufax.common.resources;


import com.lufax.jersey.usercontext.UserContextUtils;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;

public abstract class AuthenticatedRequiredRootResource {
    @Context
    protected HttpServletRequest servletRequest;

    private Long currentUserId;

    protected Long currentUser() {
        if (currentUserId == null) {
            if (null == UserContextUtils.getCurrentUserContext()) {
                currentUserId = (Long) servletRequest.getAttribute("userId");
            } else {
                currentUserId = Long.parseLong(UserContextUtils.getCurrentUserContext().getUserId());
            }
        }
        if (currentUserId == null) {
            throw new WebApplicationException(Response.Status.UNAUTHORIZED);
        }
        return currentUserId;
    }

    protected boolean isQueryForMenu() {
        String path = servletRequest.getRequestURL().toString();
        if (path.indexOf("/menu/") > 0)
            return true;
        else return false;
    }
}
