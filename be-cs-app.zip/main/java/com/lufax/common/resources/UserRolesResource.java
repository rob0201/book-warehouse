package com.lufax.common.resources;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.lufax.common.utils.BEProperties;
import com.lufax.common.utils.DevLog;
import com.lufax.jersey.client.JerseyService;
import com.lufax.jersey.exception.InvokeRemoteServiceException;
import com.sun.jersey.api.client.ClientResponse;

public class UserRolesResource {

    private long userId;
    private BEProperties beProperties;
    private JerseyService mgrJerseyService;

    public UserRolesResource(long userId, ServiceProvider serviceProvider) {
        this.userId = userId;
        this.beProperties = serviceProvider.getBeProperties();
        this.mgrJerseyService = serviceProvider.getMgrJerseyService();
    }

    @GET
    public String getUserRoles() {
        String path = String.format(beProperties.getBeUserRoles(), userId);
        try {
            ClientResponse clientResponse = mgrJerseyService.getInstance(path).invokeJersey();
            DevLog.debug(this, "The invoke [" + path + "] result is [" + clientResponse + "]");
            if (ClientResponse.Status.OK.getStatusCode() == clientResponse.getStatus()) {
            	String result = clientResponse.getEntity(String.class); 
                return result;
            } else {
            	DevLog.warn(this, "get user role return status code is " + clientResponse.getStatus());
                clientResponse.close();
            }
        } catch (InvokeRemoteServiceException e) {
        	DevLog.error(this, "get user roles, remote invoke error",e);
        }
        return "";
        
    }

    @GET
    @Path("/allUserRoles")
    @Produces(value = MediaType.APPLICATION_JSON)
    public String getAllUserRoles(){
        String path = String.format(beProperties.getBeAllUserRoles(), userId);
        try {
            ClientResponse clientResponse = mgrJerseyService.getInstance(path).invokeJersey();
            if (ClientResponse.Status.OK.getStatusCode() == clientResponse.getStatus()) {
            	String result = clientResponse.getEntity(String.class); 
                return result;
            } else {
            	DevLog.warn(this, "get all user role return status code is " + clientResponse.getStatus());
                clientResponse.close();
            }
        } catch (InvokeRemoteServiceException e) {
        	DevLog.error(this, "get all user roles, remote invoke error",e);
        }
        return "";
    }


}
