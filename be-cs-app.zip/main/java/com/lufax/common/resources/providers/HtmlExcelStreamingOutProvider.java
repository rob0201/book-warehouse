package com.lufax.common.resources.providers;

import java.io.BufferedOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import com.lufax.common.utils.DevLog;

public class HtmlExcelStreamingOutProvider extends AbstractExcelStreamingOutProvider {

    public HtmlExcelStreamingOutProvider(String[] headers, String[] headerKeys) {
        super(headers, headerKeys);
    }

    public HtmlExcelStreamingOutProvider(String title, String[] headers, String[] headerKeys) {
        super(title, headers, headerKeys);
    }

    private void setCellValue(StringBuilder sb, Object value) {
        if (value == null) {
            sb.append("<td></td>");
        } else if (value instanceof Date) {
            String targetValue = new SimpleDateFormat("yyyy-MM-dd").format((Date) value);
            sb.append("<td style=\"vnd.ms-excel.numberformat:@\">" + targetValue + "</td>");
        } else {
            sb.append("<td style=\"vnd.ms-excel.numberformat:@\">" + value + "</td>");
        }
    }

    protected void generateExcelByteByDataObject(List data) {
        StringBuilder sb = this.buildFileHeader();

        try {
            BufferedOutputStream os = new BufferedOutputStream(new FileOutputStream(file));
            os.write(sb.toString().getBytes());
            sb.delete(0, sb.length());

            //append header
            if (this.header != EMPTY) {
                sb.append("<tr>");
                for (int j = 0; j < this.header.length; j++) {
                    sb.append("<td>" + header[j] + "</td>");
                }
                sb.append("</tr>");
            }

            //append content
            for (int i = 0; i < data.size(); i++) {
                sb.append("<tr>");
                for (int j = 0; j < this.headerKey.length; j++) {
                    Object object = data.get(i);
                    Object value = getValue(object, this.headerKey[j]);
                    setCellValue(sb, value);
                }
                sb.append("</tr>");
                if (i % 20 == 0) {
                    os.write(sb.toString().getBytes());
                    sb.delete(0, sb.length());
                }
            }


            //append /body /html
            sb.append("</table></body></html>");
            os.write(sb.toString().getBytes());
            os.flush();
            sb = null;


        } catch (Exception e) {
            DevLog.error(this, "Exception happen", e);
        }
    }

    protected void generateExcelByteByDataMap(List<Map> data) {
        StringBuilder sb = buildFileHeader();

        try {
            BufferedOutputStream os = new BufferedOutputStream(new FileOutputStream(file));
            os.write(sb.toString().getBytes());
            sb.delete(0, sb.length());

            //append header
            if (this.header != EMPTY) {
                sb.append("<tr>");
                for (int j = 0; j < this.header.length; j++) {
                    sb.append("<td>" + header[j] + "</td>");
                }
                sb.append("</tr>");
            }

            //append content
            for (int i = 0; i < data.size(); i++) {
                sb.append("<tr>");
                for (int j = 0; j < this.headerKey.length; j++) {
                    Object value = data.get(i).get(this.headerKey[j]);
                    setCellValue(sb, value);
                }
                sb.append("</tr>");
                if (i % 20 == 0) {
                    os.write(sb.toString().getBytes());
                    sb.delete(0, sb.length());
                }
            }


            //append /body /html
            sb.append("</table></body></html>");
            os.write(sb.toString().getBytes());
            os.flush();
            sb = null;


        } catch (Exception e) {
        	DevLog.error(this, "Exception happen", e);
        }
    }

    private StringBuilder buildFileHeader() {
        StringBuilder sb = new StringBuilder();

        //append html head  body
        sb.append("<html xmlns:x=\"urn:schemas-microsoft-com:office:excel\">\n" +
                "<head>\n" +
                "<meta http-equiv=\"Content-Type\" content=\"text/html;charset=gb2312\">\n" +
                "    <xml>\n" +
                "        <x:ExcelWorkbook>\n" +
                "            <x:ExcelWorksheets>\n" +
                "                <x:ExcelWorksheet>\n" +
                "                    <x:Name>报表</x:Name>\n" +
                "                    <x:WorksheetOptions>\n" +
                "                        <x:ProtectContents>False</x:ProtectContents>\n" +
                "                        <x:ProtectObjects>False</x:ProtectObjects>\n" +
                "                        <x:ProtectScenarios>False</x:ProtectScenarios>\n" +
                "                    </x:WorksheetOptions>\n" +
                "                </x:ExcelWorksheet>\n" +
                "            </x:ExcelWorksheets>\n" +
                "            <x:ProtectStructure>False</x:ProtectStructure>\n" +
                "            <x:ProtectWindows>False</x:ProtectWindows>\n" +
                "        </x:ExcelWorkbook>\n" +
                "    </xml>\n" +
                "</head>\n" +
                "<body>\n" +
                "<table border=\"1\">");

//        //append title
//        sb.append("<tr><td>" + title + "</td></tr>");

        return sb;
    }
}
