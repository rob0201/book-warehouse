package com.lufax.common.resources.providers;

import javax.ws.rs.core.StreamingOutput;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public abstract class StreamingOutputProvider implements StreamingOutput {

    public void write(OutputStream output) throws IOException {
        InputStream fileInputStream = getInputStream();

        int length;
        byte[] buffer = new byte[1000];
        while ((length = fileInputStream.read(buffer)) != -1) {
            output.write(buffer, 0, length);
        }
        output.flush();
        fileInputStream.close();
        output.close();
    }

    protected abstract InputStream getInputStream() throws IOException;
}
