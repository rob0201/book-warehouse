package com.lufax.common.resources.providers;


import java.io.*;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import com.lufax.common.utils.DevLog;

abstract public class AbstractExcelStreamingOutProvider extends StreamingOutputProvider {

    protected File file;
    protected static String fileRootPath = new File(".").getAbsolutePath().replace("\\", "/");

    protected String title;
    protected String[] header;
    protected String[] headerKey;

    protected static final String[] EMPTY = new String[0];

    private AbstractExcelStreamingOutProvider() {
    }

    public AbstractExcelStreamingOutProvider(String[] headers, String[] headerKeys) {
        this.title = "default";
        this.addHeader(headers, headerKeys);
    }

    public AbstractExcelStreamingOutProvider(String title, String[] headers, String[] headerKeys) {
        this.title = title;
        this.addHeader(headers, headerKeys);
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getTitle() {
        return title;
    }

    /**
     * set Header and Header Key like ({"产品编码","产品名称"},{"PRODUCT_CODE","PRODUCT_NAME"}) or like  ({"产品编码","产品名称"},{"code","name"})
     *
     * @param headers    the title of the table
     * @param headerKeys the key value of Map or the field in Onject
     */
    private void addHeader(String[] headers, String[] headerKeys) {
        if (headers == null || headers.length == 0) {
            this.header = EMPTY;
        }

        if (headerKeys == null || headerKeys.length == 0) {
            this.headerKey = EMPTY;
            return;
        }

        int len;
        if (this.header == EMPTY) {
            len = headerKeys.length;
            this.headerKey = new String[len];
            System.arraycopy(headerKeys, 0, this.headerKey, 0, len);
        } else {
            len = headers.length < headerKeys.length ? headers.length : headerKeys.length;
            this.header = new String[len];
            this.headerKey = new String[len];
            System.arraycopy(headers, 0, this.header, 0, len);
            System.arraycopy(headerKeys, 0, this.headerKey, 0, len);
        }
    }

    protected String getFileName() {
        String fileName = "test" + UUID.randomUUID().toString() + ".xls";
        return fileName;
    }

    protected InputStream getInputStream() throws IOException {
        return new FileInputStream(file);
    }

    public void generateFileDataWithObject(List data) {
        initFile();
        generateExcelByteByDataObject(data);
    }

    public void generateFileDataWithMap(List<Map> data) {
        initFile();
        generateExcelByteByDataMap(data);
    }

    private void initFile() {
        if (file != null) return;

        file = new File(fileRootPath + "download/" + getFileName());
        OutputStream os = null;
        if (!file.exists()) {
            if (!file.getParentFile().exists()) {
                file.getParentFile().mkdir();
            }
            try {
                file.createNewFile();
            } catch (IOException e) {
                DevLog.error(this, "Failed to create new file", e);
            }
        }
    }

    protected Object getValue(Object object, String fieldName) {

        Object value = null;
        Method[] methods = object.getClass().getMethods();
        for (Method m : methods) {
            if (m.getName().equalsIgnoreCase("get" + fieldName)) {
                try {
                    return m.invoke(object);
                } catch (Exception e) {
                	DevLog.error(this, "Failed to get value from object [" + object + "] by fieldName [" + fieldName + "]", e);
                }
            }
        }
        return value;
    }

    abstract protected void generateExcelByteByDataMap(List<Map> data);

    abstract protected void generateExcelByteByDataObject(List data);
}
