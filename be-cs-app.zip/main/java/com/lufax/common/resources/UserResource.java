package com.lufax.common.resources;

import javax.ws.rs.Path;

public class UserResource {

    private Long p2pUserId;
    private ServiceProvider serviceProvider;

    public UserResource(Long p2pUserId, ServiceProvider serviceProvider) {
        this.p2pUserId = p2pUserId;
        this.serviceProvider = serviceProvider;
    }

    @Path("/menu")
    public MenuResource getMenu() {
        return new MenuResource(p2pUserId, serviceProvider);
    }

    @Path("/userRoles")
    public UserRolesResource getRoles() {
        return new UserRolesResource(p2pUserId, serviceProvider);
    }
}
