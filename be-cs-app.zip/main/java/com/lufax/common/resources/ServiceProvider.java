package com.lufax.common.resources;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.lufax.common.domain.account.repository.AccountRepository;
import com.lufax.common.domain.account.repository.TransactionHistoryRepository;
import com.lufax.common.domain.account.service.AccountService;
import com.lufax.common.domain.funds.repository.CmsCapitalStatementRepository;
import com.lufax.common.domain.funds.repository.CmsVirementBatchRepository;
import com.lufax.common.domain.product.repository.AdminOperationLogRepository;
import com.lufax.common.domain.product.repository.ProductHistoryRepository;
import com.lufax.common.domain.repository.ASGuaranteedNoteRepository;
import com.lufax.common.domain.repository.ASLoanRequestRepository;
import com.lufax.common.domain.repository.BizParametersRepository;
import com.lufax.common.domain.repository.BranchBankRepository;
import com.lufax.common.domain.repository.CollectionPlanRepository;
import com.lufax.common.domain.repository.CollectionRecordRepository;
import com.lufax.common.domain.repository.InvestmentRepository;
import com.lufax.common.domain.repository.InvestmentRequestRepository;
import com.lufax.common.domain.repository.LoanRepository;
import com.lufax.common.domain.repository.LoanRequestRepository;
import com.lufax.common.domain.repository.MemberCustomerRepository;
import com.lufax.common.domain.repository.RechargeRecordRepository;
import com.lufax.common.domain.repository.RepaymentOperationRepository;
import com.lufax.common.domain.repository.RepaymentPlanRepository;
import com.lufax.common.domain.repository.RepaymentRecordRepository;
import com.lufax.common.domain.repository.SystemFundRecordRepository;
import com.lufax.common.domain.repository.TBankCodeRepository;
import com.lufax.common.domain.repository.TBankRepository;
import com.lufax.common.domain.repository.TradeContractRepository;
import com.lufax.common.domain.repository.UserRepository;
import com.lufax.common.domain.repository.WithdrawRecordRepository;
import com.lufax.common.facade.P2PRemoteServiceFacade;
import com.lufax.common.service.BranchBankService;
import com.lufax.common.service.LoanService;
import com.lufax.common.utils.BEProperties;
import com.lufax.common.utils.UserHelper;
import com.lufax.customerService.dao.BuyRequestPoolDAO;
import com.lufax.customerService.dao.CollectionPlanDAO;
import com.lufax.customerService.dao.ExtProductSMEDAO;
import com.lufax.customerService.dao.InvestContractDAO;
import com.lufax.customerService.domain.repository.RareWordsRespository;
import com.lufax.customerService.service.AnShuoRemoteInterfaceCallService;
import com.lufax.customerService.service.CustomerOperationsLogService;
import com.lufax.customerService.service.CustomerServiceInvestmentService;
import com.lufax.customerService.service.P2pRemoteInterfaceCallService;
import com.lufax.customerService.service.PrepaymentService;
import com.lufax.customerService.service.RareWordsService;
import com.lufax.customerService.service.RepaymentService;
import com.lufax.customerService.service.SmeRemoteInterfaceCallService;
import com.lufax.customerService.service.XinbaoRemoteInterfaceCallService;
import com.lufax.jersey.client.JerseyService;
import com.lufax.sms.service.SmsService;
import com.sun.jersey.api.core.InjectParam;

@Component
public class ServiceProvider {

    @InjectParam
    private UserRepository userRepository;

    @InjectParam
    private AccountRepository accountRepository;

    @InjectParam
    private LoanRequestRepository loanRequestRepository;

    @InjectParam
    private InvestmentRequestRepository investmentRequestRepository;

    @InjectParam
    private LoanRepository loanRepository;

    @InjectParam
    private InvestmentRepository investmentRepository;

    @InjectParam
    private RechargeRecordRepository rechargeRecordRepository;


    @InjectParam
    private RepaymentRecordRepository repaymentRecordRepository;

    @InjectParam
    private RepaymentPlanRepository repaymentPlanRepository;


    @InjectParam
    private WithdrawRecordRepository withdrawalsRecordRepository;

    @InjectParam
    private PrepaymentService prepaymentService;


    @InjectParam
    private TransactionHistoryRepository transactionHistoryRepository;

    @InjectParam
    private TBankRepository tBankRepository;

    @InjectParam
    private TBankCodeRepository tBankCodeRepository;

    @InjectParam
    private BizParametersRepository bizParametersRepository;

    @InjectParam
    private BEProperties p2PProperties;

    @InjectParam
    private CollectionPlanRepository collectionPlanRepository;

    @InjectParam
    private CollectionRecordRepository collectionRecordRepository;

    @InjectParam
    private RepaymentService repaymentService;

    @InjectParam
    private CustomerOperationsLogService CustomerOperationsLogService;

    @InjectParam
    private SmsService smsService;

    @InjectParam
    private CmsCapitalStatementRepository cmsCapitalStatementRepository;


    @InjectParam
    private ProductHistoryRepository productHistoryRepository;

    @InjectParam
    private SystemFundRecordRepository systemFundRecordRepository;

    @InjectParam
    private CmsVirementBatchRepository cmsVirementBatchRepository;
    @InjectParam
    private TradeContractRepository tradeContractRepository;
    @InjectParam
    private AdminOperationLogRepository adminOperationLogRepository;

    @InjectParam
    private UserHelper userHelper;

    @InjectParam
    private SmeRemoteInterfaceCallService smeRemoteInterfaceCallService;

    @InjectParam
    private LoanService loanService;

    @InjectParam
    private P2pRemoteInterfaceCallService p2pRemoteInterfaceCallService;

    @InjectParam
    private RareWordsService rareWordsService;

    @InjectParam
    private RareWordsRespository rareWordsRespository;


    @InjectParam
    private BranchBankRepository branchBankRepository;

    @InjectParam
    private BranchBankService branchBankService;
    @InjectParam
    private AccountService accountService;

    @InjectParam
    private RepaymentOperationRepository repaymentOperationRepository;

    @InjectParam
    private BEProperties beProperties;

    @Autowired
    @Qualifier("p2pJerseyService")
    private JerseyService p2pJerseyService;

    @Autowired
    @Qualifier("smeJerseyService")
    private JerseyService smeJerseyService;

    @Autowired
    @Qualifier("mgrJerseyService")
    private JerseyService mgrJerseyService;

    @InjectParam
    private CustomerServiceInvestmentService customerServiceInvestmentService;

    @InjectParam
    private BuyRequestPoolDAO buyRequestPoolDAO;

    @InjectParam
    private CollectionPlanDAO collectionPlanDAO;

    @InjectParam
    private ExtProductSMEDAO extProductSMEDAO;

    @InjectParam
    private InvestContractDAO investContractDAO;
    
    @InjectParam
    private XinbaoRemoteInterfaceCallService xinbaoRemoteInterfaceCallService;
    @InjectParam
    private MemberCustomerRepository memberCustomerRepository;
    
    @InjectParam
    private AnShuoRemoteInterfaceCallService anShuoRemoteInterfaceCallService;
    
    @InjectParam
    private ASLoanRequestRepository asLoanRequestRepository;
    
    @InjectParam
    private P2PRemoteServiceFacade p2pAppService;
    
    @InjectParam
    private ASGuaranteedNoteRepository asGuaranteedNoteRepository;
    
    
    
    
    


    public ASGuaranteedNoteRepository getAsGuaranteedNoteRepository() {
		return asGuaranteedNoteRepository;
	}

	public P2PRemoteServiceFacade getP2pAppService() {
		return p2pAppService;
	}

	public ASLoanRequestRepository getAsLoanRequestRepository() {
		return asLoanRequestRepository;
	}

	public AnShuoRemoteInterfaceCallService getAnShuoRemoteInterfaceCallService() {
		return anShuoRemoteInterfaceCallService;
	}

	public XinbaoRemoteInterfaceCallService getXinbaoRemoteInterfaceCallService() {
		return xinbaoRemoteInterfaceCallService;
	}

	public InvestContractDAO getInvestContractDAO() {
        return investContractDAO;
    }

    public WithdrawRecordRepository getWithdrawalsRecordRepository() {
        return withdrawalsRecordRepository;
    }

    public UserRepository getUserRepository() {
        return userRepository;
    }

    public LoanRequestRepository getLoanRequestRepository() {
        return loanRequestRepository;
    }

    public InvestmentRequestRepository getInvestmentRequestRepository() {
        return investmentRequestRepository;
    }

    public LoanRepository getLoanRepository() {
        return loanRepository;
    }

    public InvestmentRepository getInvestmentRepository() {
        return investmentRepository;
    }

    public RechargeRecordRepository getRechargeRecordRepository() {
        return rechargeRecordRepository;
    }

    public RepaymentPlanRepository getRepaymentPlanRepository() {
        return repaymentPlanRepository;
    }

    public PrepaymentService getPrepaymentService() {
        return prepaymentService;
    }


    public BEProperties getBEProperties() {
        return p2PProperties;
    }

    public TBankCodeRepository gettBankCodeRepository() {
        return tBankCodeRepository;
    }

    public BizParametersRepository getBizParametersRepository() {
        return bizParametersRepository;
    }

    public CollectionPlanRepository getCollectionPlanRepository() {
        return collectionPlanRepository;
    }

    public CustomerOperationsLogService getCustomerOperationsLogService() {
        return CustomerOperationsLogService;
    }


    public SmsService getSmsService() {
        return smsService;
    }


    public TradeContractRepository getTradeContractRepository() {
        return tradeContractRepository;
    }


    public SmeRemoteInterfaceCallService getSmeRemoteInterfaceCallService() {
        return smeRemoteInterfaceCallService;
    }

    public CustomerServiceInvestmentService getCustomerServiceInvestmentService() {
        return customerServiceInvestmentService;
    }


    public P2pRemoteInterfaceCallService getP2pRemoteInterfaceCallService() {
        return p2pRemoteInterfaceCallService;
    }


    public RareWordsService getRareWordsService() {
        return rareWordsService;
    }


    public BEProperties getBeProperties() {
        return beProperties;
    }


    public JerseyService getP2pJerseyService() {
        return p2pJerseyService;
    }

    public JerseyService getSmeJerseyService() {
        return smeJerseyService;
    }


    public BuyRequestPoolDAO getBuyRequestPoolDAO() {
        return buyRequestPoolDAO;
    }


    public CollectionPlanDAO getCollectionPlanDAO() {
        return collectionPlanDAO;
    }

    public ExtProductSMEDAO getExtProductSMEDAO() {
        return extProductSMEDAO;
    }


    public JerseyService getMgrJerseyService() {
        return mgrJerseyService;
    }

	public TransactionHistoryRepository getTransactionHistoryRepository() {
		return transactionHistoryRepository;
	}

    public MemberCustomerRepository getMemberCustomerRepository() {
        return memberCustomerRepository;
    }

    public void setMemberCustomerRepository(MemberCustomerRepository memberCustomerRepository) {
        this.memberCustomerRepository = memberCustomerRepository;
    }
}
