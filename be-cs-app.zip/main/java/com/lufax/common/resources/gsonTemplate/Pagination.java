package com.lufax.common.resources.gsonTemplate;

public class Pagination {
    private int totalPage;
    private int prePage;
    private int nextPage;
    private int currentPage;
    private int pageSize;
    private Object data;
    private long totalCount;

    public Pagination(int pageSize, long totalCount, int pageNum, Object data) {
        this.pageSize = pageSize;
        this.data = data;
        this.totalCount = totalCount;
        this.totalPage = (int) Math.ceil((double) totalCount / (double) pageSize);
        this.currentPage = Math.min(totalPage, Math.max(1, pageNum));
        this.prePage = Math.max(1, this.currentPage - 1);
        this.nextPage = Math.min(totalPage, this.currentPage + 1);
    }

    public Object getData() {
        return data;
    }

    public int getTotalPage() {
        return totalPage;
    }

    public int getNextPage() {
        return nextPage;
    }

    public int getPrePage() {
        return prePage;
    }

    public int getCurrentPage() {
        return currentPage;
    }

    public int getPageSize() {
        return pageSize;
    }

	public long getTotalCount() {
		return totalCount;
	}
    
}
