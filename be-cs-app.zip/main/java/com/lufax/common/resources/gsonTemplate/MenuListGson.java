package com.lufax.common.resources.gsonTemplate;

import com.lufax.common.metadata.Menu;

import java.util.List;

public class MenuListGson {
    private List<Menu> menuRootList;

    public List<Menu> getMenuRootList() {
        return menuRootList;
    }

    public void setMenuRootList(List<Menu> menuRootList) {
        this.menuRootList = menuRootList;
    }
}
