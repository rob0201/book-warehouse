package com.lufax.common.resources.gsonTemplate;

import java.util.ArrayList;
import java.util.List;

import com.lufax.common.utils.DevLog;

public class PaginationGson {
	private long totalCount;
    private int totalPage;
    private int prePage;
    private int nextPage;
    private int currentPage;
    private List data = new ArrayList();

    public PaginationGson(int pageLimit, long totalCount, int requestPage) {
    	this.totalCount = totalCount;
        this.totalPage = (int) Math.ceil((double) totalCount / (double) pageLimit);
        this.currentPage = caculateCurrentPage(requestPage);
        this.prePage = (this.currentPage > 1) ? this.currentPage - 1 : 0;
        this.nextPage = (totalPage > this.currentPage) ? this.currentPage + 1 : totalPage;
    }

    public void setData(List data) {
        this.data = data;
    }

    public int getTotalPage() {
        return totalPage;
    }

    private int caculateCurrentPage(int requestPage) {
        int smallestPage = 1;
        try {
            return Math.min(totalPage, Math.max(smallestPage, requestPage));
        } catch (Exception e) {
            DevLog.error(this, String.format("Invalid page num (%d)", requestPage), e);
            return smallestPage;
        }
    }

    public int getCurrentPage() {
        return currentPage;
    }

    public List getData() {
        return data;
    }

    public int getNextPage() {
        return nextPage;
    }

    public long getTotalCount() {
		return totalCount;
	}

	public int getPrePage() {
        return prePage;
    }
}
