package com.lufax.common.resources;

public enum LinkRelationType {
    RELATED,UNKNOWN;
    public static LinkRelationType getLinkRelationTypeByName(String name){
        LinkRelationType[] linkRelationTypes=LinkRelationType.values();
        for(LinkRelationType linkRelationType:linkRelationTypes)
            if(linkRelationType.name().equalsIgnoreCase(name))
                return linkRelationType;
        return UNKNOWN;

    }
}
