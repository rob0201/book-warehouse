package com.lufax.common.resources;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.google.gson.Gson;
import com.lufax.common.resources.gsonTemplate.MenuListGson;
import com.lufax.common.utils.BEProperties;
import com.lufax.common.utils.DevLog;
import com.lufax.common.utils.EmptyChecker;
import com.lufax.jersey.client.JerseyService;
import com.lufax.jersey.exception.InvokeRemoteServiceException;
import com.lufax.jersey.usercontext.UserContext;
import com.lufax.jersey.usercontext.UserContextUtils;
import com.sun.jersey.api.client.ClientResponse;


public class MenuResource {

    private long p2pUserId;
    private JerseyService mgrJerseyService;
    private BEProperties beProperties;

    public MenuResource(long p2pUserId, ServiceProvider serviceProvider) {
        this.p2pUserId = p2pUserId;
        this.mgrJerseyService = serviceProvider.getMgrJerseyService();
        this.beProperties = serviceProvider.getBeProperties();
    }

    @GET
    @Path("/menuRoot")
    @Produces(value = MediaType.APPLICATION_JSON)
    public String getAccessMenuRoot() {

        String path = String.format(beProperties.getBeMenuRoot(), p2pUserId);

        UserContext uc = new UserContext(p2pUserId + "");
        UserContextUtils.setCurrentUserContext(uc);

        ClientResponse clientResponse = null;
        try {
            clientResponse = mgrJerseyService.getInstance(path).invokeJersey();
            if (ClientResponse.Status.OK.getStatusCode() == clientResponse.getStatus()) {
                String menuList = clientResponse.getEntity(String.class);
                return menuList;
            } else {
                DevLog.warn(this, "get menu root return status code is " + clientResponse.getStatus());
            }
        } catch (InvokeRemoteServiceException e) {
            DevLog.error(this, "get menu root, remote invoke error", e);
            clientResponse.close();
        }
        return new Gson().toJson(new MenuListGson());
    }

    @GET
    @Path("/menuTree/{menuRootName}")
    @Produces(value = MediaType.APPLICATION_JSON)
    public String getMenuTree(@PathParam("menuRootName") String menuRootName) {

        if (EmptyChecker.isEmpty(menuRootName)) {
            throw new WebApplicationException(Response.status(Response.Status.BAD_REQUEST).entity("menuRootName cannot be null").build());
        }

        String path = String.format(beProperties.getBeMenuTreeUrl(), p2pUserId, menuRootName);

        UserContext uc = new UserContext(p2pUserId + "");
        UserContextUtils.setCurrentUserContext(uc);

        try {
            ClientResponse clientResponse = mgrJerseyService.getInstance(path).invokeJersey();
            if (ClientResponse.Status.OK.getStatusCode() == clientResponse.getStatus()) {
                String menuList = clientResponse.getEntity(String.class);
                return menuList;
            } else {
                DevLog.warn(this, "get menu tree return status code is " + clientResponse.getStatus());
                clientResponse.close();
            }
        } catch (InvokeRemoteServiceException e) {
            DevLog.error(this, "get menu tree, remote invoke error", e);
            return "{}";
        }
        return "{}";
    }
}
