package com.lufax.common.resources;

import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;

import com.sun.jersey.api.core.InjectParam;

@Path("users")
public class UsersResource extends AuthenticatedRequiredRootResource {

	@InjectParam
	private ServiceProvider serviceProvider;

	@Path("/{userid}")
	public UserResource getUser(@PathParam("userid") long userid) {
		if (userid != currentUser()) {
			throw new WebApplicationException(Response.Status.FORBIDDEN);
		}
		return new UserResource(userid, serviceProvider);
	}

}
