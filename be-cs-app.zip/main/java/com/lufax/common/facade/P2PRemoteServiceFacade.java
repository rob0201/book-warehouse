package com.lufax.common.facade;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.lufax.common.Constant;
import com.lufax.common.dto.p2p.PrepaymentMeasureResultDTO;
import com.lufax.common.utils.DevLog;
import com.lufax.jersey.client.JerseyService;

@Service
public class P2PRemoteServiceFacade extends AbstractRemoteFacade{
	@Autowired
	@Qualifier("p2pJerseyService")
	private JerseyService p2pJerseyService;

	@Override
	protected JerseyService getJerseyService() {
		return p2pJerseyService;
	}
	public PrepaymentMeasureResultDTO calculatePrerepayment(Long userId, Long customerId, Long loanId, String date) {
		DevLog.debug(this, "The user [" + userId + "] visit the customer [" + customerId + "] loanId [" + loanId + "] date [" + date + "] to calculate the prerepayment");
		String uri = String.format(Constant.P2P_GET_MEANURE_URI, customerId, loanId);
		Map<String, String> parameter = new HashMap<String, String>();
		parameter.put("date", date);
		return get(customerId, uri, parameter, PrepaymentMeasureResultDTO.class);
	}
}
