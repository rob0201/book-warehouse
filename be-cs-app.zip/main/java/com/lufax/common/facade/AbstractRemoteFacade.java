package com.lufax.common.facade;

import java.lang.reflect.Type;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import com.google.gson.Gson;
import com.lufax.common.exception.RemoteInvokeException;
import com.lufax.jersey.client.JerseyRequestParam;
import com.lufax.jersey.client.JerseyService;
import com.lufax.jersey.client.response.helper.GSONHelper;
import com.lufax.jersey.exception.InvokeRemoteServiceException;
import com.lufax.jersey.utils.Logger;
import com.sun.jersey.api.client.ClientResponse;

public abstract class AbstractRemoteFacade {
	protected abstract JerseyService getJerseyService();

	protected <T> T post(Long customerId, String uri, Map<String, String> parameter, final Class<T> clazz) {
        return invoke(customerId,uri, "post", parameter, clazz);
	}
	
	protected void post(Long customerId, String uri, Map<String, String> parameter) {
        invoke(customerId, uri, "post", parameter, null);
	}
	protected <T> T get(Long customerId, String uri,final Class<T> clazz) {
		return invoke(customerId,uri, "get", Collections.<String, String>emptyMap(), clazz);
	}
	protected <T> T get(Long customerId, String uri,Map<String, String> parameter, final Class<T> clazz) {
		return invoke(customerId,uri, "get", parameter, clazz);
	}
	
	protected <T> List<T> getAsList(Long customerId, String uri, Type type) {
		return invoke(customerId,uri, "get", Collections.<String, String>emptyMap(),  type);
	}
	protected <T> List<T> getAsList(Long customerId, String uri, Map<String, String> parameter, Type type) {
		return invoke(customerId, uri, "get", parameter,  type);
	}
	
	private <T> T invoke(Long customerId, String uri, String method, Map<String, String> parameters, Class<T> clazz) {
		Logger.info(this, "-->invoke remote app[" + getJerseyService().getHost().getHostURI() + "] uri [" + uri + "] method [" + method + "] ");
		JerseyRequestParam param = new JerseyRequestParam();
		param.setMethodName(method);
		param.setParameters(parameters);
		ClientResponse clientResponse = null;
		try {			
			clientResponse = getJerseyService().getInstance(uri).withUser(customerId.toString()).invokeJersey(param);
			Logger.info(this, "The invoke remote app[" + getJerseyService().getHost().getHostURI() + "] uri [" + uri + "] result is : [" + clientResponse + "]");
			if(clientResponse.getStatus() == ClientResponse.Status.OK.getStatusCode()) {
				if(clazz != null) {
					return GSONHelper.convert(clientResponse, clazz);
				} else {
					return null;
				}
			} else {
				Logger.warn(this, "The invoke remote app[" + getJerseyService().getHost().getHostURI() + "] uri [" + uri + "] result status [" + clientResponse.getStatus() + "]");
				throw new RemoteInvokeException("Failed to invoke remote app");
			}
		} catch (InvokeRemoteServiceException e) {
			Logger.error(this, "Failed to invoke the remote app ", e);
			throw new RemoteInvokeException("Failed to invoke remote app", e);
		} finally {
			if(clientResponse != null) {
				clientResponse.close();
			}
		}		
	}
	private <T> T invoke(Long customerId, String uri, String method, Map<String, String> parameters, Type type) {
		Logger.info(this, "-->invoke remote app[" + getJerseyService().getHost().getHostURI() + "] uri [" + uri + "] method [" + method + "] ");
		JerseyRequestParam param = new JerseyRequestParam();
		param.setMethodName(method);
		param.setParameters(parameters);
		ClientResponse clientResponse = null;
		try {			
			clientResponse = getJerseyService().getInstance(uri).withUser(customerId.toString()).invokeJersey(param);
			Logger.info(this, "The invoke remote app[" + getJerseyService().getHost().getHostURI() + "] uri [" + uri + "] result is : [" + clientResponse + "]");
			if(clientResponse.getStatus() == ClientResponse.Status.OK.getStatusCode()) {
				if(type != null) {
					return new Gson().fromJson(clientResponse.getEntity(String.class), type);
				} else {
					return null;
				}
			} else {
				Logger.warn(this, "The invoke remote app[" + getJerseyService().getHost().getHostURI() + "] uri [" + uri + "] result status [" + clientResponse.getStatus() + "]");
				throw new RemoteInvokeException("Failed to invoke remote app");
			}
		} catch (InvokeRemoteServiceException e) {
			Logger.error(this, "Failed to invoke the remote app ", e);
			throw new RemoteInvokeException("Failed to invoke remote app", e);
		} finally {
			if(clientResponse != null) {
				clientResponse.close();
			}
		}		
	}	
}
