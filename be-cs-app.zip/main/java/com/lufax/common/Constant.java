package com.lufax.common;

public final class Constant {
	// p2p app url list
	public static final String P2P_GET_MEANURE_URI = "/service/users/%s/loans/%s/prepayment/measure";//测试信保的提前还款
	
	// mask utils
	public static final char MASK_CHAR = '*';
	
	
	//common
	public static final int DEFAULT_PAGE_SIZE = 15;
}
