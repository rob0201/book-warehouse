package com.lufax.common.service;

import com.lufax.common.domain.RechargeRecordSequence;
import com.lufax.common.domain.repository.RechargeRecordSequenceRepository;
import com.lufax.common.utils.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;

@Service
public class RechargeRecordDailyResetSequence extends DailyResetSequence {

    @Autowired
    private RechargeRecordSequenceRepository rechargeRecordSequenceRepository;

    private static final int LENGTH_OF_SEQUENCE = 8;

    public RechargeRecordDailyResetSequence() {
    }

    public RechargeRecordDailyResetSequence(DateProvider dateProvider, RechargeRecordSequenceRepository rechargeRecordSequenceRepository) {
        super(dateProvider);
        this.rechargeRecordSequenceRepository = rechargeRecordSequenceRepository;
    }

    @Override
    public String generate() {
        Date today = dateProvider.today();
        RechargeRecordSequence rechargeRecordSequence = new RechargeRecordSequence(today);

        rechargeRecordSequenceRepository.persist(rechargeRecordSequence);

        Long maxIdBeforeToday = rechargeRecordSequenceRepository.findMaxIdBefore(rechargeRecordSequence.getCreatedAt());
        long sequence = rechargeRecordSequence.id() - maxIdBeforeToday;

        return String.format("%s%0" + LENGTH_OF_SEQUENCE + "d", DateUtils.formatDateAsString(today), sequence);
    }
}
