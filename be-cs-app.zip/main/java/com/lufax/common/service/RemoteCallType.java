package com.lufax.common.service;


public enum RemoteCallType {
    GUARANTEE_CONFIRM_CONFIRM("guarantee confirm the compensation"),
    RARE_WORDS_WITHDRAW("rare words withdraw");

    String desc;

    RemoteCallType(String desc) {
        this.desc = desc;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}
