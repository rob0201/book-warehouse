package com.lufax.common.service;

import com.lufax.common.domain.BranchBank;
import com.lufax.common.domain.repository.BranchBankRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BranchBankService {
    @Autowired
    private BranchBankRepository branchBankRepository;

    public BranchBank findBySubBankCode(String subBankCode) {
        return branchBankRepository.findBranchBankBySubBankCode(subBankCode);
    }
}
