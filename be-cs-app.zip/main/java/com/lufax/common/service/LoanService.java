package com.lufax.common.service;

import com.lufax.common.domain.Loan;
import com.lufax.common.domain.repository.LoanRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class LoanService {
    @Autowired
    private LoanRepository loanRepository;
    @Transactional
    public Loan findLoanByLoanCode(String loanCode){
        return loanRepository.findLoanByLoanCode(loanCode);
    }
}
