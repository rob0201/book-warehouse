package com.lufax.common.service;

import com.lufax.common.domain.StatusChangeHistory;

public interface StatusChangeListener {
    void onInvestmentRequestChanged(StatusChangeHistory statusChangeHistory);

    void onLoanRequestChanged(StatusChangeHistory statusChangeHistory);

}
