package com.lufax.common.service;

import com.lufax.common.domain.LoanRequestSequence;
import com.lufax.common.domain.repository.LoanRequestSequenceRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.Date;

@Service
public class LoanRequestDailyResetSequence extends DailyResetSequence {

    @Autowired
    private LoanRequestSequenceRepository loanRequestSequenceRepository;

    private static final String DATE_FORMAT = "yyMMdd";
    public static final int LENGTH_OF_SEQUENCE = 5;

    public LoanRequestDailyResetSequence() {
        super();
    }

    public LoanRequestDailyResetSequence(DateProvider dateProvider, LoanRequestSequenceRepository loanRequestSequenceRepository) {
        super(dateProvider);
        this.loanRequestSequenceRepository = loanRequestSequenceRepository;
    }

    @Override
    public String generate() {
        Date today = dateProvider.today();
        LoanRequestSequence loanRequestSequence = new LoanRequestSequence(today);

        loanRequestSequenceRepository.persist(loanRequestSequence);

        Long maxIdBeforeToday = loanRequestSequenceRepository.findMaxIdBefore(loanRequestSequence.getCreatedAt());
        long sequence = loanRequestSequence.id() - maxIdBeforeToday;

        return String.format("%s%0" + LENGTH_OF_SEQUENCE + "d", new SimpleDateFormat(DATE_FORMAT).format(today), sequence);
    }
}
