package com.lufax.common.service;

import com.lufax.common.domain.LoanSequence;
import com.lufax.common.domain.repository.LoanSequenceRepository;
import com.lufax.common.utils.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;

@Service
public class LoanDailyResetSequence extends DailyResetSequence {

    @Autowired
    private LoanSequenceRepository loanSequenceRepository;

    public static final int LENGTH_OF_SEQUENCE = 8;

    public LoanDailyResetSequence() {
    }

    public LoanDailyResetSequence(DateProvider dateProvider, LoanSequenceRepository loanSequenceRepository) {
        super(dateProvider);
        this.loanSequenceRepository = loanSequenceRepository;
    }

    @Override
    public String generate() {
        Date today = dateProvider.today();
        LoanSequence loanSequence = new LoanSequence(today);

        loanSequenceRepository.persist(loanSequence);

        Long maxIdBeforeToday = loanSequenceRepository.findMaxIdBefore(loanSequence.getCreatedAt());
        long sequence = loanSequence.id() - maxIdBeforeToday;

        return String.format("%s0000%d" + LENGTH_OF_SEQUENCE + "d", DateUtils.formatDateAsString(today), sequence);
    }
}
