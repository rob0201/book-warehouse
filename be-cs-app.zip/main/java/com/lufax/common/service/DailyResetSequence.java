package com.lufax.common.service;

import java.util.Date;

public abstract class DailyResetSequence {

    static interface DateProvider {
        Date today();
    }

    protected DateProvider dateProvider;

    public DailyResetSequence() {
        dateProvider = new DateProvider() {
            public Date today() {
                return new Date();
            }
        };
    }

    DailyResetSequence(DateProvider dateProvider) {
        this.dateProvider = dateProvider;
    }

    abstract public String generate();
}
