package com.lufax.common.pojo;

public interface Domain {
    public String getNameSpace();
}
